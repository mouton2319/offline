#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import os
import re
from pathlib import Path
from collections import OrderedDict

RE_L1 = re.compile(r"^1\s+(\d{5})\b")
RE_L2 = re.compile(r"^2\s+(\d{5})\b")


class LRUFileCache:
    """多数の出力ファイルを高速に追記するための簡易LRUファイルハンドルキャッシュ"""
    def __init__(self, max_open: int = 256):
        self.max_open = max_open
        self._files = OrderedDict()  # sat -> file handle

    def get(self, path: Path):
        key = str(path)
        if key in self._files:
            fh = self._files.pop(key)
            self._files[key] = fh
            return fh

        # open new
        path.parent.mkdir(parents=True, exist_ok=True)
        fh = path.open("a", encoding="utf-8", newline="\n")
        self._files[key] = fh

        # evict
        while len(self._files) > self.max_open:
            _, old = self._files.popitem(last=False)
            try:
                old.close()
            except Exception:
                pass
        return fh

    def close_all(self):
        for _, fh in self._files.items():
            try:
                fh.close()
            except Exception:
                pass
        self._files.clear()


def split_tle_by_object(input_filename: str, out_dir: str, *, max_open: int = 256, strict: bool = False, quiet: bool = False):
    in_path = Path(input_filename)
    if not in_path.exists():
        raise FileNotFoundError(f"input not found: {in_path.resolve()}")

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    cache = LRUFileCache(max_open=max_open)

    pending_l1 = None
    pending_sat = None

    # stats
    written = 0
    skipped_l2_no_l1 = 0
    skipped_mismatch = 0
    ignored = 0

    try:
        with in_path.open("r", encoding="utf-8", errors="replace") as f:
            for lineno, raw in enumerate(f, 1):
                line = raw.strip()
                if not line:
                    ignored += 1
                    continue

                # 行末 "\" が付いているデータがある場合の互換対策
                if line.endswith("\\"):
                    line = line[:-1].rstrip()

                m1 = RE_L1.match(line)
                if m1:
                    pending_l1 = line
                    pending_sat = m1.group(1)
                    continue

                m2 = RE_L2.match(line)
                if m2:
                    sat2 = m2.group(1)
                    if pending_l1 is None:
                        skipped_l2_no_l1 += 1
                        if not quiet:
                            print(f"[WARN] line2に対応するline1が無い: line={lineno} {line[:120]!r}")
                        if strict:
                            raise ValueError(f"line2 without line1 at line {lineno}")
                        continue

                    if sat2 != pending_sat:
                        skipped_mismatch += 1
                        if not quiet:
                            print(f"[WARN] sat不一致: line1={pending_sat} line2={sat2} (line={lineno})")
                        if strict:
                            raise ValueError(f"sat mismatch at line {lineno}")
                        # ここでは「壊れているペア」と見なして捨てる
                        pending_l1 = None
                        pending_sat = None
                        continue

                    # 正常ペア
                    out_file = out_path / f"{pending_sat}.txt"
                    fh = cache.get(out_file)
                    fh.write(pending_l1 + "\n")
                    fh.write(line + "\n")
                    written += 1

                    pending_l1 = None
                    pending_sat = None
                    continue

                # 0行目(衛星名)などは無視
                ignored += 1

    finally:
        cache.close_all()

    print(
        f"[DONE] written_pairs={written} "
        f"skipped_l2_no_l1={skipped_l2_no_l1} skipped_mismatch={skipped_mismatch} ignored_lines={ignored} "
        f"out_dir={out_path.resolve()}"
    )


def main():
    ap = argparse.ArgumentParser(description="巨大TLEファイルを衛星番号ごとに分割（頑健版）")
    ap.add_argument("--input", default="tle2018.txt", help="入力TLEファイル")
    ap.add_argument("--out-dir", default="./sepalated_tle_2018", help="出力先ディレクトリ")
    ap.add_argument("--max-open-files", type=int, default=256, help="同時に開く出力ファイル数(LRU)")
    ap.add_argument("--strict", action="store_true", help="壊れた入力を検出したら例外で停止")
    ap.add_argument("--quiet", action="store_true", help="WARNログを抑制")
    args = ap.parse_args()

    split_tle_by_object(
        args.input,
        args.out_dir,
        max_open=args.max_open_files,
        strict=args.strict,
        quiet=args.quiet,
    )


if __name__ == "__main__":
    main()