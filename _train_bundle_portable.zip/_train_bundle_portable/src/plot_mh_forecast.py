#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
plot_mh_forecast.py — MH(multi-horizon直接予測, target_mode="cv_residual_mh")モデルの
予測を matplotlib(cartopy不使用, Agg)で1枚絵にする確認用ツール。

2モード:
  (a) single : 固定プロトコル(input-len点を入力→未来steps点を予測)の1枚絵。
               入力履歴・実測の未来・MH予測・CV等速外挿を重ね、タイトルにMAEを表示。
  (b) rolling: 複数のアンカー時点(観測長)から出したsteps歩予測を色グラデーションで
               重ね、「観測が増えるにつれ予測が修正されていく」様子を1枚に示す。

=== 予測の復元ロジック ===
rolling_forecast.py の rolling_forecast_positions() をそのまま import して流用する。
これは eval_batch.py の batched_predict_mh() / _predict_mh_cum() と厳密一致する数式
(cv0=cv_n_last=0 対応済み: CV項ゼロで residual のみから累積変位を復元)。
positions=[i] を1点だけ渡すと「位置iを右端とする末尾窓」で予測するので、single モードで
input-len=L のとき positions=[L-1] を渡せば eval_batch の履歴 lon[:L] からの予測と一致する。

描画スタイルは visualize_trajectory_prediction.py の plot_map の簡易版(cartopy無し版)に準拠:
  - Agg バックエンド、ファイル保存のみ
  - equal aspect を緯度で lon をスケール補正(1度あたりkmが lat で異なるため)
  - 凡例つき、タイトルに AI MAE / CV MAE(km) を表示

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  # (a) single
  python .\src\plot_mh_forecast.py single --model <pt> --traj-csv <csv> `
    --input-len 80 --steps 20 --out-png <png>
  # (b) rolling
  python .\src\plot_mh_forecast.py rolling --model <pt> --traj-csv <csv> `
    --anchors 80,85,90,95 --steps 20 --out-png <png>
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

import matplotlib
matplotlib.use("Agg")               # GUI不要・ファイル保存のみ
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap


def _setup_jp_font():
    """凡例・タイトルの日本語が tofu(□)にならないよう、利用可能な日本語フォントを
    matplotlib のデフォルトに設定する(Windows想定: Meiryo / Yu Gothic / MS Gothic)。
    マイナス記号が全角化する不具合も回避する。"""
    import matplotlib.font_manager as fm
    installed = set(f.name for f in fm.fontManager.ttflist)
    for cand in ("Meiryo", "Yu Gothic", "MS Gothic", "MS PGothic"):
        if cand in installed:
            plt.rcParams["font.family"] = cand
            break
    plt.rcParams["axes.unicode_minus"] = False   # 数値のマイナスを半角に


_setup_jp_font()

# 同じ src フォルダの共通ロジックを import。
sys.path.insert(0, str(Path(__file__).resolve().parent))
from traj_common import load_model, lonlat_to_disp_km, KM_PER_DEG_LAT   # noqa: E402
from eval_batch import (   # noqa: E402
    read_traj, haversine_km_arr, _km_per_deg_lon_arr, classify_regime,
)
# 予測の復元は rolling_forecast のロジックをそのまま流用(eval_batch と厳密一致)。
from rolling_forecast import rolling_forecast_positions   # noqa: E402


# ---------------------------------------------------------------------------
# CV等速外挿(visualize_trajectory_prediction.rollout_cv と同一: 直近 n_last 点平均)
# ---------------------------------------------------------------------------
def rollout_cv(hist_lon, hist_lat, steps, n_last):
    """等速直線(CV)ベースライン: 履歴末尾 n_last 点の平均速度で steps 歩外挿する。"""
    from traj_common import km_per_deg_lon
    disp = lonlat_to_disp_km(hist_lon, hist_lat)
    if len(disp) < 2:
        return (np.full(steps, hist_lon[-1]), np.full(steps, hist_lat[-1]))
    n = max(1, min(int(n_last), len(disp) - 1))
    v = disp[-n:].mean(axis=0)                              # 平均移動量(km/step)
    cur_lon, cur_lat = float(hist_lon[-1]), float(hist_lat[-1])
    out_lon, out_lat = [], []
    for _ in range(int(steps)):
        cur_lon = cur_lon + v[0] / km_per_deg_lon(cur_lat)
        cur_lat = cur_lat + v[1] / KM_PER_DEG_LAT
        out_lon.append(cur_lon); out_lat.append(cur_lat)
    return np.asarray(out_lon), np.asarray(out_lat)


def _apply_geo_aspect(ax, all_lat):
    """equal aspect を緯度で補正する。lon 1度は lat 1度より短い(cosθ倍)ので、
    地図上の距離が正しく見えるよう aspect = 1/cos(平均緯度) を設定する
    (visualize の plot_map が cartopy でやっている等距離見えの簡易版)。"""
    mean_lat = float(np.mean(all_lat))
    ax.set_aspect(1.0 / max(np.cos(np.radians(mean_lat)), 1e-6))


def _set_extent(ax, all_lon, all_lat, pad=0.12):
    """全点を包む範囲に少し余白を足して軸範囲を設定する(plot_map と同流儀)。"""
    mlon = max(0.005, (all_lon.max() - all_lon.min()) * pad)
    mlat = max(0.005, (all_lat.max() - all_lat.min()) * pad)
    ax.set_xlim(all_lon.min() - mlon, all_lon.max() + mlon)
    ax.set_ylim(all_lat.min() - mlat, all_lat.max() + mlat)


def _load(model_path, device_str):
    import torch
    device = torch.device(device_str if device_str else
                          ("cuda" if torch.cuda.is_available() else "cpu"))
    model, cfg = load_model(Path(model_path), device)
    mode = getattr(cfg, "target_mode", "disp")
    if mode != "cv_residual_mh":
        raise SystemExit(f"[ERROR] このツールは target_mode='cv_residual_mh' 専用です。"
                         f"指定モデルは {mode}。")
    return model, cfg, device


# ===========================================================================
# (a) single: 固定プロトコルの1枚絵
# ===========================================================================
def cmd_single(args) -> int:
    model, cfg, device = _load(args.model, args.device)

    lon, lat = read_traj(Path(args.traj_csv))
    n = len(lon)
    input_len = min(int(args.input_len), n - 1)
    steps = min(int(args.steps), n - input_len)
    if input_len < 2 or steps < 1:
        raise SystemExit(f"[ERROR] 航跡が短すぎます(点数={n})。")

    hist_lon, hist_lat = lon[:input_len], lat[:input_len]
    truth_lon = lon[input_len:input_len + steps]
    truth_lat = lat[input_len:input_len + steps]

    # 予測: 位置 i=input_len-1(=履歴末尾)を起点に h=1..H を1回のforwardで得る。
    # eval_batch の履歴 lon[:input_len] からの予測と厳密一致する(positions=[input_len-1])。
    positions = np.asarray([input_len - 1], dtype=np.int64)
    pred_lon2d, pred_lat2d, H = rolling_forecast_positions(
        [model], [cfg], lon, lat, positions, device, int(args.gpu_batch))
    pred_lon = pred_lon2d[0, :steps]
    pred_lat = pred_lat2d[0, :steps]

    # CV等速外挿(直近 cv-n-last 点平均)
    cv_lon, cv_lat = rollout_cv(hist_lon, hist_lat, steps, int(args.cv_n_last))

    ai_err = haversine_km_arr(pred_lon, pred_lat, truth_lon, truth_lat)
    cv_err = haversine_km_arr(cv_lon, cv_lat, truth_lon, truth_lat)
    regime = classify_regime(truth_lon, truth_lat, hist_lon, hist_lat)

    # --- 描画 ---
    # 描画範囲は 履歴・実測・AI予測 を基準に決める(CVは急停止/反転で大きく暴走し、
    # 範囲がそれに支配されると肝心のAI追従が潰れて読めなくなるため範囲計算から除外)。
    # CVの線自体は描くが、範囲外に伸びた分は軸でクリップされる。
    focus_lon = np.concatenate([hist_lon, truth_lon, pred_lon])
    focus_lat = np.concatenate([hist_lat, truth_lat, pred_lat])
    fig, ax = plt.subplots(figsize=(9, 8))
    _set_extent(ax, focus_lon, focus_lat)
    _apply_geo_aspect(ax, focus_lat)
    ax.set_xlabel("lon"); ax.set_ylabel("lat")
    ax.grid(True, linewidth=0.3, color="gray", alpha=0.4)

    ax.plot(hist_lon, hist_lat, "-", color="#1f77b4", lw=1.5, label="入力履歴 (history)")
    ax.plot([hist_lon[-1]], [hist_lat[-1]], "o", color="#1f77b4", ms=10, mec="k",
            label="アンカー (予測起点)")
    ax.plot(truth_lon, truth_lat, "-o", color="#2ca02c", lw=2, ms=4,
            label="実測の未来 (truth)")
    ax.plot(pred_lon, pred_lat, "-x", color="#d62728", lw=2, ms=7,
            label="MH予測 (AI)")
    ax.plot(cv_lon, cv_lat, "--", color="#7f7f7f", lw=1.5,
            label=f"CV等速外挿 (直近{int(args.cv_n_last)}点平均)")

    stem = Path(args.traj_csv).stem
    title = (f"{stem}  [regime={regime}]  in={input_len} steps={steps}\n"
             f"AI MAE={ai_err.mean():.3f} km   CV MAE={cv_err.mean():.3f} km   "
             f"(AI final={ai_err[-1]:.3f}, CV final={cv_err[-1]:.3f})")
    ax.set_title(title, fontsize=11)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()

    out_png = Path(args.out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(out_png), dpi=int(args.dpi))
    plt.close(fig)

    print(f"[single] {stem}  regime={regime}  "
          f"AI MAE={ai_err.mean():.3f} km  CV MAE={cv_err.mean():.3f} km")
    print(f"[single] PNG -> {out_png}")
    return 0


# ===========================================================================
# (b) rolling: 逐次修正の様子を1枚に重ねる
# ===========================================================================
def cmd_rolling(args) -> int:
    model, cfg, device = _load(args.model, args.device)

    lon, lat = read_traj(Path(args.traj_csv))
    n = len(lon)

    # アンカー(観測長)の解析。--anchors は「観測点数」を意味する: 観測長 a なら
    # 起点位置 i=a-1(末尾 a 点を履歴として使う)。single と同じ規約。
    anchors = [int(s.strip()) for s in str(args.anchors).split(",") if s.strip()]
    anchors = sorted(set(a for a in anchors if 2 <= a <= n - 1))
    if not anchors:
        raise SystemExit(f"[ERROR] 有効なアンカーがありません(航跡長 n={n})。")
    steps_req = int(args.steps)

    positions = np.asarray([a - 1 for a in anchors], dtype=np.int64)   # 起点位置 i
    pred_lon2d, pred_lat2d, H = rolling_forecast_positions(
        [model], [cfg], lon, lat, positions, device, int(args.gpu_batch))

    # 各アンカーの予測(実測が尽きる分は steps を縮める)と MAE を計算。
    per_anchor = []   # dict(a, i, steps, pred_lon, pred_lat, mae)
    for k, a in enumerate(anchors):
        steps = min(steps_req, H, n - a)          # 未来 a..a+steps-1 が実測に存在する範囲
        if steps < 1:
            continue
        plon = pred_lon2d[k, :steps]
        plat = pred_lat2d[k, :steps]
        tlon = lon[a:a + steps]
        tlat = lat[a:a + steps]
        err = haversine_km_arr(plon, plat, tlon, tlat)
        per_anchor.append(dict(a=a, i=a - 1, steps=steps,
                               pred_lon=plon, pred_lat=plat, mae=float(err.mean())))
    if not per_anchor:
        raise SystemExit("[ERROR] どのアンカーも予測範囲を確保できませんでした。")

    # --- 描画 ---
    fig, ax = plt.subplots(figsize=(11, 8))

    # 航跡全体(薄灰)と実測(緑)。実測は最初のアンカー以降を強調。
    ax.plot(lon, lat, "-", color="#cccccc", lw=1.0, label="航跡全体")
    first_a = per_anchor[0]["a"]
    ax.plot(lon[first_a - 1:], lat[first_a - 1:], "-", color="#2ca02c", lw=1.6,
            label="実測 (truth)")

    # 各アンカー時点からの予測を、古い予測ほど薄い紫→新しい予測ほど濃い赤のグラデーションで。
    # 中間に青みを挟み(紫→青紫→橙→赤)、アンカー同士の色が識別しやすいようにする。
    cmap = LinearSegmentedColormap.from_list(
        "mh_roll", ["#7b3fa0", "#3b6fd4", "#e8820c", "#d62728"])
    m = len(per_anchor)
    all_lon = [lon]
    all_lat = [lat]
    for j, pa in enumerate(per_anchor):
        frac = j / max(m - 1, 1)                  # 0=最古, 1=最新
        color = cmap(frac)
        alpha = 0.45 + 0.55 * frac                # 古い予測ほど薄く、新しいほど濃く
        ax.plot(pa["pred_lon"], pa["pred_lat"], "-x", color=color, lw=2.0, ms=6,
                alpha=alpha,
                label=f"予測@t={pa['a']} (MAE={pa['mae']:.2f}km)")
        # アンカー点(予測起点=観測位置)をマーカー表示。
        ax.plot([lon[pa["i"]]], [lat[pa["i"]]], "o", color=color, ms=11, mec="k",
                alpha=min(1.0, alpha + 0.2))
        all_lon.append(pa["pred_lon"]); all_lat.append(pa["pred_lat"])

    cat_lon = np.concatenate(all_lon)
    cat_lat = np.concatenate(all_lat)
    # 予測とアンカー周辺に注目できるよう、範囲は予測点群+アンカー近傍に絞る。
    focus_lon = np.concatenate([pa["pred_lon"] for pa in per_anchor] +
                               [np.array([lon[pa["i"]] for pa in per_anchor])])
    focus_lat = np.concatenate([pa["pred_lat"] for pa in per_anchor] +
                               [np.array([lat[pa["i"]] for pa in per_anchor])])
    _set_extent(ax, focus_lon, focus_lat, pad=0.35)
    _apply_geo_aspect(ax, focus_lat)
    ax.set_xlabel("lon"); ax.set_ylabel("lat")
    ax.grid(True, linewidth=0.3, color="gray", alpha=0.4)

    stem = Path(args.traj_csv).stem
    regime0 = classify_regime(
        lon[first_a:first_a + min(steps_req, n - first_a)],
        lat[first_a:first_a + min(steps_req, n - first_a)],
        lon[:first_a], lat[:first_a]) if n - first_a >= 1 else "n/a"
    mae_list = ", ".join(f"t{pa['a']}={pa['mae']:.2f}" for pa in per_anchor)
    title = (f"{stem}  ローリング修正予測  anchors={anchors}\n"
             f"各アンカーからの{steps_req}歩予測 (AI MAE km: {mae_list})")
    ax.set_title(title, fontsize=10)
    # 凡例は軸の外(右)に置き、予測点群と重ならないようにする。
    ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), fontsize=8)
    fig.tight_layout()

    out_png = Path(args.out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(out_png), dpi=int(args.dpi))
    plt.close(fig)

    print(f"[rolling] {stem}  anchors={anchors}")
    for pa in per_anchor:
        print(f"          t={pa['a']:4d} (i={pa['i']}) steps={pa['steps']} "
              f"AI MAE={pa['mae']:.3f} km")
    print(f"[rolling] PNG -> {out_png}")
    return 0


# ===========================================================================
# CLI
# ===========================================================================
def main() -> int:
    p = argparse.ArgumentParser(
        description="MHモデルの予測を matplotlib で1枚絵にする(single / rolling)。")
    sub = p.add_subparsers(dest="cmd", required=True)

    ps = sub.add_parser("single", help="固定プロトコルの1枚絵(履歴/実測/MH予測/CV)")
    ps.add_argument("--model", required=True, help="traj_model.pt (cv_residual_mh)")
    ps.add_argument("--traj-csv", required=True)
    ps.add_argument("--input-len", type=int, default=80)
    ps.add_argument("--steps", type=int, default=20)
    ps.add_argument("--cv-n-last", type=int, default=6, help="CV外挿の直近点数")
    ps.add_argument("--out-png", required=True)
    ps.add_argument("--dpi", type=int, default=130)
    ps.add_argument("--gpu-batch", type=int, default=256)
    ps.add_argument("--device", default="")

    pr = sub.add_parser("rolling", help="複数アンカーからの予測を重ねて逐次修正を可視化")
    pr.add_argument("--model", required=True, help="traj_model.pt (cv_residual_mh)")
    pr.add_argument("--traj-csv", required=True)
    pr.add_argument("--anchors", required=True,
                    help="アンカー(観測点数)のカンマ区切り。例: 80,85,90,95")
    pr.add_argument("--steps", type=int, default=20)
    pr.add_argument("--out-png", required=True)
    pr.add_argument("--dpi", type=int, default=130)
    pr.add_argument("--gpu-batch", type=int, default=256)
    pr.add_argument("--device", default="")

    args = p.parse_args()
    if args.cmd == "single":
        return cmd_single(args)
    if args.cmd == "rolling":
        return cmd_rolling(args)
    p.error("不明なサブコマンド")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
