#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Predict-only script for GEO AZ/EL models.

Flow:
1) Predict AZ/EL by either:
   - harmonic period/amplitude model, or
   - LSTM with cyclic trig features.
2) If TLEs exist, blend TLE-trusted windows (TLE-priority -> model-priority).
3) Reconstruct Lat/Lon/Alt from final AZ/EL and output CSV.
4) If truth exists and fully/partially covers timestamps, output metrics/plots.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Dict, Tuple

import numpy as np

import ufo4_harmonic_azel_tf as hm
import ufo4_lla_physical_model as lpm
import ufo4_orbit_predict_tf as core
import ufo4_sidereal_coeff_model as scm


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Predict UFO4 AZ/EL with harmonic period-amplitude model.")

    p.add_argument("--model-dir", default="ufo4_azel_model_artifacts", help="Directory with meta/params.")
    p.add_argument("--meta-path", default="", help="Override meta json path.")
    p.add_argument("--param-path", default="", help="Override parameter npz path.")
    p.add_argument("--model-path", default="", help="Backward-compatible alias of --param-path.")

    p.add_argument(
        "--predict-template",
        default="2024_calc_az_el.csv",
        help="Template CSV with date/UNIX columns (used unless range mode).",
    )
    p.add_argument("--predict-start", default="", help='Range mode start JST "YYYY-MM-DD HH:MM:SS".')
    p.add_argument("--predict-end", default="", help='Range mode end JST "YYYY-MM-DD HH:MM:SS".')
    p.add_argument("--predict-step-minutes", type=int, default=1)

    p.add_argument("--truth-file", default="", help="Optional truth CSV for evaluation.")
    p.add_argument("--allow-partial-truth-eval", action="store_true")
    p.add_argument("--allow-stale-model-year-gap", action="store_true")

    p.add_argument("--output-dir", default="ufo4_prediction_tf")
    p.add_argument("--batch-size", type=int, default=4096, help="Batch size for TLE adaptation.")
    p.add_argument("--max-plot-points-per-month", type=int, default=12000)

    p.add_argument("--observer-lat", type=float, default=None)
    p.add_argument("--observer-lon", type=float, default=None)
    p.add_argument("--observer-alt-m", type=float, default=None)
    p.add_argument("--geo-radius-km", type=float, default=None)
    p.add_argument("--sat-name", default="")

    p.add_argument("--apply-month-bias", dest="apply_month_bias", action="store_true")
    p.add_argument("--no-apply-month-bias", dest="apply_month_bias", action="store_false")
    p.add_argument("--repeat-latest-year-base", dest="repeat_latest_year_base", action="store_true")
    p.add_argument("--no-repeat-latest-year-base", dest="repeat_latest_year_base", action="store_false")
    p.add_argument("--model-delta-cap-az", type=float, default=0.20)
    p.add_argument("--model-delta-cap-el", type=float, default=0.20)
    p.add_argument("--model-delta-decay-days", type=float, default=120.0)
    p.add_argument("--force-lstm-delta-blend", action="store_true")
    p.add_argument("--force-repeat-only", action="store_true")
    p.add_argument("--use-first-tle-global-bias", dest="use_first_tle_global_bias", action="store_true")
    p.add_argument("--no-first-tle-global-bias", dest="use_first_tle_global_bias", action="store_false")
    p.add_argument("--use-repeat-trend-correction", dest="use_repeat_trend_correction", action="store_true")
    p.add_argument("--no-repeat-trend-correction", dest="use_repeat_trend_correction", action="store_false")
    p.add_argument("--use-learned-error-correction", dest="use_learned_error_correction", action="store_true")
    p.add_argument("--no-learned-error-correction", dest="use_learned_error_correction", action="store_false")
    p.add_argument("--error-corr-az-cap", type=float, default=None)
    p.add_argument("--error-corr-el-cap", type=float, default=None)
    p.add_argument("--use-recent-slot-overlay", dest="use_recent_slot_overlay", action="store_true")
    p.add_argument("--no-recent-slot-overlay", dest="use_recent_slot_overlay", action="store_false")
    p.add_argument("--use-lla-physical-model", dest="use_lla_physical_model", action="store_true")
    p.add_argument("--no-lla-physical-model", dest="use_lla_physical_model", action="store_false")

    p.add_argument("--use-latest-tle-correction", dest="use_latest_tle_correction", action="store_true")
    p.add_argument("--no-latest-tle-correction", dest="use_latest_tle_correction", action="store_false")
    p.add_argument("--latest-tle-dir", default="")
    p.add_argument(
        "--target-tle-dir",
        default="",
        help="Authoritative target-period TLE directory. Covered rows are predicted directly from these TLEs.",
    )
    p.add_argument("--use-target-tle-direct", dest="use_target_tle_direct", action="store_true")
    p.add_argument("--no-use-target-tle-direct", dest="use_target_tle_direct", action="store_false")
    p.add_argument("--auto-detect-target-tle-dir", dest="auto_detect_target_tle_dir", action="store_true")
    p.add_argument("--no-auto-detect-target-tle-dir", dest="auto_detect_target_tle_dir", action="store_false")
    p.add_argument("--tle-correction-start", default="")
    p.add_argument("--tle-priority-days", type=float, default=None)
    p.add_argument("--tle-max-weight", type=float, default=None)
    p.add_argument("--tle-decay-hours", type=float, default=None)
    p.add_argument("--tle-max-hours", type=float, default=None)
    p.add_argument("--tle-agreement-az-deg", type=float, default=0.30)
    p.add_argument("--tle-agreement-el-deg", type=float, default=0.25)
    p.add_argument("--tle-agreement-decay", type=float, default=2.0)

    p.add_argument("--tle-adapt-epochs", type=int, default=None)
    p.add_argument("--tle-adapt-lr", type=float, default=None)
    p.add_argument("--tle-adapt-reg", type=float, default=None)
    p.add_argument("--tle-adapt-min-rows", type=int, default=None)
    p.add_argument("--tle-adapt-huber-delta", type=float, default=0.03)
    p.add_argument("--enable-tle-adaptation", dest="enable_tle_adaptation", action="store_true")
    p.add_argument("--disable-tle-adaptation", dest="enable_tle_adaptation", action="store_false")

    p.set_defaults(
        use_latest_tle_correction=None,
        apply_month_bias=None,
        repeat_latest_year_base=True,
        enable_tle_adaptation=None,
        use_first_tle_global_bias=False,
        use_repeat_trend_correction=None,
        use_learned_error_correction=None,
        use_recent_slot_overlay=None,
        use_lla_physical_model=None,
        use_target_tle_direct=False,
        auto_detect_target_tle_dir=False,
    )
    return p.parse_args()


def _get_meta_value(meta: dict, key: str, override):
    if override is not None and override != "":
        return override
    return meta.get(key)


def _resolve_value(meta: dict, key: str, override, default):
    v = _get_meta_value(meta, key, override)
    if v is None or v == "":
        return default
    return v


def _weighted_huber(tf, y_true, y_pred, sample_w, delta: float):
    ch_w = tf.constant([1.0, 1.0, 1.5], dtype=tf.float32)
    err = tf.abs(y_pred - y_true)
    d = tf.constant(float(delta), dtype=tf.float32)
    quad = tf.minimum(err, d)
    lin = err - quad
    huber = 0.5 * tf.square(quad) + d * lin
    row = tf.reduce_sum(huber * ch_w, axis=1)
    num = tf.reduce_sum(row * sample_w)
    den = tf.reduce_sum(sample_w) + tf.constant(1e-9, dtype=tf.float32)
    return num / den


def _adapt_params_with_tle(
    tf,
    params_in: Dict[str, np.ndarray | float],
    cfg: hm.HarmonicConfig,
    unix_obs: np.ndarray,
    azel_obs: np.ndarray,
    sample_w: np.ndarray,
    epochs: int,
    lr: float,
    reg: float,
    batch_size: int,
    huber_delta: float,
) -> Dict[str, np.ndarray | float]:
    if unix_obs.shape[0] == 0:
        return hm.copy_params(params_in)

    params = hm.copy_params(params_in)
    raw_v, w_v, b_v = hm.create_tf_variables(params)
    w_ref = tf.constant(np.asarray(params["W"], dtype=np.float32), dtype=tf.float32)
    b_ref = tf.constant(np.asarray(params["b"], dtype=np.float32), dtype=tf.float32)

    y_obs = hm.azel_to_targets(azel_obs)
    w_obs = np.asarray(sample_w, dtype=np.float32).reshape(-1)
    if np.mean(w_obs) > 0:
        w_obs = w_obs / np.mean(w_obs)
    else:
        w_obs = np.ones_like(w_obs, dtype=np.float32)

    ds = tf.data.Dataset.from_tensor_slices(
        (
            unix_obs.astype(np.float32),
            y_obs.astype(np.float32),
            w_obs.astype(np.float32),
        )
    ).batch(int(max(64, batch_size)), drop_remainder=False)

    opt = tf.keras.optimizers.Adam(learning_rate=float(lr), clipnorm=1.5)
    anchor_unix = float(params["anchor_unix"])
    p_ref = hm.period_from_raw_np(float(np.asarray(params["raw_period"]).reshape(-1)[0]), cfg)
    p_ref_tf = tf.constant(float(p_ref), dtype=tf.float32)

    for _ in range(int(max(1, epochs))):
        for unix_b, y_b, ww_b in ds:
            with tf.GradientTape() as tape:
                x_b, period = hm.build_features_tf(unix_b, anchor_unix=anchor_unix, raw_period_tf=raw_v, cfg=cfg)
                y_pred = tf.tanh(tf.matmul(x_b, w_v) + tf.reshape(b_v, (1, 3)))
                data_loss = _weighted_huber(tf, y_b, y_pred, ww_b, delta=float(huber_delta))
                reg_w = tf.constant(float(reg), dtype=tf.float32) * tf.reduce_mean(tf.square(w_v - w_ref))
                reg_b = tf.constant(0.25 * float(reg), dtype=tf.float32) * tf.reduce_mean(tf.square(b_v - b_ref))
                period_s = tf.reshape(period, ())
                reg_p = tf.constant(0.25 * float(reg), dtype=tf.float32) * tf.square((period_s - p_ref_tf) / p_ref_tf)
                loss = data_loss + reg_w + reg_b + reg_p
            grads = tape.gradient(loss, [raw_v, w_v, b_v])
            opt.apply_gradients(zip(grads, [raw_v, w_v, b_v]))

    return hm.pack_params_from_tf(raw_v, w_v, b_v, anchor_unix=anchor_unix)


def _infer_train_years_from_meta(meta: dict) -> list[int]:
    out: list[int] = []
    for p in meta.get("train_files", []) or []:
        try:
            out.append(int(core.parse_year_from_path(Path(str(p)))))
        except Exception:
            continue
    return sorted(set(out))


def _build_repeat_latest_year_prediction(meta: dict, pred_unix: np.ndarray) -> np.ndarray | None:
    train_files = [Path(str(x)) for x in (meta.get("train_files") or [])]
    best: tuple[int, Path] | None = None
    for p in train_files:
        if not p.exists():
            continue
        try:
            yy = int(core.parse_year_from_path(p))
        except Exception:
            continue
        if best is None or yy > best[0]:
            best = (yy, p)
    if best is None:
        return None
    _, latest_path = best
    unix_y, azel_y = core.load_orbit_numeric_azel(latest_path)
    w = np.ones((len(unix_y),), dtype=np.float32)
    tpl = core.build_azel_template(unix=unix_y, azel=azel_y, weight=w)
    pred_rep, _ = core.lookup_template_azel(pred_unix, tpl)
    return pred_rep


def _predict_repeat_from_template_path(template_path: Path, pred_unix: np.ndarray) -> np.ndarray:
    tpl = _load_template_pack(template_path)
    pred_rep, _ = core.lookup_template_azel(np.asarray(pred_unix, dtype=np.float64), tpl)
    return np.asarray(pred_rep, dtype=np.float64)


def _resolve_target_tle_dirs(
    pred_unix: np.ndarray,
    sat_name: str,
    explicit_dir: str,
    auto_detect: bool,
) -> list[Path]:
    out: list[Path] = []
    if str(explicit_dir).strip():
        p = Path(str(explicit_dir).strip())
        if p.exists() and p.is_dir():
            out.append(p)
        return out
    if not bool(auto_detect) or len(pred_unix) == 0:
        return out
    years_local: set[int] = set()
    for u in np.asarray(pred_unix, dtype=np.float64):
        d = dt.datetime.utcfromtimestamp(int(round(float(u)))) + dt.timedelta(hours=9)
        years_local.add(int(d.year))
    sat_tag = str(sat_name).strip() or "23467"
    for yy in sorted(years_local):
        cand = Path(f"{sat_tag}_{yy}")
        if cand.exists() and cand.is_dir():
            out.append(cand)
    return out


def _propagate_tle_azel_lla_at_unix(
    tle_path: Path,
    sat_name: str,
    observer_lat: float,
    observer_lon: float,
    unix: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    if core.EarthSatellite is None or core.load is None or core.wgs84 is None:
        raise RuntimeError("skyfield is not available for target-period TLE direct prediction.")

    line1, line2 = core.read_tle_pair_lines(tle_path)
    ts = core.load.timescale()
    sat = core.EarthSatellite(line1, line2, sat_name, ts)
    obs = core.wgs84.latlon(observer_lat, observer_lon)

    yy, mo, dd, hh, mm, ss = core._unix_to_ymdhms(unix)
    t = ts.utc(yy, mo, dd, hh, mm, ss)

    geo = sat.at(t)
    lat, lon = core.wgs84.latlon_of(geo)
    alt = core.wgs84.height_of(geo).km
    topo = (sat - obs).at(t)
    el, az, _ = topo.altaz()

    azel = np.column_stack(
        [
            core.wrap360(np.asarray(az.degrees, dtype=np.float64)),
            np.asarray(el.degrees, dtype=np.float64),
        ]
    ).astype(np.float64)
    lla = np.column_stack(
        [
            np.asarray(lat.degrees, dtype=np.float64),
            np.asarray(lon.degrees, dtype=np.float64),
            np.asarray(alt, dtype=np.float64),
        ]
    ).astype(np.float64)
    return azel, lla


def _apply_target_tle_direct_prediction(
    pred_unix: np.ndarray,
    pred_azel: np.ndarray,
    sat_name: str,
    observer_lat: float,
    observer_lon: float,
    tle_dirs: list[Path],
) -> Tuple[np.ndarray, np.ndarray | None, np.ndarray, dict]:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    out_lla = np.full((len(pred_unix), 3), np.nan, dtype=np.float64)
    covered = np.zeros((len(pred_unix),), dtype=bool)
    tle_files: list[tuple[int, Path]] = []
    used_dirs: list[str] = []
    for tle_dir in tle_dirs:
        if not tle_dir.exists() or (not tle_dir.is_dir()):
            continue
        used_dirs.append(str(tle_dir))
        tle_files.extend(core.collect_tle_files(tle_dir))
    if not tle_files:
        return out, None, covered, {
            "enabled": True,
            "applied": False,
            "dirs": used_dirs,
            "tle_count": 0,
            "rows_covered": 0,
        }

    tle_files.sort(key=lambda x: (int(x[0]), str(x[1])))
    for i, (epoch_unix, tle_path) in enumerate(tle_files):
        if i + 1 < len(tle_files):
            seg_mask = (pred_unix >= float(epoch_unix)) & (pred_unix < float(tle_files[i + 1][0]))
        else:
            seg_mask = pred_unix >= float(epoch_unix)
        if not np.any(seg_mask):
            continue
        idx = np.where(seg_mask)[0]
        azel_seg, lla_seg = _propagate_tle_azel_lla_at_unix(
            tle_path=tle_path,
            sat_name=sat_name,
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            unix=np.asarray(pred_unix[idx], dtype=np.float64),
        )
        out[idx] = azel_seg
        out_lla[idx] = lla_seg
        covered[idx] = True

    meta = {
        "enabled": True,
        "applied": bool(np.any(covered)),
        "dirs": used_dirs,
        "tle_count": int(len(tle_files)),
        "rows_covered": int(np.sum(covered)),
    }
    if not np.any(covered):
        return out, None, covered, meta
    return out, out_lla, covered, meta


def _blend_model_with_repeat(
    pred_unix: np.ndarray,
    pred_repeat: np.ndarray,
    pred_model: np.ndarray,
    anchor_unix: float,
    cap_az_deg: float,
    cap_el_deg: float,
    decay_days: float,
) -> np.ndarray:
    pr = np.asarray(pred_repeat, dtype=np.float64)
    pm = np.asarray(pred_model, dtype=np.float64)
    if pr.shape != pm.shape:
        raise ValueError("repeat/model shape mismatch")

    da = hm.angle_diff_deg(pm[:, 0], pr[:, 0])
    de = pm[:, 1] - pr[:, 1]
    da = np.clip(da, -abs(float(cap_az_deg)), abs(float(cap_az_deg)))
    de = np.clip(de, -abs(float(cap_el_deg)), abs(float(cap_el_deg)))

    if float(decay_days) > 0.0:
        dt_days = np.maximum(0.0, (np.asarray(pred_unix, dtype=np.float64) - float(anchor_unix)) / 86400.0)
        w = np.exp(-dt_days / float(decay_days))
    else:
        w = np.ones((len(pred_unix),), dtype=np.float64)
    az = core.wrap360(pr[:, 0] + w * da)
    el = np.clip(pr[:, 1] + w * de, -90.0, 90.0)
    return np.column_stack([az, el]).astype(np.float64)


def _circular_mean_deg(values_deg: np.ndarray) -> float:
    v = np.asarray(values_deg, dtype=np.float64).reshape(-1)
    if v.size == 0:
        return 0.0
    rad = np.deg2rad(v)
    s = float(np.mean(np.sin(rad)))
    c = float(np.mean(np.cos(rad)))
    return float((np.degrees(np.arctan2(s, c)) + 360.0) % 360.0)


def _apply_first_tle_global_bias(
    pred_unix: np.ndarray,
    pred_azel: np.ndarray,
    tle_dir: Path,
    sat_name: str,
    observer_lat: float,
    observer_lon: float,
    priority_days: float,
    min_rows: int = 120,
) -> tuple[np.ndarray, dict]:
    try:
        tle_list = core.collect_tle_files(tle_dir)
    except Exception:
        return pred_azel, {"applied": False, "reason": "no_tle"}
    first_epoch, first_path = tle_list[0]
    if len(pred_unix) == 0:
        return pred_azel, {"applied": False, "reason": "empty_prediction"}

    start = max(int(first_epoch), int(np.floor(float(np.min(pred_unix)))))
    end = min(int(np.floor(float(np.max(pred_unix)))), int(first_epoch + max(1.0, float(priority_days)) * 86400.0))
    if end < start:
        return pred_azel, {"applied": False, "reason": "no_overlap"}
    m = (pred_unix >= float(start)) & (pred_unix <= float(end))
    if int(np.sum(m)) < int(min_rows):
        return pred_azel, {"applied": False, "reason": "too_few_rows", "rows": int(np.sum(m))}

    u = pred_unix[m]
    tle_azel = core.propagate_tle_azel_at_unix(
        tle_path=first_path,
        sat_name=sat_name,
        observer_lat=observer_lat,
        observer_lon=observer_lon,
        unix=u,
    )
    da = hm.angle_diff_deg(pred_azel[m, 0], tle_azel[:, 0])  # model - tle
    de = pred_azel[m, 1] - tle_azel[:, 1]
    az_bias = _circular_mean_deg(da)
    if az_bias > 180.0:
        az_bias -= 360.0
    el_bias = float(np.mean(de))

    out = pred_azel.copy()
    out[:, 0] = core.wrap360(out[:, 0] - az_bias)
    out[:, 1] = np.clip(out[:, 1] - el_bias, -90.0, 90.0)
    info = {
        "applied": True,
        "rows": int(np.sum(m)),
        "az_bias_deg": float(az_bias),
        "el_bias_deg": float(el_bias),
        "tle_path": str(first_path),
        "window_start_unix": int(start),
        "window_end_unix": int(end),
    }
    return out, info


def _load_error_correction_pack(model_dir: Path, meta: dict):
    ec = meta.get("error_correction", {}) or {}
    if not bool(ec.get("trained", False)):
        return None
    rel = str(ec.get("path", "ufo4_error_correction.npz"))
    p = model_dir / rel
    if not p.exists():
        return None
    z = np.load(p)
    cfg = hm.ecfg_from_dict(ec.get("config", {}))
    out = {
        "path": str(p),
        "cfg": cfg,
        "slot_az_bias_deg": np.asarray(z["slot_az_bias_deg"], dtype=np.float64),
        "slot_el_bias_deg": np.asarray(z["slot_el_bias_deg"], dtype=np.float64),
        "slot_weight": np.asarray(z["slot_weight"], dtype=np.float64),
        "beta_az": np.asarray(z["beta_az"], dtype=np.float64),
        "beta_el": np.asarray(z["beta_el"], dtype=np.float64),
        "az_cap": float(ec.get("az_cap", 0.40)),
        "el_cap": float(ec.get("el_cap", 0.40)),
    }
    return out


def _apply_learned_error_correction(
    pred_unix: np.ndarray,
    pred_azel: np.ndarray,
    anchor_unix: float,
    corr_pack: dict,
    az_cap_override: float | None,
    el_cap_override: float | None,
) -> np.ndarray:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    sidx = core.compute_slot_index(pred_unix)

    saz = np.asarray(corr_pack["slot_az_bias_deg"], dtype=np.float64)
    sel = np.asarray(corr_pack["slot_el_bias_deg"], dtype=np.float64)
    out[:, 0] = core.wrap360(out[:, 0] + saz[sidx])
    out[:, 1] = out[:, 1] + sel[sidx]

    x = hm.build_error_features_np(
        unix=np.asarray(pred_unix, dtype=np.float64),
        anchor_unix=float(anchor_unix),
        cfg=corr_pack["cfg"],
        base_azel=out,
    )
    da = x @ np.asarray(corr_pack["beta_az"], dtype=np.float64).reshape(-1)
    de = x @ np.asarray(corr_pack["beta_el"], dtype=np.float64).reshape(-1)
    az_cap = float(az_cap_override) if az_cap_override is not None else float(corr_pack.get("az_cap", 0.40))
    el_cap = float(el_cap_override) if el_cap_override is not None else float(corr_pack.get("el_cap", 0.40))
    da = np.clip(da, -abs(az_cap), abs(az_cap))
    de = np.clip(de, -abs(el_cap), abs(el_cap))

    out[:, 0] = core.wrap360(out[:, 0] + da)
    out[:, 1] = np.clip(out[:, 1] + de, -90.0, 90.0)
    return out


def _minute_grid_unix(start_unix: int, end_unix: int) -> np.ndarray:
    if int(end_unix) < int(start_unix):
        return np.zeros((0,), dtype=np.float64)
    arr = np.arange(int(start_unix), int(end_unix) + 1, 60, dtype=np.int64)
    return arr.astype(np.float64)


def _parse_correction_start_unix(correction_start_str: str, default_unix: int) -> int:
    s = str(correction_start_str or "").strip()
    if not s:
        return int(default_unix)
    d = dt.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
    return int(core.jst_naive_to_unix_seconds(d))


def _predict_with_month_bias(
    unix: np.ndarray,
    params: Dict[str, np.ndarray | float],
    cfg: hm.HarmonicConfig,
    month_bias_map: Dict[str, Dict[str, float]],
    apply_month_bias: bool,
) -> np.ndarray:
    azel = hm.predict_azel_np(unix, params=params, cfg=cfg)
    if apply_month_bias and month_bias_map:
        azel = core.apply_monthly_bias_azel(unix, azel, month_bias_map)
    return azel


def _load_template_pack(path: Path) -> core.TemplatePack:
    z = np.load(path)
    if "template_mode" in z:
        mode_arr = np.asarray(z["template_mode"]).reshape(-1)
        mode = str(mode_arr[0]) if mode_arr.size else "sidereal_phase"
    else:
        mode = "solar_minute"
    tpl = core.TemplatePack(
        slot_az_deg=np.asarray(z["slot_az_deg"], dtype=np.float64),
        slot_el_deg=np.asarray(z["slot_el_deg"], dtype=np.float64),
        slot_weight=np.asarray(z["slot_weight"], dtype=np.float64),
        minute_az_deg=np.asarray(z["minute_az_deg"], dtype=np.float64),
        minute_el_deg=np.asarray(z["minute_el_deg"], dtype=np.float64),
        minute_weight=np.asarray(z["minute_weight"], dtype=np.float64),
        mode=mode,
    )
    return _fill_template_missing_slots_local(tpl)


def _fill_template_missing_slots_local(tpl: core.TemplatePack) -> core.TemplatePack:
    slot_w = np.asarray(tpl.slot_weight, dtype=np.float64).reshape(-1)
    valid = slot_w > 0.0
    if slot_w.size == 0 or np.all(valid):
        return tpl
    valid_idx = np.flatnonzero(valid)
    if valid_idx.size == 0:
        return tpl
    all_idx = np.arange(slot_w.shape[0], dtype=np.int32)
    right_pos = np.searchsorted(valid_idx, all_idx, side="left")
    right_pos = np.clip(right_pos, 0, valid_idx.size - 1)
    left_pos = np.clip(right_pos - 1, 0, valid_idx.size - 1)
    left_idx = valid_idx[left_pos]
    right_idx = valid_idx[right_pos]
    choose_right = np.abs(right_idx - all_idx) < np.abs(all_idx - left_idx)
    nearest_idx = np.where(choose_right, right_idx, left_idx).astype(np.int32)

    slot_az = np.asarray(tpl.slot_az_deg, dtype=np.float64).copy()
    slot_el = np.asarray(tpl.slot_el_deg, dtype=np.float64).copy()
    slot_w_filled = slot_w.copy()
    miss = ~valid
    slot_az[miss] = slot_az[nearest_idx[miss]]
    slot_el[miss] = slot_el[nearest_idx[miss]]
    slot_w_filled[miss] = np.maximum(slot_w[nearest_idx[miss]], 1.0e-6)
    return core.TemplatePack(
        slot_az_deg=slot_az,
        slot_el_deg=slot_el,
        slot_weight=slot_w_filled,
        minute_az_deg=np.asarray(tpl.minute_az_deg, dtype=np.float64).copy(),
        minute_el_deg=np.asarray(tpl.minute_el_deg, dtype=np.float64).copy(),
        minute_weight=np.asarray(tpl.minute_weight, dtype=np.float64).copy(),
    )


def _compute_year_from_unix_local(unix: np.ndarray) -> np.ndarray:
    sec_local = np.asarray(np.round(unix), dtype=np.int64) + int(core.JST_OFFSET_SEC)
    dt_y = sec_local.astype("datetime64[s]").astype("datetime64[Y]")
    return (dt_y.astype(np.int64) + 1970).astype(np.int32)


def _compute_common_day_index(unix: np.ndarray) -> np.ndarray:
    return (core.compute_slot_index(np.asarray(unix, dtype=np.float64)) // int(core.MINUTES_PER_DAY)).astype(np.int32)


def _compute_common_week_index(unix: np.ndarray) -> np.ndarray:
    return (_compute_common_day_index(unix) // 7).astype(np.int32)


def _apply_segment_blend_gain(
    key_idx: np.ndarray,
    pred_repeat: np.ndarray | None,
    pred_corr: np.ndarray,
    gain_map: dict | None,
) -> np.ndarray:
    if pred_repeat is None or not gain_map:
        return np.asarray(pred_corr, dtype=np.float64).copy()
    key = np.asarray(key_idx, dtype=np.int32).reshape(-1)
    rep = np.asarray(pred_repeat, dtype=np.float64)
    cor = np.asarray(pred_corr, dtype=np.float64)
    if key.shape[0] != rep.shape[0] or rep.shape != cor.shape:
        raise ValueError("segment blend input length mismatch")
    out = cor.copy()
    for kk in sorted(set(int(v) for v in np.unique(key))):
        mask = key == kk
        if not np.any(mask):
            continue
        gain = float(gain_map.get(f"{kk:02d}", 0.0))
        gain = float(np.clip(gain, 0.0, 1.0))
        if gain >= 0.999:
            continue
        if gain <= 0.0:
            out[mask] = rep[mask]
            continue
        out[mask, 0] = core.circular_blend_deg(
            rep[mask, 0],
            cor[mask, 0],
            np.full((int(np.sum(mask)),), gain, dtype=np.float64),
        )
        out[mask, 1] = (1.0 - gain) * rep[mask, 1] + gain * cor[mask, 1]
    out[:, 1] = np.clip(out[:, 1], -90.0, 90.0)
    return out


def _shift_unix_within_day(unix: np.ndarray, shift_minutes: int) -> np.ndarray:
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    if u.size == 0 or int(shift_minutes) == 0:
        return u.copy()
    return (u + float(int(shift_minutes) * 60)).astype(np.float64)


def _lookup_template_with_row_shifts(pred_unix: np.ndarray, tpl: core.TemplatePack, shift_by_row: np.ndarray) -> np.ndarray:
    u = np.asarray(pred_unix, dtype=np.float64).reshape(-1)
    shifts = np.asarray(shift_by_row, dtype=np.int32).reshape(-1)
    if u.shape[0] != shifts.shape[0]:
        raise ValueError("prediction unix/shift length mismatch")
    shifted = u.copy()
    for sh in np.unique(shifts):
        mask = shifts == int(sh)
        if not np.any(mask):
            continue
        shifted[mask] = _shift_unix_within_day(u[mask], int(sh))
    pred, _ = core.lookup_template_azel(shifted, tpl)
    return np.asarray(pred, dtype=np.float64)


def _load_repeat_trend_correction_pack(model_dir: Path, meta: dict):
    rtc = meta.get("repeat_trend_correction", {}) or {}
    if not bool(rtc.get("trained", False)):
        return None
    rel = str(rtc.get("path", "")).strip()
    if not rel:
        return None
    p = model_dir / rel
    if not p.exists():
        return None
    z = np.load(p)
    return {
        "path": str(p),
        "year_center": float(np.asarray(z["year_center"]).reshape(-1)[0]),
        "max_shift_minutes": int(np.asarray(z["max_shift_minutes"]).reshape(-1)[0]),
        "az_cap": float(np.asarray(z["az_cap"]).reshape(-1)[0]),
        "el_cap": float(np.asarray(z["el_cap"]).reshape(-1)[0]),
        "day_shift_intercept": np.asarray(z["day_shift_intercept"], dtype=np.float64) if "day_shift_intercept" in z else None,
        "day_shift_slope": np.asarray(z["day_shift_slope"], dtype=np.float64) if "day_shift_slope" in z else None,
        "day_gain": np.asarray(z["day_gain"], dtype=np.float64) if "day_gain" in z else None,
        "month_shift_intercept": np.asarray(z["month_shift_intercept"], dtype=np.float64) if "month_shift_intercept" in z else None,
        "month_shift_slope": np.asarray(z["month_shift_slope"], dtype=np.float64) if "month_shift_slope" in z else None,
        "slot_az_intercept": np.asarray(z["slot_az_intercept"], dtype=np.float64),
        "slot_az_slope": np.asarray(z["slot_az_slope"], dtype=np.float64),
        "slot_el_intercept": np.asarray(z["slot_el_intercept"], dtype=np.float64),
        "slot_el_slope": np.asarray(z["slot_el_slope"], dtype=np.float64),
        "week_gain_map": dict(rtc.get("week_gain_map", {}) or {}),
        "month_gain_map": dict(rtc.get("month_gain_map", {}) or {}),
    }


def _apply_repeat_trend_correction(
    pred_unix: np.ndarray,
    tpl: core.TemplatePack,
    pack: dict | None,
) -> Tuple[np.ndarray, np.ndarray]:
    if not pack:
        pred, _ = core.lookup_template_azel(np.asarray(pred_unix, dtype=np.float64), tpl)
        return np.asarray(pred, dtype=np.float64), np.asarray(pred, dtype=np.float64)
    mon = core.compute_month_from_unix_local(pred_unix)
    day_idx = _compute_common_day_index(pred_unix)
    yy = _compute_year_from_unix_local(pred_unix).astype(np.float64)
    year_center = float(pack["year_center"])
    shift_row = np.zeros((len(pred_unix),), dtype=np.int32)
    if (pack.get("day_shift_intercept") is not None) and (pack.get("day_shift_slope") is not None):
        raw = np.asarray(pack["day_shift_intercept"], dtype=np.float64)[day_idx]
        raw = raw + np.asarray(pack["day_shift_slope"], dtype=np.float64)[day_idx] * (yy - year_center)
        shift_row = np.clip(
            np.rint(raw),
            -abs(int(pack["max_shift_minutes"])),
            abs(int(pack["max_shift_minutes"])),
        ).astype(np.int32)
    else:
        for mm in range(1, 13):
            mask = mon == mm
            if not np.any(mask):
                continue
            raw = np.asarray(pack["month_shift_intercept"], dtype=np.float64)[mm - 1]
            raw = raw + np.asarray(pack["month_shift_slope"], dtype=np.float64)[mm - 1] * (yy[mask] - year_center)
            shift_row[mask] = np.clip(
                np.rint(raw),
                -abs(int(pack["max_shift_minutes"])),
                abs(int(pack["max_shift_minutes"])),
            ).astype(np.int32)
    pred_shift = _lookup_template_with_row_shifts(pred_unix, tpl, shift_row)
    slot_idx = core.compute_slot_index(pred_unix)
    da = np.asarray(pack["slot_az_intercept"], dtype=np.float64)[slot_idx]
    da = da + np.asarray(pack["slot_az_slope"], dtype=np.float64)[slot_idx] * (yy - year_center)
    de = np.asarray(pack["slot_el_intercept"], dtype=np.float64)[slot_idx]
    de = de + np.asarray(pack["slot_el_slope"], dtype=np.float64)[slot_idx] * (yy - year_center)
    da = np.clip(da, -abs(float(pack["az_cap"])), abs(float(pack["az_cap"])))
    de = np.clip(de, -abs(float(pack["el_cap"])), abs(float(pack["el_cap"])))
    pred_corr = pred_shift.copy()
    pred_corr[:, 0] = core.wrap360(pred_corr[:, 0] + da)
    pred_corr[:, 1] = np.clip(pred_corr[:, 1] + de, -90.0, 90.0)
    day_gain = pack.get("day_gain", None)
    if day_gain is not None:
        gain_map = {f"{ii:02d}": float(day_gain[ii]) for ii in range(len(day_gain))}
        pred_corr = _apply_segment_blend_gain(
            key_idx=day_idx,
            pred_repeat=pred_shift,
            pred_corr=pred_corr,
            gain_map=gain_map,
        )
    else:
        week_gain_map = pack.get("week_gain_map", {}) or {}
        month_gain_map = pack.get("month_gain_map", {}) or {}
        gain_map = week_gain_map if week_gain_map else month_gain_map
        if gain_map:
            key_idx = _compute_common_week_index(pred_unix) if week_gain_map else mon
            pred_corr = _apply_segment_blend_gain(
                key_idx=key_idx,
                pred_repeat=pred_shift,
                pred_corr=pred_corr,
                gain_map=gain_map,
            )
    return pred_corr, pred_shift


def _discover_year_csvs(search_dir: Path) -> Dict[int, Path]:
    out: Dict[int, Path] = {}
    for p in sorted(search_dir.glob("*_calc_az_el.csv")):
        try:
            yy = int(core.parse_year_from_path(p))
        except Exception:
            continue
        out[int(yy)] = p
    return out


def _load_year_start_correction_pack(model_dir: Path, meta: dict):
    ysc = meta.get("year_start_correction", {}) or {}
    rel = str(ysc.get("path", "")).strip()
    if not rel:
        return None
    p = model_dir / rel
    if not p.exists():
        return None
    z = np.load(p)
    return {
        "path": str(p),
        "days": int(np.asarray(z["days"]).reshape(-1)[0]),
        "slot_az_bias_deg": np.asarray(z["slot_az_bias_deg"], dtype=np.float64),
        "slot_el_bias_deg": np.asarray(z["slot_el_bias_deg"], dtype=np.float64),
        "weight": np.asarray(z["weight"], dtype=np.float64),
    }


def _apply_year_start_correction(pred_unix: np.ndarray, pred_azel: np.ndarray, pack: dict | None) -> np.ndarray:
    if not pack:
        return np.asarray(pred_azel, dtype=np.float64).copy()
    horizon = int(max(0, pack.get("days", 0))) * core.MINUTES_PER_DAY
    if horizon <= 0:
        return np.asarray(pred_azel, dtype=np.float64).copy()
    slot_idx = core.compute_slot_index(pred_unix)
    use = slot_idx < int(horizon)
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if np.any(use):
        saz = np.asarray(pack["slot_az_bias_deg"], dtype=np.float64)
        sel = np.asarray(pack["slot_el_bias_deg"], dtype=np.float64)
        out[use, 0] = core.wrap360(out[use, 0] + saz[slot_idx[use]])
        out[use, 1] = np.clip(out[use, 1] + sel[slot_idx[use]], -90.0, 90.0)
    return out


def _apply_month_blend_gain(pred_unix: np.ndarray, pred_repeat: np.ndarray | None, pred_corr: np.ndarray, gain_map: dict | None) -> np.ndarray:
    mon = core.compute_month_from_unix_local(pred_unix)
    return _apply_segment_blend_gain(mon, pred_repeat, pred_corr, gain_map)


def _load_recent_slot_overlay_pack(model_dir: Path, meta: dict):
    rs = meta.get("recent_slot_overlay", {}) or {}
    if not bool(rs.get("trained", False)):
        return None
    rel = str(rs.get("path", "")).strip()
    if not rel:
        return None
    p = model_dir / rel
    if not p.exists():
        return None
    z = np.load(p)
    return {
        "path": str(p),
        "recent_pairs": int(np.asarray(z["recent_pairs"]).reshape(-1)[0]) if "recent_pairs" in z else int(rs.get("recent_pairs", 3)),
        "smooth_window": int(np.asarray(z["smooth_window"]).reshape(-1)[0]) if "smooth_window" in z else int(rs.get("smooth_window", 181)),
        "az_cap": float(np.asarray(z["az_cap"]).reshape(-1)[0]) if "az_cap" in z else float(rs.get("az_cap", 0.50)),
        "el_cap": float(np.asarray(z["el_cap"]).reshape(-1)[0]) if "el_cap" in z else float(rs.get("el_cap", 0.35)),
        "alpha": float(np.asarray(z["alpha"]).reshape(-1)[0]) if "alpha" in z else float(rs.get("alpha", 0.0)),
        "slot_az_bias_deg": np.asarray(z["slot_az_bias_deg"], dtype=np.float64),
        "slot_el_bias_deg": np.asarray(z["slot_el_bias_deg"], dtype=np.float64),
        "slot_weight": np.asarray(z["slot_weight"], dtype=np.float64) if "slot_weight" in z else np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64),
    }


def _load_lla_physical_model(model_dir: Path, meta: dict):
    info = meta.get("lla_physical_model", {}) or {}
    if not bool(info.get("trained", False)):
        return None, info
    rel = str(info.get("path", "")).strip()
    if not rel:
        return None, info
    p = model_dir / rel
    if not p.exists():
        return None, info
    model = lpm.load_model(p)
    model["path"] = str(p)
    return model, info


def _apply_recent_slot_overlay(pred_unix: np.ndarray, pred_azel: np.ndarray, pack: dict | None) -> np.ndarray:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if not pack:
        return out
    alpha = float(pack.get("alpha", 0.0))
    if alpha <= 0.0:
        return out
    slot_idx = core.compute_slot_index(pred_unix)
    saz = np.asarray(pack["slot_az_bias_deg"], dtype=np.float64)
    sel = np.asarray(pack["slot_el_bias_deg"], dtype=np.float64)
    out[:, 0] = core.wrap360(out[:, 0] + alpha * saz[slot_idx])
    out[:, 1] = np.clip(out[:, 1] + alpha * sel[slot_idx], -90.0, 90.0)
    return out


def _infer_step_seconds(pred_unix: np.ndarray) -> float:
    u = np.asarray(pred_unix, dtype=np.float64).reshape(-1)
    if u.shape[0] < 2:
        return 60.0
    du = np.diff(u)
    du = du[du > 0.0]
    if du.size == 0:
        return 60.0
    return float(np.median(du))


def _build_prefixed_unix(pred_unix: np.ndarray, prefix_len: int) -> np.ndarray:
    if int(prefix_len) <= 0:
        return np.asarray(pred_unix, dtype=np.float64)
    u = np.asarray(pred_unix, dtype=np.float64).reshape(-1)
    if u.size == 0:
        return u
    step = _infer_step_seconds(u)
    prefix = u[0] - step * np.arange(int(prefix_len), 0, -1, dtype=np.float64)
    return np.concatenate([prefix, u], axis=0)


def _guard_stale_model_year_gap(meta: dict, pred_unix: np.ndarray, allow_stale: bool) -> None:
    if pred_unix.size == 0:
        return
    latest_model_year = int(meta.get("template_reference_year", 0) or 0)
    if latest_model_year <= 0:
        years = _infer_train_years_from_meta(meta)
        if years:
            latest_model_year = max(years)
    if latest_model_year <= 0:
        return

    first_pred_jst = dt.datetime.utcfromtimestamp(int(round(float(pred_unix[0])))) + dt.timedelta(hours=9)
    pred_year = int(first_pred_jst.year)
    gap = pred_year - latest_model_year
    if latest_model_year >= pred_year and (not bool(allow_stale)):
        raise RuntimeError(
            "Model latest year is not older than the prediction year. "
            f"latest_model_year={latest_model_year}, prediction_year={pred_year}. "
            "For yearly backtests this is data leakage. Retrain with the latest available year held out, "
            "or use --allow-stale-model-year-gap to override."
        )
    if gap <= 1:
        return

    discovered = _discover_year_csvs(Path("."))
    missing_local = [yy for yy in sorted(discovered) if latest_model_year < yy < pred_year]
    if missing_local and (not bool(allow_stale)):
        raise RuntimeError(
            "Model is stale for this prediction range. "
            f"latest_model_year={latest_model_year}, prediction_year={pred_year}, "
            f"newer local yearly CSVs exist: {missing_local}. "
            "Retrain first, or use --allow-stale-model-year-gap to override."
        )
    if gap > 1:
        core.log(
            f"[WARN] Model latest year={latest_model_year}, prediction starts in {pred_year} "
            f"(gap={gap}). Accuracy will degrade."
        )


def _predict_with_lstm_template(
    tf,
    model,
    tpl: core.TemplatePack,
    pred_unix: np.ndarray,
    lcfg: hm.LSTMConfig,
    batch_size: int,
) -> Tuple[np.ndarray, np.ndarray]:
    u = np.asarray(pred_unix, dtype=np.float64).reshape(-1)
    if u.size == 0:
        empty = np.zeros((0, 2), dtype=np.float64)
        return empty, empty

    pred_repeat, _ = core.lookup_template_azel(u, tpl)
    ext_unix = _build_prefixed_unix(u, prefix_len=max(0, int(lcfg.seq_len) - 1))
    ext_base, ext_slot_w = core.lookup_template_azel(ext_unix, tpl)
    feat_ext = hm.build_lstm_step_features_np(
        unix=ext_unix,
        base_azel=ext_base,
        slot_weight=ext_slot_w,
        yearly_harmonics=int(lcfg.time_yearly_harmonics),
    )
    ds = tf.keras.utils.timeseries_dataset_from_array(
        data=np.asarray(feat_ext, dtype=np.float32),
        targets=None,
        sequence_length=int(lcfg.seq_len),
        sequence_stride=1,
        shuffle=False,
        batch_size=int(batch_size),
    )
    pred_raw = model.predict(ds, verbose=1)
    pred_raw = np.asarray(pred_raw, dtype=np.float32)
    pred_raw = pred_raw[: u.shape[0]]
    pred_trig = hm.normalize_trig4_np(pred_raw)
    pred_azel = hm.trig4_to_azel(pred_trig)
    return pred_azel, pred_repeat


def _apply_tle_adaptive_correction(
    tf,
    pred_unix: np.ndarray,
    base_params: Dict[str, np.ndarray | float],
    cfg: hm.HarmonicConfig,
    month_bias_map: Dict[str, Dict[str, float]],
    apply_month_bias: bool,
    tle_dir: Path,
    sat_name: str,
    observer_lat: float,
    observer_lon: float,
    correction_start_str: str,
    priority_days: float,
    max_weight: float,
    decay_hours: float,
    max_hours: float,
    adapt_epochs: int,
    adapt_lr: float,
    adapt_reg: float,
    adapt_min_rows: int,
    adapt_batch_size: int,
    adapt_huber_delta: float,
) -> Tuple[np.ndarray, np.ndarray, core.TLECorrectionMeta]:
    tle_list = core.collect_tle_files(tle_dir)
    latest_epoch, latest_path = tle_list[-1]

    correction_start_unix = _parse_correction_start_unix(correction_start_str, default_unix=tle_list[0][0])
    meta = core.TLECorrectionMeta(
        enabled=True,
        applied=False,
        tle_path=str(latest_path),
        tle_epoch_unix=int(latest_epoch),
        correction_start_unix=int(correction_start_unix),
        priority_days=float(priority_days),
        max_weight=float(max_weight),
        decay_hours=float(decay_hours),
        max_hours=float(max_hours),
        tle_count=int(len(tle_list)),
        segments_used=0,
        rows_corrected=0,
    )

    pred_model = _predict_with_month_bias(
        unix=pred_unix,
        params=base_params,
        cfg=cfg,
        month_bias_map=month_bias_map,
        apply_month_bias=apply_month_bias,
    )
    pred_final = pred_model.copy()
    w_all = np.zeros((pred_unix.shape[0],), dtype=np.float64)
    params_cur = hm.copy_params(base_params)

    for i, (tle_epoch_unix, tle_path) in enumerate(tle_list):
        seg_start = max(int(correction_start_unix), int(tle_epoch_unix))
        if i + 1 < len(tle_list):
            seg_end = int(tle_list[i + 1][0]) - 1
        else:
            seg_end = int(np.floor(float(np.max(pred_unix))))
        if seg_end < seg_start:
            continue

        # 1) Adapt period/amplitude parameters with this TLE on a trusted window.
        adapt_end = min(seg_end, int(tle_epoch_unix + max(0.0, float(priority_days)) * 86400.0))
        if adapt_end >= seg_start:
            obs_mask = (pred_unix >= float(seg_start)) & (pred_unix <= float(adapt_end))
            unix_obs = pred_unix[obs_mask]
            if unix_obs.shape[0] < int(adapt_min_rows):
                unix_obs = _minute_grid_unix(seg_start, adapt_end)

            if unix_obs.shape[0] >= int(adapt_min_rows):
                tle_obs = core.propagate_tle_azel_at_unix(
                    tle_path=tle_path,
                    sat_name=sat_name,
                    observer_lat=observer_lat,
                    observer_lon=observer_lon,
                    unix=unix_obs,
                )
                dt_h = np.maximum(0.0, (unix_obs - float(tle_epoch_unix)) / 3600.0)
                tau_h = max(24.0, float(priority_days) * 12.0)
                obs_w = np.exp(-dt_h / tau_h).astype(np.float32)
                params_cur = _adapt_params_with_tle(
                    tf=tf,
                    params_in=params_cur,
                    cfg=cfg,
                    unix_obs=unix_obs,
                    azel_obs=tle_obs,
                    sample_w=obs_w,
                    epochs=int(adapt_epochs),
                    lr=float(adapt_lr),
                    reg=float(adapt_reg),
                    batch_size=int(adapt_batch_size),
                    huber_delta=float(adapt_huber_delta),
                )

        # 2) Apply this TLE to prediction rows in its segment.
        seg_mask = (pred_unix >= float(seg_start)) & (pred_unix <= float(seg_end))
        if not np.any(seg_mask):
            continue

        idx_seg = np.where(seg_mask)[0]
        unix_seg = pred_unix[idx_seg]
        seg_model = _predict_with_month_bias(
            unix=unix_seg,
            params=params_cur,
            cfg=cfg,
            month_bias_map=month_bias_map,
            apply_month_bias=apply_month_bias,
        )
        pred_model[idx_seg] = seg_model

        w_seg = core.compute_tle_blend_weights(
            unix=unix_seg,
            tle_epoch_unix=tle_epoch_unix,
            correction_start_unix=correction_start_unix,
            priority_days=priority_days,
            max_weight=max_weight,
            decay_hours=decay_hours,
            max_hours=max_hours,
        )
        use = w_seg > 1e-6
        seg_final = seg_model.copy()
        if np.any(use):
            tle_seg = core.propagate_tle_azel_at_unix(
                tle_path=tle_path,
                sat_name=sat_name,
                observer_lat=observer_lat,
                observer_lon=observer_lon,
                unix=unix_seg[use],
            )
            seg_final[use, 0] = core.circular_blend_deg(seg_model[use, 0], tle_seg[:, 0], w_seg[use])
            seg_final[use, 1] = (1.0 - w_seg[use]) * seg_model[use, 1] + w_seg[use] * tle_seg[:, 1]
            w_all[idx_seg[use]] = w_seg[use]
        pred_final[idx_seg] = seg_final
        meta.segments_used += 1

    pred_final[:, 1] = np.clip(pred_final[:, 1], -90.0, 90.0)
    pred_model[:, 1] = np.clip(pred_model[:, 1], -90.0, 90.0)

    meta.rows_corrected = int(np.sum(w_all > 1e-6))
    meta.applied = bool(meta.segments_used > 0)
    return pred_final, pred_model, meta


def main() -> None:
    args = parse_args()
    core.require_tensorflow()
    hm.require_tensorflow()
    tf = core.tf

    model_dir = Path(args.model_dir)
    meta_path = Path(args.meta_path) if str(args.meta_path).strip() else (model_dir / "ufo4_azel_model_meta.json")
    if not meta_path.exists():
        raise FileNotFoundError(f"meta not found: {meta_path}")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    training_mode = str(meta.get("training_mode", "")).strip()
    is_sidereal_mode = training_mode.startswith("sidereal_")
    is_lstm_mode = training_mode.startswith("lstm_")
    train_years = _infer_train_years_from_meta(meta)
    month_blend_gain = meta.get("month_blend_gain", {}) or {}
    rtc_meta = meta.get("repeat_trend_correction", {}) or {}
    rtc_enabled_meta = bool(rtc_meta.get("enabled", False)) and bool(rtc_meta.get("trained", False))
    use_repeat_trend_correction = (
        bool(args.use_repeat_trend_correction)
        if args.use_repeat_trend_correction is not None
        else rtc_enabled_meta
    )

    month_bias_map = meta.get("month_bias_azel", {})
    apply_month_bias = bool(args.apply_month_bias) if args.apply_month_bias is not None else True
    ec_meta = meta.get("error_correction", {}) or {}
    ec_meta_enabled = bool(ec_meta.get("enabled", False)) and bool(ec_meta.get("trained", False))
    use_learned_error_correction = (
        bool(args.use_learned_error_correction)
        if args.use_learned_error_correction is not None
        else ec_meta_enabled
    )
    rs_meta = meta.get("recent_slot_overlay", {}) or {}
    rs_meta_enabled = bool(rs_meta.get("enabled", False)) and bool(rs_meta.get("trained", False))
    use_recent_slot_overlay = (
        bool(args.use_recent_slot_overlay)
        if args.use_recent_slot_overlay is not None
        else rs_meta_enabled
    )
    lla_meta = meta.get("lla_physical_model", {}) or {}
    lla_meta_enabled = bool(lla_meta.get("enabled", False)) and bool(lla_meta.get("trained", False))
    use_lla_physical_model = (
        bool(args.use_lla_physical_model)
        if args.use_lla_physical_model is not None
        else lla_meta_enabled
    )
    corr_pack = _load_error_correction_pack(model_dir=model_dir, meta=meta)
    year_start_pack = _load_year_start_correction_pack(model_dir=model_dir, meta=meta)
    repeat_trend_pack = _load_repeat_trend_correction_pack(model_dir=model_dir, meta=meta)
    recent_slot_overlay_pack = _load_recent_slot_overlay_pack(model_dir=model_dir, meta=meta)
    lla_physical_model, lla_physical_info = _load_lla_physical_model(model_dir=model_dir, meta=meta)

    observer_lat = float(_resolve_value(meta, "observer_lat", args.observer_lat, 36.3022))
    observer_lon = float(_resolve_value(meta, "observer_lon", args.observer_lon, 137.9031))
    observer_alt_m = float(_resolve_value(meta, "observer_alt_m", args.observer_alt_m, 0.0))
    geo_radius_km = float(_resolve_value(meta, "geo_radius_km", args.geo_radius_km, 42164.0))
    sat_name = str(_resolve_value(meta, "sat_name", args.sat_name or None, "23467"))

    meta_use_tle = bool(meta.get("use_latest_tle_correction", True))
    use_tle = bool(args.use_latest_tle_correction) if args.use_latest_tle_correction is not None else meta_use_tle
    latest_tle_dir = str(_resolve_value(meta, "latest_tle_dir", args.latest_tle_dir, "pred_tle"))
    tle_correction_start = str(_resolve_value(meta, "tle_correction_start", args.tle_correction_start, ""))
    tle_priority_days = float(_resolve_value(meta, "tle_priority_days", args.tle_priority_days, 7.0))
    tle_max_weight = float(_resolve_value(meta, "tle_max_weight", args.tle_max_weight, 1.0))
    tle_decay_hours = float(_resolve_value(meta, "tle_decay_hours", args.tle_decay_hours, 336.0))
    tle_max_hours = float(_resolve_value(meta, "tle_max_hours", args.tle_max_hours, 0.0))
    tle_adapt_epochs = int(_resolve_value(meta, "tle_adapt_epochs", args.tle_adapt_epochs, 40))
    tle_adapt_lr = float(_resolve_value(meta, "tle_adapt_lr", args.tle_adapt_lr, 1.0e-3))
    tle_adapt_reg = float(_resolve_value(meta, "tle_adapt_reg", args.tle_adapt_reg, 5.0e-4))
    tle_adapt_min_rows = int(_resolve_value(meta, "tle_adapt_min_rows", args.tle_adapt_min_rows, 120))
    enable_tle_adaptation = bool(args.enable_tle_adaptation) if args.enable_tle_adaptation is not None else False

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    monthly_plot_dir = output_dir / "monthly_plots"
    pred_csv_path = output_dir / "predicted_calc_az_el.csv"
    pred_csv_before_tle_path = output_dir / "predicted_calc_az_el_before_tle.csv"
    metrics_json_path = output_dir / "metrics.json"
    metrics_csv_path = output_dir / "metrics_az_el.csv"
    metrics_monthly_csv_path = output_dir / "metrics_monthly_az_el.csv"
    metrics_before_csv_path = output_dir / "metrics_az_el_before_tle.csv"
    metrics_before_monthly_csv_path = output_dir / "metrics_monthly_az_el_before_tle.csv"
    metrics_lla_csv_path = output_dir / "metrics_lla_reconstructed.csv"

    use_range_mode = bool(str(args.predict_start).strip()) and bool(str(args.predict_end).strip())
    if use_range_mode:
        core.log("Building prediction timeline from --predict-start/--predict-end...")
        pred_dates, pred_unix = core.make_dates_unix_from_range(
            start_jst_str=str(args.predict_start),
            end_jst_str=str(args.predict_end),
            step_minutes=int(args.predict_step_minutes),
        )
    else:
        template_csv = Path(args.predict_template)
        if not template_csv.exists():
            raise FileNotFoundError(
                f"predict-template not found: {template_csv}. "
                "Use --predict-start/--predict-end for range mode."
            )
        pred_dates, pred_unix = core.load_template_with_dates(template_csv)

    target_tle_dirs: list[Path] = []
    use_target_tle_direct = False
    if bool(args.use_target_tle_direct) or bool(args.auto_detect_target_tle_dir) or str(args.target_tle_dir).strip():
        core.log(
            "[WARN] target-period TLE direct prediction is disabled by configuration. "
            "Ignoring --target-tle-dir/--use-target-tle-direct/--auto-detect-target-tle-dir."
        )

    _guard_stale_model_year_gap(
        meta=meta,
        pred_unix=np.asarray(pred_unix, dtype=np.float64),
        allow_stale=bool(args.allow_stale_model_year_gap),
    )

    anchor_unix = float(meta.get("anchor_unix", 0.0))
    pred_repeat = None
    pred_repeat_guard = None
    pred_model_core = None
    pred_azel_before_tle = None
    pred_lla_target_tle = None
    pred_lla_physical = None
    lla_physical_primary = False
    target_tle_mask = np.zeros((len(pred_unix),), dtype=bool)
    target_tle_meta = {"enabled": False, "applied": False, "dirs": []}
    lla_primary_requested = (
        bool(use_lla_physical_model)
        and (lla_physical_model is not None)
        and bool(lla_physical_info.get("use_as_primary_no_tle", True))
        and (not bool(args.force_repeat_only))
    )

    if lla_primary_requested:
        pred_azel_physical, pred_lla_physical = lpm.predict_with_model(
            model=lla_physical_model,
            unix=np.asarray(pred_unix, dtype=np.float64),
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            observer_alt_m=observer_alt_m,
        )
        pred_model_core = np.asarray(pred_azel_physical, dtype=np.float64)
        pred_azel_before_tle = pred_model_core.copy()
        lla_physical_primary = True
        core.log(
            "Predicting by LLA physical no-TLE model: "
            f"sidereal_h={int(lla_physical_model['config'].sidereal_harmonics)}, "
            f"yearly_h={int(lla_physical_model['config'].yearly_harmonics)}, "
            f"cross_h={int(lla_physical_model['config'].cross_harmonics)}, "
            f"slot_alpha={float(lla_physical_model['config'].slot_alpha):.3f}"
        )
    elif is_sidereal_mode:
        model_override = str(args.model_path).strip() or str(args.param_path).strip()
        model_path = Path(model_override) if model_override else (model_dir / str(meta.get("model_path", "")))
        if not model_path.exists():
            raise FileNotFoundError(f"sidereal coefficient model not found: {model_path}")
        template_rel = str(meta.get("template_path", "")).strip()
        template_path = model_dir / template_rel
        if not template_path.exists():
            raise FileNotFoundError(f"template npz not found: {template_path}")
        sid_cfg = scm.cfg_from_dict(meta.get("sidereal_coeff_config", {}))
        sid_model, sid_corr, alpha_az, alpha_el = scm.load_saved_model(model_path, scm.cfg_to_dict(sid_cfg))
        tpl = _load_template_pack(template_path)
        pred_repeat = _predict_repeat_from_template_path(template_path, np.asarray(pred_unix, dtype=np.float64))
        pred_repeat_guard = pred_repeat.copy()
        pred_azel_before_tle, pred_sidereal_base, _ = scm.apply_transition_delta_model(
            model=sid_model,
            tpl_prev=tpl,
            unix=np.asarray(pred_unix, dtype=np.float64),
            corr_model=sid_corr,
            alpha_az=float(alpha_az),
            alpha_el=float(alpha_el),
        )
        pred_model_core = pred_azel_before_tle.copy()
        core.log(
            "Predicting by sidereal coefficient model: "
            f"sidereal_h={sid_cfg.sidereal_harmonics}, "
            f"yearly_h={sid_cfg.yearly_harmonics}, "
            f"alpha=({float(alpha_az):.3f},{float(alpha_el):.3f})"
        )
    elif is_lstm_mode:
        model_override = str(args.model_path).strip() or str(args.param_path).strip()
        model_path = Path(model_override) if model_override else (model_dir / str(meta.get("model_path", "")))
        if not model_path.exists():
            raise FileNotFoundError(f"LSTM model not found: {model_path}")
        template_rel = str(meta.get("template_path", "")).strip()
        template_path = model_dir / template_rel
        if not template_path.exists():
            raise FileNotFoundError(f"template npz not found: {template_path}")

        lcfg = hm.lcfg_from_dict(meta.get("lstm_config", {}))
        seq_model = tf.keras.models.load_model(model_path, compile=False)
        tpl = _load_template_pack(template_path)
        core.log(
            "Predicting by LSTM cyclic trig model: "
            f"seq_len={lcfg.seq_len}, yearly_harmonics={lcfg.time_yearly_harmonics}"
        )
        pred_model_raw, pred_repeat_raw = _predict_with_lstm_template(
            tf=tf,
            model=seq_model,
            tpl=tpl,
            pred_unix=pred_unix,
            lcfg=lcfg,
            batch_size=int(args.batch_size),
        )
        pred_repeat = pred_repeat_raw.copy()
        pred_repeat_guard = pred_repeat_raw.copy()
        if bool(use_repeat_trend_correction) and (repeat_trend_pack is not None):
            pred_repeat_guard, _ = _apply_repeat_trend_correction(
                pred_unix=np.asarray(pred_unix, dtype=np.float64),
                tpl=tpl,
                pack=repeat_trend_pack,
            )
            core.log(
                "Applied repeat-trend correction "
                f"(source={repeat_trend_pack['path']}, max_shift={int(repeat_trend_pack['max_shift_minutes'])} min)."
            )
        pred_lstm_core = pred_model_raw.copy()
        if apply_month_bias and month_bias_map and (not bool(use_repeat_trend_correction and repeat_trend_pack is not None)):
            pred_repeat_guard = core.apply_monthly_bias_azel(pred_unix, pred_repeat_guard, month_bias_map)
        if apply_month_bias and month_bias_map:
            pred_lstm_core = core.apply_monthly_bias_azel(pred_unix, pred_lstm_core, month_bias_map)
        pred_model_core = pred_repeat_guard.copy()
        pred_azel_before_tle = pred_repeat_guard.copy()
        if bool(args.repeat_latest_year_base) and (bool(args.force_lstm_delta_blend) or (not bool(use_repeat_trend_correction and repeat_trend_pack is not None))):
            pred_azel_before_tle = _blend_model_with_repeat(
                pred_unix=pred_unix,
                pred_repeat=pred_repeat_guard,
                pred_model=pred_lstm_core,
                anchor_unix=anchor_unix,
                cap_az_deg=min(0.05, float(args.model_delta_cap_az)),
                cap_el_deg=min(0.05, float(args.model_delta_cap_el)),
                decay_days=float(args.model_delta_decay_days),
            )
        elif bool(args.repeat_latest_year_base):
            core.log("repeat-trend correction is active: skipping LSTM delta blend by default.")
    else:
        param_override = str(args.param_path).strip() or str(args.model_path).strip()
        params_path = Path(param_override) if param_override else (model_dir / str(meta.get("param_path", meta.get("model_path", ""))))
        if not params_path.exists():
            raise FileNotFoundError(f"parameter npz not found: {params_path}")
        cfg = hm.cfg_from_dict(meta.get("harmonic_config", {}))
        params_base = hm.load_params(params_path)
        anchor_unix = float(params_base.get("anchor_unix", meta.get("anchor_unix", 0.0)))
        core.log(
            "Predicting by harmonic period-amplitude model: "
            f"period={hm.period_from_raw_np(float(params_base['raw_period'][0]), cfg):.9f} sec"
        )
        pred_model_core = _predict_with_month_bias(
            unix=pred_unix,
            params=params_base,
            cfg=cfg,
            month_bias_map=month_bias_map,
            apply_month_bias=apply_month_bias,
        )
        pred_azel_before_tle = pred_model_core.copy()
        if bool(args.repeat_latest_year_base):
            pred_repeat = _build_repeat_latest_year_prediction(meta=meta, pred_unix=pred_unix)
            if pred_repeat is None:
                core.log("[WARN] repeat-latest-year-base requested, but latest training CSV was not found.")
            else:
                pred_repeat_guard = pred_repeat.copy()
                if bool(use_repeat_trend_correction) and (repeat_trend_pack is not None):
                    template_rel = str(meta.get("template_path", "")).strip()
                    template_path = model_dir / template_rel if template_rel else None
                    if template_path is not None and template_path.exists():
                        tpl = _load_template_pack(template_path)
                        pred_repeat_guard, _ = _apply_repeat_trend_correction(
                            pred_unix=np.asarray(pred_unix, dtype=np.float64),
                            tpl=tpl,
                            pack=repeat_trend_pack,
                        )
                        core.log(
                            "Applied repeat-trend correction "
                            f"(source={repeat_trend_pack['path']}, max_shift={int(repeat_trend_pack['max_shift_minutes'])} min)."
                        )
                    else:
                        core.log("[WARN] repeat-trend correction artifact exists, but template_path is missing.")
                if apply_month_bias and month_bias_map and (not bool(use_repeat_trend_correction and repeat_trend_pack is not None)):
                    pred_repeat_guard = core.apply_monthly_bias_azel(pred_unix, pred_repeat_guard, month_bias_map)
                pred_azel_before_tle = _blend_model_with_repeat(
                    pred_unix=pred_unix,
                    pred_repeat=pred_repeat_guard,
                    pred_model=pred_model_core,
                    anchor_unix=anchor_unix,
                    cap_az_deg=float(args.model_delta_cap_az),
                    cap_el_deg=float(args.model_delta_cap_el),
                    decay_days=float(args.model_delta_decay_days),
                )

    if (not bool(lla_primary_requested)) and use_lla_physical_model and (lla_physical_model is not None):
        pred_azel_physical, pred_lla_physical = lpm.predict_with_model(
            model=lla_physical_model,
            unix=np.asarray(pred_unix, dtype=np.float64),
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            observer_alt_m=observer_alt_m,
        )
        pred_model_core = np.asarray(pred_azel_physical, dtype=np.float64)
        pred_azel_before_tle = pred_model_core.copy()
        lla_physical_primary = bool(lla_physical_info.get("use_as_primary_no_tle", True))
        core.log(
            "Applied LLA physical no-TLE model: "
            f"sidereal_h={int(lla_physical_model['config'].sidereal_harmonics)}, "
            f"yearly_h={int(lla_physical_model['config'].yearly_harmonics)}, "
            f"cross_h={int(lla_physical_model['config'].cross_harmonics)}, "
            f"slot_alpha={float(lla_physical_model['config'].slot_alpha):.3f}"
        )
    elif use_lla_physical_model and (lla_physical_model is None):
        core.log("[WARN] LLA physical model was requested but artifact was not found.")

    if train_years and len(pred_unix) > 0:
        latest_train_year = max(train_years)
        first_pred_jst = dt.datetime.utcfromtimestamp(int(round(float(pred_unix[0])))) + dt.timedelta(hours=9)
        year_gap = int(first_pred_jst.year - latest_train_year)
        if year_gap > 1 and (not bool(lla_physical_primary)):
            core.log(
                f"[WARN] Prediction start year={first_pred_jst.year} but latest training year={latest_train_year} "
                f"(gap={year_gap}). For stability, forcing repeat baseline."
            )
            if pred_repeat_guard is not None:
                pred_azel_before_tle = pred_repeat_guard.copy()
            elif pred_repeat is not None:
                pred_azel_before_tle = pred_repeat.copy()
            else:
                core.log("[WARN] repeat baseline unavailable; keeping model prediction.")

    if bool(args.force_repeat_only):
        if pred_repeat_guard is not None:
            pred_azel_before_tle = pred_repeat_guard.copy()
            core.log("force-repeat-only enabled: using repeat baseline only before TLE correction.")
        elif pred_repeat is not None:
            pred_azel_before_tle = pred_repeat.copy()
            core.log("force-repeat-only enabled: using repeat baseline only before TLE correction.")
        else:
            core.log("[WARN] force-repeat-only was set, but repeat baseline is unavailable.")

    if pred_repeat_guard is not None and pred_model_core is not None and (not bool(args.force_repeat_only)):
        d_az_med = float(np.median(np.abs(hm.angle_diff_deg(pred_model_core[:, 0], pred_repeat_guard[:, 0]))))
        d_el_med = float(np.median(np.abs(pred_model_core[:, 1] - pred_repeat_guard[:, 1])))
        if (not bool(lla_physical_primary)) and (d_az_med > 1.0 or d_el_med > 1.0):
            core.log(
                "[WARN] Model prediction diverged from repeat baseline "
                f"(median |dAZ|={d_az_med:.3f}, |dEL|={d_el_med:.3f}). "
                "Using repeat baseline to avoid degradation."
            )
            pred_azel_before_tle = pred_repeat_guard.copy()

    if (not bool(lla_physical_primary)) and (year_start_pack is not None):
        pred_azel_before_tle = _apply_year_start_correction(
            pred_unix=pred_unix,
            pred_azel=pred_azel_before_tle,
            pack=year_start_pack,
        )
        core.log(
            "Applied year-start correction template "
            f"(days={int(year_start_pack['days'])}, source={year_start_pack['path']})."
        )

    if (not bool(lla_physical_primary)) and use_learned_error_correction and (corr_pack is not None):
        pred_azel_before_tle = _apply_learned_error_correction(
            pred_unix=pred_unix,
            pred_azel=pred_azel_before_tle,
            anchor_unix=anchor_unix,
            corr_pack=corr_pack,
            az_cap_override=args.error_corr_az_cap,
            el_cap_override=args.error_corr_el_cap,
        )
        core.log(
            "Applied learned inference-error correction "
            f"(features={hm.error_feature_dim(corr_pack['cfg'])}, source={corr_pack['path']})."
        )
    elif (not bool(lla_physical_primary)) and use_learned_error_correction and (corr_pack is None):
        core.log("[WARN] learned error correction requested but correction artifact was not found.")

    if (not bool(lla_physical_primary)) and pred_repeat_guard is not None and month_blend_gain:
        pred_azel_before_tle = _apply_month_blend_gain(
            pred_unix=pred_unix,
            pred_repeat=pred_repeat_guard,
            pred_corr=pred_azel_before_tle,
            gain_map=month_blend_gain,
        )
        core.log(
            "Applied month-wise blend gain toward repeat baseline: "
            + ", ".join(f"{k}={float(v):.3f}" for k, v in sorted(month_blend_gain.items()))
        )

    if (not bool(lla_physical_primary)) and use_recent_slot_overlay and (recent_slot_overlay_pack is not None):
        overlay_pack = dict(recent_slot_overlay_pack)
        alpha_eff = float(overlay_pack.get("alpha", 0.0))
        if alpha_eff <= 0.0 and train_years and len(pred_unix) > 0:
            latest_train_year = max(train_years)
            first_pred_jst = dt.datetime.utcfromtimestamp(int(round(float(pred_unix[0])))) + dt.timedelta(hours=9)
            if int(first_pred_jst.year) == int(latest_train_year + 1):
                alpha_eff = 0.25
                overlay_pack["alpha"] = float(alpha_eff)
                core.log(
                    "[WARN] recent slot-overlay holdout alpha collapsed to 0. "
                    "For immediate next-year extrapolation, using conservative alpha=0.25."
                )
        pred_azel_before_tle = _apply_recent_slot_overlay(
            pred_unix=pred_unix,
            pred_azel=pred_azel_before_tle,
            pack=overlay_pack,
        )
        core.log(
            "Applied recent slot-overlay correction "
            f"(alpha={float(overlay_pack.get('alpha', 0.0)):.3f}, "
            f"source={overlay_pack['path']})."
        )

    if bool(use_tle) and bool(args.use_first_tle_global_bias):
        try:
            pred_azel_before_tle, bias_info = _apply_first_tle_global_bias(
                pred_unix=pred_unix,
                pred_azel=pred_azel_before_tle,
                tle_dir=Path(latest_tle_dir),
                sat_name=sat_name,
                observer_lat=observer_lat,
                observer_lon=observer_lon,
                priority_days=tle_priority_days,
                min_rows=max(120, int(min(2000, len(pred_unix)))),
            )
            if bool(bias_info.get("applied")):
                core.log(
                    "Applied first-TLE global bias anchor: "
                    f"az_bias={bias_info.get('az_bias_deg', 0.0):.4f} deg, "
                    f"el_bias={bias_info.get('el_bias_deg', 0.0):.4f} deg, "
                    f"rows={int(bias_info.get('rows', 0))}"
                )
        except Exception as e:
            core.log(f"[WARN] first-TLE global bias anchor skipped: {e}")

    tle_meta = core.TLECorrectionMeta(
        enabled=bool(use_tle),
        applied=False,
        tle_path="",
        tle_epoch_unix=0,
        correction_start_unix=0,
        priority_days=float(tle_priority_days),
        max_weight=float(tle_max_weight),
        decay_hours=float(tle_decay_hours),
        max_hours=float(tle_max_hours),
        tle_count=0,
        segments_used=0,
        rows_corrected=0,
    )

    pred_azel = pred_azel_before_tle.copy()
    if use_tle:
        try:
            if (not is_lstm_mode) and (not is_sidereal_mode) and enable_tle_adaptation and int(tle_adapt_epochs) > 0:
                pred_azel, _pred_model_after_adapt, tle_meta = _apply_tle_adaptive_correction(
                    tf=tf,
                    pred_unix=pred_unix,
                    base_params=params_base,
                    cfg=cfg,
                    month_bias_map=month_bias_map,
                    apply_month_bias=apply_month_bias,
                    tle_dir=Path(latest_tle_dir),
                    sat_name=sat_name,
                    observer_lat=observer_lat,
                    observer_lon=observer_lon,
                    correction_start_str=tle_correction_start,
                    priority_days=tle_priority_days,
                    max_weight=tle_max_weight,
                    decay_hours=tle_decay_hours,
                    max_hours=tle_max_hours,
                    adapt_epochs=tle_adapt_epochs,
                    adapt_lr=tle_adapt_lr,
                    adapt_reg=tle_adapt_reg,
                    adapt_min_rows=tle_adapt_min_rows,
                    adapt_batch_size=int(args.batch_size),
                    adapt_huber_delta=float(args.tle_adapt_huber_delta),
                )
            else:
                if enable_tle_adaptation and int(tle_adapt_epochs) > 0 and (is_lstm_mode or is_sidereal_mode):
                    core.log("[WARN] TLE adaptation is only implemented for harmonic mode. Using multi-TLE blending.")
                pred_azel, _, _, tle_meta = core.apply_multi_tle_correction(
                    pred_unix=pred_unix,
                    pred_azel=pred_azel_before_tle,
                    tle_dir=Path(latest_tle_dir),
                    sat_name=sat_name,
                    observer_lat=observer_lat,
                    observer_lon=observer_lon,
                    correction_start_str=tle_correction_start,
                    priority_days=tle_priority_days,
                    max_weight=tle_max_weight,
                    decay_hours=tle_decay_hours,
                    max_hours=tle_max_hours,
                    agreement_az_deg=float(args.tle_agreement_az_deg),
                    agreement_el_deg=float(args.tle_agreement_el_deg),
                    agreement_decay=float(args.tle_agreement_decay),
                )
            if tle_meta.applied:
                if (not is_lstm_mode) and (not is_sidereal_mode) and enable_tle_adaptation and int(tle_adapt_epochs) > 0:
                    core.log(
                        "Applied multi-TLE adaptive correction: "
                        f"tles={tle_meta.tle_count}, segments={tle_meta.segments_used}, rows={tle_meta.rows_corrected}"
                    )
                else:
                    core.log(
                        "Applied multi-TLE correction: "
                        f"tles={tle_meta.tle_count}, segments={tle_meta.segments_used}, rows={tle_meta.rows_corrected}"
                    )
            else:
                core.log("TLE correction enabled, but no applicable segment was found.")
        except Exception as e:
            core.log(f"[WARN] TLE correction skipped: {e}")

    if use_target_tle_direct:
        pred_azel, pred_lla_target_tle, target_tle_mask, target_tle_meta = _apply_target_tle_direct_prediction(
            pred_unix=np.asarray(pred_unix, dtype=np.float64),
            pred_azel=pred_azel,
            sat_name=sat_name,
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            tle_dirs=target_tle_dirs,
        )
        if bool(target_tle_meta.get("applied")):
            core.log(
                "Applied authoritative target-period TLE prediction: "
                f"dirs={','.join(str(p) for p in target_tle_dirs)}, "
                f"tles={int(target_tle_meta.get('tle_count', 0))}, "
                f"rows={int(target_tle_meta.get('rows_covered', 0))}"
            )
        else:
            core.log(
                "Target-period TLE direct prediction was requested, "
                "but no rows were covered by the detected TLE files."
            )

    pred_lla = core.azel_to_lla_geoshell(
        az_deg=pred_azel[:, 0],
        el_deg=pred_azel[:, 1],
        observer_lat_deg=observer_lat,
        observer_lon_deg=observer_lon,
        observer_alt_m=observer_alt_m,
        geo_radius_km=geo_radius_km,
    )
    if pred_lla_target_tle is not None and np.any(target_tle_mask):
        pred_lla[target_tle_mask] = pred_lla_target_tle[target_tle_mask]
    pred_full = np.column_stack([pred_lla, pred_azel]).astype(np.float64)

    core.write_prediction_csv(pred_csv_path, pred_dates, pred_unix, pred_lla=pred_lla, pred_azel=pred_azel)
    if use_tle and tle_meta.applied:
        pred_lla_before = core.azel_to_lla_geoshell(
            az_deg=pred_azel_before_tle[:, 0],
            el_deg=pred_azel_before_tle[:, 1],
            observer_lat_deg=observer_lat,
            observer_lon_deg=observer_lon,
            observer_alt_m=observer_alt_m,
            geo_radius_km=geo_radius_km,
        )
        core.write_prediction_csv(
            pred_csv_before_tle_path,
            pred_dates,
            pred_unix,
            pred_lla=pred_lla_before,
            pred_azel=pred_azel_before_tle,
        )
    core.log(f"Saved predicted CSV: {pred_csv_path}")

    truth_path = Path(args.truth_file) if str(args.truth_file).strip() else None
    if truth_path is None:
        core.log("No truth file specified. Skipping evaluation.")
        return
    if not truth_path.exists():
        core.log(f"Truth file not found: {truth_path}. Skipping evaluation.")
        return

    true_unix, true_full = core.load_orbit_numeric_full(truth_path)
    try:
        pred_aligned, true_aligned, unix_aligned = core.align_by_unix(
            pred_unix=pred_unix,
            pred_full=pred_full,
            true_unix=true_unix,
            true_full=true_full,
        )
    except RuntimeError:
        core.log("No overlapping UNIX timestamps with truth. Skipping evaluation.")
        return

    n_pred = int(len(pred_unix))
    n_eval = int(len(unix_aligned))
    if n_eval < n_pred and (not bool(args.allow_partial_truth_eval)):
        cov = 100.0 * float(n_eval) / float(max(1, n_pred))
        core.log(
            "Truth does not fully cover prediction period "
            f"(coverage={n_eval}/{n_pred} = {cov:.2f}%). "
            "Skipping metrics and error plots. "
            "Use --allow-partial-truth-eval to evaluate overlap only."
        )
        return
    if n_eval < n_pred:
        cov = 100.0 * float(n_eval) / float(max(1, n_pred))
        core.log(f"Partial truth coverage: {n_eval}/{n_pred} ({cov:.2f}%). Evaluating overlap only.")

    pred_full_before = pred_full.copy()
    pred_full_before[:, 3] = pred_azel_before_tle[:, 0]
    pred_full_before[:, 4] = pred_azel_before_tle[:, 1]
    pred_before_aligned, _, _ = core.align_by_unix(
        pred_unix=pred_unix,
        pred_full=pred_full_before,
        true_unix=true_unix,
        true_full=true_full,
    )

    metrics_azel = core.compute_metrics_azel(y_true_full=true_aligned, y_pred_full=pred_aligned)
    monthly_azel = core.compute_monthly_azel_metrics(unix=unix_aligned, y_true_full=true_aligned, y_pred_full=pred_aligned)
    metrics_azel_before = core.compute_metrics_azel(y_true_full=true_aligned, y_pred_full=pred_before_aligned)
    monthly_azel_before = core.compute_monthly_azel_metrics(
        unix=unix_aligned,
        y_true_full=true_aligned,
        y_pred_full=pred_before_aligned,
    )
    metrics_lla = core.compute_metrics_lla(y_true_full=true_aligned, y_pred_full=pred_aligned)

    core.write_metrics_json(
        path=metrics_json_path,
        rows_evaluated=true_aligned.shape[0],
        calib=core.BiasCalibration(alpha_az=1.0, alpha_el=1.0),
        overall_azel_final=metrics_azel,
        monthly_azel_final=monthly_azel,
        overall_lla=metrics_lla,
        overall_azel_before_tle=metrics_azel_before,
        monthly_azel_before_tle=monthly_azel_before,
        tle_meta=tle_meta,
    )
    try:
        metrics_json_obj = json.loads(metrics_json_path.read_text(encoding="utf-8"))
        metrics_json_obj["target_tle_direct"] = target_tle_meta
        metrics_json_obj["lla_physical_model"] = {
            "requested": bool(use_lla_physical_model),
            "available": bool(lla_physical_model is not None),
            "primary": bool(lla_physical_primary),
            "path": str(lla_physical_model.get("path", "")) if isinstance(lla_physical_model, dict) else "",
            "meta": lla_physical_info,
        }
        metrics_json_path.write_text(json.dumps(metrics_json_obj, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        core.log(f"[WARN] failed to append target_tle_direct metadata to metrics.json: {e}")
    core.write_metrics_csv(metrics_csv_path, metrics_azel)
    core.write_monthly_metrics_csv(metrics_monthly_csv_path, monthly_azel)
    core.write_metrics_csv(metrics_before_csv_path, metrics_azel_before)
    core.write_monthly_metrics_csv(metrics_before_monthly_csv_path, monthly_azel_before)
    core.write_lla_metrics_csv(metrics_lla_csv_path, metrics_lla)

    monthly_plot_dir.mkdir(parents=True, exist_ok=True)
    for old_png in monthly_plot_dir.glob("*.png"):
        try:
            old_png.unlink()
        except Exception:
            pass
    core.plot_monthly_azel(
        unix=unix_aligned,
        y_true_full=true_aligned,
        y_pred_full=pred_aligned,
        out_dir=monthly_plot_dir,
        max_points_per_month=int(args.max_plot_points_per_month),
    )

    core.log(f"Saved metrics JSON           : {metrics_json_path}")
    core.log(f"Saved metrics CSV (AZ/EL)    : {metrics_csv_path}")
    core.log(f"Saved monthly metrics CSV    : {metrics_monthly_csv_path}")
    core.log(f"Saved before-TLE metrics CSV : {metrics_before_csv_path}")
    core.log(f"Saved before-TLE monthly CSV : {metrics_before_monthly_csv_path}")
    core.log(f"Saved reconstructed LLA CSV  : {metrics_lla_csv_path}")
    core.log(f"Saved monthly plots directory: {monthly_plot_dir}")
    core.log("Predict-only run complete.")


if __name__ == "__main__":
    main()
