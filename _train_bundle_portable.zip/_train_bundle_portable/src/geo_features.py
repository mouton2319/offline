#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
地理特徴量(海岸線までの距離・陸海判定)を計算する共通モジュール。

cartopy 同梱の Natural Earth(physical/land)だけを使う。追加DLは不要。

=== 設計(性能が肝) ===
全世界の海岸線に1点ずつ距離を測ると非常に遅い(数日規模)。さらにファイルごとに
グリッドを作り直すと、外洋横断など広域の船で巨大グリッドになり破綻する。

そこで2段構えにする:
  1. build_distance_grid(): データ全域のbboxに対して「海岸線距離グリッド」と
     「陸海グリッド」を **一度だけ** 計算し、.npz に保存する(数分)。
  2. add_geo_features(): その .npz を読み込み(高速)、各AIS点はバイリニア補間で
     引くだけ(shapely不要・点数によらず高速・並列worker安全)。

責務分離:
  - prepare_ai_feature_csv.py が --add-geo 指定時にこのモジュールを使い、CSVに列を足す。
  - 学習・推論・比較スクリプトは、その列を「読むだけ」(再計算しない)。

提供する地理特徴量(GEO_FEATURES):
  - coast_dist_km  : 最寄り海岸線までの距離(km)。大きいほど外洋、小さいほど沿岸・港湾。
  - coast_dist_inv : 1/(1+coast_dist_km)。港湾接近で1に近づく正規化値(減速・停止の手がかり)。
  - is_on_land     : 陸地ポリゴン内なら1、海上なら0。
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple

import numpy as np

# 地理特徴量の列名(prepare/学習/推論で共有)。
GEO_FEATURES = ["coast_dist_km", "coast_dist_inv", "is_on_land"]

KM_PER_DEG_LAT = 110.574

# 既定のグリッド保存先(prepareと同じ階層)。
DEFAULT_GRID_PATH = Path(__file__).resolve().parent / "geo_coast_grid.npz"

# プロセス内でロード済みグリッドをキャッシュ(workerごとに1回ロード)。
_GRID_CACHE: dict = {}


def build_distance_grid(
    lon_min: float,
    lon_max: float,
    lat_min: float,
    lat_max: float,
    step_deg: float = 0.005,
    resolution: str = "10m",
    out_path: Optional[Path] = None,
    margin_deg: float = 0.3,
    progress_every: int = 500,
) -> Path:
    """データ全域のbboxに対する海岸線距離・陸海グリッドを計算し .npz に保存する。

    Args:
        lon_min/lon_max/lat_min/lat_max: 全データの座標範囲。
        step_deg: グリッド解像度(度)。0.005≒550m。
        resolution: Natural Earth解像度("10m"/"50m"/"110m")。
        out_path: 保存先 .npz。Noneなら DEFAULT_GRID_PATH。
        margin_deg: bboxに付ける余白。
        progress_every: 何行ごとに進捗表示するか。

    Returns:
        保存した .npz のパス。
    """
    import shapely
    import cartopy.io.shapereader as shpreader
    from shapely.ops import unary_union
    from shapely.geometry import box
    from scipy.ndimage import distance_transform_edt

    _ = progress_every  # EDT方式では行ループしないので未使用
    out_path = Path(out_path) if out_path else DEFAULT_GRID_PATH

    lon0 = float(lon_min) - margin_deg
    lon1 = float(lon_max) + margin_deg
    lat0 = float(lat_min) - margin_deg
    lat1 = float(lat_max) + margin_deg

    print(f"[GEO GRID] bbox lon[{lon0:.2f},{lon1:.2f}] lat[{lat0:.2f},{lat1:.2f}] "
          f"step={step_deg} res={resolution}")

    land_shp = shpreader.natural_earth(resolution=resolution, category="physical", name="land")
    geoms = list(shpreader.Reader(land_shp).geometries())
    land_union = unary_union(geoms)
    region = box(lon0, lat0, lon1, lat1)
    local_land = land_union.intersection(region)

    # グリッド軸(lookup_grid と同じ lon0 + i*step の格子点)。
    gx = np.arange(lon0, lon1 + step_deg, step_deg)
    gy = np.arange(lat0, lat1 + step_deg, step_deg)
    ny, nx = len(gy), len(gx)
    print(f"[GEO GRID] grid {ny} x {nx} = {ny*nx/1e6:.1f}M cells (EDT方式)")

    # --- 陸海マスク: shapely.prepare + contains_xy をベクトル化(数秒) ---
    LON, LAT = np.meshgrid(gx, gy)   # [ny, nx], 行0 = lat0
    if local_land.is_empty:
        land = np.zeros((ny, nx), dtype=bool)
    else:
        shapely.prepare(local_land)   # これが無いと contains が桁違いに遅い
        land = shapely.contains_xy(local_land, LON, LAT)

    # --- 海岸線距離: scipy の Euclidean Distance Transform で一括計算(数秒) ---
    # EDT は「各セルから最寄りの背景(False)セルまでの距離」をセル単位で返す。
    # 海セル→最寄り陸、陸セル→最寄り海、をそれぞれ計算して合成すると
    # 全セルが「海岸線(陸海境界)までの距離」になる。
    R = 6371.0088                      # 地球平均半径(km)
    deg2km = np.pi * R / 180.0
    dy_km = float((gy[1] - gy[0]) * deg2km) if ny > 1 else 1.0
    # 経度方向の実距離は緯度でcos(lat)倍に縮む。全緯度帯の平均cosで近似する。
    mean_cos = float(np.mean(np.cos(np.radians(gy))))
    dx_km = float((gx[1] - gx[0]) * deg2km * mean_cos) if nx > 1 else 1.0
    sampling = (dy_km, dx_km)          # (行=緯度方向, 列=経度方向) のkm/セル

    if land.any() and (~land).any():
        dist_sea = distance_transform_edt(~land, sampling=sampling)   # 海セル→最寄り陸
        dist_land = distance_transform_edt(land, sampling=sampling)   # 陸セル→最寄り海
        dist = np.where(land, dist_land, dist_sea).astype(np.float32)
    else:
        # 全部海(または全部陸)で境界が無い場合。
        dist = np.full((ny, nx), 9999.0, dtype=np.float32)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        out_path,
        dist=dist, land=land,
        lon0=lon0, lat0=lat0, step=step_deg, nx=nx, ny=ny,
    )
    print(f"[GEO GRID] saved {out_path}  size_MB={out_path.stat().st_size/1e6:.1f}")
    return out_path


def _load_grid(grid_path: Path) -> dict:
    """.npz グリッドをロードしてキャッシュする(worker毎に1回)。"""
    key = str(grid_path)
    if key in _GRID_CACHE:
        return _GRID_CACHE[key]
    if not Path(grid_path).exists():
        raise FileNotFoundError(
            f"{grid_path} が見つかりません。先に build_distance_grid()"
            "(prepare_ai_feature_csv.py の --build-geo-grid)でグリッドを作成してください。"
        )
    z = np.load(grid_path)
    grid = {
        "dist": z["dist"], "land": z["land"],
        "lon0": float(z["lon0"]), "lat0": float(z["lat0"]),
        "step": float(z["step"]), "nx": int(z["nx"]), "ny": int(z["ny"]),
    }
    _GRID_CACHE[key] = grid
    return grid


def lookup_grid(lons: np.ndarray, lats: np.ndarray, grid_path: Path) -> Tuple[np.ndarray, np.ndarray]:
    """点群の (海岸線距離km, 陸海フラグ) を事前計算グリッドの補間で返す。

    Args:
        lons: 経度配列。
        lats: 緯度配列。
        grid_path: build_distance_grid()が作った .npz。

    Returns:
        `(coast_dist_km, is_on_land)`。距離はバイリニア補間、陸海は最近傍。
    """
    grid = _load_grid(grid_path)
    dist = grid["dist"]
    land = grid["land"]
    lon0, lat0, step = grid["lon0"], grid["lat0"], grid["step"]
    nx, ny = grid["nx"], grid["ny"]

    lons = np.asarray(lons, dtype=np.float64)
    lats = np.asarray(lats, dtype=np.float64)
    fx = np.clip((lons - lon0) / step, 0, nx - 1.001)
    fy = np.clip((lats - lat0) / step, 0, ny - 1.001)
    x0 = fx.astype(int)
    y0 = fy.astype(int)
    wx = fx - x0
    wy = fy - y0

    d = (
        dist[y0, x0] * (1 - wx) * (1 - wy)
        + dist[y0, x0 + 1] * wx * (1 - wy)
        + dist[y0 + 1, x0] * (1 - wx) * wy
        + dist[y0 + 1, x0 + 1] * wx * wy
    ).astype(np.float32)
    on_land = land[np.round(fy).astype(int), np.round(fx).astype(int)]
    return d, on_land


def add_geo_features(df, grid_path: Optional[Path] = None) -> None:
    """DataFrameに地理特徴量列(GEO_FEATURES)を破壊的に追加する。

    事前計算グリッド(.npz)を引くだけなので高速・並列worker安全。

    Args:
        df: lon/lat列を持つDataFrame。
        grid_path: build_distance_grid()が作った .npz。Noneなら DEFAULT_GRID_PATH。

    Returns:
        None。df に coast_dist_km / coast_dist_inv / is_on_land を追加する。
    """
    grid_path = Path(grid_path) if grid_path else DEFAULT_GRID_PATH
    if df.empty:
        for c in GEO_FEATURES:
            df[c] = np.float32(0.0)
        return

    lons = df["lon"].to_numpy(dtype=np.float64)
    lats = df["lat"].to_numpy(dtype=np.float64)
    dist, land = lookup_grid(lons, lats, grid_path)
    df["coast_dist_km"] = dist.astype(np.float32)
    df["coast_dist_inv"] = (1.0 / (1.0 + dist)).astype(np.float32)
    df["is_on_land"] = land.astype(np.float32)
