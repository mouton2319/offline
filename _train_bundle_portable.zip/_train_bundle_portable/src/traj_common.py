#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡予測(v1: decoder-only Transformer)の共通ライブラリ。

学習(traj_train.py)・推論(traj_predict.py)・可視化(visualize_trajectory_prediction.py)が
共有する「定数・座標変換・特徴量・データセット・モデル・checkpoint入出力」を集約する。
CLI(引数解析やmain)は持たない。

=== 特徴量の考え方 ===
モデルの入力は基本「移動量 dx_km, dy_km」。--feature-cols で追加の数値列を足せる。
  - CSVにある数値列(lon, lat, dlon, dlat, speed_deg_per_min など)はそのまま使う。
  - 時刻の周期特徴(tod_sin/cos, doy_sin/cos)は timestamp/unix_time から計算する
    (生の時刻値は巨大かつ年で分布がずれるため、周期エンコードにする)。
推論の自己回帰では、モデルが出した dx,dy から追加特徴を「再構成」して次入力に供給する
(reconstruct_next_extra)。これで学習時と推論時の特徴定義が一致する。
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import Dataset
except ImportError:
    raise SystemExit("[ERROR] PyTorch がありません。 pip install torch numpy pandas")

# 局所km換算の定数。
KM_PER_DEG_LAT = 110.574
KM_PER_DEG_LON_AT_EQUATOR = 111.320

REQUIRED_COLUMNS = ["lon", "lat"]

# 時刻から計算する周期特徴(CSVには無くても timestamp/unix_time から作る)。
TIME_CYCLIC = ["tod_sin", "tod_cos", "doy_sin", "doy_cos"]


# ---------------------------------------------------------------------------
# 座標・移動量ユーティリティ
# ---------------------------------------------------------------------------
def km_per_deg_lon(lat: float) -> float:
    """指定緯度での経度1度あたりの距離(km)。"""
    return max(KM_PER_DEG_LON_AT_EQUATOR * math.cos(math.radians(float(lat))), 1e-6)


def lonlat_to_disp_km(lon: np.ndarray, lat: np.ndarray) -> np.ndarray:
    """lon/lat列から、各点の「直前点からの移動量(dx_km, dy_km)」を作る。先頭点は0。"""
    lon = np.asarray(lon, dtype=np.float64)
    lat = np.asarray(lat, dtype=np.float64)
    n = len(lon)
    disp = np.zeros((n, 2), dtype=np.float64)
    if n >= 2:
        mid_lat = 0.5 * (lat[1:] + lat[:-1])
        lon_scale = KM_PER_DEG_LON_AT_EQUATOR * np.cos(np.radians(mid_lat))
        disp[1:, 0] = (lon[1:] - lon[:-1]) * lon_scale
        disp[1:, 1] = (lat[1:] - lat[:-1]) * KM_PER_DEG_LAT
    return disp


def haversine_km(lon1, lat1, lon2, lat2) -> float:
    """2点間の球面距離(km)。スカラー用。"""
    R = 6371.0088
    lon1, lat1, lon2, lat2 = map(math.radians, (lon1, lat1, lon2, lat2))
    dlon, dlat = lon2 - lon1, lat2 - lat1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 2.0 * R * math.asin(math.sqrt(min(1.0, a)))


# ---------------------------------------------------------------------------
# 特徴量(追加列・時刻周期)の組み立てと、推論時の再構成
# ---------------------------------------------------------------------------
def unix_seconds(df: pd.DataFrame) -> np.ndarray:
    """DataFrameからUNIX秒配列を得る(unix_time優先、無ければtimestampから)。"""
    if "unix_time" in df.columns:
        u = pd.to_numeric(df["unix_time"], errors="coerce")
        if u.notna().any() and float(u.dropna().abs().median()) > 1e12:  # ミリ秒なら秒へ
            u = u / 1000.0
        return u.fillna(0.0).to_numpy(dtype=np.float64)
    if "timestamp" in df.columns:
        t = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
        return (t.astype("int64") / 1e9).to_numpy(dtype=np.float64)
    return np.zeros(len(df), dtype=np.float64)


def compute_time_cyclic(unix: np.ndarray) -> Dict[str, np.ndarray]:
    """UNIX秒配列から時刻周期特徴(tod_sin/cos, doy_sin/cos)を計算する。"""
    dt = pd.to_datetime(np.asarray(unix, dtype=np.float64), unit="s", utc=True)
    sod = (dt.hour * 3600.0 + dt.minute * 60.0 + dt.second + dt.microsecond / 1e6)
    sod = np.asarray(sod, dtype=np.float64)
    tod = 2.0 * np.pi * sod / 86400.0
    doy = np.asarray(dt.dayofyear, dtype=np.float64)
    doy_ang = 2.0 * np.pi * (doy - 1.0 + sod / 86400.0) / 365.2425
    return {
        "tod_sin": np.sin(tod), "tod_cos": np.cos(tod),
        "doy_sin": np.sin(doy_ang), "doy_cos": np.cos(doy_ang),
    }


def compute_coast_dist(lon, lat) -> np.ndarray:
    """各点の最寄り海岸線距離(km)を、事前計算グリッド(geo_coast_grid.npz)から高速に引く。
    学習・推論で同じ方式にするため、CSV列ではなく lon/lat から都度計算する。"""
    import geo_features  # 同じ src の地理グリッドモジュール(遅延import)
    d, _ = geo_features.lookup_grid(
        np.asarray(lon, dtype=np.float64), np.asarray(lat, dtype=np.float64),
        geo_features.DEFAULT_GRID_PATH,
    )
    return np.asarray(d, dtype=np.float64)


def compute_turn_rate(lon, lat, interval_minutes: float = 3.0) -> np.ndarray:
    """各点の旋回率(度/分)を移動量の方位変化から計算する(学習・推論で同一定義)。"""
    disp = lonlat_to_disp_km(lon, lat)               # [N,2] (東, 北)
    heading = np.arctan2(disp[:, 0], disp[:, 1])     # 北=0, 東=+ の方位(rad)
    n = len(np.asarray(lon))
    tr = np.zeros(n, dtype=np.float64)
    if n > 1:
        dh = np.diff(heading)
        dh = np.arctan2(np.sin(dh), np.cos(dh))       # [-pi,pi] へ正規化
        tr[1:] = np.degrees(dh) / max(float(interval_minutes), 1e-6)
    return tr


def build_feature_matrix(df: pd.DataFrame, feature_cols: List[str], interval_minutes: float = 3.0) -> np.ndarray:
    """各点の追加特徴量行列 [N, len(feature_cols)] を作る。

    - coast_dist_km : geo_coast_grid.npz から lon/lat で計算(CSV列に依存しない)
    - turn_rate     : 移動量の方位変化から計算(同上)
    - 時刻周期(TIME_CYCLIC): timestamp/unix_time から計算
    - それ以外      : CSVの数値列をそのまま(無ければ0)
    学習(Dataset/fit_stats)と推論(初期履歴)で共通に使い、特徴の定義を一致させる。
    """
    n = len(df)
    lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
    lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
    cyc = compute_time_cyclic(unix_seconds(df)) if any(c in TIME_CYCLIC for c in feature_cols) else None
    coast = compute_coast_dist(lon, lat) if "coast_dist_km" in feature_cols else None
    turn = compute_turn_rate(lon, lat, interval_minutes) if "turn_rate" in feature_cols else None
    cols = []
    for c in feature_cols:
        if c in TIME_CYCLIC:
            v = cyc[c]
        elif c == "coast_dist_km":
            v = coast
        elif c == "turn_rate":
            v = turn
        elif c in df.columns:
            v = pd.to_numeric(df[c], errors="coerce").fillna(0.0).to_numpy(dtype=np.float64)
        else:
            v = np.zeros(n, dtype=np.float64)
        cols.append(np.asarray(v, dtype=np.float64))
    return np.stack(cols, axis=1) if cols else np.zeros((n, 0), dtype=np.float64)


def reconstruct_next_extra(feature_cols: List[str], new_lon: float, new_lat: float,
                           prev_lon: float, prev_lat: float, new_unix: float,
                           interval_minutes: float, prev_dxy=None, cur_dxy=None) -> np.ndarray:
    """推論1ステップ分の追加特徴ベクトルを、生成後の状態から再構成する。

    build_feature_matrix と同じ定義になるようにする:
      - lon/lat、直前点からの度数差 dlon/dlat、度数速度、時刻周期
      - coast_dist_km : 新座標をグリッドで引く
      - turn_rate     : 直前の移動ベクトル(prev_dxy)と今の移動(cur_dxy)の方位差
    未知の列は0。
    """
    dlon = new_lon - prev_lon
    dlat = new_lat - prev_lat
    speed_dpm = math.sqrt(dlon * dlon + dlat * dlat) / max(float(interval_minutes), 1e-6)
    cyc = compute_time_cyclic(np.asarray([new_unix], dtype=np.float64))
    vals = {
        "lon": float(new_lon), "lat": float(new_lat),
        "dlon": float(dlon), "dlat": float(dlat),
        "speed_deg_per_min": float(speed_dpm),
        "tod_sin": float(cyc["tod_sin"][0]), "tod_cos": float(cyc["tod_cos"][0]),
        "doy_sin": float(cyc["doy_sin"][0]), "doy_cos": float(cyc["doy_cos"][0]),
    }
    if "coast_dist_km" in feature_cols:
        vals["coast_dist_km"] = float(compute_coast_dist([new_lon], [new_lat])[0])
    if "turn_rate" in feature_cols:
        if prev_dxy is not None and cur_dxy is not None:
            hp = math.atan2(float(prev_dxy[0]), float(prev_dxy[1]))
            hc = math.atan2(float(cur_dxy[0]), float(cur_dxy[1]))
            dh = math.atan2(math.sin(hc - hp), math.cos(hc - hp))
            vals["turn_rate"] = math.degrees(dh) / max(float(interval_minutes), 1e-6)
        else:
            vals["turn_rate"] = 0.0
    return np.asarray([vals.get(c, 0.0) for c in feature_cols], dtype=np.float64)


# ---------------------------------------------------------------------------
# 設定
# ---------------------------------------------------------------------------
@dataclass
class TrajConfig:
    """checkpoint に保存する再現用の設定。"""
    feature_cols: List[str]          # 追加で使う列(基本の dx,dy 以外)
    input_dim: int                   # 入力次元(= 2 + len(feature_cols))
    d_model: int
    nhead: int
    num_layers: int
    dim_feedforward: int
    dropout: float
    max_len: int
    interval_minutes: float
    disp_mean: List[float] = field(default_factory=lambda: [0.0, 0.0])
    disp_std: List[float] = field(default_factory=lambda: [1.0, 1.0])
    feat_mean: List[float] = field(default_factory=list)
    feat_std: List[float] = field(default_factory=list)
    # --- CV残差ターゲット版(traj_*_cvres.py)で使用。通常版はデフォルトのまま ---
    # target_mode: "disp"=移動量を直接予測 / "cv_residual"=次の1歩のCV残差 /
    #              "cv_residual_stop"=CV残差+停止確率 /
    #              "cv_residual_mh"=multi-horizon直接予測(各位置から h=1..horizon の
    #                               累積変位を一括予測。推論は自己回帰せず1回のforward) /
    #              "cv_residual_mdn"=multi-horizon の確率版(horizon別 K=mdn_k の
    #                               2次元Laplace混合密度=MDNを出力。負対数尤度で学習し、
    #                               推論は各horizonで最大重みモードのμにコミット。
    #                               ヘッド出力次元は H*K*5=logit(1)+μ(2)+log_b(2))
    target_mode: str = "disp"
    cv_n_last: int = 6                  # 等速(CV)予測に使う直近点数
    res_mean: List[float] = field(default_factory=lambda: [0.0, 0.0])
    res_std: List[float] = field(default_factory=lambda: [1.0, 1.0])
    # --- multi-horizon版(traj_train_cvres_mh.py)で使用。既定は後方互換(horizon=1) ---
    horizon: int = 1                    # 直接予測する未来ステップ数(mh版はH=20)
    # horizon別の累積残差の標準化統計。形 [H][2]。既定は空(非mh版では未使用)。
    mh_res_mean: List[List[float]] = field(default_factory=list)
    mh_res_std: List[List[float]] = field(default_factory=list)
    # --- MDN版(traj_train_cvres_mdn.py, target_mode="cv_residual_mdn")で使用 ---
    # mdn_k: horizon別の混合成分数K。0=MDNなし(後方互換)。MDN版はK=3等を設定。
    # 出力次元は out_dim=H*K*5(モードごとに logit(1)+μ(2)+log_b(2))。
    mdn_k: int = 0
    # --- 停止ゲート版(traj_*_cvres_stop.py)で使用。既定値は旧checkpointと互換 ---
    out_dim: int = 2                    # ヘッド出力次元(2=dx,dy / 3=dx,dy+停止logit)
    stop_thresh_km: float = 0.0         # 「停止」とみなす次ステップ移動量(km)。0=停止ヘッド無し
    model_arch: str = "traj_decoder_only_v1"


# ---------------------------------------------------------------------------
# Dataset: 1ファイル = 1航跡を遅延読み込み
# ---------------------------------------------------------------------------
class TrajectoryDataset(Dataset):
    """航跡別CSVを1ファイルずつ読み、(特徴量系列, 移動量系列)を返す。"""

    def __init__(self, files: List[Path], feature_cols: List[str], max_len: int, train: bool, seed: int = 42):
        self.files = files
        self.feature_cols = list(feature_cols)
        self.max_len = int(max_len)
        self.train = bool(train)
        self.rng = random.Random(seed)
        # 高速化: read_csv で読む列を最小化する。coast_dist_km/turn_rate は計算、
        # 時刻周期は timestamp/unix_time から作るので、CSVから実際に読むのは
        # lon/lat/時刻 +（計算でない）追加特徴量列だけでよい。
        need = {"lon", "lat", "unix_time", "timestamp"}
        for c in self.feature_cols:
            if c not in ("coast_dist_km", "turn_rate") and c not in TIME_CYCLIC:
                need.add(c)
        self._usecols = need

    def __len__(self):
        return len(self.files)

    def _read(self, path: Path) -> pd.DataFrame:
        # usecols(callable)で存在する必要列だけ読む。無い列は無視され安全。
        df = pd.read_csv(path, usecols=lambda c: c in self._usecols)
        for c in REQUIRED_COLUMNS:
            if c not in df.columns:
                raise ValueError(f"{path} に {c} 列がありません")
        if "unix_time" in df.columns:
            df = df.sort_values("unix_time")
        elif "timestamp" in df.columns:
            df = df.assign(_t=pd.to_datetime(df["timestamp"], utc=True, errors="coerce")).sort_values("_t")
        return df.reset_index(drop=True)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        df = self._read(self.files[idx])
        lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
        lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
        disp = lonlat_to_disp_km(lon, lat)                 # [N, 2]

        if self.feature_cols:
            extra = build_feature_matrix(df, self.feature_cols)          # [N, E]
            feats = np.concatenate([disp.astype(np.float32), extra.astype(np.float32)], axis=1)  # [N, 2+E]
        else:
            feats = disp.astype(np.float32)                 # [N, 2]

        n = len(feats)
        if n > self.max_len:
            s = self.rng.randint(0, n - self.max_len) if self.train else 0
            feats = feats[s:s + self.max_len]
            disp = disp[s:s + self.max_len]

        return {
            "feats": torch.from_numpy(feats.astype(np.float32)),   # [L, F]
            "disp": torch.from_numpy(disp.astype(np.float32)),     # [L, 2]
        }


def collate_trajectories(batch: List[Dict[str, torch.Tensor]], disp_mean, disp_std, feat_mean, feat_std):
    """可変長航跡をパディングし、次ステップ予測用の (入力, 目標, マスク) を作る。

    位置 i の入力から「位置 i+1 への移動量 disp[i+1]」を予測する。
    supervise する位置は 0..L-2(最後の点 L-1 は教師が無いのでマスク)。
    """
    B = len(batch)
    lengths = [b["feats"].shape[0] for b in batch]
    Lmax = max(lengths)
    F = batch[0]["feats"].shape[1]

    X = torch.zeros(B, Lmax, F)
    Y = torch.zeros(B, Lmax, 2)
    valid = torch.zeros(B, Lmax, dtype=torch.bool)   # 教師ありの位置
    pad = torch.ones(B, Lmax, dtype=torch.bool)      # True=パディング(attentionで無視)

    dm = torch.tensor(disp_mean); ds = torch.tensor(disp_std)
    for i, b in enumerate(batch):
        L = b["feats"].shape[0]
        X[i, :L] = b["feats"]
        pad[i, :L] = False
        if L >= 2:
            Y[i, :L - 1] = (b["disp"][1:L] - dm) / ds
            valid[i, :L - 1] = True

    fm = torch.tensor(feat_mean) if feat_mean else None
    fs = torch.tensor(feat_std) if feat_std else None
    if fm is not None and fm.numel() == F:
        X = (X - fm) / fs
        X = X * (~pad).unsqueeze(-1)   # パディングは0のまま

    return {"x": X, "y": Y, "valid": valid, "pad": pad}


# ---------------------------------------------------------------------------
# モデル: decoder-only 因果 Transformer
# ---------------------------------------------------------------------------
class PositionalEncoding(nn.Module):
    """系列位置を表す正弦波位置符号(学習パラメータなし)。"""
    def __init__(self, d_model: int, max_len: int = 4096):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, : x.size(1), :]


class TrajectoryTransformer(nn.Module):
    """因果マスク付き Transformer で「次の移動量」を予測する decoder-only モデル。"""

    def __init__(self, cfg: TrajConfig):
        super().__init__()
        self.cfg = cfg
        self.input_proj = nn.Linear(cfg.input_dim, cfg.d_model)
        self.pos = PositionalEncoding(cfg.d_model, max_len=max(cfg.max_len + 8, 64))
        self.drop = nn.Dropout(cfg.dropout)
        layer = nn.TransformerEncoderLayer(
            d_model=cfg.d_model, nhead=cfg.nhead, dim_feedforward=cfg.dim_feedforward,
            dropout=cfg.dropout, batch_first=True, activation="gelu",
        )
        # TransformerEncoder + 因果マスク = decoder-only(GPT風)として使う。
        self.backbone = nn.TransformerEncoder(layer, num_layers=cfg.num_layers)
        self.head = nn.Sequential(
            nn.Linear(cfg.d_model, cfg.d_model), nn.GELU(), nn.Dropout(cfg.dropout),
            nn.Linear(cfg.d_model, int(getattr(cfg, "out_dim", 2))),  # 次の移動量 (dx,dy) [+停止logit]
        )

    def forward(self, x: torch.Tensor, pad_mask: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: [B, L, F] 入力特徴量(標準化済み)。
            pad_mask: [B, L] True=パディング。
        Returns:
            [B, L, out_dim] 各位置における「次の移動量」予測(標準化スケール)。
            out_dim=3 のとき最終チャネルは停止logit。
        """
        L = x.size(1)
        h = self.drop(self.pos(self.input_proj(x)))
        # 因果マスク: 位置 i は i 以前しか見られない(未来を見せない)。
        causal = torch.triu(torch.ones(L, L, device=x.device, dtype=torch.bool), diagonal=1)
        h = self.backbone(h, mask=causal, src_key_padding_mask=pad_mask)
        return self.head(h)


def build_model(cfg: TrajConfig) -> TrajectoryTransformer:
    return TrajectoryTransformer(cfg)


# ---------------------------------------------------------------------------
# 標準化統計の推定 / ファイル列挙 / checkpoint 読み込み
# ---------------------------------------------------------------------------
def fit_stats(files: List[Path], feature_cols: List[str], sample: int, seed: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """移動量(dx,dy)と追加特徴量の mean/std を、サンプル航跡から推定する。"""
    rng = random.Random(seed)
    picks = files if len(files) <= sample else rng.sample(files, sample)
    disp_all, feat_all = [], []
    for p in picks:
        try:
            df = pd.read_csv(p)
            lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
            lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
        except Exception:
            continue
        d = lonlat_to_disp_km(lon, lat)
        if len(d) >= 2:
            disp_all.append(d[1:])                          # 先頭の0は除く
        if feature_cols:
            feat_all.append(build_feature_matrix(df, feature_cols).astype(np.float64))
    disp = np.concatenate(disp_all, axis=0) if disp_all else np.zeros((1, 2))
    disp_mean = disp.mean(axis=0); disp_std = disp.std(axis=0)
    disp_std = np.where(disp_std < 1e-6, 1.0, disp_std)

    if feature_cols:
        fa = np.concatenate(feat_all, axis=0)
        f_mean_extra = fa.mean(axis=0); f_std_extra = fa.std(axis=0)
        f_std_extra = np.where(f_std_extra < 1e-6, 1.0, f_std_extra)
        feat_mean = np.concatenate([disp_mean, f_mean_extra])
        feat_std = np.concatenate([disp_std, f_std_extra])
    else:
        feat_mean = disp_mean.copy(); feat_std = disp_std.copy()
    return disp_mean, disp_std, feat_mean, feat_std


def list_traj_files(data_dir: Path, pattern: str, limit: int) -> List[Path]:
    """航跡CSVの一覧を作る(limit>0 なら先頭N件)。"""
    files = sorted(data_dir.glob(pattern))
    if limit and limit > 0:
        files = files[:limit]
    return files


def cv_disp_from_seq(disp: np.ndarray, cv_n: int) -> np.ndarray:
    """各位置iの「次への等速(CV)予測移動量」= 直近cv_n点の移動量平均 を返す [L,2]。

    CV残差ターゲット版(traj_*_cvres.py)で、学習ターゲットと推論復元の両方に使う共通定義。
    位置iまでの移動量から「次も同じペースで動く」と仮定した等速予測。
    """
    disp = np.asarray(disp, dtype=np.float64)
    L = disp.shape[0]
    cv = np.zeros((L, 2), dtype=np.float64)
    if L == 0:
        return cv
    cs = np.cumsum(disp, axis=0)
    for i in range(L):
        s = max(0, i - int(cv_n) + 1)
        tot = cs[i] - (cs[s - 1] if s > 0 else np.zeros(2))
        cv[i] = tot / (i - s + 1)
    return cv


def load_model(model_path: Path, device) -> Tuple[TrajectoryTransformer, TrajConfig]:
    """checkpoint(traj_model.pt)からモデルとcfgを復元する。"""
    ckpt = torch.load(model_path, map_location=device, weights_only=False)
    cfg = TrajConfig(**ckpt["cfg"])
    model = build_model(cfg).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.eval()
    return model, cfg
