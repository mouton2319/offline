import numpy as np, pandas as pd
MAX_SHIFT=20

def wrap180(x):
    return ((x + 180.0) % 360.0) - 180.0

def load(y):
    df=pd.read_csv(f'/work/{y}_calc_az_el.csv', usecols=['date','AZ','EL'])
    dt=pd.to_datetime(df['date'])
    df['day']=dt.dt.strftime('%m-%d')
    df['minute']=dt.dt.hour*60+dt.dt.minute
    return df

def shift_arr(a, s):
    if s>=0:
        return np.r_[np.full(s,np.nan), a[:len(a)-s]] if s else a.copy()
    ss=-s
    return np.r_[a[ss:], np.full(ss,np.nan)]

def fit_params(prev, cur):
    out={}
    grp_prev={d:g.set_index('minute')[['AZ','EL']].reindex(range(1440)) for d,g in prev.groupby('day')}
    grp_cur={d:g.set_index('minute')[['AZ','EL']].reindex(range(1440)) for d,g in cur.groupby('day')}
    for d,c in grp_cur.items():
        p=grp_prev.get(d)
        if p is None: continue
        p_az=p['AZ'].to_numpy(); p_el=p['EL'].to_numpy(); c_az=c['AZ'].to_numpy(); c_el=c['EL'].to_numpy()
        best=None
        for s in range(-MAX_SHIFT, MAX_SHIFT+1):
            pa=shift_arr(p_az,s); pe=shift_arr(p_el,s)
            m=np.isfinite(pa)&np.isfinite(pe)&np.isfinite(c_az)&np.isfinite(c_el)
            if m.sum()<1000: continue
            da=wrap180(c_az[m]-pa[m]); de=c_el[m]-pe[m]
            azo=np.median(da); elo=np.median(de)
            rem=np.maximum(np.abs(wrap180(pa[m]+azo-c_az[m])), np.abs(pe[m]+elo-c_el[m]))
            sc=np.quantile(rem,0.99)
            if best is None or sc<best[0]: best=(sc,s,float(azo),float(elo),float(rem.max()),float(rem.mean()))
        if best is not None: out[d]=best
    return out, grp_prev, grp_cur

def apply_and_eval(prev_grp, cur_grp, params):
    az=[]; el=[]
    for d,c in cur_grp.items():
        p=prev_grp.get(d)
        if p is None or d not in params: continue
        s,azo,elo=params[d]
        pa=shift_arr(p['AZ'].to_numpy(), int(round(s)))
        pe=shift_arr(p['EL'].to_numpy(), int(round(s)))
        pa=pd.Series(pa).interpolate(limit_direction='both').to_numpy()
        pe=pd.Series(pe).interpolate(limit_direction='both').to_numpy()
        c_az=c['AZ'].to_numpy(); c_el=c['EL'].to_numpy()
        m=np.isfinite(pa)&np.isfinite(pe)&np.isfinite(c_az)&np.isfinite(c_el)
        da=np.abs(wrap180((pa[m]+azo)-c_az[m])); de=np.abs((pe[m]+elo)-c_el[m])
        az.append(da); el.append(de)
    az=np.concatenate(az); el=np.concatenate(el)
    return float((az.mean()+el.mean())/2), float(max(az.max(), el.max()))

prev22=load(2022); cur23=load(2023); cur24=load(2024); prev23=load(2023); prev21=load(2021); cur22=load(2022)
params23, grp22, grp23 = fit_params(prev22, cur23)
params22, grp21, grp22b = fit_params(prev21, cur22)
_, grp23prev, grp24 = fit_params(prev23, cur24)

p_last={d:(v[1],v[2],v[3]) for d,v in params23.items()}
print('last', apply_and_eval(grp23prev, grp24, p_last))
p_damped={}
for d,v in params23.items():
    s,azo,elo=v[1],v[2],v[3]
    if d in params22:
        s=float(np.clip(s + 0.5*(s-params22[d][1]), -MAX_SHIFT, MAX_SHIFT))
        azo=float(azo + 0.5*(azo-params22[d][2]))
        elo=float(elo + 0.5*(elo-params22[d][3]))
    p_damped[d]=(s,azo,elo)
print('damped', apply_and_eval(grp23prev, grp24, p_damped))
p_mean={}
for d,v in params23.items():
    s,azo,elo=v[1],v[2],v[3]
    if d in params22:
        s=(s+params22[d][1])/2; azo=(azo+params22[d][2])/2; elo=(elo+params22[d][3])/2
    p_mean[d]=(s,azo,elo)
print('mean2', apply_and_eval(grp23prev, grp24, p_mean))
