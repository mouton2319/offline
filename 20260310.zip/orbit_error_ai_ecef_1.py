#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
【要約（200〜400字程度）】
単一TLE＋そのTLEから計算したbaseline軌道（Lat/Lon/Alt）を入力とし、真値との差（true−baseline）をECEF位置残差Δr[km]として学習します。モデルは平均＋対数分散（不確かさ）を同時推定し、推論時はalpha（検証で推定）×不確かさゲート×クリップで過補正を抑制して「baselineを壊さない」ことを最優先に設計しました。補正後はECEF→測地座標へ戻し、AZ/ELは観測点から再計算して整合性を保ちます。

【使い方（例）】
(1) 学習（2023）
  python3.11 orbit_error_ai_ecef.py train \
    --tle-dir 28628_2023 --pred-dir 28628_2023_csv --err-dir 28628_2023_error \
    --truth-csv 2023_calc_az_el.csv --out-model orbit_error_model_ecef \
    --epochs 80 --batch-size 4096 --lr 1e-3 --early-stop-patience 10 --overwrite

(2) 予測＋補正（2024、プロット/評価まで自動）
  python3.11 orbit_error_ai_ecef.py predict \
    --model orbit_error_model_ecef \
    --tle-file 28628_2024/2024-03-03-01-41-42.txt \
    --baseline-csv 28628_2024_csv/2024-03-03-01-41-42.csv \
    --out-corrected-csv 28628_2024_corrected/2024-03-03-01-41-42.csv \
    --out-pred-delta-csv 28628_2024_corrected/2024-03-03-01-41-42_pred_delta.csv \
    --truth-csv 2024_calc_az_el.csv --plot-dir 28628_2024_corrected/plots \
    --days 30 --step-minutes 1 --sigma-gate-km 10 --clip-k-sigma 5 --plot-sample-every 5 --overwrite

【前提とデフォルト】
- CSV形式: date,UNIX,Lat,Lon,Alt,AZ,EL（Lat/Lon/AZ/ELはdeg、Altはkmを想定）
- 学習/予測ホライズン: 30日（1分刻み）
- 真値との突合はUNIX完全一致のみ（補間しません）
- 観測点（AZ/EL再計算）デフォルト: lat=36.3022, lon=137.9031, alt=0.0[km]

【参考（式の根拠、コメント内にURL記載）】
- ESA Navipedia: ECEF<->ENU変換、Az/El計算
- MathWorks: ecef2lla / lla2ecef（WGS84）
- Skyfield docs: TLE/SGP4の有効期間や精度目安

"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import tensorflow as tf


# =========================
# 基本ユーティリティ
# =========================

def log(msg: str) -> None:
    """標準出力へ簡潔なログを出す。"""
    print(msg, flush=True)


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def now_jst_str() -> str:
    jst = dt.timezone(dt.timedelta(hours=9))
    return dt.datetime.now(tz=jst).strftime("%Y-%m-%d %H:%M:%S%z")


# =========================
# 角度/周期量の処理
# =========================

def wrap360(deg: np.ndarray) -> np.ndarray:
    """[0, 360)へ正規化（numpy対応）。"""
    return np.mod(deg, 360.0)


def wrap180(deg: np.ndarray) -> np.ndarray:
    """[-180, 180)へ正規化（numpy対応）。"""
    x = np.mod(deg + 180.0, 360.0) - 180.0
    return x


def angle_diff_deg(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """角度差 a - b を最短弧で返す（deg, [-180,180)）。"""
    return wrap180(a - b)


def sincos_deg(deg: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    rad = np.deg2rad(deg)
    return np.sin(rad), np.cos(rad)


# =========================
# WGS84: LLA <-> ECEF（km系）
# =========================
# 参考:
# - MathWorks ecef2lla / lla2ecef（WGS84の測地座標変換）:
#   https://jp.mathworks.com/help/aerotbx/ug/ecef2lla.html
#   https://www.mathworks.com/help/aerotbx/ug/lla2ecef.html
# - WGS84の式はDoD WGS84 TR8350.2等に基づくことが多い（MathWorks FileExchange例）:
#   https://jp.mathworks.com/matlabcentral/fileexchange/7942-covert-lat-lon-alt-to-ecef-cartesian
#
# ENU変換・Az/El算出:
# - ESA Navipedia:
#   https://gssc.esa.int/navipedia/index.php/Transformations_between_ECEF_and_ENU_coordinates

WGS84_A_KM = 6378.137  # km
WGS84_F = 1.0 / 298.257223563
WGS84_B_KM = WGS84_A_KM * (1.0 - WGS84_F)
WGS84_E2 = WGS84_F * (2.0 - WGS84_F)  # 第一離心率^2
WGS84_EP2 = (WGS84_A_KM**2 - WGS84_B_KM**2) / (WGS84_B_KM**2)  # 第二離心率^2


def lla_to_ecef_km(lat_deg: np.ndarray, lon_deg: np.ndarray, alt_km: np.ndarray) -> np.ndarray:
    """測地座標→ECEF(km)。"""
    lat = np.deg2rad(lat_deg)
    lon = np.deg2rad(lon_deg)

    sin_lat = np.sin(lat)
    cos_lat = np.cos(lat)
    sin_lon = np.sin(lon)
    cos_lon = np.cos(lon)

    N = WGS84_A_KM / np.sqrt(1.0 - WGS84_E2 * sin_lat**2)

    x = (N + alt_km) * cos_lat * cos_lon
    y = (N + alt_km) * cos_lat * sin_lon
    z = (N * (1.0 - WGS84_E2) + alt_km) * sin_lat
    return np.stack([x, y, z], axis=-1)


def ecef_to_lla_km(x_km: np.ndarray, y_km: np.ndarray, z_km: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """ECEF(km)→測地座標(lat, lon, alt[km])。Bowring近似。"""
    x = np.asarray(x_km)
    y = np.asarray(y_km)
    z = np.asarray(z_km)

    lon = np.arctan2(y, x)

    p = np.sqrt(x**2 + y**2)
    theta = np.arctan2(z * WGS84_A_KM, p * WGS84_B_KM)

    sin_theta = np.sin(theta)
    cos_theta = np.cos(theta)

    lat = np.arctan2(
        z + WGS84_EP2 * WGS84_B_KM * sin_theta**3,
        p - WGS84_E2 * WGS84_A_KM * cos_theta**3
    )

    sin_lat = np.sin(lat)
    N = WGS84_A_KM / np.sqrt(1.0 - WGS84_E2 * sin_lat**2)
    alt = p / np.cos(lat) - N

    lat_deg = np.rad2deg(lat)
    lon_deg = np.rad2deg(lon)
    lon_deg = wrap180(lon_deg)
    return lat_deg, lon_deg, alt


def ecef_to_enu_km(sat_ecef_km: np.ndarray, obs_lat_deg: float, obs_lon_deg: float, obs_alt_km: float = 0.0) -> np.ndarray:
    """観測点(LLA)に対する衛星位置のENUベクトル（km）。"""
    obs_ecef = lla_to_ecef_km(np.array(obs_lat_deg), np.array(obs_lon_deg), np.array(obs_alt_km)).reshape(3,)
    d = sat_ecef_km - obs_ecef.reshape(1, 3)

    lat = math.radians(obs_lat_deg)
    lon = math.radians(obs_lon_deg)

    sin_lat = math.sin(lat); cos_lat = math.cos(lat)
    sin_lon = math.sin(lon); cos_lon = math.cos(lon)

    # NavipediaのECEF→ENU変換行列を使用
    t = np.array([
        [-sin_lon,           cos_lon,          0.0],
        [-cos_lon*sin_lat,  -sin_lon*sin_lat,  cos_lat],
        [ cos_lon*cos_lat,   sin_lon*cos_lat,  sin_lat],
    ], dtype=np.float64)

    return d @ t.T


def enu_to_az_el_deg(enu_km: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """ENU(km)→AZ/EL(deg)。Az=atan2(E,N), El=atan2(U,sqrt(E^2+N^2))。"""
    e = enu_km[:, 0]
    n = enu_km[:, 1]
    u = enu_km[:, 2]

    az = np.rad2deg(np.arctan2(e, n))
    az = wrap360(az)

    horiz = np.sqrt(e**2 + n**2)
    el = np.rad2deg(np.arctan2(u, horiz))
    el = np.clip(el, -90.0, 90.0)
    return az, el


# =========================
# TLEパーサ
# =========================

@dataclasses.dataclass
class TLEInfo:
    inc_deg: float
    raan_deg: float
    ecc: float
    argp_deg: float
    mean_anom_deg: float
    mean_motion_rev_per_day: float
    bstar: float
    ndot: float
    nddot: float
    epoch_utc: dt.datetime


def _parse_tle_epoch(epoch_year_2digit: int, epoch_day: float) -> dt.datetime:
    year = 1900 + epoch_year_2digit if epoch_year_2digit >= 57 else 2000 + epoch_year_2digit
    day_int = int(math.floor(epoch_day))
    frac = epoch_day - day_int
    base = dt.datetime(year, 1, 1, tzinfo=dt.timezone.utc) + dt.timedelta(days=day_int - 1)
    return base + dt.timedelta(days=frac)


def _parse_tle_exponent_field(s: str) -> float:
    s = s.strip()
    if not s:
        return 0.0
    sign = 1.0
    if s[0] == '-':
        sign = -1.0
        s = s[1:]
    elif s[0] == '+':
        s = s[1:]
    if '+' in s[1:]:
        i = s[1:].index('+') + 1
        mant = s[:i]
        exp = s[i:]
    elif '-' in s[1:]:
        i = s[1:].index('-') + 1
        mant = s[:i]
        exp = s[i:]
    else:
        return sign * float(s)
    mant_f = float("0." + mant)
    exp_i = int(exp)
    return sign * mant_f * (10.0 ** exp_i)


def parse_tle_file(tle_path: Path) -> TLEInfo:
    lines = [ln.strip('\n') for ln in tle_path.read_text(encoding='utf-8', errors='ignore').splitlines() if ln.strip()]
    if len(lines) < 2:
        raise ValueError(f"TLE lines < 2: {tle_path}")
    if lines[0].startswith('1 ') and lines[1].startswith('2 '):
        line1, line2 = lines[0], lines[1]
    else:
        line1, line2 = lines[-2], lines[-1]
        if not (line1.startswith('1 ') and line2.startswith('2 ')):
            raise ValueError(f"Unrecognized TLE format: {tle_path}")

    epoch_year = int(line1[18:20])
    epoch_day = float(line1[20:32])
    ndot = float(line1[33:43].strip() or 0.0)
    nddot = _parse_tle_exponent_field(line1[44:52])
    bstar = _parse_tle_exponent_field(line1[53:61])
    epoch_utc = _parse_tle_epoch(epoch_year, epoch_day)

    inc_deg = float(line2[8:16])
    raan_deg = float(line2[17:25])
    ecc = float("0." + line2[26:33].strip())
    argp_deg = float(line2[34:42])
    mean_anom_deg = float(line2[43:51])
    mean_motion = float(line2[52:63])

    return TLEInfo(
        inc_deg=inc_deg,
        raan_deg=raan_deg,
        ecc=ecc,
        argp_deg=argp_deg,
        mean_anom_deg=mean_anom_deg,
        mean_motion_rev_per_day=mean_motion,
        bstar=bstar,
        ndot=ndot,
        nddot=nddot,
        epoch_utc=epoch_utc,
    )


# =========================
# オンライン統計
# =========================

class OnlineMeanVar:
    def __init__(self, dim: int):
        self.dim = dim
        self.n = 0
        self.mean = np.zeros(dim, dtype=np.float64)
        self.M2 = np.zeros(dim, dtype=np.float64)

    def update(self, x: np.ndarray) -> None:
        x = np.asarray(x, dtype=np.float64)
        if x.ndim == 1:
            x = x.reshape(1, -1)
        for row in x:
            self.n += 1
            delta = row - self.mean
            self.mean += delta / self.n
            delta2 = row - self.mean
            self.M2 += delta * delta2

    def finalize(self, eps: float = 1e-12) -> Tuple[np.ndarray, np.ndarray]:
        if self.n < 2:
            var = np.ones(self.dim, dtype=np.float64)
        else:
            var = self.M2 / (self.n - 1)
        std = np.sqrt(np.maximum(var, eps))
        return self.mean.astype(np.float64), std.astype(np.float64)


# =========================
# 特徴量生成
# =========================

@dataclasses.dataclass
class FeatureConfig:
    days_horizon: int = 30
    step_minutes: int = 1
    sample_every: int = 1
    include_az_el_deriv: bool = True


def _unix_to_utc_datetime(unix_s: np.ndarray) -> List[dt.datetime]:
    return [dt.datetime.fromtimestamp(int(u), tz=dt.timezone.utc) for u in unix_s.tolist()]


def _time_features_from_unix(unix_s: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    dts = _unix_to_utc_datetime(unix_s)
    doy = np.empty(len(dts), dtype=np.float64)
    tod = np.empty(len(dts), dtype=np.float64)
    for i, t in enumerate(dts):
        day_of_year = t.timetuple().tm_yday
        sec_of_day = t.hour * 3600 + t.minute * 60 + t.second
        doy[i] = day_of_year + sec_of_day / 86400.0
        tod[i] = sec_of_day / 86400.0
    year_len = 365.2422
    doy_phase = 2.0 * math.pi * (doy / year_len)
    tod_phase = 2.0 * math.pi * tod
    return np.sin(doy_phase), np.cos(doy_phase), np.sin(tod_phase), np.cos(tod_phase)


def _ecef_velocity_km_s(ecef_km: np.ndarray, dt_seconds: float) -> np.ndarray:
    return np.gradient(ecef_km, dt_seconds, axis=0).astype(np.float64)


def _az_el_derivative_deg_s(az_deg: np.ndarray, el_deg: np.ndarray, dt_seconds: float) -> Tuple[np.ndarray, np.ndarray]:
    az = az_deg.astype(np.float64)
    el = el_deg.astype(np.float64)
    daz = np.empty_like(az)
    delv = np.empty_like(el)
    daz[0] = angle_diff_deg(np.array([az[1]]), np.array([az[0]]))[0] / dt_seconds
    daz[-1] = angle_diff_deg(np.array([az[-1]]), np.array([az[-2]]))[0] / dt_seconds
    delv[0] = (el[1] - el[0]) / dt_seconds
    delv[-1] = (el[-1] - el[-2]) / dt_seconds
    if len(az) > 2:
        daz[1:-1] = angle_diff_deg(az[2:], az[:-2]) / (2.0 * dt_seconds)
        delv[1:-1] = (el[2:] - el[:-2]) / (2.0 * dt_seconds)
    return daz, delv


def build_features(
    tle_info: TLEInfo,
    baseline_df: pd.DataFrame,
    truth_df: Optional[pd.DataFrame],
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, Optional[np.ndarray], np.ndarray, pd.DataFrame]:
    df = baseline_df.copy()
    df['UNIX'] = df['UNIX'].astype(np.int64)

    if len(df) > 0:
        start_unix = int(df['UNIX'].iloc[0])
        end_unix = start_unix + int(cfg.days_horizon * 86400)
        df = df[df['UNIX'] < end_unix].reset_index(drop=True)

    if cfg.sample_every > 1:
        df = df.iloc[::cfg.sample_every].reset_index(drop=True)

    if truth_df is not None:
        merged = df.join(truth_df, on='UNIX', how='inner', rsuffix='_true')
    else:
        merged = df

    if len(merged) == 0:
        return np.zeros((0, 1), dtype=np.float32), None, np.zeros((0, 3), dtype=np.float64), merged

    lat = merged['Lat'].to_numpy(np.float64)
    lon = merged['Lon'].to_numpy(np.float64)
    alt = merged['Alt'].to_numpy(np.float64)

    baseline_ecef = lla_to_ecef_km(lat, lon, alt)
    dt_seconds = float(cfg.step_minutes * 60)
    baseline_vel = _ecef_velocity_km_s(baseline_ecef, dt_seconds)

    unix = merged['UNIX'].to_numpy(np.int64)
    elapsed = (unix - unix[0]).astype(np.float64)
    horizon_sec = float(cfg.days_horizon * 86400)
    dt_norm = np.clip(elapsed / horizon_sec, 0.0, 1.0)

    doy_sin, doy_cos, tod_sin, tod_cos = _time_features_from_unix(unix)

    tle_epoch_unix = int(tle_info.epoch_utc.timestamp())
    tle_age_min = (unix.astype(np.float64) - float(tle_epoch_unix)) / 60.0

    inc = tle_info.inc_deg
    raan = tle_info.raan_deg
    argp = tle_info.argp_deg
    M = tle_info.mean_anom_deg
    raan_s, raan_c = sincos_deg(np.array(raan))
    argp_s, argp_c = sincos_deg(np.array(argp))
    M_s, M_c = sincos_deg(np.array(M))

    if 'AZ' in merged.columns and 'EL' in merged.columns:
        baz = merged['AZ'].to_numpy(np.float64)
        bel = merged['EL'].to_numpy(np.float64)
        baz_s, baz_c = sincos_deg(baz)
        bel_s, bel_c = sincos_deg(bel)
        if cfg.include_az_el_deriv:
            dbaz, dbel = _az_el_derivative_deg_s(baz, bel, dt_seconds)
        else:
            dbaz = np.zeros_like(baz); dbel = np.zeros_like(bel)
    else:
        baz_s = np.zeros(len(merged)); baz_c = np.zeros(len(merged))
        bel_s = np.zeros(len(merged)); bel_c = np.zeros(len(merged))
        dbaz = np.zeros(len(merged)); dbel = np.zeros(len(merged))

    def const(v: float) -> np.ndarray:
        return np.full(len(merged), float(v), dtype=np.float64)

    feats: List[np.ndarray] = []
    feats.extend([
        const(inc),
        const(raan),
        const(tle_info.ecc),
        const(argp),
        const(M),
        const(tle_info.mean_motion_rev_per_day),
        const(tle_info.bstar),
        const(tle_info.ndot),
        const(tle_info.nddot),
        const(float(raan_s)), const(float(raan_c)),
        const(float(argp_s)), const(float(argp_c)),
        const(float(M_s)), const(float(M_c)),
        tle_age_min,
        dt_norm,
        doy_sin, doy_cos,
        tod_sin, tod_cos,
        baseline_ecef[:, 0], baseline_ecef[:, 1], baseline_ecef[:, 2],
        baseline_vel[:, 0], baseline_vel[:, 1], baseline_vel[:, 2],
        baz_s, baz_c, bel_s, bel_c,
        dbaz, dbel,
    ])

    X = np.stack(feats, axis=1).astype(np.float32)

    Y = None
    if truth_df is not None:
        lat_t = merged['Lat_true'].to_numpy(np.float64)
        lon_t = merged['Lon_true'].to_numpy(np.float64)
        alt_t = merged['Alt_true'].to_numpy(np.float64)
        true_ecef = lla_to_ecef_km(lat_t, lon_t, alt_t)
        Y = (true_ecef - baseline_ecef).astype(np.float32)

    return X, Y, baseline_ecef.astype(np.float64), merged


def feature_names(cfg: FeatureConfig) -> List[str]:
    return [
        "tle_inc_deg",
        "tle_raan_deg",
        "tle_ecc",
        "tle_argp_deg",
        "tle_M_deg",
        "tle_mean_motion_rev_per_day",
        "tle_bstar",
        "tle_ndot",
        "tle_nddot",
        "tle_raan_sin", "tle_raan_cos",
        "tle_argp_sin", "tle_argp_cos",
        "tle_M_sin", "tle_M_cos",
        "tle_age_min",
        "dt_norm",
        "doy_sin", "doy_cos",
        "tod_sin", "tod_cos",
        "base_x_km", "base_y_km", "base_z_km",
        "base_vx_km_s", "base_vy_km_s", "base_vz_km_s",
        "base_az_sin", "base_az_cos",
        "base_el_sin", "base_el_cos",
        "base_daz_deg_s", "base_del_deg_s",
    ]


# =========================
# モデル
# =========================

class GaussianNLL(tf.keras.losses.Loss):
    def __init__(self, name: str = "gaussian_nll"):
        super().__init__(reduction=tf.keras.losses.Reduction.NONE, name=name)
        self.log2pi = math.log(2.0 * math.pi)

    def call(self, y_true, y_pred):
        mean = y_pred[:, 0:3]
        logvar = y_pred[:, 3:6]
        logvar = tf.clip_by_value(logvar, -20.0, 10.0)
        inv_var = tf.exp(-logvar)
        sq = tf.square(y_true - mean)
        nll = 0.5 * (tf.reduce_sum(inv_var * sq + logvar + self.log2pi, axis=1))
        return nll


def build_mlp_model(input_dim: int, dt_norm_idx: int, hidden: Sequence[int], l2: float, dropout: float) -> tf.keras.Model:
    x_in = tf.keras.Input(shape=(input_dim,), name="x")
    h = x_in
    for i, units in enumerate(hidden):
        h = tf.keras.layers.Dense(
            units, activation="relu",
            kernel_regularizer=tf.keras.regularizers.l2(l2) if l2 > 0 else None,
            name=f"dense_{i}",
        )(h)
        if dropout > 0:
            h = tf.keras.layers.Dropout(dropout, name=f"drop_{i}")(h)
    out = tf.keras.layers.Dense(
        6, activation=None,
        kernel_regularizer=tf.keras.regularizers.l2(l2) if l2 > 0 else None,
        name="out_mean_logvar",
    )(h)

    raw_mean = out[:, 0:3]
    logvar = out[:, 3:6]
    dt_norm = tf.expand_dims(x_in[:, dt_norm_idx], axis=1)
    mean = dt_norm * raw_mean
    y_out = tf.concat([mean, logvar], axis=1)
    return tf.keras.Model(inputs=x_in, outputs=y_out, name="orbit_error_ecef_mlp")


# =========================
# 保存・読込
# =========================

def is_model_file(path: Path) -> bool:
    return path.suffix.lower() in (".keras", ".h5")


def resolve_model_and_meta(model_arg: Path) -> Tuple[Path, Path]:
    if model_arg.is_dir():
        return model_arg / "model.keras", model_arg / "meta.json"
    model_path = model_arg
    meta_path = model_arg.parent / "meta.json"
    if not meta_path.exists():
        alt = model_arg.with_suffix(model_arg.suffix + ".meta.json")
        if alt.exists():
            meta_path = alt
    return model_path, meta_path


def save_model_and_meta(model: tf.keras.Model, meta: Dict, out_model: Path, overwrite: bool) -> Tuple[Path, Path]:
    if is_model_file(out_model):
        model_path = out_model
        meta_path = out_model.parent / "meta.json"
        if (model_path.exists() or meta_path.exists()) and not overwrite:
            raise FileExistsError(f"Output exists (use --overwrite): {out_model}")
        ensure_dir(out_model.parent)
        model.save(str(model_path))
        meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return model_path, meta_path

    out_dir = out_model
    ensure_dir(out_dir)
    model_path = out_dir / "model.keras"
    meta_path = out_dir / "meta.json"
    if (model_path.exists() or meta_path.exists()) and not overwrite:
        raise FileExistsError(f"Output exists (use --overwrite): {out_dir}")
    model.save(str(model_path))
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return model_path, meta_path


def load_model_and_meta(model_arg: Path) -> Tuple[tf.keras.Model, Dict]:
    model_path, meta_path = resolve_model_and_meta(model_arg)
    if not model_path.exists():
        raise FileNotFoundError(f"model not found: {model_path}")
    if not meta_path.exists():
        raise FileNotFoundError(f"meta not found: {meta_path}")
    model = tf.keras.models.load_model(str(model_path), compile=False)
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    return model, meta


# =========================
# メトリクス
# =========================

@dataclasses.dataclass
class Metrics:
    """評価用メトリクス（UNIXでinner joinした行のみで計算）"""
    rows: int
    mae: Dict[str, float]
    rmse: Dict[str, float]


def _mae_rmse(a: np.ndarray, b: np.ndarray, is_angle: bool = False) -> Tuple[float, float]:
    if is_angle:
        diff = angle_diff_deg(a, b)
    else:
        diff = a - b
    mae = float(np.mean(np.abs(diff)))
    rmse = float(np.sqrt(np.mean(diff**2)))
    return mae, rmse

def _coerce_unix_int64(df: pd.DataFrame) -> pd.DataFrame:
    """UNIX列を安全にint64へ変換する。

    - float/str/Int64 など混在に耐える
    - indexがUNIXのDataFrameも受ける（reset_indexして列化）
    """
    if "UNIX" not in df.columns:
        if getattr(df.index, "name", None) == "UNIX":
            df = df.reset_index()
        else:
            raise ValueError("UNIX列が見つかりません")
    s = pd.to_numeric(df["UNIX"], errors="coerce").round()
    out = df.copy()
    out["UNIX"] = s.astype("Int64")
    out = out.dropna(subset=["UNIX"]).copy()
    out["UNIX"] = out["UNIX"].astype(np.int64)
    return out



def compute_metrics_latlonalt_az_el(
    truth: pd.DataFrame,
    base: pd.DataFrame,
    corr: pd.DataFrame,
) -> Tuple[Metrics, Metrics]:
    """真値(truth)と baseline / corrected を UNIX 完全一致で評価する（補間なし）。

    - 同一UNIXの行だけを inner join して MAE/RMSE を算出
    - 一致行が無い場合は rows=0 & NaN を返す（例外では止めない）
    """
    keys = ["Lat", "Lon", "Alt", "AZ", "EL"]

    def _prep(df: pd.DataFrame, suffix: str, label: str) -> pd.DataFrame:
        d = _coerce_unix_int64(df)
        missing = [k for k in keys if k not in d.columns]
        if missing:
            raise ValueError(f"{label}: missing columns: {missing}")
        d = d[["UNIX"] + keys].copy()
        d = d.drop_duplicates("UNIX", keep="last").sort_values("UNIX").reset_index(drop=True)
        ren = {k: f"{k}{suffix}" for k in keys}
        d = d.rename(columns=ren)
        return d

    t = _prep(truth, "_true", "truth")
    b = _prep(base,  "_base", "baseline")
    c = _prep(corr,  "_corr", "corrected")

    m = t.merge(b, on="UNIX", how="inner").merge(c, on="UNIX", how="inner")
    if len(m) == 0:
        nan = float("nan")
        empty = Metrics(rows=0, mae={k: nan for k in keys}, rmse={k: nan for k in keys})
        return empty, empty

    bm: Dict[str, Tuple[float, float]] = {}
    cm: Dict[str, Tuple[float, float]] = {}
    bm["Lat"] = _mae_rmse(m["Lat_base"].to_numpy(), m["Lat_true"].to_numpy(), False)
    bm["Lon"] = _mae_rmse(m["Lon_base"].to_numpy(), m["Lon_true"].to_numpy(), True)
    bm["Alt"] = _mae_rmse(m["Alt_base"].to_numpy(), m["Alt_true"].to_numpy(), False)
    bm["AZ"]  = _mae_rmse(m["AZ_base"].to_numpy(),  m["AZ_true"].to_numpy(),  True)
    bm["EL"]  = _mae_rmse(m["EL_base"].to_numpy(),  m["EL_true"].to_numpy(),  False)

    cm["Lat"] = _mae_rmse(m["Lat_corr"].to_numpy(), m["Lat_true"].to_numpy(), False)
    cm["Lon"] = _mae_rmse(m["Lon_corr"].to_numpy(), m["Lon_true"].to_numpy(), True)
    cm["Alt"] = _mae_rmse(m["Alt_corr"].to_numpy(), m["Alt_true"].to_numpy(), False)
    cm["AZ"]  = _mae_rmse(m["AZ_corr"].to_numpy(),  m["AZ_true"].to_numpy(),  True)
    cm["EL"]  = _mae_rmse(m["EL_corr"].to_numpy(),  m["EL_true"].to_numpy(),  False)

    base_metrics = Metrics(
        rows=int(len(m)),
        mae={k: v[0] for k, v in bm.items()},
        rmse={k: v[1] for k, v in bm.items()},
    )
    corr_metrics = Metrics(
        rows=int(len(m)),
        mae={k: v[0] for k, v in cm.items()},
        rmse={k: v[1] for k, v in cm.items()},
    )
    return base_metrics, corr_metrics




# =========================
# 補正適用
# =========================

def apply_delta_and_recompute(
    baseline_df: pd.DataFrame,
    baseline_ecef_km: np.ndarray,
    delta_km: np.ndarray,
    obs_lat: float,
    obs_lon: float,
    obs_alt_km: float = 0.0,
) -> pd.DataFrame:
    sat_ecef = baseline_ecef_km + delta_km
    lat_deg, lon_deg, alt_km = ecef_to_lla_km(sat_ecef[:, 0], sat_ecef[:, 1], sat_ecef[:, 2])
    enu = ecef_to_enu_km(sat_ecef, obs_lat, obs_lon, obs_alt_km)
    az_deg, el_deg = enu_to_az_el_deg(enu)

    out = baseline_df.copy()
    out["Lat"] = lat_deg
    out["Lon"] = lon_deg
    out["Alt"] = alt_km
    out["AZ"] = az_deg
    out["EL"] = el_deg
    return out


# =========================
# プロット
# =========================

def plot_compare(
    stem: str,
    truth_df: pd.DataFrame,
    baseline_df: pd.DataFrame,
    corrected_df: pd.DataFrame,
    out_dir: Path,
    sample_every: int = 5,
) -> None:
    """Truth / Baseline / Corrected を同一UNIXで比較してPNGを出力する。"""
    ensure_dir(out_dir)
    # headless環境（docker等）でも必ずPNG保存できるようにAgg backend固定
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    keys = ["Lat", "Lon", "Alt", "AZ", "EL"]

    def _prep(df: pd.DataFrame, suffix: str, label: str) -> pd.DataFrame:
        d = _coerce_unix_int64(df)
        missing = [k for k in keys if k not in d.columns]
        if missing:
            raise ValueError(f"{label}: missing columns: {missing}")
        d = d[["UNIX"] + keys].copy()
        d = d.drop_duplicates("UNIX", keep="last").sort_values("UNIX").reset_index(drop=True)
        ren = {k: f"{k}{suffix}" for k in keys}
        return d.rename(columns=ren)

    t = _prep(truth_df, "_true", "truth")
    b = _prep(baseline_df, "_base", "baseline")
    c = _prep(corrected_df, "_corr", "corrected")
    m = t.merge(b, on="UNIX", how="inner").merge(c, on="UNIX", how="inner")
    if len(m) == 0:
        log("[WARN] plot_compare skipped: no matching UNIX")
        return

    if sample_every > 1:
        mp = m.iloc[::sample_every].copy()
    else:
        mp = m

    unix0 = int(mp["UNIX"].iloc[0])
    t_day = (mp["UNIX"].to_numpy(np.float64) - float(unix0)) / 86400.0

    specs = [("Lat", False), ("Lon", True), ("Alt", False), ("AZ", True), ("EL", False)]
    for key, is_angle in specs:
        y_true = mp[f"{key}_true"].to_numpy(np.float64)
        y_base = mp[f"{key}_base"].to_numpy(np.float64)
        y_corr = mp[f"{key}_corr"].to_numpy(np.float64)

        if is_angle:
            e_base = np.abs(angle_diff_deg(y_base, y_true))
            e_corr = np.abs(angle_diff_deg(y_corr, y_true))
        else:
            e_base = np.abs(y_base - y_true)
            e_corr = np.abs(y_corr - y_true)

        fig = plt.figure(figsize=(12, 7))
        ax1 = fig.add_subplot(2, 1, 1)
        ax1.plot(t_day, y_true, label="Truth")
        ax1.plot(t_day, y_base, label="Baseline")
        ax1.plot(t_day, y_corr, label="Corrected")
        ax1.set_title(f"{stem} : {key} 値（間引き={sample_every}）")
        ax1.set_xlabel("経過日"); ax1.set_ylabel(key)
        ax1.grid(True); ax1.legend()

        ax2 = fig.add_subplot(2, 1, 2)
        ax2.plot(t_day, e_base, label="|Baseline-Truth|")
        ax2.plot(t_day, e_corr, label="|Corrected-Truth|")
        ax2.set_title(f"{stem} : {key} 絶対誤差（間引き={sample_every}）")
        ax2.set_xlabel("経過日"); ax2.set_ylabel("|error|")
        ax2.grid(True); ax2.legend()

        out_path = out_dir / f"{stem}_{key}.png"
        fig.tight_layout()
        fig.savefig(out_path, dpi=150)
        plt.close(fig)


def plot_baseline_vs_corrected(
    stem: str,
    baseline_df: pd.DataFrame,
    corrected_df: pd.DataFrame,
    out_dir: Path,
    sample_every: int = 5,
) -> None:
    """truthが無い/一致しない場合でも、Baseline vs Corrected をPNGで確認できるようにする。"""
    ensure_dir(out_dir)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    keys = ["Lat", "Lon", "Alt", "AZ", "EL"]

    def _prep(df: pd.DataFrame, suffix: str, label: str) -> pd.DataFrame:
        d = _coerce_unix_int64(df)
        missing = [k for k in keys if k not in d.columns]
        if missing:
            raise ValueError(f"{label}: missing columns: {missing}")
        d = d[["UNIX"] + keys].copy()
        d = d.drop_duplicates("UNIX", keep="last").sort_values("UNIX").reset_index(drop=True)
        ren = {k: f"{k}{suffix}" for k in keys}
        return d.rename(columns=ren)

    b = _prep(baseline_df, "_base", "baseline")
    c = _prep(corrected_df, "_corr", "corrected")
    m = b.merge(c, on="UNIX", how="inner")
    if len(m) == 0:
        log("[WARN] plot_baseline_vs_corrected skipped: no matching UNIX")
        return

    if sample_every > 1:
        mp = m.iloc[::sample_every].copy()
    else:
        mp = m

    unix0 = int(mp["UNIX"].iloc[0])
    t_day = (mp["UNIX"].to_numpy(np.float64) - float(unix0)) / 86400.0

    specs = [("Lat", False), ("Lon", True), ("Alt", False), ("AZ", True), ("EL", False)]
    for key, is_angle in specs:
        y_base = mp[f"{key}_base"].to_numpy(np.float64)
        y_corr = mp[f"{key}_corr"].to_numpy(np.float64)
        if is_angle:
            diff = angle_diff_deg(y_corr, y_base)  # corr - base (wrap考慮)
        else:
            diff = y_corr - y_base

        fig = plt.figure(figsize=(12, 7))
        ax1 = fig.add_subplot(2, 1, 1)
        ax1.plot(t_day, y_base, label="Baseline")
        ax1.plot(t_day, y_corr, label="Corrected")
        ax1.set_title(f"{stem} : {key} 値（Baseline vs Corrected / 間引き={sample_every}）")
        ax1.set_xlabel("経過日"); ax1.set_ylabel(key)
        ax1.grid(True); ax1.legend()

        ax2 = fig.add_subplot(2, 1, 2)
        ax2.plot(t_day, np.abs(diff), label="|Corrected-Baseline|")
        ax2.set_title(f"{stem} : {key} 差分の絶対値（|corr-base| / 間引き={sample_every}）")
        ax2.set_xlabel("経過日"); ax2.set_ylabel("|diff|")
        ax2.grid(True); ax2.legend()

        out_path = out_dir / f"{stem}_{key}_baseline_vs_corrected.png"
        fig.tight_layout()
        fig.savefig(out_path, dpi=150)
        plt.close(fig)


def plot_delta_summary(
    stem: str,
    delta_df: pd.DataFrame,
    out_dir: Path,
    sample_every: int = 5,
) -> None:
    """予測した補正Δ（ECEF）と不確かさ/weightの挙動をPNGで出力してデバッグしやすくする。"""
    ensure_dir(out_dir)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    d = _coerce_unix_int64(delta_df)
    need = ["dx_final_km", "dy_final_km", "dz_final_km", "sigma_rms_km", "weight"]
    miss = [c for c in need if c not in d.columns]
    if miss:
        log(f"[WARN] plot_delta_summary skipped: missing columns {miss}")
        return

    d = d.sort_values("UNIX").reset_index(drop=True)
    if sample_every > 1:
        dp = d.iloc[::sample_every].copy()
    else:
        dp = d

    if len(dp) == 0:
        log("[WARN] plot_delta_summary skipped: empty")
        return

    unix0 = int(dp["UNIX"].iloc[0])
    t_day = (dp["UNIX"].to_numpy(np.float64) - float(unix0)) / 86400.0

    dx = dp["dx_final_km"].to_numpy(np.float64)
    dy = dp["dy_final_km"].to_numpy(np.float64)
    dz = dp["dz_final_km"].to_numpy(np.float64)
    dr = np.sqrt(dx*dx + dy*dy + dz*dz)

    fig = plt.figure(figsize=(12, 7))
    ax1 = fig.add_subplot(2, 1, 1)
    ax1.plot(t_day, dr, label="|Δr_final| [km]")
    ax1.plot(t_day, dp["sigma_rms_km"].to_numpy(np.float64), label="sigma_rms [km]")
    if all(c in dp.columns for c in ["dx_mean_km", "dy_mean_km", "dz_mean_km"]):
        dm = np.sqrt(
            dp["dx_mean_km"].to_numpy(np.float64)**2
            + dp["dy_mean_km"].to_numpy(np.float64)**2
            + dp["dz_mean_km"].to_numpy(np.float64)**2
        )
        ax1.plot(t_day, dm, label="|Δr_mean| [km]")
    ax1.set_title(f"{stem} : predicted delta / uncertainty（間引き={sample_every}）")
    ax1.set_xlabel("経過日"); ax1.set_ylabel("km")
    ax1.grid(True); ax1.legend()

    ax2 = fig.add_subplot(2, 1, 2)
    ax2.plot(t_day, dp["weight"].to_numpy(np.float64), label="weight")
    ax2.set_title("uncertainty gate weight")
    ax2.set_xlabel("経過日"); ax2.set_ylabel("weight")
    ax2.set_ylim(-0.05, 1.05)
    ax2.grid(True); ax2.legend()

    out_path = out_dir / f"{stem}_delta_summary.png"
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# =========================
# データロード/一覧
# =========================

def load_truth_csv(truth_csv: Path) -> pd.DataFrame:
    """真値CSVをロードしてUNIX indexのDataFrameとして返す（学習用）。

    build_features() は df.join(truth_df, on='UNIX') を使うため、truth_df は UNIX を index に持つ必要があります。
    """
    df = pd.read_csv(truth_csv)
    df = _coerce_unix_int64(df)
    df = df.drop_duplicates("UNIX", keep="last").sort_values("UNIX")
    df = df.set_index("UNIX").sort_index()
    return df


def list_baseline_csv_files(pred_dir: Path) -> List[Path]:
    return sorted([p for p in pred_dir.glob("*.csv") if p.is_file()])


def stem_from_path(p: Path) -> str:
    return p.name[:-len(p.suffix)]


def deterministic_split(stem: str, val_split: float, seed: int) -> str:
    h = hashlib.md5((stem + str(seed)).encode("utf-8")).hexdigest()
    r = int(h[:8], 16) / float(16**8)
    return "val" if r < val_split else "train"


# =========================
# スケーラ
# =========================

def compute_scalers(
    files: List[Path],
    tle_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict]:
    names = feature_names(cfg)
    dt_idx = names.index("dt_norm")
    x_stat = OnlineMeanVar(dim=len(names))
    y_stat = OnlineMeanVar(dim=3)
    rows = 0
    used = 0
    for i, csv_path in enumerate(files):
        st = stem_from_path(csv_path)
        tle_path = tle_dir / f"{st}.txt"
        if not tle_path.exists():
            continue
        tle = parse_tle_file(tle_path)
        base_df = pd.read_csv(csv_path)
        X, Y, _, _ = build_features(tle, base_df, truth_df, cfg)
        if Y is None or len(Y) == 0:
            continue
        x_stat.update(X.astype(np.float64))
        y_stat.update(Y.astype(np.float64))
        rows += len(Y)
        used += 1
        if (i+1) % 25 == 0:
            log(f"[SCALER] {i+1}/{len(files)} files, rows={rows}")

    x_mean, x_std = x_stat.finalize()
    y_mean, y_std = y_stat.finalize()

    # dt_normはスケールしない
    x_mean[dt_idx] = 0.0
    x_std[dt_idx] = 1.0

    meta = {
        "created_at_jst": now_jst_str(),
        "feature_names": names,
        "dt_norm_idx": int(dt_idx),
        "x_mean": x_mean.tolist(),
        "x_std": x_std.tolist(),
        "y_mean": y_mean.tolist(),
        "y_std": y_std.tolist(),
        "cfg": dataclasses.asdict(cfg),
        "scaler_rows": int(rows),
        "scaler_files": int(used),
    }
    return x_mean, x_std, y_mean, y_std, meta


def scale_x(X: np.ndarray, x_mean: np.ndarray, x_std: np.ndarray) -> np.ndarray:
    return ((X - x_mean.reshape(1, -1)) / x_std.reshape(1, -1)).astype(np.float32)


def scale_y(Y: np.ndarray, y_mean: np.ndarray, y_std: np.ndarray) -> np.ndarray:
    return ((Y - y_mean.reshape(1, -1)) / y_std.reshape(1, -1)).astype(np.float32)


def unscale_y(mean_scaled: np.ndarray, logvar_scaled: np.ndarray, y_mean: np.ndarray, y_std: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    mean = mean_scaled * y_std.reshape(1, -1) + y_mean.reshape(1, -1)
    # exp(logvar) のオーバーフローを避ける（推論時の警告/inf伝播を防ぐ）
    logvar_scaled = np.clip(logvar_scaled, -50.0, 50.0)
    var_scaled = np.exp(logvar_scaled)
    var = var_scaled * (y_std.reshape(1, -1) ** 2)
    sigma = np.sqrt(np.maximum(var, 1e-12))
    return mean.astype(np.float64), sigma.astype(np.float64)


# =========================
# 学習
# =========================

def train_model(args: argparse.Namespace) -> int:
    tle_dir = Path(args.tle_dir)
    pred_dir = Path(args.pred_dir)
    err_dir = Path(args.err_dir) if args.err_dir else None
    out_model = Path(args.out_model)

    truth_df = load_truth_csv(Path(args.truth_csv))

    cfg = FeatureConfig(
        days_horizon=args.days_horizon,
        step_minutes=args.step_minutes,
        sample_every=args.sample_every,
        include_az_el_deriv=(not args.no_az_el_deriv),
    )

    all_csv = list_baseline_csv_files(pred_dir)
    usable = []
    for p in all_csv:
        st = stem_from_path(p)
        if not (tle_dir / f"{st}.txt").exists():
            continue
        if err_dir is not None and not (err_dir / f"{st}.csv").exists():
            continue
        usable.append(p)

    if not usable:
        log("[ERROR] usable baseline CSV not found")
        return 2

    train_files = [p for p in usable if deterministic_split(stem_from_path(p), args.val_split, args.seed) == "train"]
    val_files = [p for p in usable if deterministic_split(stem_from_path(p), args.val_split, args.seed) == "val"]
    if not val_files:
        n = max(1, int(0.1 * len(train_files)))
        val_files = train_files[:n]
        train_files = train_files[n:]

    if args.max_files is not None:
        train_files = train_files[:args.max_files]
        val_files = val_files[:max(1, int(len(val_files) * args.max_files / max(1, len(usable))))]

    log(f"[INFO] train_files={len(train_files)} val_files={len(val_files)} truth={args.truth_csv}")

    x_mean, x_std, y_mean, y_std, meta = compute_scalers(train_files, tle_dir, truth_df, cfg)

    names = meta["feature_names"]
    dt_idx = int(meta["dt_norm_idx"])
    input_dim = len(names)

    hidden = [int(x) for x in args.hidden.split(",") if x.strip()]
    model = build_mlp_model(input_dim, dt_idx, hidden=hidden, l2=args.l2, dropout=args.dropout)
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=args.lr), loss=GaussianNLL())

    rng = np.random.default_rng(args.seed)

    # best管理
    best_score = float("inf")
    best_epoch = -1
    best_alpha = 0.0
    no_improve = 0

    tmp_dir = out_model if out_model.suffix == "" else out_model.parent
    ensure_dir(tmp_dir)
    best_model_path = tmp_dir / "_best_model.keras"

    def file_batches(csv_path: Path) -> Iterable[Tuple[np.ndarray, np.ndarray, np.ndarray]]:
        st = stem_from_path(csv_path)
        tle = parse_tle_file(tle_dir / f"{st}.txt")
        base_df = pd.read_csv(csv_path)
        X, Y, _, _ = build_features(tle, base_df, truth_df, cfg)
        if Y is None or len(Y) == 0:
            return
        Xs = scale_x(X, x_mean, x_std)
        Ys = scale_y(Y, y_mean, y_std)
        dt_raw = Xs[:, dt_idx:dt_idx+1]
        n = len(Ys)
        idx = np.arange(n)
        rng.shuffle(idx)
        Xs = Xs[idx]; Ys = Ys[idx]; dt_raw = dt_raw[idx]
        bs = int(args.batch_size)
        for s in range(0, n, bs):
            e = min(n, s+bs)
            yield Xs[s:e], Ys[s:e], dt_raw[s:e]

    def eval_val(files: List[Path]) -> Tuple[float, float, float, int, float]:
        # 1st pass: alpha推定用のsum
        sum_bp = 0.0
        sum_pp = 0.0
        rows = 0
        for csv_path in files:
            st = stem_from_path(csv_path)
            tle_path = tle_dir / f"{st}.txt"
            if not tle_path.exists():
                continue
            tle = parse_tle_file(tle_path)
            base_df = pd.read_csv(csv_path)
            X, Y, _, _ = build_features(tle, base_df, truth_df, cfg)
            if Y is None or len(Y) == 0:
                continue
            Xs = scale_x(X, x_mean, x_std)
            pred = model.predict(Xs, batch_size=int(args.batch_size), verbose=0)
            mean_s = pred[:, 0:3]
            logvar_s = pred[:, 3:6]
            mean_km, _ = unscale_y(mean_s, logvar_s, y_mean, y_std)
            b = -Y.astype(np.float64)
            p = mean_km
            sum_bp += float(np.sum(b * p))
            sum_pp += float(np.sum(p * p))
            rows += len(Y)
        if rows == 0 or sum_pp < 1e-12:
            alpha = 0.0
        else:
            alpha = float(np.clip(-sum_bp / sum_pp, 0.0, 1.0))

        # 2nd pass: 評価
        rows2 = 0
        sum_y2 = np.zeros(3, dtype=np.float64)
        sum_r2 = np.zeros(3, dtype=np.float64)
        for csv_path in files:
            st = stem_from_path(csv_path)
            tle_path = tle_dir / f"{st}.txt"
            if not tle_path.exists():
                continue
            tle = parse_tle_file(tle_path)
            base_df = pd.read_csv(csv_path)
            X, Y, _, _ = build_features(tle, base_df, truth_df, cfg)
            if Y is None or len(Y) == 0:
                continue
            Xs = scale_x(X, x_mean, x_std)
            pred = model.predict(Xs, batch_size=int(args.batch_size), verbose=0)
            mean_s = pred[:, 0:3]
            logvar_s = pred[:, 3:6]
            mean_km, _ = unscale_y(mean_s, logvar_s, y_mean, y_std)

            y = Y.astype(np.float64)
            r = y - alpha * mean_km
            sum_y2 += np.sum(y*y, axis=0)
            sum_r2 += np.sum(r*r, axis=0)
            rows2 += len(y)

        if rows2 == 0:
            return float("inf"), float("inf"), float("inf"), 0, alpha

        rmse_base = np.sqrt(sum_y2 / rows2)
        rmse_corr = np.sqrt(sum_r2 / rows2)
        rmse_base_rms = float(np.sqrt(np.mean(rmse_base**2)))
        rmse_corr_rms = float(np.sqrt(np.mean(rmse_corr**2)))
        score = rmse_corr_rms
        return score, rmse_base_rms, rmse_corr_rms, rows2, alpha

    for epoch in range(1, int(args.epochs)+1):
        rng.shuffle(train_files)
        total_loss = 0.0
        total_rows = 0
        for f in train_files:
            for xb, yb, dtb in file_batches(f):
                if args.time_weight_power > 0:
                    w = np.power(np.clip(dtb.reshape(-1), 0.0, 1.0), args.time_weight_power) + 1e-3
                else:
                    w = None
                loss = model.train_on_batch(xb, yb, sample_weight=w, return_dict=False)
                total_loss += float(loss) * len(yb)
                total_rows += len(yb)
        train_loss = total_loss / max(1, total_rows)

        score, rmse_base, rmse_corr, val_rows, alpha = eval_val(val_files)
        log(f"[EPOCH {epoch}/{args.epochs}] train_loss={train_loss:.6f} rows={total_rows}")
        log(f"  [VAL] rows={val_rows} rmse_rms(base->corr) {rmse_base:.6f} -> {rmse_corr:.6f} | alpha={alpha:.4f} | score={score:.6f}")

        improved = (best_score - score) > float(args.early_stop_min_delta)
        if improved:
            best_score = score
            best_epoch = epoch
            best_alpha = alpha
            no_improve = 0
            model.save(str(best_model_path))
        else:
            no_improve += 1

        if args.early_stop_patience > 0 and epoch >= args.early_stop_warmup:
            if no_improve >= int(args.early_stop_patience):
                log(f"[EARLY STOP] no improve for {no_improve} epochs. best_epoch={best_epoch} best_score={best_score:.6f}")
                break

    if best_model_path.exists():
        model = tf.keras.models.load_model(str(best_model_path), compile=False)

    meta["alpha"] = float(best_alpha)
    meta["best_epoch"] = int(best_epoch)
    meta["best_score_rmse_ecef_rms_km"] = float(best_score)
    meta["model"] = {"hidden": hidden, "dropout": float(args.dropout), "l2": float(args.l2), "dt_norm_multiply_mean": True}

    model_path, meta_path = save_model_and_meta(model, meta, out_model, overwrite=args.overwrite)
    log(f"[SAVED] model={model_path} meta={meta_path}")
    return 0


# =========================
# 推論
# =========================

def predict_and_correct(args: argparse.Namespace) -> int:
    model, meta = load_model_and_meta(Path(args.model))

    x_mean = np.array(meta["x_mean"], dtype=np.float32)
    x_std = np.array(meta["x_std"], dtype=np.float32)
    y_mean = np.array(meta["y_mean"], dtype=np.float64)
    y_std = np.array(meta["y_std"], dtype=np.float64)
    dt_idx = int(meta["dt_norm_idx"])
    alpha = float(meta.get("alpha", 0.0))

    tle = parse_tle_file(Path(args.tle_file))
    base_df = pd.read_csv(Path(args.baseline_csv))

    cfg = FeatureConfig(days_horizon=int(args.days), step_minutes=int(args.step_minutes), sample_every=1, include_az_el_deriv=(not args.no_az_el_deriv))

    X, _, baseline_ecef_km, merged = build_features(tle, base_df, truth_df=None, cfg=cfg)
    if len(X) == 0:
        log("[ERROR] no prediction rows")
        return 2

    Xs = scale_x(X, x_mean, x_std)
    pred = model.predict(Xs, batch_size=int(args.batch_size), verbose=0)
    mean_s = pred[:, 0:3]
    logvar_s = pred[:, 3:6]
    mean_km, sigma_km = unscale_y(mean_s, logvar_s, y_mean, y_std)

    # logvarを物理単位(km^2)へ変換（var_y = exp(logvar_s)*std^2）
    logvar_km = logvar_s + 2.0 * np.log(y_std.reshape(1, -1))

    sigma_rms = np.sqrt(np.mean(sigma_km**2, axis=1))
    if args.sigma_gate_km > 0:
        weight = 1.0 / (1.0 + (sigma_rms / float(args.sigma_gate_km)))
    else:
        weight = np.ones_like(sigma_rms)

    clip_lim = float(args.clip_k_sigma) * y_std.reshape(1, -1)
    clipped = np.clip(mean_km, -clip_lim, clip_lim)
    delta_final = alpha * weight.reshape(-1, 1) * clipped

    # baseline側もホライズンで切る（build_featuresと合わせる）
    df_use = base_df.copy()
    df_use["UNIX"] = df_use["UNIX"].astype(np.int64)
    start_unix = int(df_use["UNIX"].iloc[0])
    end_unix = start_unix + int(args.days * 86400)
    df_use = df_use[df_use["UNIX"] < end_unix].reset_index(drop=True)

    if len(df_use) != len(delta_final):
        log(f"[WARN] baseline rows mismatch: df={len(df_use)} pred={len(delta_final)} (use build_features output length)")
        df_use = df_use.iloc[:len(delta_final)].reset_index(drop=True)
        baseline_ecef_km = baseline_ecef_km[:len(delta_final)]
        mean_km = mean_km[:len(delta_final)]
        sigma_km = sigma_km[:len(delta_final)]
        sigma_rms = sigma_rms[:len(delta_final)]
        weight = weight[:len(delta_final)]
        delta_final = delta_final[:len(delta_final)]

    corrected_df = apply_delta_and_recompute(
        baseline_df=df_use,
        baseline_ecef_km=baseline_ecef_km,
        delta_km=delta_final,
        obs_lat=float(args.observer_lat),
        obs_lon=float(args.observer_lon),
        obs_alt_km=float(args.observer_alt_km),
    )

    out_corr = Path(args.out_corrected_csv)
    if out_corr.exists() and not args.overwrite:
        log(f"[ERROR] exists: {out_corr} (use --overwrite)")
        return 2
    ensure_dir(out_corr.parent)
    corrected_df.to_csv(out_corr, index=False)
    log(f"[SAVED] corrected: {out_corr}")

    out_delta = Path(args.out_pred_delta_csv)
    if out_delta.exists() and not args.overwrite:
        log(f"[ERROR] exists: {out_delta} (use --overwrite)")
        return 2
    ensure_dir(out_delta.parent)

    delta_df = pd.DataFrame({
        "date": df_use.get("date", pd.Series([""] * len(df_use))).astype(str),
        "UNIX": df_use["UNIX"].astype(np.int64),
        "logvarx_scaled": logvar_s[:, 0],
        "logvary_scaled": logvar_s[:, 1],
        "logvarz_scaled": logvar_s[:, 2],
        "logvarx_km2": logvar_km[:, 0],
        "logvary_km2": logvar_km[:, 1],
        "logvarz_km2": logvar_km[:, 2],
        "dx_mean_km": mean_km[:, 0],
        "dy_mean_km": mean_km[:, 1],
        "dz_mean_km": mean_km[:, 2],
        "sx_km": sigma_km[:, 0],
        "sy_km": sigma_km[:, 1],
        "sz_km": sigma_km[:, 2],
        "sigma_rms_km": sigma_rms,
        "weight": weight,
        "alpha": float(alpha),
        "dx_final_km": delta_final[:, 0],
        "dy_final_km": delta_final[:, 1],
        "dz_final_km": delta_final[:, 2],
    })
    delta_df.to_csv(out_delta, index=False)
    log(f"[SAVED] pred delta: {out_delta}")


    # =========================
    # 評価（truth）/ プロット
    # =========================

    # plot-dirが明示されている場合はそれを使う。未指定でも truth-csv があれば out-corrected-csv と同階層に plots/ を自動生成。
    plot_dir: Optional[Path] = None
    if getattr(args, "plot_dir", None):
        plot_dir = Path(args.plot_dir)
    elif args.truth_csv:
        plot_dir = out_corr.parent / "plots"

    # truthの有無に関係なく、baseline/corrected と delta の挙動はPNGで確認できるようにする
    if plot_dir is not None:
        try:
            plot_baseline_vs_corrected(
                stem=out_corr.stem,
                baseline_df=df_use,
                corrected_df=corrected_df,
                out_dir=plot_dir,
                sample_every=int(args.plot_sample_every),
            )
            plot_delta_summary(
                stem=out_corr.stem,
                delta_df=delta_df,
                out_dir=plot_dir,
                sample_every=int(args.plot_sample_every),
            )
            log(f"[SAVED] plots (baseline/delta): {plot_dir}")
        except Exception as e:
            log(f"[WARN] plot generation (baseline/delta) failed: {e}")

    # truthがあれば評価と Truth/Baseline/Corrected の比較プロット
    if args.truth_csv:
        truth_path = Path(args.truth_csv)
        truth_full = pd.read_csv(truth_path)
        truth_full = _coerce_unix_int64(truth_full)

        # 予測窓に絞る（無駄なmerge/plotを避ける）
        u0 = int(df_use["UNIX"].min()) if len(df_use) else 0
        u1 = int(df_use["UNIX"].max()) if len(df_use) else 0
        if len(truth_full) > 0:
            tmin = int(truth_full["UNIX"].min())
            tmax = int(truth_full["UNIX"].max())
        else:
            tmin = tmax = 0
        truth_sub = truth_full[(truth_full["UNIX"] >= u0) & (truth_full["UNIX"] <= u1)].copy()
        if len(truth_sub) == 0:
            log(
                "[WARN] truth-csv has no rows in prediction window. "
                f"pred_unix=[{u0}..{u1}] truth_unix=[{tmin}..{tmax}]. "
                "予測が2024年なら、2024年の真値CSVを --truth-csv で指定してください。"
            )

        base_use = df_use.copy()
        base_metrics, corr_metrics = compute_metrics_latlonalt_az_el(truth_sub, base_use, corrected_df)

        out_metrics = out_corr.parent / (out_corr.stem + "_metrics.csv")
        rows_out = []
        for name, m in [("baseline", base_metrics), ("corrected", corr_metrics)]:
            r = {"kind": name, "rows": int(m.rows)}
            for k in ["Lat", "Lon", "Alt", "AZ", "EL"]:
                r[f"{k}_MAE"] = m.mae[k]
                r[f"{k}_RMSE"] = m.rmse[k]
            rows_out.append(r)
        pd.DataFrame(rows_out).to_csv(out_metrics, index=False)
        log(f"[SAVED] metrics: {out_metrics}")

        if base_metrics.rows > 0:
            log("[METRIC] MAE/RMSE (baseline -> corrected)")
            for k in ["Lat", "Lon", "Alt", "AZ", "EL"]:
                log(f"  {k}: MAE {base_metrics.mae[k]:.6g} -> {corr_metrics.mae[k]:.6g} | RMSE {base_metrics.rmse[k]:.6g} -> {corr_metrics.rmse[k]:.6g}")
        else:
            log("[WARN] metric skipped: no matching UNIX between truth and prediction window")

        if plot_dir is not None:
            try:
                plot_compare(
                    stem=out_corr.stem,
                    truth_df=truth_sub,
                    baseline_df=base_use,
                    corrected_df=corrected_df,
                    out_dir=plot_dir,
                    sample_every=int(args.plot_sample_every),
                )
                log(f"[SAVED] plots (truth/baseline/corrected): {plot_dir}")
            except Exception as e:
                log(f"[WARN] plot_compare failed: {e}")
    return 0


# =========================
# CLI
# =========================

def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="orbit_error_ai_ecef.py",
        description="単一TLE + baseline CSV からECEF残差Δrを学習/予測し、30日補正軌道を生成（TF/Keras）",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train", help="学習（2023）")
    t.add_argument("--tle-dir", required=True)
    t.add_argument("--pred-dir", required=True)
    t.add_argument("--err-dir", default=None)
    t.add_argument("--truth-csv", default="2023_calc_az_el.csv")
    t.add_argument("--out-model", required=True)
    t.add_argument("--overwrite", action="store_true")

    t.add_argument("--days-horizon", type=int, default=30)
    t.add_argument("--step-minutes", type=int, default=1)
    t.add_argument("--sample-every", type=int, default=1)
    t.add_argument("--max-files", type=int, default=None)
    t.add_argument("--val-split", type=float, default=0.1)
    t.add_argument("--seed", type=int, default=42)

    t.add_argument("--epochs", type=int, default=80)
    t.add_argument("--batch-size", type=int, default=4096)
    t.add_argument("--lr", type=float, default=1e-3)
    t.add_argument("--hidden", type=str, default="256,256,128")
    t.add_argument("--dropout", type=float, default=0.0)
    t.add_argument("--l2", type=float, default=1e-6)
    t.add_argument("--no-az-el-deriv", action="store_true")

    t.add_argument("--early-stop-patience", type=int, default=10)
    t.add_argument("--early-stop-min-delta", type=float, default=0.0)
    t.add_argument("--early-stop-warmup", type=int, default=5)
    t.add_argument("--time-weight-power", type=float, default=0.0)

    pr = sub.add_parser("predict", help="予測（2024）+補正+（任意）評価/プロット")
    pr.add_argument("--model", required=True)
    pr.add_argument("--tle-file", required=True)
    pr.add_argument("--baseline-csv", required=True)
    pr.add_argument("--out-corrected-csv", required=True)
    pr.add_argument("--out-pred-delta-csv", required=True)
    pr.add_argument("--truth-csv", default=None,
                    help="真値CSV(date,UNIX,Lat,Lon,Alt,AZ,EL)。指定するとメトリクス計算と比較プロット(PNG)を実行します。")
    pr.add_argument("--plot-dir", default=None,
                    help="比較プロット(PNG)の出力先。省略時は out-corrected-csv と同じフォルダに plots/ を作成します（truth-csv指定時のみ）。")
    pr.add_argument("--plot-sample-every", type=int, default=5,
                    help="プロット用の間引き（例:5なら5分に1点）。既定:5")

    pr.add_argument("--days", type=int, default=30)
    pr.add_argument("--step-minutes", type=int, default=1)
    pr.add_argument("--batch-size", type=int, default=4096)
    pr.add_argument("--sigma-gate-km", type=float, default=10.0)
    pr.add_argument("--clip-k-sigma", type=float, default=5.0)
    pr.add_argument("--overwrite", action="store_true")
    pr.add_argument("--no-az-el-deriv", action="store_true")

    pr.add_argument("--observer-lat", type=float, default=36.3022)
    pr.add_argument("--observer-lon", type=float, default=137.9031)
    pr.add_argument("--observer-alt-km", type=float, default=0.0)

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
    args = make_parser().parse_args(argv)
    if args.cmd == "train":
        return train_model(args)
    if args.cmd == "predict":
        return predict_and_correct(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
