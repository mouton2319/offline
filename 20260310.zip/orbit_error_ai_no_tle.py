#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Learn/predict orbit error from `No + TLE` only.

This script implements the workflow below:
1. Train error model from 2023 error CSV files (`No,date,UNIX,Lat,Lon,Alt,AZ,EL`)
   and matching TLE files.
2. Predict 30-day (1 min step) error from a single 2024 TLE + baseline CSV.
3. Apply correction to baseline, then save corrected CSV, metrics, and plots.

Error definition in this repository:
  error = predicted - true
So corrected value is:
  corrected = baseline - predicted_error
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


TARGET_COLS = ["Lat", "Lon", "Alt", "AZ", "EL"]
ANGLE_COLS = {"Lon", "AZ"}
MINUTES_PER_DAY = 1440.0
SIDEREAL_PERIOD_MIN = 1436.07


def log(msg: str) -> None:
    print(msg, flush=True)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def now_jst_str() -> str:
    jst = dt.timezone(dt.timedelta(hours=9))
    return dt.datetime.now(tz=jst).strftime("%Y-%m-%d %H:%M:%S%z")


def wrap360(deg: np.ndarray) -> np.ndarray:
    return np.mod(deg, 360.0)


def wrap180(deg: np.ndarray) -> np.ndarray:
    return (deg + 180.0) % 360.0 - 180.0


def angle_diff_deg(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return wrap180(np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64))


def deterministic_split(stem: str, val_split: float, seed: int) -> str:
    h = hashlib.md5((stem + str(seed)).encode("utf-8")).hexdigest()
    r = int(h[:8], 16) / float(16**8)
    return "val" if r < val_split else "train"


def _coerce_unix_int64(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "UNIX" not in out.columns:
        raise ValueError("UNIX column is missing")
    out["UNIX"] = pd.to_numeric(out["UNIX"], errors="coerce").round().astype("Int64")
    out = out.dropna(subset=["UNIX"]).copy()
    out["UNIX"] = out["UNIX"].astype(np.int64)
    return out


def _coerce_no_int64(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "No" not in out.columns:
        out.insert(0, "No", np.arange(1, len(out) + 1, dtype=np.int64))
        return out
    out["No"] = pd.to_numeric(out["No"], errors="coerce").astype("Int64")
    out = out.dropna(subset=["No"]).copy()
    out["No"] = out["No"].astype(np.int64)
    return out


def load_orbit_csv(path: Path, require_targets: bool = True) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = _coerce_unix_int64(df)
    df = _coerce_no_int64(df)

    missing_basic = [c for c in ("date", "UNIX", "No") if c not in df.columns]
    if missing_basic:
        raise ValueError(f"{path}: missing columns {missing_basic}")

    if require_targets:
        missing_targets = [c for c in TARGET_COLS if c not in df.columns]
        if missing_targets:
            raise ValueError(f"{path}: missing target columns {missing_targets}")

    if require_targets:
        for c in TARGET_COLS:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        df = df.dropna(subset=TARGET_COLS).copy()

    df = df.drop_duplicates(subset=["No"], keep="last").sort_values("No").reset_index(drop=True)
    return df


def trim_horizon_and_stride(
    df: pd.DataFrame,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> pd.DataFrame:
    out = df.copy()
    if days_horizon <= 0:
        raise ValueError(f"days_horizon must be > 0, got {days_horizon}")
    if step_minutes <= 0:
        raise ValueError(f"step_minutes must be > 0, got {step_minutes}")
    if sample_every <= 0:
        raise ValueError(f"sample_every must be > 0, got {sample_every}")

    max_rows_1min = int(days_horizon * 24 * 60)
    out = out.iloc[:max_rows_1min].copy()

    stride = int(step_minutes) * int(sample_every)
    if stride > 1:
        out = out.iloc[::stride].copy()
    out = out.reset_index(drop=True)
    return out


@dataclasses.dataclass
class TLEInfo:
    inc_deg: float
    raan_deg: float
    ecc: float
    argp_deg: float
    mean_anom_deg: float
    mean_motion_rev_per_day: float
    bstar: float
    ndot: float
    nddot: float
    epoch_year_2digit: int
    epoch_day: float


def _parse_tle_exponent_field(s: str) -> float:
    s = s.strip()
    if not s:
        return 0.0
    sign = 1.0
    if s[0] == "-":
        sign = -1.0
        s = s[1:]
    elif s[0] == "+":
        s = s[1:]

    plus_pos = s[1:].find("+")
    minus_pos = s[1:].find("-")
    if plus_pos >= 0:
        i = plus_pos + 1
    elif minus_pos >= 0:
        i = minus_pos + 1
    else:
        return sign * float(s)

    mant = s[:i]
    exp = s[i:]
    return sign * float("0." + mant) * (10.0 ** int(exp))


def parse_tle_file(path: Path) -> TLEInfo:
    lines = [
        ln.strip("\n")
        for ln in path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if ln.strip()
    ]
    if len(lines) < 2:
        raise ValueError(f"TLE line count < 2: {path}")

    if lines[0].startswith("1 ") and lines[1].startswith("2 "):
        line1, line2 = lines[0], lines[1]
    else:
        line1, line2 = lines[-2], lines[-1]
        if not (line1.startswith("1 ") and line2.startswith("2 ")):
            raise ValueError(f"Unrecognized TLE format: {path}")

    epoch_year = int(line1[18:20])
    epoch_day = float(line1[20:32])
    ndot = float(line1[33:43].strip() or 0.0)
    nddot = _parse_tle_exponent_field(line1[44:52])
    bstar = _parse_tle_exponent_field(line1[53:61])

    return TLEInfo(
        inc_deg=float(line2[8:16]),
        raan_deg=float(line2[17:25]),
        ecc=float("0." + line2[26:33].strip()),
        argp_deg=float(line2[34:42]),
        mean_anom_deg=float(line2[43:51]),
        mean_motion_rev_per_day=float(line2[52:63]),
        bstar=bstar,
        ndot=ndot,
        nddot=nddot,
        epoch_year_2digit=epoch_year,
        epoch_day=epoch_day,
    )


def _sincos_deg_scalar(deg: float) -> Tuple[float, float]:
    rad = math.radians(float(deg))
    return math.sin(rad), math.cos(rad)


def tle_feature_vector(tle: TLEInfo) -> Tuple[np.ndarray, List[str]]:
    inc_s, inc_c = _sincos_deg_scalar(tle.inc_deg)
    raan_s, raan_c = _sincos_deg_scalar(tle.raan_deg)
    argp_s, argp_c = _sincos_deg_scalar(tle.argp_deg)
    ma_s, ma_c = _sincos_deg_scalar(tle.mean_anom_deg)

    epoch_day_norm = float(tle.epoch_day) / 366.0
    epoch_day_frac = float(tle.epoch_day) - math.floor(float(tle.epoch_day))

    vals = np.array(
        [
            tle.inc_deg,
            inc_s,
            inc_c,
            tle.raan_deg,
            raan_s,
            raan_c,
            tle.ecc,
            tle.argp_deg,
            argp_s,
            argp_c,
            tle.mean_anom_deg,
            ma_s,
            ma_c,
            tle.mean_motion_rev_per_day,
            tle.bstar,
            tle.ndot,
            tle.nddot,
            epoch_day_norm,
            epoch_day_frac,
        ],
        dtype=np.float64,
    )
    names = [
        "tle_inc_deg",
        "tle_inc_sin",
        "tle_inc_cos",
        "tle_raan_deg",
        "tle_raan_sin",
        "tle_raan_cos",
        "tle_ecc",
        "tle_argp_deg",
        "tle_argp_sin",
        "tle_argp_cos",
        "tle_mean_anom_deg",
        "tle_mean_anom_sin",
        "tle_mean_anom_cos",
        "tle_mean_motion_rev_per_day",
        "tle_bstar",
        "tle_ndot",
        "tle_nddot",
        "tle_epoch_day_norm",
        "tle_epoch_day_frac",
    ]
    return vals, names


@dataclasses.dataclass
class FeatureConfig:
    day_harmonics: int = 4
    span_harmonics: int = 2
    include_sidereal: bool = True
    include_interactions: bool = True


def build_no_features(
    no: np.ndarray,
    total_rows: int,
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, List[str], Dict[str, np.ndarray]]:
    no_f = np.asarray(no, dtype=np.float64)
    if no_f.ndim != 1:
        raise ValueError("No must be 1-D")
    if len(no_f) == 0:
        return np.zeros((0, 1), dtype=np.float64), ["no_norm"], {
            "no_norm": np.zeros((0,), dtype=np.float64),
            "no_norm2": np.zeros((0,), dtype=np.float64),
            "span_sin_1": np.zeros((0,), dtype=np.float64),
            "span_cos_1": np.zeros((0,), dtype=np.float64),
        }

    denom = float(max(1, total_rows - 1))
    minute_index = no_f - 1.0
    no_norm = np.clip(minute_index / denom, 0.0, 1.0)
    no_norm2 = no_norm * no_norm
    no_norm3 = no_norm2 * no_norm

    feats: List[np.ndarray] = [no_norm, no_norm2, no_norm3]
    names: List[str] = ["no_norm", "no_norm2", "no_norm3"]

    for k in range(1, int(cfg.day_harmonics) + 1):
        phase = 2.0 * math.pi * k * (minute_index / MINUTES_PER_DAY)
        feats.append(np.sin(phase))
        feats.append(np.cos(phase))
        names.append(f"day_sin_{k}")
        names.append(f"day_cos_{k}")

    if cfg.include_sidereal:
        phase_sid = 2.0 * math.pi * (minute_index / SIDEREAL_PERIOD_MIN)
        feats.append(np.sin(phase_sid))
        feats.append(np.cos(phase_sid))
        names.append("sidereal_sin_1")
        names.append("sidereal_cos_1")

    span_sin_1 = np.zeros_like(no_norm)
    span_cos_1 = np.zeros_like(no_norm)
    for k in range(1, int(cfg.span_harmonics) + 1):
        phase = 2.0 * math.pi * k * no_norm
        s = np.sin(phase)
        c = np.cos(phase)
        feats.append(s)
        feats.append(c)
        names.append(f"span_sin_{k}")
        names.append(f"span_cos_{k}")
        if k == 1:
            span_sin_1 = s
            span_cos_1 = c

    x = np.stack(feats, axis=1).astype(np.float64)
    aux = {
        "no_norm": no_norm,
        "no_norm2": no_norm2,
        "span_sin_1": span_sin_1,
        "span_cos_1": span_cos_1,
    }
    return x, names, aux


def build_design_matrix(
    no: np.ndarray,
    total_rows: int,
    tle: TLEInfo,
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, List[str]]:
    x_no, no_names, aux = build_no_features(no, total_rows, cfg)
    tle_vec, tle_names = tle_feature_vector(tle)
    n = len(no)

    x_tle = np.repeat(tle_vec.reshape(1, -1), n, axis=0)
    feats: List[np.ndarray] = [x_no, x_tle]
    names: List[str] = list(no_names) + list(tle_names)

    if cfg.include_interactions:
        basis = [
            ("no_norm", aux["no_norm"]),
            ("no_norm2", aux["no_norm2"]),
            ("span_sin_1", aux["span_sin_1"]),
            ("span_cos_1", aux["span_cos_1"]),
        ]
        interact_keys = {
            "tle_inc_deg",
            "tle_raan_sin",
            "tle_raan_cos",
            "tle_ecc",
            "tle_argp_sin",
            "tle_argp_cos",
            "tle_mean_anom_sin",
            "tle_mean_anom_cos",
            "tle_mean_motion_rev_per_day",
            "tle_bstar",
            "tle_ndot",
            "tle_nddot",
        }
        idx = [i for i, name in enumerate(tle_names) if name in interact_keys]

        if idx:
            x_tle_sel = x_tle[:, idx]
            tle_sel_names = [tle_names[i] for i in idx]
            for b_name, b in basis:
                x_b = b.reshape(-1, 1) * x_tle_sel
                feats.append(x_b)
                names.extend([f"{b_name}*{tn}" for tn in tle_sel_names])

    x = np.concatenate(feats, axis=1).astype(np.float64)
    return x, names


class OnlineMeanVar:
    def __init__(self, dim: int) -> None:
        self.dim = int(dim)
        self.n = 0
        self.mean = np.zeros(self.dim, dtype=np.float64)
        self.m2 = np.zeros(self.dim, dtype=np.float64)

    def update(self, x: np.ndarray) -> None:
        arr = np.asarray(x, dtype=np.float64)
        if arr.ndim != 2 or arr.shape[1] != self.dim:
            raise ValueError(f"shape mismatch: expected (*,{self.dim}), got {arr.shape}")
        m = arr.shape[0]
        if m <= 0:
            return

        b_mean = np.mean(arr, axis=0)
        b_m2 = np.sum((arr - b_mean.reshape(1, -1)) ** 2, axis=0)

        if self.n == 0:
            self.n = m
            self.mean = b_mean
            self.m2 = b_m2
            return

        total = self.n + m
        delta = b_mean - self.mean
        self.mean = self.mean + delta * (m / total)
        self.m2 = self.m2 + b_m2 + (delta ** 2) * (self.n * m / total)
        self.n = total

    def finalize(self, eps: float = 1e-12) -> Tuple[np.ndarray, np.ndarray]:
        if self.n < 2:
            std = np.ones(self.dim, dtype=np.float64)
            return self.mean.astype(np.float64), std
        var = self.m2 / (self.n - 1)
        std = np.sqrt(np.maximum(var, eps))
        return self.mean.astype(np.float64), std.astype(np.float64)


@dataclasses.dataclass
class ModelBundle:
    cfg: FeatureConfig
    feature_names: List[str]
    target_cols: List[str]
    angle_cols: List[str]
    x_mean: np.ndarray
    x_std: np.ndarray
    y_mean: np.ndarray
    y_std: np.ndarray
    beta: np.ndarray
    alpha_vec: np.ndarray
    default_clip_k_sigma: float
    ridge_lambda: float
    error_definition: str
    train_rows: int
    train_files: int
    val_files: int


def _load_training_pair(
    tle_path: Path,
    err_path: Path,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    tle = parse_tle_file(tle_path)
    df = load_orbit_csv(err_path, require_targets=True)
    df = trim_horizon_and_stride(df, days_horizon=days_horizon, step_minutes=step_minutes, sample_every=sample_every)
    if len(df) == 0:
        return np.zeros((0, 1), dtype=np.float64), np.zeros((0, len(TARGET_COLS)), dtype=np.float64), ["dummy"]

    no = df["No"].to_numpy(np.int64)
    total_rows = int(max(1, int(df["No"].max())))
    x, names = build_design_matrix(no=no, total_rows=total_rows, tle=tle, cfg=cfg)
    y = df[TARGET_COLS].to_numpy(np.float64)
    return x, y, names


def compute_scalers(
    stems: List[str],
    tle_dir: Path,
    err_dir: Path,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str], int]:
    x_stat: Optional[OnlineMeanVar] = None
    y_stat = OnlineMeanVar(dim=len(TARGET_COLS))
    feature_names: Optional[List[str]] = None
    rows = 0

    for i, stem in enumerate(stems, start=1):
        tle_path = tle_dir / f"{stem}.txt"
        err_path = err_dir / f"{stem}.csv"
        try:
            x, y, names = _load_training_pair(
                tle_path=tle_path,
                err_path=err_path,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
                cfg=cfg,
            )
        except Exception as e:
            log(f"[WARN] scaler skip {stem}: {e}")
            continue

        if len(x) == 0:
            continue

        if x_stat is None:
            x_stat = OnlineMeanVar(dim=x.shape[1])
            feature_names = names
        elif x.shape[1] != x_stat.dim:
            raise ValueError(f"feature dim mismatch for {stem}: {x.shape[1]} vs {x_stat.dim}")

        x_stat.update(x)
        y_stat.update(y)
        rows += len(x)

        if i % 25 == 0:
            log(f"[SCALER] {i}/{len(stems)} files, rows={rows}")

    if x_stat is None or feature_names is None or rows == 0:
        raise RuntimeError("no usable training rows for scalers")

    x_mean, x_std = x_stat.finalize()
    y_mean, y_std = y_stat.finalize()
    x_std = np.where(x_std < 1e-9, 1.0, x_std)
    y_std = np.where(y_std < 1e-9, 1.0, y_std)
    return x_mean, x_std, y_mean, y_std, feature_names, rows


def _fit_ridge_closed_form(
    stems: List[str],
    tle_dir: Path,
    err_dir: Path,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    cfg: FeatureConfig,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    ridge_lambda: float,
    target_clip_sigma: float,
    time_weight_power: float,
) -> Tuple[np.ndarray, int]:
    dim_x = int(x_mean.shape[0])
    dim_xb = dim_x + 1  # bias
    dim_y = len(TARGET_COLS)

    a = np.zeros((dim_xb, dim_xb), dtype=np.float64)
    b = np.zeros((dim_xb, dim_y), dtype=np.float64)
    rows = 0

    y_lo = y_mean - target_clip_sigma * y_std if target_clip_sigma > 0 else None
    y_hi = y_mean + target_clip_sigma * y_std if target_clip_sigma > 0 else None

    for i, stem in enumerate(stems, start=1):
        tle_path = tle_dir / f"{stem}.txt"
        err_path = err_dir / f"{stem}.csv"
        try:
            x, y, _ = _load_training_pair(
                tle_path=tle_path,
                err_path=err_path,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
                cfg=cfg,
            )
        except Exception as e:
            log(f"[WARN] train skip {stem}: {e}")
            continue
        if len(x) == 0:
            continue

        if y_lo is not None and y_hi is not None:
            y = np.clip(y, y_lo.reshape(1, -1), y_hi.reshape(1, -1))

        x_s = (x - x_mean.reshape(1, -1)) / x_std.reshape(1, -1)
        y_s = (y - y_mean.reshape(1, -1)) / y_std.reshape(1, -1)

        x_b = np.concatenate([np.ones((len(x_s), 1), dtype=np.float64), x_s], axis=1)

        if time_weight_power > 0:
            no = np.arange(1, len(x_b) + 1, dtype=np.float64)
            no_norm = np.clip((no - 1.0) / max(1.0, len(x_b) - 1.0), 0.0, 1.0)
            w = np.power(no_norm, time_weight_power) + 1e-3
            sw = np.sqrt(w).reshape(-1, 1)
            x_w = x_b * sw
            y_w = y_s * sw
        else:
            x_w = x_b
            y_w = y_s

        a += x_w.T @ x_w
        b += x_w.T @ y_w
        rows += len(x)

        if i % 25 == 0:
            log(f"[FIT] {i}/{len(stems)} files, rows={rows}")

    if rows == 0:
        raise RuntimeError("no usable training rows for ridge fitting")

    reg = np.eye(dim_xb, dtype=np.float64) * float(max(0.0, ridge_lambda))
    reg[0, 0] = 0.0  # do not regularize bias
    mat = a + reg
    try:
        beta = np.linalg.solve(mat, b)
    except np.linalg.LinAlgError:
        beta = np.linalg.pinv(mat) @ b
    return beta.astype(np.float64), rows


def _predict_error_from_features(
    x: np.ndarray,
    beta: np.ndarray,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
) -> np.ndarray:
    x_s = (x - x_mean.reshape(1, -1)) / x_std.reshape(1, -1)
    x_b = np.concatenate([np.ones((len(x_s), 1), dtype=np.float64), x_s], axis=1)
    y_s = x_b @ beta
    y = y_s * y_std.reshape(1, -1) + y_mean.reshape(1, -1)
    return y.astype(np.float64)


def _compute_error_residual(
    y_true_error: np.ndarray,
    y_pred_error: np.ndarray,
    col_name: str,
) -> np.ndarray:
    if col_name in ANGLE_COLS:
        return angle_diff_deg(y_true_error, y_pred_error)
    return y_true_error - y_pred_error


def fit_alpha_vector(
    stems: List[str],
    tle_dir: Path,
    err_dir: Path,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    cfg: FeatureConfig,
    bundle: ModelBundle,
    alpha_clip_min: float = 0.0,
    alpha_clip_max: float = 1.0,
) -> np.ndarray:
    sum_yp = np.zeros(len(TARGET_COLS), dtype=np.float64)
    sum_pp = np.zeros(len(TARGET_COLS), dtype=np.float64)

    for stem in stems:
        tle_path = tle_dir / f"{stem}.txt"
        err_path = err_dir / f"{stem}.csv"
        try:
            x, y, _ = _load_training_pair(
                tle_path=tle_path,
                err_path=err_path,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
                cfg=cfg,
            )
        except Exception:
            continue
        if len(x) == 0:
            continue

        p = _predict_error_from_features(
            x=x,
            beta=bundle.beta,
            x_mean=bundle.x_mean,
            x_std=bundle.x_std,
            y_mean=bundle.y_mean,
            y_std=bundle.y_std,
        )

        for i, col in enumerate(TARGET_COLS):
            yv = y[:, i]
            pv = p[:, i]
            if col in ANGLE_COLS:
                yv = wrap180(yv)
                pv = wrap180(pv)
            sum_yp[i] += np.sum(yv * pv)
            sum_pp[i] += np.sum(pv * pv)

    alpha = np.zeros(len(TARGET_COLS), dtype=np.float64)
    ok = sum_pp > 1e-12
    alpha[ok] = sum_yp[ok] / sum_pp[ok]
    alpha = np.clip(alpha, alpha_clip_min, alpha_clip_max)
    return alpha


def evaluate_error_prediction(
    stems: List[str],
    tle_dir: Path,
    err_dir: Path,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    cfg: FeatureConfig,
    bundle: ModelBundle,
    alpha_vec: Optional[np.ndarray] = None,
) -> Dict[str, float]:
    if not stems:
        return {}

    sum_base = np.zeros(len(TARGET_COLS), dtype=np.float64)
    sum_corr = np.zeros(len(TARGET_COLS), dtype=np.float64)
    rows = 0

    if alpha_vec is None:
        alpha_use = np.ones((len(TARGET_COLS),), dtype=np.float64)
    else:
        alpha_use = np.asarray(alpha_vec, dtype=np.float64).reshape(-1)
        if alpha_use.shape[0] != len(TARGET_COLS):
            raise ValueError(f"alpha_vec must have {len(TARGET_COLS)} elements, got {alpha_use.shape}")

    for stem in stems:
        tle_path = tle_dir / f"{stem}.txt"
        err_path = err_dir / f"{stem}.csv"
        try:
            x, y, _ = _load_training_pair(
                tle_path=tle_path,
                err_path=err_path,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
                cfg=cfg,
            )
        except Exception as e:
            log(f"[WARN] eval skip {stem}: {e}")
            continue
        if len(x) == 0:
            continue

        y_hat_raw = _predict_error_from_features(
            x=x,
            beta=bundle.beta,
            x_mean=bundle.x_mean,
            x_std=bundle.x_std,
            y_mean=bundle.y_mean,
            y_std=bundle.y_std,
        )
        y_hat = y_hat_raw * alpha_use.reshape(1, -1)

        for i, col in enumerate(TARGET_COLS):
            base = y[:, i]
            res = _compute_error_residual(y_true_error=y[:, i], y_pred_error=y_hat[:, i], col_name=col)
            if col in ANGLE_COLS:
                base = wrap180(base)
            sum_base[i] += np.sum(base * base)
            sum_corr[i] += np.sum(res * res)
        rows += len(y)

    if rows == 0:
        return {}

    rmse_base = np.sqrt(sum_base / rows)
    rmse_corr = np.sqrt(sum_corr / rows)
    mse_base = sum_base / rows
    mse_corr = sum_corr / rows

    out: Dict[str, float] = {"rows": float(rows)}
    for i, col in enumerate(TARGET_COLS):
        out[f"{col}_RMSE_base"] = float(rmse_base[i])
        out[f"{col}_RMSE_corr"] = float(rmse_corr[i])
        out[f"{col}_MSE_base"] = float(mse_base[i])
        out[f"{col}_MSE_corr"] = float(mse_corr[i])

    out["global_MSE_base"] = float(np.mean(mse_base))
    out["global_MSE_corr"] = float(np.mean(mse_corr))
    out["global_RMSE_base"] = float(np.sqrt(out["global_MSE_base"]))
    out["global_RMSE_corr"] = float(np.sqrt(out["global_MSE_corr"]))
    if out["global_RMSE_base"] > 0:
        out["global_RMSE_improve_pct"] = float(
            100.0 * (out["global_RMSE_base"] - out["global_RMSE_corr"]) / out["global_RMSE_base"]
        )
    else:
        out["global_RMSE_improve_pct"] = float("nan")
    return out


def save_model(bundle: ModelBundle, out_model: Path, overwrite: bool) -> Path:
    out_dir = out_model if out_model.suffix == "" else out_model.parent
    ensure_dir(out_dir)
    meta_path = out_dir / "meta.json"
    if meta_path.exists() and not overwrite:
        raise FileExistsError(f"exists: {meta_path} (use --overwrite)")

    payload = {
        "created_at_jst": now_jst_str(),
        "model_type": "ridge_no_tle_error_model",
        "feature_cfg": dataclasses.asdict(bundle.cfg),
        "feature_names": bundle.feature_names,
        "target_cols": bundle.target_cols,
        "angle_cols": bundle.angle_cols,
        "x_mean": bundle.x_mean.tolist(),
        "x_std": bundle.x_std.tolist(),
        "y_mean": bundle.y_mean.tolist(),
        "y_std": bundle.y_std.tolist(),
        "beta": bundle.beta.tolist(),
        "alpha_vec": bundle.alpha_vec.tolist(),
        "default_clip_k_sigma": float(bundle.default_clip_k_sigma),
        "ridge_lambda": float(bundle.ridge_lambda),
        "error_definition": bundle.error_definition,
        "train_rows": int(bundle.train_rows),
        "train_files": int(bundle.train_files),
        "val_files": int(bundle.val_files),
    }
    meta_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return meta_path


def load_model(model_path: Path) -> ModelBundle:
    meta_path = model_path / "meta.json" if model_path.is_dir() else model_path
    if not meta_path.exists():
        raise FileNotFoundError(f"meta.json not found: {meta_path}")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))

    cfg = FeatureConfig(**meta["feature_cfg"])
    bundle = ModelBundle(
        cfg=cfg,
        feature_names=list(meta["feature_names"]),
        target_cols=list(meta.get("target_cols", TARGET_COLS)),
        angle_cols=list(meta.get("angle_cols", list(ANGLE_COLS))),
        x_mean=np.asarray(meta["x_mean"], dtype=np.float64),
        x_std=np.asarray(meta["x_std"], dtype=np.float64),
        y_mean=np.asarray(meta["y_mean"], dtype=np.float64),
        y_std=np.asarray(meta["y_std"], dtype=np.float64),
        beta=np.asarray(meta["beta"], dtype=np.float64),
        alpha_vec=np.asarray(meta.get("alpha_vec", [1.0] * len(TARGET_COLS)), dtype=np.float64),
        default_clip_k_sigma=float(meta.get("default_clip_k_sigma", 4.0)),
        ridge_lambda=float(meta.get("ridge_lambda", 1e-3)),
        error_definition=str(meta.get("error_definition", "pred_minus_true")),
        train_rows=int(meta.get("train_rows", 0)),
        train_files=int(meta.get("train_files", 0)),
        val_files=int(meta.get("val_files", 0)),
    )
    return bundle


def list_stems_with_both(tle_dir: Path, csv_dir: Path) -> List[str]:
    tle_stems = {p.stem for p in tle_dir.glob("*.txt") if p.is_file()}
    csv_stems = {p.stem for p in csv_dir.glob("*.csv") if p.is_file()}
    return sorted(tle_stems & csv_stems)


def apply_correction(
    baseline_df: pd.DataFrame,
    pred_error: np.ndarray,
    error_definition: str,
) -> pd.DataFrame:
    if pred_error.shape[1] != len(TARGET_COLS):
        raise ValueError(f"pred_error shape mismatch: {pred_error.shape}")

    out = baseline_df.copy()
    if error_definition == "pred_minus_true":
        sign = -1.0
    elif error_definition == "true_minus_pred":
        sign = 1.0
    else:
        raise ValueError(f"unsupported error_definition: {error_definition}")

    for i, col in enumerate(TARGET_COLS):
        out[col] = out[col].to_numpy(np.float64) + sign * pred_error[:, i]

    out["Lon"] = wrap180(out["Lon"].to_numpy(np.float64))
    out["AZ"] = wrap360(out["AZ"].to_numpy(np.float64))
    out["EL"] = np.clip(out["EL"].to_numpy(np.float64), -90.0, 90.0)
    return out


def _prep_metrics_df(df: pd.DataFrame, suffix: str) -> pd.DataFrame:
    d = df.copy()
    d = _coerce_unix_int64(d)
    miss = [c for c in TARGET_COLS if c not in d.columns]
    if miss:
        raise ValueError(f"missing columns {miss}")
    d = d[["UNIX"] + TARGET_COLS].drop_duplicates("UNIX", keep="last").sort_values("UNIX").reset_index(drop=True)
    ren = {c: f"{c}{suffix}" for c in TARGET_COLS}
    return d.rename(columns=ren)


def compute_metrics(
    truth_df: pd.DataFrame,
    base_df: pd.DataFrame,
    corr_df: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    t = _prep_metrics_df(truth_df, "_true")
    b = _prep_metrics_df(base_df, "_base")
    c = _prep_metrics_df(corr_df, "_corr")
    m = t.merge(b, on="UNIX", how="inner").merge(c, on="UNIX", how="inner")

    rows = int(len(m))
    if rows == 0:
        nan = float("nan")
        df = pd.DataFrame(
            [
                {"kind": "baseline", "rows": 0, **{f"{k}_MSE": nan for k in TARGET_COLS}, **{f"{k}_RMSE": nan for k in TARGET_COLS}, "global_MSE": nan, "global_RMSE": nan},
                {"kind": "corrected", "rows": 0, **{f"{k}_MSE": nan for k in TARGET_COLS}, **{f"{k}_RMSE": nan for k in TARGET_COLS}, "global_MSE": nan, "global_RMSE": nan},
            ]
        )
        return df, m

    def _mse_rmse(a: np.ndarray, b_: np.ndarray, is_angle: bool) -> Tuple[float, float]:
        if is_angle:
            d = angle_diff_deg(a, b_)
        else:
            d = a - b_
        mse = float(np.mean(d**2))
        rmse = float(np.sqrt(mse))
        return mse, rmse

    base_row: Dict[str, float] = {"kind": "baseline", "rows": float(rows)}
    corr_row: Dict[str, float] = {"kind": "corrected", "rows": float(rows)}
    base_mse_list: List[float] = []
    corr_mse_list: List[float] = []

    for col in TARGET_COLS:
        is_angle = col in ANGLE_COLS
        mse_b, rmse_b = _mse_rmse(m[f"{col}_base"].to_numpy(np.float64), m[f"{col}_true"].to_numpy(np.float64), is_angle)
        mse_c, rmse_c = _mse_rmse(m[f"{col}_corr"].to_numpy(np.float64), m[f"{col}_true"].to_numpy(np.float64), is_angle)
        base_row[f"{col}_MSE"] = mse_b
        base_row[f"{col}_RMSE"] = rmse_b
        corr_row[f"{col}_MSE"] = mse_c
        corr_row[f"{col}_RMSE"] = rmse_c
        base_mse_list.append(mse_b)
        corr_mse_list.append(mse_c)

    base_row["global_MSE"] = float(np.mean(base_mse_list))
    corr_row["global_MSE"] = float(np.mean(corr_mse_list))
    base_row["global_RMSE"] = float(np.sqrt(base_row["global_MSE"]))
    corr_row["global_RMSE"] = float(np.sqrt(corr_row["global_MSE"]))

    metrics = pd.DataFrame([base_row, corr_row])
    return metrics, m


def plot_truth_baseline_corrected(
    stem: str,
    merged_df: pd.DataFrame,
    out_dir: Path,
    sample_every: int,
) -> None:
    ensure_dir(out_dir)
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if len(merged_df) == 0:
        log("[WARN] plot skipped: no matching UNIX")
        return

    m = merged_df.iloc[:: max(1, int(sample_every))].copy()
    unix0 = float(m["UNIX"].iloc[0])
    t_day = (m["UNIX"].to_numpy(np.float64) - unix0) / 86400.0

    for col in TARGET_COLS:
        y_true = m[f"{col}_true"].to_numpy(np.float64)
        y_base = m[f"{col}_base"].to_numpy(np.float64)
        y_corr = m[f"{col}_corr"].to_numpy(np.float64)

        if col in ANGLE_COLS:
            e_base = np.abs(angle_diff_deg(y_base, y_true))
            e_corr = np.abs(angle_diff_deg(y_corr, y_true))
        else:
            e_base = np.abs(y_base - y_true)
            e_corr = np.abs(y_corr - y_true)

        fig = plt.figure(figsize=(12, 7))
        ax1 = fig.add_subplot(2, 1, 1)
        ax1.plot(t_day, y_true, label="Truth")
        ax1.plot(t_day, y_base, label="Baseline")
        ax1.plot(t_day, y_corr, label="Corrected")
        ax1.set_title(f"{stem} : {col} value")
        ax1.set_xlabel("Elapsed day")
        ax1.set_ylabel(col)
        ax1.grid(True)
        ax1.legend()

        ax2 = fig.add_subplot(2, 1, 2)
        ax2.plot(t_day, e_base, label="|Baseline-Truth|")
        ax2.plot(t_day, e_corr, label="|Corrected-Truth|")
        ax2.set_title(f"{stem} : {col} absolute error")
        ax2.set_xlabel("Elapsed day")
        ax2.set_ylabel("|error|")
        ax2.grid(True)
        ax2.legend()

        out_path = out_dir / f"{stem}_{col}.png"
        fig.tight_layout()
        fig.savefig(out_path, dpi=150)
        plt.close(fig)


def plot_baseline_vs_corrected(
    stem: str,
    baseline_df: pd.DataFrame,
    corrected_df: pd.DataFrame,
    out_dir: Path,
    sample_every: int,
) -> None:
    ensure_dir(out_dir)
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    b = _prep_metrics_df(baseline_df, "_base")
    c = _prep_metrics_df(corrected_df, "_corr")
    m = b.merge(c, on="UNIX", how="inner")
    if len(m) == 0:
        log("[WARN] baseline-vs-corrected plot skipped: no matching UNIX")
        return

    mp = m.iloc[:: max(1, int(sample_every))].copy()
    unix0 = float(mp["UNIX"].iloc[0])
    t_day = (mp["UNIX"].to_numpy(np.float64) - unix0) / 86400.0

    for col in TARGET_COLS:
        y_base = mp[f"{col}_base"].to_numpy(np.float64)
        y_corr = mp[f"{col}_corr"].to_numpy(np.float64)
        if col in ANGLE_COLS:
            diff = angle_diff_deg(y_corr, y_base)
        else:
            diff = y_corr - y_base

        fig = plt.figure(figsize=(12, 7))
        ax1 = fig.add_subplot(2, 1, 1)
        ax1.plot(t_day, y_base, label="Baseline")
        ax1.plot(t_day, y_corr, label="Corrected")
        ax1.set_title(f"{stem} : {col} baseline vs corrected")
        ax1.set_xlabel("Elapsed day")
        ax1.set_ylabel(col)
        ax1.grid(True)
        ax1.legend()

        ax2 = fig.add_subplot(2, 1, 2)
        ax2.plot(t_day, np.abs(diff), label="|Corrected-Baseline|")
        ax2.set_title(f"{stem} : {col} correction magnitude")
        ax2.set_xlabel("Elapsed day")
        ax2.set_ylabel("|diff|")
        ax2.grid(True)
        ax2.legend()

        out_path = out_dir / f"{stem}_{col}_baseline_vs_corrected.png"
        fig.tight_layout()
        fig.savefig(out_path, dpi=150)
        plt.close(fig)


def _predict_for_dataframe(
    bundle: ModelBundle,
    tle: TLEInfo,
    baseline_df: pd.DataFrame,
) -> np.ndarray:
    no = baseline_df["No"].to_numpy(np.int64)
    total_rows = int(max(1, int(baseline_df["No"].max())))
    x, names = build_design_matrix(no=no, total_rows=total_rows, tle=tle, cfg=bundle.cfg)
    if names != bundle.feature_names:
        raise ValueError("feature names mismatch between training and inference")
    y_hat = _predict_error_from_features(
        x=x,
        beta=bundle.beta,
        x_mean=bundle.x_mean,
        x_std=bundle.x_std,
        y_mean=bundle.y_mean,
        y_std=bundle.y_std,
    )
    return y_hat


def run_predict_one(
    bundle: ModelBundle,
    tle_file: Path,
    baseline_csv: Path,
    out_corrected_csv: Path,
    out_pred_error_csv: Path,
    truth_df: Optional[pd.DataFrame],
    out_metrics_csv: Optional[Path],
    plot_dir: Optional[Path],
    days: int,
    step_minutes: int,
    sample_every: int,
    plot_sample_every: int,
    overwrite: bool,
    error_definition_override: Optional[str],
    alpha_override: Optional[float],
    clip_k_sigma_override: Optional[float],
) -> Dict[str, float]:
    tle = parse_tle_file(tle_file)
    base = load_orbit_csv(baseline_csv, require_targets=True)
    base = trim_horizon_and_stride(base, days_horizon=days, step_minutes=step_minutes, sample_every=sample_every)
    if len(base) == 0:
        raise RuntimeError(f"no rows in baseline after trimming: {baseline_csv}")

    err_def = error_definition_override or bundle.error_definition
    y_hat_raw = _predict_for_dataframe(bundle=bundle, tle=tle, baseline_df=base)
    alpha_vec = bundle.alpha_vec.reshape(1, -1)
    if alpha_override is not None:
        alpha_vec = np.full_like(alpha_vec, float(alpha_override), dtype=np.float64)
    y_hat = y_hat_raw * alpha_vec

    clip_k_sigma = bundle.default_clip_k_sigma if clip_k_sigma_override is None else float(clip_k_sigma_override)
    if clip_k_sigma > 0:
        clip_abs = clip_k_sigma * bundle.y_std.reshape(1, -1)
        y_hat = np.clip(y_hat, -clip_abs, clip_abs)

    corr = apply_correction(base, y_hat, error_definition=err_def)

    if out_corrected_csv.exists() and not overwrite:
        raise FileExistsError(f"exists: {out_corrected_csv} (use --overwrite)")
    if out_pred_error_csv.exists() and not overwrite:
        raise FileExistsError(f"exists: {out_pred_error_csv} (use --overwrite)")

    ensure_dir(out_corrected_csv.parent)
    ensure_dir(out_pred_error_csv.parent)

    corr.to_csv(out_corrected_csv, index=False)

    pred_df = pd.DataFrame(
        {
            "No": base["No"].to_numpy(np.int64),
            "date": base["date"].astype(str),
            "UNIX": base["UNIX"].to_numpy(np.int64),
            "Lat": y_hat[:, 0],
            "Lon": y_hat[:, 1],
            "Alt": y_hat[:, 2],
            "AZ": y_hat[:, 3],
            "EL": y_hat[:, 4],
            "error_definition": err_def,
            "alpha_Lat": float(alpha_vec[0, 0]),
            "alpha_Lon": float(alpha_vec[0, 1]),
            "alpha_Alt": float(alpha_vec[0, 2]),
            "alpha_AZ": float(alpha_vec[0, 3]),
            "alpha_EL": float(alpha_vec[0, 4]),
            "clip_k_sigma": float(clip_k_sigma),
        }
    )
    pred_df.to_csv(out_pred_error_csv, index=False)

    log(f"[SAVED] corrected: {out_corrected_csv}")
    log(f"[SAVED] predicted error: {out_pred_error_csv}")

    summary: Dict[str, float] = {
        "rows_pred": float(len(base)),
    }

    if plot_dir is not None:
        plot_baseline_vs_corrected(
            stem=out_corrected_csv.stem,
            baseline_df=base,
            corrected_df=corr,
            out_dir=plot_dir,
            sample_every=plot_sample_every,
        )
        log(f"[SAVED] baseline-vs-corrected plots: {plot_dir}")

    if truth_df is not None:
        metrics_df, merged = compute_metrics(truth_df=truth_df, base_df=base, corr_df=corr)
        metrics_path = out_metrics_csv or (out_corrected_csv.parent / f"{out_corrected_csv.stem}_metrics.csv")
        if metrics_path.exists() and not overwrite:
            raise FileExistsError(f"exists: {metrics_path} (use --overwrite)")
        ensure_dir(metrics_path.parent)
        metrics_df.to_csv(metrics_path, index=False)
        log(f"[SAVED] metrics: {metrics_path}")

        if len(metrics_df) >= 2:
            b = metrics_df[metrics_df["kind"] == "baseline"].iloc[0]
            c = metrics_df[metrics_df["kind"] == "corrected"].iloc[0]
            summary["rows_eval"] = float(b["rows"])
            summary["global_RMSE_base"] = float(b["global_RMSE"])
            summary["global_RMSE_corr"] = float(c["global_RMSE"])
            if float(b["global_RMSE"]) > 0:
                summary["global_RMSE_improve_pct"] = float(
                    100.0 * (float(b["global_RMSE"]) - float(c["global_RMSE"])) / float(b["global_RMSE"])
                )
            else:
                summary["global_RMSE_improve_pct"] = float("nan")

            log("[METRIC] MSE/RMSE (baseline -> corrected)")
            for col in TARGET_COLS:
                log(
                    f"  {col}: MSE {float(b[f'{col}_MSE']):.6g} -> {float(c[f'{col}_MSE']):.6g} | "
                    f"RMSE {float(b[f'{col}_RMSE']):.6g} -> {float(c[f'{col}_RMSE']):.6g}"
                )
            log(
                f"  GLOBAL: MSE {float(b['global_MSE']):.6g} -> {float(c['global_MSE']):.6g} | "
                f"RMSE {float(b['global_RMSE']):.6g} -> {float(c['global_RMSE']):.6g}"
            )

        if plot_dir is not None:
            plot_truth_baseline_corrected(
                stem=out_corrected_csv.stem,
                merged_df=merged,
                out_dir=plot_dir,
                sample_every=plot_sample_every,
            )
            log(f"[SAVED] truth/baseline/corrected plots: {plot_dir}")

    return summary


def train_cmd(args: argparse.Namespace) -> int:
    tle_dir = Path(args.tle_dir)
    err_dir = Path(args.error_dir)
    out_model = Path(args.out_model)

    stems = list_stems_with_both(tle_dir, err_dir)
    if not stems:
        log("[ERROR] no matching TLE/error pairs found")
        return 2

    if args.max_files is not None:
        stems = stems[: int(args.max_files)]

    train_stems = [s for s in stems if deterministic_split(s, args.val_split, args.seed) == "train"]
    val_stems = [s for s in stems if deterministic_split(s, args.val_split, args.seed) == "val"]
    if not train_stems:
        train_stems = stems
    if not val_stems:
        n = max(1, int(0.1 * len(train_stems)))
        val_stems = train_stems[:n]

    cfg = FeatureConfig(
        day_harmonics=int(args.day_harmonics),
        span_harmonics=int(args.span_harmonics),
        include_sidereal=(not args.no_sidereal),
        include_interactions=(not args.no_interactions),
    )

    log(
        f"[INFO] files total/train/val = {len(stems)}/{len(train_stems)}/{len(val_stems)}, "
        f"days={args.days_horizon}, step={args.step_minutes}, sample_every={args.sample_every}"
    )

    x_mean, x_std, y_mean, y_std, feature_names, scaler_rows = compute_scalers(
        stems=train_stems,
        tle_dir=tle_dir,
        err_dir=err_dir,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        cfg=cfg,
    )
    log(f"[INFO] scaler rows={scaler_rows} dim={len(feature_names)}")

    beta, fit_rows = _fit_ridge_closed_form(
        stems=train_stems,
        tle_dir=tle_dir,
        err_dir=err_dir,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        cfg=cfg,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        ridge_lambda=float(args.ridge_lambda),
        target_clip_sigma=float(args.target_clip_sigma),
        time_weight_power=float(args.time_weight_power),
    )
    log(f"[INFO] fit rows={fit_rows}")

    bundle = ModelBundle(
        cfg=cfg,
        feature_names=feature_names,
        target_cols=list(TARGET_COLS),
        angle_cols=sorted(list(ANGLE_COLS)),
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        beta=beta,
        alpha_vec=np.ones((len(TARGET_COLS),), dtype=np.float64),
        default_clip_k_sigma=float(args.default_clip_k_sigma),
        ridge_lambda=float(args.ridge_lambda),
        error_definition="pred_minus_true",
        train_rows=int(fit_rows),
        train_files=int(len(train_stems)),
        val_files=int(len(val_stems)),
    )

    alpha_source = val_stems if val_stems else train_stems
    alpha_vec = fit_alpha_vector(
        stems=alpha_source,
        tle_dir=tle_dir,
        err_dir=err_dir,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        cfg=cfg,
        bundle=bundle,
        alpha_clip_min=float(args.alpha_clip_min),
        alpha_clip_max=float(args.alpha_clip_max),
    )
    bundle.alpha_vec = alpha_vec
    log(
        "[INFO] alpha per target (Lat,Lon,Alt,AZ,EL) = "
        + ", ".join(f"{v:.6g}" for v in alpha_vec.tolist())
    )

    train_eval = evaluate_error_prediction(
        stems=train_stems,
        tle_dir=tle_dir,
        err_dir=err_dir,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        cfg=cfg,
        bundle=bundle,
        alpha_vec=bundle.alpha_vec,
    )
    val_eval = evaluate_error_prediction(
        stems=val_stems,
        tle_dir=tle_dir,
        err_dir=err_dir,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        cfg=cfg,
        bundle=bundle,
        alpha_vec=bundle.alpha_vec,
    )

    if train_eval:
        log(
            f"[TRAIN] global RMSE {train_eval['global_RMSE_base']:.6g} -> "
            f"{train_eval['global_RMSE_corr']:.6g} "
            f"({train_eval['global_RMSE_improve_pct']:.3f}%)"
        )
    if val_eval:
        log(
            f"[VAL] global RMSE {val_eval['global_RMSE_base']:.6g} -> "
            f"{val_eval['global_RMSE_corr']:.6g} "
            f"({val_eval['global_RMSE_improve_pct']:.3f}%)"
        )
        for col in TARGET_COLS:
            log(f"  {col}: RMSE {val_eval[f'{col}_RMSE_base']:.6g} -> {val_eval[f'{col}_RMSE_corr']:.6g}")

    meta_path = save_model(bundle=bundle, out_model=out_model, overwrite=args.overwrite)

    summary = {
        "train_eval": train_eval,
        "val_eval": val_eval,
    }
    summary_path = meta_path.parent / "train_summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[SAVED] model meta: {meta_path}")
    log(f"[SAVED] train summary: {summary_path}")
    return 0


def predict_cmd(args: argparse.Namespace) -> int:
    bundle = load_model(Path(args.model))
    truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True) if args.truth_csv else None

    out_corr = Path(args.out_corrected_csv)
    out_err = Path(args.out_pred_error_csv)
    out_metrics = Path(args.out_metrics_csv) if args.out_metrics_csv else None
    plot_dir = Path(args.plot_dir) if args.plot_dir else (out_corr.parent / "plots")

    run_predict_one(
        bundle=bundle,
        tle_file=Path(args.tle_file),
        baseline_csv=Path(args.baseline_csv),
        out_corrected_csv=out_corr,
        out_pred_error_csv=out_err,
        truth_df=truth_df,
        out_metrics_csv=out_metrics,
        plot_dir=plot_dir,
        days=int(args.days),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        plot_sample_every=int(args.plot_sample_every),
        overwrite=args.overwrite,
        error_definition_override=args.error_definition,
        alpha_override=args.alpha_override,
        clip_k_sigma_override=args.clip_k_sigma,
    )
    return 0


def predict_dir_cmd(args: argparse.Namespace) -> int:
    bundle = load_model(Path(args.model))
    tle_dir = Path(args.tle_dir)
    baseline_dir = Path(args.baseline_dir)
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)

    truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True) if args.truth_csv else None
    plot_dir = out_dir / "plots"

    files = sorted([p for p in baseline_dir.glob(args.glob) if p.is_file()])
    if not files:
        log(f"[ERROR] no baseline files: dir={baseline_dir}, glob={args.glob}")
        return 2

    summary_rows: List[Dict[str, float]] = []
    total = len(files)

    for i, base_path in enumerate(files, start=1):
        stem = base_path.stem
        tle_file = tle_dir / f"{stem}.txt"
        if not tle_file.exists():
            log(f"[SKIP] ({i}/{total}) missing TLE: {tle_file.name}")
            continue

        out_corr = out_dir / f"{stem}.csv"
        out_err = out_dir / f"{stem}_pred_error.csv"
        out_metrics = out_dir / f"{stem}_metrics.csv"

        try:
            s = run_predict_one(
                bundle=bundle,
                tle_file=tle_file,
                baseline_csv=base_path,
                out_corrected_csv=out_corr,
                out_pred_error_csv=out_err,
                truth_df=truth_df,
                out_metrics_csv=out_metrics,
                plot_dir=plot_dir,
                days=int(args.days),
                step_minutes=int(args.step_minutes),
                sample_every=int(args.sample_every),
                plot_sample_every=int(args.plot_sample_every),
                overwrite=args.overwrite,
                error_definition_override=args.error_definition,
                alpha_override=args.alpha_override,
                clip_k_sigma_override=args.clip_k_sigma,
            )
            row = {"stem": stem}
            row.update(s)
            summary_rows.append(row)
            log(f"[OK] ({i}/{total}) {stem}")
        except Exception as e:
            log(f"[FAIL] ({i}/{total}) {stem}: {e}")

    summary_path = out_dir / "summary_metrics.csv"
    if summary_rows:
        pd.DataFrame(summary_rows).to_csv(summary_path, index=False)
        log(f"[SAVED] summary: {summary_path}")
    else:
        log("[WARN] no successful predictions in directory mode")
    return 0


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="orbit_error_ai_no_tle.py",
        description="Learn and apply orbit error correction from No + TLE only.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train", help="Train error model from 2023 error files")
    t.add_argument("--tle-dir", default="23467_2023")
    t.add_argument("--error-dir", default="23467_2023_error")
    t.add_argument("--out-model", default="orbit_error_model_no_tle")
    t.add_argument("--days-horizon", type=int, default=30)
    t.add_argument("--step-minutes", type=int, default=1)
    t.add_argument("--sample-every", type=int, default=1)
    t.add_argument("--val-split", type=float, default=0.1)
    t.add_argument("--seed", type=int, default=42)
    t.add_argument("--max-files", type=int, default=None)
    t.add_argument("--day-harmonics", type=int, default=4)
    t.add_argument("--span-harmonics", type=int, default=2)
    t.add_argument("--no-sidereal", action="store_true")
    t.add_argument("--no-interactions", action="store_true")
    t.add_argument("--ridge-lambda", type=float, default=1e-2)
    t.add_argument("--target-clip-sigma", type=float, default=8.0)
    t.add_argument("--time-weight-power", type=float, default=0.0)
    t.add_argument("--alpha-clip-min", type=float, default=0.0)
    t.add_argument("--alpha-clip-max", type=float, default=1.0)
    t.add_argument("--default-clip-k-sigma", type=float, default=4.0, help="Default correction clip in inference: k * y_std")
    t.add_argument("--overwrite", action="store_true")

    pr = sub.add_parser("predict", help="Predict/correct one baseline CSV")
    pr.add_argument("--model", required=True)
    pr.add_argument("--tle-file", required=True)
    pr.add_argument("--baseline-csv", required=True)
    pr.add_argument("--out-corrected-csv", required=True)
    pr.add_argument("--out-pred-error-csv", required=True)
    pr.add_argument("--out-metrics-csv", default=None)
    pr.add_argument("--truth-csv", default=None)
    pr.add_argument("--plot-dir", default=None)
    pr.add_argument("--plot-sample-every", type=int, default=5)
    pr.add_argument("--days", type=int, default=30)
    pr.add_argument("--step-minutes", type=int, default=1)
    pr.add_argument("--sample-every", type=int, default=1)
    pr.add_argument("--error-definition", choices=["pred_minus_true", "true_minus_pred"], default=None)
    pr.add_argument("--alpha-override", type=float, default=None, help="Override learned alpha with a scalar (e.g. 1.0)")
    pr.add_argument("--clip-k-sigma", type=float, default=None, help="Override correction clip k (k * y_std). <=0 disables clipping.")
    pr.add_argument("--overwrite", action="store_true")

    pdm = sub.add_parser("predict-dir", help="Predict/correct all baseline CSVs in a directory")
    pdm.add_argument("--model", required=True)
    pdm.add_argument("--tle-dir", default="23467_2024")
    pdm.add_argument("--baseline-dir", default="23467_2024_csv")
    pdm.add_argument("--out-dir", default="23467_2024_corrected")
    pdm.add_argument("--truth-csv", default="2024_calc_az_el.csv")
    pdm.add_argument("--glob", default="*.csv")
    pdm.add_argument("--days", type=int, default=30)
    pdm.add_argument("--step-minutes", type=int, default=1)
    pdm.add_argument("--sample-every", type=int, default=1)
    pdm.add_argument("--plot-sample-every", type=int, default=5)
    pdm.add_argument("--error-definition", choices=["pred_minus_true", "true_minus_pred"], default=None)
    pdm.add_argument("--alpha-override", type=float, default=None, help="Override learned alpha with a scalar (e.g. 1.0)")
    pdm.add_argument("--clip-k-sigma", type=float, default=None, help="Override correction clip k (k * y_std). <=0 disables clipping.")
    pdm.add_argument("--overwrite", action="store_true")

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = make_parser().parse_args(argv)
    if args.cmd == "train":
        return train_cmd(args)
    if args.cmd == "predict":
        return predict_cmd(args)
    if args.cmd == "predict-dir":
        return predict_dir_cmd(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
