========================================================================
 航跡予測AI v2 — 学習/推論/評価スクリプト一式（ポータブル版）
 作成: 2026-07-08
========================================================================

このフォルダは、コードだけを持ち運べるようにまとめたものです。
データファイル（GeoJSON数百GB、航跡CSV約150GB、学習済みモデル.pt）は
容量が大きいため含めていません。別マシンで動かすには、下記「データの用意」
の手順で自分でデータを生成するか、元データ/モデルを別途コピーしてください。

------------------------------------------------------------------------
 0. 動作環境
------------------------------------------------------------------------
- OS      : Windows + PowerShell（日本語パスOK。パス指定は -LiteralPath 推奨）
- Python  : 3.10+（cu128対応のtorchをGPU学習に使用）
- 依存    : torch(2.11+cu128), numpy, pandas, scipy, shapely, matplotlib
            （cartopyは任意。無くても --no-cartopy 系で動く）
- GPU     : 学習はCUDA GPU推奨（開発機はRTX 5070 12GB）。
            目的地推論・評価の一部はCPUのみでも可。
- 文字コード: python実行前に必ず  $env:PYTHONUTF8='1'  を設定（日本語ログ対策）

  依存インストール例:
    pip install torch --index-url https://download.pytorch.org/whl/cu128
    pip install numpy pandas scipy shapely matplotlib

- コマンドは全て「srcフォルダ内」で実行する前提です。まず:
    Set-Location -LiteralPath '<このフォルダ>\src'
    $env:PYTHONUTF8='1'

------------------------------------------------------------------------
 1. スクリプト一覧（srcフォルダ）
------------------------------------------------------------------------
● 共通ライブラリ（他が import する土台。単体実行しない）
  traj_common.py          座標変換・モデル定義・データセット・cfg入出力

● 現行の主力パイプライン（★=これだけで学習→推論→評価が回る）
  ★ traj_train_cvres_mh.py   学習: multi-horizon直接予測（運用モデルcv0はこれ）
  ★ eval_batch.py            評価: 1000航跡を一括評価＋モデル間ペア検定
  ★ rolling_forecast.py      推論: 逐次修正型（観測が増えるごと予測更新）＋ローリング評価
    plot_mh_forecast.py      可視化: MH予測の地図PNG（single / rolling）
  ★ destination_baseline.py  目的地推論: 終点クラスタ語彙＋MMSI/位置検索（build/predict/evaluate）

● データ前処理（生GeoJSON→学習用CSVを作る。データ再生成時のみ）
  mmsi_geojson_to_timeseries_keep_attrs.py  GeoJSON→3分間隔の時系列CSV
  split_by_mmsi.py                          MMSI別に分割
  split_trajectories_by_gap.py              時間ギャップで航跡別CSVに分割
  carve_val500.py                           検証/ホールドアウト用の切り出し
  convert_2016_geojson.py                   2016データの変換補助

● 参考・実験系（現行運用では未使用。履歴として同梱）
  traj_train_cvres_sched.py   cv6版（固定ベンチ最良XXLの学習に使用）
  traj_train_cvres.py / traj_predict_cvres.py       CV残差の基本形
  traj_train_cvres_mdn.py                            確率分布ヘッド（棄却）
  traj_train_cvres_stop.py / traj_predict_cvres_stop.py  停止ゲート（棄却）
  traj_train.py / traj_predict.py                    移動量を直接予測する旧版
  visualize_trajectory_prediction.py                 旧可視化（MH非対応）
  add_coast_distance.py / geo_features.py / prepare_ai_feature_csv.py
      海岸線距離などの特徴量生成。現行dx,dyモデルでは不要。
      使う場合は geo_coast_grid.npz(約83MB, 本バンドル未同梱)が別途必要
      （geo_features.py で再生成可能）。

------------------------------------------------------------------------
 2. データの用意（別マシンで一から作る場合）
------------------------------------------------------------------------
生の月次GeoJSON（Tracks_YYYY_MM.geojson）から、学習用の「航跡別CSV」を作る。

 (1) GeoJSON → 3分間隔CSV
   python .\mmsi_geojson_to_timeseries_keep_attrs.py --in <Tracks_2016_01.geojson> --out <out.csv> ...
   （引数の詳細は各スクリプト冒頭のdocstring / --help を参照）

 (2) MMSI別 → 時間ギャップで航跡分割
   python .\split_trajectories_by_gap.py ...
   → 出力が学習の入力となる「MMSI_xxx_traj_xxxx.csv」の集合（例: trajectories_2017/）

 (3) 検証セットの切り出し（学習から隔離）
   python .\carve_val500.py ...   （val500 / holdout を作る）

 ※ データ配置の想定（元リポジトリ）:
     claude_test\trajectories_full\    2016の航跡CSV
     claude_test\trajectories_2017\    2017の航跡CSV
     claude_test\val500\               checkpoint選択用の検証セット
     claude_test\holdout2017\          主評価セット（1000航跡）
   別マシンでは相対パスを自分の配置に合わせて読み替えること。

------------------------------------------------------------------------
 3. 【本命】変位予測モデル（運用モデル cv0×XL）: 学習→推論→評価
------------------------------------------------------------------------
--- 3-1. 学習（約1.5〜2時間 / RTX 5070。seedを変えて2本作ればアンサンブル可）---
  python .\traj_train_cvres_mh.py `
    --data-dir ..\..\claude_test\trajectories_full ..\..\claude_test\trajectories_2017 `
    --out-dir  ..\..\claude_test\artifacts_mh_xl_cv0 `
    --val-dir  ..\..\claude_test\val500 `
    --cv-n-last 0 --horizon 20 --max-len 256 --batch-size 128 `
    --d-model 384 --nhead 8 --num-layers 8 --dim-feedforward 1536 `
    --epochs 5 --num-workers 16 --scaler-sample 3000 --amp --device cuda

  ・--cv-n-last 0 = CVアンカー無し（突発機動の追従が良くなる。運用はこれ）
  ・--amp = bf16で約2倍速
  ・各エポックで traj_model_ep{N}.pt を保存し、val最良を traj_model.pt に採用
  ・監視: ログの grad_skip が各エポック数回以内 / val_MAE が nan でないこと
  ・開始3分後に別窓で nvidia-smi 確認。GPU使用率90%以上・消費150W以上なら健全。
    100%表示なのに低電力(20〜60W)ならVRAM溢れ→共有メモリ退避で激遅。--batch-size 96へ。
  ・パスは自分の配置に合わせて変更（上例は src から見た相対パス。絶対パス推奨）

--- 3-2. 推論（逐次修正型。観測を足すごとに予測を更新）---
  python .\rolling_forecast.py forecast `
    --models <traj_model.pt> `
    --traj-csv <ある1航跡のCSV> `
    --min-history 20 --out-csv <pred_rolling.csv>

  ・出力CSVの各行 = (予測起点rev_i, 何歩先h, pred_lon, pred_lat)
  ・「今この瞬間の最新予測」= rev_i が最大の20行
  ・新しい観測が来たらCSVを追記して再実行するだけ（1 forward、一瞬）
  ・2モデルのアンサンブルは --models A.pt,B.pt（カンマ区切り）

--- 3-3. 評価1: 固定プロトコル（input80点→20歩、数十秒）---
  python .\eval_batch.py `
    --model <traj_model.pt> `
    --data-dir <holdout2017> `
    --out-csv <my_eval.csv> --device cuda
  → mean / median / trim10 / CVスキル比 / ステップ別 / レジーム別(stop/turn/cruise)
    参考値: cv0×XL ≈ 1.196km、cv6×XXL 2seedアンサンブル ≈ 1.151km

--- 3-4. 評価2: モデル間のペア検定（改善したかの判定は必ずこれ）---
  python .\eval_batch.py compare <旧.csv> <新.csv>
  → ペアt検定 + Wilcoxon。|t|>=2 で有意の目安。差0.02km以下は誤差圏内。

--- 3-5. 評価3: ローリング評価（運用時の実力＝突発機動対応の本番指標。約5分）---
  python .\rolling_forecast.py evaluate `
    --models <traj_model.pt> --data-dir <holdout2017> `
    --min-len 150 --limit 300 --min-history 20 --out-dir <my_rolling>
  → リードタイム曲線 / 固定ターゲット収束 / 機動イベント回復曲線
    参考値: cv0×XL h10=0.55km, h20=1.17km

--- 3-6. 可視化（任意）---
  python .\plot_mh_forecast.py single  --model <pt> --traj-csv <csv> --input-len 80 --steps 20 --out-png <png>
  python .\plot_mh_forecast.py rolling --model <pt> --traj-csv <csv> --anchors 75,80,85,90 --steps 20 --out-png <png>

  ★注意: eval_batch のCSVの cv_mae 列は、cv0系モデルだと「直近1点CV」基準に
    なる（cfgのcv_n_lastに追従）。cv6系との比較は必ず ai_mae 列 か compare で。

------------------------------------------------------------------------
 4. 目的地推論ベースライン（最終的にどの港へ行くか）
------------------------------------------------------------------------
GPUニューラル学習は不要。110万航跡の集計＝索引ビルド。

--- 4-1. 「学習」= 索引ビルド（約8分。学習データを変えた時だけ）---
  python .\destination_baseline.py build `
    --data-dir <trajectories_full> <trajectories_2017> `
    --out-dir  <destination_index> --num-workers 16
  → destination_index\（index.pkl, zones.csv=目的地帯一覧, build_meta.txt）
    健全性目安: zone数≈1300 / 最大zoneシェア<5% / カバレッジ≈77%

--- 4-2. 推論（逐次更新。--every N 点ごとに予測を更新した履歴表）---
  python .\destination_baseline.py predict `
    --index-dir <destination_index> --traj-csv <1航跡CSV> `
    --every 10 --top-k 3 --out-csv <pred_destination.csv>

--- 4-3. 評価（進捗20/50/80%時点 × 既知/初見船 の的中率）---
  python .\destination_baseline.py evaluate `
    --index-dir <destination_index> --data-dir <holdout2017> `
    --out-csv <destination_eval.csv>
  → 参考値: 進捗80%で Top-1 65%/Top-3 81%、的中時の距離中央値≈4km
    （距離4kmはゾーン粒度20km由来のオフセット。ゾーン的中は成功の意味）
  ★注意: 現状のholdout2017は99.3%が既知船。初見船の真値は
    MMSI分割ホールドアウト（docs参照）を作ってから測ること。

------------------------------------------------------------------------
 5. 実行順序のまとめ（初めての別マシン）
------------------------------------------------------------------------
  [A] 環境構築（0章） → [B] データ生成（2章: GeoJSON→航跡CSV→val/holdout）
  → [C] 変位モデル学習（3-1） → [D] 推論/評価（3-2〜3-6）
  → [E] 目的地索引ビルド（4-1） → [F] 目的地推論/評価（4-2〜4-3）

  既に学習済み .pt と航跡CSVを別途コピーできるなら [B][C][E] は省略し、
  [D][F] の推論・評価から始められる。

------------------------------------------------------------------------
 6. 詳しい背景・実験履歴・今後の方針
------------------------------------------------------------------------
  docs\NEXT_SESSION_PROMPT.md を参照（全実験の結果表、棄却した方針とその根拠、
  次の優先ロードマップ、既知の落とし穴＝VRAM溢れ/評価リーク/cv_mae列の注意 等）。
  各スクリプトの引数詳細は、ファイル冒頭のdocstringと --help に記載。
========================================================================
