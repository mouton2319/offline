import numpy as np, pandas as pd
import ufo4_orbit_predict_tf as core
import ufo4_harmonic_azel_tf as hm

def load(y):
    u,f=core.load_orbit_numeric_full(f'{y}_calc_az_el.csv')
    return u.astype(np.float64), f[:,3:5].astype(np.float64)

def align_prev_to_cur(prev_u, prev_a, cur_u):
    tpl=core.build_azel_template(prev_u, prev_a, np.ones((len(prev_u),),dtype=np.float32))
    base,_=core.lookup_template_azel(cur_u, tpl)
    return base, tpl

years={y:load(y) for y in range(2021,2025)}
base23,_=align_prev_to_cur(*years[2022], years[2023][0])
d23=np.column_stack([hm.angle_diff_deg(years[2023][1][:,0], base23[:,0]), years[2023][1][:,1]-base23[:,1]])
base24,_=align_prev_to_cur(*years[2023], years[2024][0])
truth=years[2024][1]

# baseline repeat
pred=base24.copy()
az=np.abs(hm.angle_diff_deg(pred[:,0], truth[:,0])); el=np.abs(pred[:,1]-truth[:,1])
print('repeat', (az.mean()+el.mean())/2, max(az.max(), el.max()))

# raw last delta copied by same index/key using 2023 delta length
n=min(len(base24), len(d23))
pred=base24[:n].copy(); pred[:,0]=core.wrap360(pred[:,0]+d23[:n,0]); pred[:,1]=np.clip(pred[:,1]+d23[:n,1], -90, 90)
tr=truth[:n]
az=np.abs(hm.angle_diff_deg(pred[:,0], tr[:,0])); el=np.abs(pred[:,1]-tr[:,1])
print('repeat + raw last delta', (az.mean()+el.mean())/2, max(az.max(), el.max()))

# damped with previous delta change using 2021->22 and 2022->23 raw deltas
base22,_=align_prev_to_cur(*years[2021], years[2022][0])
d22=np.column_stack([hm.angle_diff_deg(years[2022][1][:,0], base22[:,0]), years[2022][1][:,1]-base22[:,1]])
n=min(len(base24), len(d23), len(d22))
d_pred=d23[:n] + 0.5*(d23[:n]-d22[:n])
pred=base24[:n].copy(); pred[:,0]=core.wrap360(pred[:,0]+d_pred[:,0]); pred[:,1]=np.clip(pred[:,1]+d_pred[:,1], -90, 90)
tr=truth[:n]
az=np.abs(hm.angle_diff_deg(pred[:,0], tr[:,0])); el=np.abs(pred[:,1]-tr[:,1])
print('repeat + damped raw delta', (az.mean()+el.mean())/2, max(az.max(), el.max()))
