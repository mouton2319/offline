#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
指定フォルダ内のCSVファイルすべてに「No」列を追加して 1,2,3,... と連番を振るスクリプト。

- CSVごとにNoは必ず1から開始（初期化）
- 既に先頭列が「No」の場合は、その列を連番で上書き（元のNo列は破棄）
- 文字コードは自動推定（UTF-8 BOMあり→utf-8-sig、BOMなし→utf-8→cp932→shift_jis→euc_jp の順で試行）
- 区切り文字（delimiter）はSnifferで推定（失敗時はカンマ）

使い方例:
  python add_no_to_csvs.py "C:\data\csvs" --output-dir "C:\data\csvs_out"
  python add_no_to_csvs.py "/path/to/csvs" --inplace --backup

※大量ファイル/大容量でも動くように、pandasではなく標準csvモジュールでストリーム処理しています。
"""

from __future__ import annotations

import argparse
import csv
import os
import shutil
import sys
from pathlib import Path
from typing import Iterable, Optional, Sequence, Tuple


ENCODING_CANDIDATES: Sequence[str] = (
    "utf-8",       # BOMなしUTF-8
    "cp932",       # Windows日本語(Shift_JIS互換)
    "shift_jis",
    "euc_jp",
)


def detect_encoding(path: Path, candidates: Sequence[str] = ENCODING_CANDIDATES) -> str:
    """文字コードを推定する。

    - UTF-8のBOMが付いている場合は utf-8-sig を返す（BOMを自動除去するため）
    - それ以外は candidates の順にデコードできるか試す
    """
    head = path.read_bytes()[:8192]

    # UTF-8 BOM
    if head.startswith(b"\xef\xbb\xbf"):
        return "utf-8-sig"

    for enc in candidates:
        try:
            head.decode(enc)
            return enc
        except UnicodeDecodeError:
            continue

    raise RuntimeError(
        f"文字コードを自動判定できませんでした: {path}. "
        "必要なら --encoding を指定してください（例: --encoding cp932）"
    )


def detect_dialect_and_lineterminator(path: Path, encoding: str) -> Tuple[csv.Dialect, str]:
    """区切り文字などのdialectと、改行コードを推定する。"""
    # 改行コード推定（バイナリで確認）
    head_bytes = path.read_bytes()[:8192]
    lineterminator = "\r\n" if b"\r\n" in head_bytes else "\n"

    # dialect推定（テキストで確認）
    try:
        sample_text = head_bytes.decode(encoding, errors="strict")
    except UnicodeDecodeError:
        # encodingはdetect済みの想定だが、念のため
        sample_text = head_bytes.decode(encoding, errors="replace")

    sniffer = csv.Sniffer()
    try:
        dialect = sniffer.sniff(sample_text, delimiters=[",", "\t", ";", "|"])
    except csv.Error:
        dialect = csv.excel  # デフォルトはカンマ区切り想定

    # 元ファイルの改行に合わせる（Snifferは\r\nになりがち）
    try:
        dialect.lineterminator = lineterminator  # type: ignore[attr-defined]
    except Exception:
        # 念のため（通常は設定可能）
        pass

    return dialect, lineterminator


def iter_csv_files(input_dir: Path, pattern: str, recursive: bool) -> Iterable[Path]:
    if recursive:
        yield from sorted(input_dir.rglob(pattern))
    else:
        yield from sorted(input_dir.glob(pattern))


def add_no_column_one_file(
    input_path: Path,
    output_path: Path,
    *,
    no_header: bool,
    encoding: Optional[str],
) -> None:
    """1つのCSVにNo列を追加して output_path へ書き出す（ストリーム処理）。"""
    enc = encoding or detect_encoding(input_path)
    dialect, _ = detect_dialect_and_lineterminator(input_path, enc)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = output_path.with_suffix(output_path.suffix + ".tmp")

    with input_path.open("r", encoding=enc, newline="") as f_in, tmp_path.open("w", encoding=enc, newline="") as f_out:
        reader = csv.reader(f_in, dialect=dialect)
        writer = csv.writer(f_out, dialect=dialect)

        # ヘッダ処理
        first_row = next(reader, None)
        if first_row is None:
            # 空ファイル
            return

        if no_header:
            # ヘッダ無し: 先頭行もデータ扱いでNo付与
            writer.writerow(["1", *first_row])
            for i, row in enumerate(reader, start=2):
                writer.writerow([str(i), *row])
        else:
            header = first_row

            # 既に先頭がNo列なら上書き（元No列は破棄）
            has_no_at_first = (len(header) > 0 and header[0].lstrip("\ufeff") == "No")
            if has_no_at_first:
                writer.writerow(header)
                for i, row in enumerate(reader, start=1):
                    # row[0]が既存Noなので捨てる
                    if len(row) >= 1:
                        writer.writerow([str(i), *row[1:]])
                    else:
                        writer.writerow([str(i)])
            else:
                writer.writerow(["No", *header])
                for i, row in enumerate(reader, start=1):
                    writer.writerow([str(i), *row])

    # tmp -> output へ原子的に置換
    os.replace(tmp_path, output_path)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="フォルダ内の全CSVにNo列（1..）を追加します。")
    parser.add_argument("input_dir", help="入力CSVが入っているフォルダ")
    parser.add_argument("--output-dir", default=None, help="出力先フォルダ（省略時は input_dir/_with_no に出力）")
    parser.add_argument("--inplace", action="store_true", help="元CSVを上書きします（安全のためtmp経由）")
    parser.add_argument("--backup", action="store_true", help="--inplace時に .bak を作ってから上書きします")
    parser.add_argument("--recursive", action="store_true", help="サブフォルダも含めて再帰的に処理します")
    parser.add_argument("--pattern", default="*.csv", help='対象ファイルのglobパターン（既定: "*.csv"）')
    parser.add_argument("--no-header", action="store_true", help="CSVにヘッダ行が無い場合に指定")
    parser.add_argument("--encoding", default=None, help="文字コードを固定する場合に指定（例: utf-8, cp932）")

    args = parser.parse_args(argv)

    input_dir = Path(args.input_dir).expanduser().resolve()
    if not input_dir.exists() or not input_dir.is_dir():
        print(f"[ERROR] input_dir が存在しないか、フォルダではありません: {input_dir}", file=sys.stderr)
        return 2

    if args.inplace:
        output_dir = None
    else:
        output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else (input_dir / "_with_no")

    targets = [p for p in iter_csv_files(input_dir, args.pattern, args.recursive) if p.is_file()]
    if not targets:
        print(f"[INFO] 対象CSVが見つかりませんでした: dir={input_dir} pattern={args.pattern}", file=sys.stderr)
        return 0

    processed = 0
    failed = 0

    for in_path in targets:
        try:
            if args.inplace:
                out_path = in_path
                if args.backup:
                    bak_path = in_path.with_suffix(in_path.suffix + ".bak")
                    # 既にbakがある場合は上書きしない（安全）
                    if not bak_path.exists():
                        shutil.copy2(in_path, bak_path)
            else:
                # 入力フォルダからの相対パスを保って出力
                rel = in_path.relative_to(input_dir)
                out_path = output_dir / rel  # type: ignore[operator]

            add_no_column_one_file(
                in_path,
                out_path,
                no_header=args.no_header,
                encoding=args.encoding,
            )
            processed += 1
            print(f"[OK] {in_path} -> {out_path}")
        except Exception as e:
            failed += 1
            print(f"[NG] {in_path}: {e}", file=sys.stderr)

    print(f"[DONE] processed={processed}, failed={failed}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
