import json, math
from pathlib import Path
import numpy as np
import ufo4_sidereal_coeff_model as scm
import ufo4_orbit_predict_tf as core
import ufo4_harmonic_azel_tf as hm

cfg=scm.SiderealCoeffConfig(
    sidereal_harmonics=4,
    yearly_harmonics=2,
    year_poly_order=1,
    use_year_cycle_2=False,
    use_year_cycle_3=False,
    ridge=1e-3,
    correction_ridge=5e-3,
    chunk_rows=60000,
)

year_data={}
for y in range(2017,2025):
    unix, full = core.load_orbit_numeric_full(Path(f'{y}_calc_az_el.csv'))
    year_data[y]=(unix.astype(np.float64), full[:,3:5].astype(np.float64))

pair_betas={}
pair_tpl={}
for y in range(2018,2024):
    beta,tpl=scm._fit_pair_delta_beta(year_data[y-1][0], year_data[y-1][1], year_data[y][0], year_data[y][1], cfg, None)
    pair_betas[y]=beta
    pair_tpl[y]=tpl
    pred_base,_ = core.lookup_template_azel(year_data[y][0], tpl)
    delta = scm._predict_pair_delta_from_beta(beta, year_data[y][0], cfg)
    pred=pred_base.copy(); pred[:,0]=core.wrap360(pred[:,0]+delta[:,0]); pred[:,1]=np.clip(pred[:,1]+delta[:,1], -90, 90)
    az=np.abs(hm.angle_diff_deg(pred[:,0], year_data[y][1][:,0])); el=np.abs(pred[:,1]-year_data[y][1][:,1])
    print('fit pair exact', y, 'mae', float((az.mean()+el.mean())/2), 'max', float(max(az.max(), el.max())))

methods={}
methods['last']=lambda hist,target: hist[max(hist.keys())]
methods['mean']=lambda hist,target: np.mean(np.stack([hist[k] for k in sorted(hist)], axis=0), axis=0)
methods['wmean2']=lambda hist,target: np.average(np.stack([hist[k] for k in sorted(hist)], axis=0), axis=0, weights=np.linspace(1,2,len(hist)))

def lin(hist,target):
    yrs=np.array(sorted(hist),dtype=float)
    Y=np.stack([hist[k].reshape(-1) for k in yrs.astype(int)], axis=0)
    X=np.c_[np.ones_like(yrs), yrs]
    B=np.linalg.lstsq(X, Y, rcond=None)[0]
    return (np.array([1.0,float(target)]) @ B).reshape(next(iter(hist.values())).shape)
methods['linear']=lin

def damped(hist,target):
    yrs=sorted(hist)
    last=hist[yrs[-1]]
    if len(yrs)>=2:
        diff=hist[yrs[-1]]-hist[yrs[-2]]
        return last+0.5*diff
    return last
methods['damped']=damped

def cyc2(hist,target):
    yrs=np.array(sorted(hist),dtype=float)
    Y=np.stack([hist[int(k)].reshape(-1) for k in yrs], axis=0)
    X=np.c_[np.ones_like(yrs), np.sin(np.pi*(yrs-yrs[0])), np.cos(np.pi*(yrs-yrs[0]))]
    B=np.linalg.lstsq(X, Y, rcond=None)[0]
    xt=np.array([1.0, math.sin(math.pi*(target-yrs[0])), math.cos(math.pi*(target-yrs[0]))])
    return (xt @ B).reshape(next(iter(hist.values())).shape)
methods['cyc2']=cyc2


def eval_year(target, beta_pred):
    tpl=scm._build_prev_template(*year_data[target-1])
    base,_=core.lookup_template_azel(year_data[target][0], tpl)
    delta=scm._predict_pair_delta_from_beta(beta_pred, year_data[target][0], cfg)
    pred=base.copy(); pred[:,0]=core.wrap360(pred[:,0]+delta[:,0]); pred[:,1]=np.clip(pred[:,1]+delta[:,1], -90, 90)
    truth=year_data[target][1]
    az=np.abs(hm.angle_diff_deg(pred[:,0], truth[:,0])); el=np.abs(pred[:,1]-truth[:,1])
    return float((az.mean()+el.mean())/2), float(max(az.max(), el.max()))

for name, fn in methods.items():
    scores=[]
    for target in range(2020,2024):
        hist={y:pair_betas[y] for y in range(2018,target) if y in pair_betas}
        if len(hist)<2:
            continue
        beta_pred=fn(hist, target)
        scores.append((target,)+eval_year(target,beta_pred))
    beta2024=fn(pair_betas, 2024)
    s2024=eval_year(2024,beta2024)
    print('\nmethod', name)
    for row in scores:
        print(' holdout', row)
    print(' target2024', s2024)
