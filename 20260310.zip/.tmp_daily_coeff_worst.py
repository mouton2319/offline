import numpy as np, pandas as pd
H=2

def load_year(y):
    df=pd.read_csv(f'{y}_calc_az_el.csv', usecols=['date','AZ','EL'])
    dt=pd.to_datetime(df['date'])
    df['day_key']=dt.dt.strftime('%m-%d')
    df['minute']=dt.dt.hour*60+dt.dt.minute
    return df

def fit_day(minute, values, H=2):
    t=minute.to_numpy(dtype=float)
    y=values.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/1440.0
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    return np.linalg.lstsq(X,y,rcond=None)[0]

def eval_day(minute, beta, H=2):
    t=minute.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/1440.0
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    return X@beta

frames={y:load_year(y) for y in range(2017,2025)}
coefs={y:{} for y in range(2017,2025)}
for y,df in frames.items():
    for day,g in df.groupby('day_key'):
        coefs[y][day]=(fit_day(g['minute'], g['AZ'], H), fit_day(g['minute'], g['EL'], H))

truth=frames[2024]
rows=[]
for day,g in truth.groupby('day_key'):
    hist=[]
    for y in range(2017,2024):
        if day in coefs[y]: hist.append((y,coefs[y][day]))
    years=np.array([y for y,_ in hist], dtype=float)
    az_mat=np.stack([c[0] for _,c in hist], axis=0)
    el_mat=np.stack([c[1] for _,c in hist], axis=0)
    yrs=years[-4:]; A=np.c_[np.ones_like(yrs), yrs]
    B=np.linalg.lstsq(A, az_mat[-4:], rcond=None)[0]; b_az=np.array([1,2024.0])@B
    B=np.linalg.lstsq(A, el_mat[-4:], rcond=None)[0]; b_el=np.array([1,2024.0])@B
    paz=eval_day(g['minute'], b_az, H)
    pel=eval_day(g['minute'], b_el, H)
    da=np.abs(paz-g['AZ'].to_numpy())
    de=np.abs(pel-g['EL'].to_numpy())
    rows.append((day, da.max(), de.max(), da.mean(), de.mean(), g.iloc[np.argmax(np.maximum(da,de))]['date']))
rows=pd.DataFrame(rows, columns=['day','az_max','el_max','az_mae','el_mae','worst_time'])
print(rows.sort_values(['az_max','el_max'], ascending=False).head(20).to_string(index=False))
