#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡予測【multi-horizon 直接予測ヘッド版】の学習スクリプト。

土台は traj_train_cvres_sched.py。LRスケジュール(warmup+cosine)・val評価・
エポック毎checkpoint保存の機構はそのまま維持し、ターゲットと出力ヘッドだけを
「各位置iから horizon h=1..H の累積変位を一括直接予測」に置き換える。

=== 背景・狙い ===
従来のCV残差版は「次の1歩の残差」を予測して推論を20ステップ自己回帰していたため、
誤差が線形蓄積する exposure bias が支配的だった(step1=0.10km -> step20=2.9km)。
本版は各位置から h=1..H の累積変位を直接予測し、推論を1回のforwardで完結させる
(自己回帰なし)。これにより後半ステップ(s10-s20)の誤差蓄積を断ち切る狙い。

=== ターゲット定義(collate_cvres_mh) ===
各位置 i(0..L-2)、各 h=1..H について:
  - 累積変位  cum[i,h] = disp[i+1] + disp[i+2] + ... + disp[i+h]   (km)
  - CV累積    = h * cv[i]   (cv[i]=位置iまでの直近cv_n点平均移動量、cv_disp_from_seq と同一)
  - ターゲット residual[i,h] = (cum[i,h] - h*cv[i] - mh_res_mean[h]) / mh_res_std[h]
  - 有効マスク: i+h <= L-1
Y 形状 [B, L, H, 2]、マスク [B, L, H]。cumsum を使い O(L*H) のループを避ける。

=== 出力・損失 ===
モデル出力 [B, L, 2*H] -> view [B, L, H, 2]。損失は全有効 (i,h) の SmoothL1 平均
(horizon間の重みは均等)。

=== val評価(エポック毎) ===
各val航跡の input_len 点をモデルに入れ、最終位置の出力 [H,2] から
  dxy_cum[h] = h*cv_last + (residual[h]*std+mean)
  lon_h = lon0 + cumx[h]/km_per_deg_lon(lat0)、lat_h = lat0 + cumy[h]/KM_PER_DEG_LAT
で20点の予測位置を作り、truth と haversine 平均(sched の val と同じ集計・レジーム表示)。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\traj_train_cvres_mh.py `
    --data-dir .\\claude_test\\trajectories_full `
    --out-dir .\\claude_test\\artifacts_mh `
    --val-dir .\\claude_test\\val500 `
    --cv-n-last 6 --horizon 20 --max-len 256 --batch-size 256 --num-workers 16 --scaler-sample 3000 `
    --d-model 256 --nhead 8 --num-layers 6 --dim-feedforward 1024 `
    --epochs 8 --device cuda
"""

from __future__ import annotations

import argparse
import contextlib
import json
import math
import random
import sys
from collections import defaultdict
from dataclasses import asdict
from functools import partial
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parent))
from traj_common import (   # noqa: E402
    TrajConfig, TrajectoryDataset, build_model, fit_stats, list_traj_files,
    cv_disp_from_seq, lonlat_to_disp_km, km_per_deg_lon, KM_PER_DEG_LAT,
)
# val評価は eval_batch.py の前処理・レジーム分類・haversine を再利用。
from eval_batch import (   # noqa: E402
    read_traj, classify_regime, rollout_cv_single, haversine_km_arr,
)


# === multi-horizon collate =====================================================
def collate_cvres_mh(batch, feat_mean, feat_std, mh_res_mean, mh_res_std, cv_n, horizon):
    """各位置 i から horizon h=1..H の累積変位残差を一括ターゲットにする collate。

    ターゲット residual[i,h] = (cum[i,h] - h*cv[i] - mh_res_mean[h]) / mh_res_std[h]
      cum[i,h] = disp[i+1..i+h] の和、cv[i] = 位置iまでの直近cv_n点平均移動量。
    Y 形状 [B, L, H, 2]、マスク valid [B, L, H](i+h<=L-1 のみ True)。
    """
    H = int(horizon)
    B = len(batch)
    lengths = [b["feats"].shape[0] for b in batch]
    Lmax = max(lengths)
    F = batch[0]["feats"].shape[1]

    X = torch.zeros(B, Lmax, F)
    Y = torch.zeros(B, Lmax, H, 2)
    valid = torch.zeros(B, Lmax, H, dtype=torch.bool)
    pad = torch.ones(B, Lmax, dtype=torch.bool)

    mh_mean = np.asarray(mh_res_mean, dtype=np.float64)   # [H,2]
    mh_std = np.asarray(mh_res_std, dtype=np.float64)     # [H,2]

    for bi, b in enumerate(batch):
        L = b["feats"].shape[0]
        X[bi, :L] = b["feats"]
        pad[bi, :L] = False
        if L < 2:
            continue
        disp = b["disp"].numpy().astype(np.float64)       # [L,2]
        # cv_n=0 は「アンカー無し変種」: CV項をゼロにし、ターゲットを累積変位そのもの
        # (cum − h*0 = cum)にする。cv_disp_from_seq は cv_n=0 でゼロ割になるため呼ばない。
        if cv_n <= 0:
            cv = np.zeros((disp.shape[0], 2), dtype=np.float64)  # [L,2] アンカー無し
        else:
            cv = cv_disp_from_seq(disp, cv_n)              # [L,2] 各位置の1歩CV予測

        # 累積変位 cum[i,h] = sum_{k=1..h} disp[i+k] を cumsum で O(L*H) の明示ループなしに作る。
        # csum[j] = disp[0..j-1] の和(prefix、長さ L+1、csum[0]=0)。
        csum = np.zeros((L + 1, 2), dtype=np.float64)
        csum[1:] = np.cumsum(disp, axis=0)
        # i(0..L-2)、h(1..H) について i+h<=L-1 のみ有効。
        # cum[i,h] = csum[i+h+1] - csum[i+1]
        for h in range(1, H + 1):
            i_max = L - 1 - h                              # i は 0..i_max が有効
            if i_max < 0:
                break                                      # このh以降(より大)も無効
            idx = np.arange(0, i_max + 1)                  # 有効な i
            cum = csum[idx + h + 1] - csum[idx + 1]        # [n,2] 累積変位
            cv_cum = float(h) * cv[idx]                    # [n,2] CV累積
            resid = (cum - cv_cum - mh_mean[h - 1]) / mh_std[h - 1]   # 標準化残差 [n,2]
            Y[bi, idx, h - 1] = torch.from_numpy(resid).float()
            valid[bi, idx, h - 1] = True

    fm = torch.tensor(feat_mean) if feat_mean else None
    fs = torch.tensor(feat_std) if feat_std else None
    if fm is not None and fm.numel() == F:
        X = (X - fm) / fs
        X = X * (~pad).unsqueeze(-1)
    return {"x": X, "y": Y, "valid": valid, "pad": pad}


# === multi-horizon 残差統計(fit_res_stats の H 対応版)==========================
def fit_res_stats_mh(files, cv_n, horizon, sample, seed):
    """horizon別の累積残差 (cum[i,h] - h*cv[i]) の mean/std を推定する。

    返り値: mh_mean [H,2], mh_std [H,2]。std<1e-6 は 1.0 に置換(0割回避)。
    """
    H = int(horizon)
    rng = random.Random(seed)
    picks = files if len(files) <= sample else rng.sample(files, sample)
    # horizon別に残差を貯める。
    buckets = [[] for _ in range(H)]
    for p in picks:
        try:
            df = pd.read_csv(p)
            lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
            lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
        except Exception:
            continue
        disp = lonlat_to_disp_km(lon, lat)
        L = len(disp)
        if L < 2:
            continue
        # cv_n=0 は「アンカー無し変種」: CV項ゼロ。残差 = 累積変位そのものを標準化する。
        if cv_n <= 0:
            cv = np.zeros((L, 2), dtype=np.float64)
        else:
            cv = cv_disp_from_seq(disp, cv_n)
        csum = np.zeros((L + 1, 2), dtype=np.float64)
        csum[1:] = np.cumsum(disp, axis=0)
        for h in range(1, H + 1):
            i_max = L - 1 - h
            if i_max < 0:
                break
            idx = np.arange(0, i_max + 1)
            cum = csum[idx + h + 1] - csum[idx + 1]
            resid = cum - float(h) * cv[idx]              # 標準化前の残差 [n,2]
            buckets[h - 1].append(resid)

    mh_mean = np.zeros((H, 2), dtype=np.float64)
    mh_std = np.ones((H, 2), dtype=np.float64)
    for h in range(H):
        if buckets[h]:
            arr = np.concatenate(buckets[h], axis=0)
            m = arr.mean(axis=0)
            s = arr.std(axis=0)
            s = np.where(s < 1e-6, 1.0, s)
            mh_mean[h] = m
            mh_std[h] = s
    return mh_mean, mh_std


# === LRスケジュール(sched と同一)=============================================
def make_warmup_cosine_lambda(total_steps: int, warmup_steps: int, lr_min_ratio: float):
    """ステップ数 -> LR倍率 を返す関数(LambdaLR 用)。sched スクリプトと同一。"""
    warmup_steps = max(0, int(warmup_steps))
    total_steps = max(1, int(total_steps))
    decay_steps = max(1, total_steps - warmup_steps)

    def fn(step: int) -> float:
        if warmup_steps > 0 and step < warmup_steps:
            return float(step + 1) / float(warmup_steps)
        prog = min(1.0, float(step - warmup_steps) / float(decay_steps))
        cos = 0.5 * (1.0 + math.cos(math.pi * prog))
        return lr_min_ratio + (1.0 - lr_min_ratio) * cos

    return fn


# === val評価(multi-horizon: 1回forward、自己回帰なし)==========================
def evaluate_val_mae_mh(model, cfg, val_files, device, input_len_arg, steps_arg,
                        gpu_batch, val_limit, use_amp=False):
    """val セットの平均 ai_mae(km)を返す。multi-horizon の1回forward復元式で予測。

    集計・レジーム表示は sched の evaluate_val_mae と同一。自己回帰は行わない。
    val_limit>0 なら先頭 val_limit 件だけ評価(CPUスモークの時短用)。
    use_amp=True かつ CUDA のときは model forward を bf16 autocast で実行する
    (モデル出力のみbf16。cpu() で numpy に戻したあとの位置復元・haversine は
     従来通り float32/64 で計算するため最終精度は変わらない)。
    """
    cv_n = int(cfg.cv_n_last)
    H = int(getattr(cfg, "horizon", 20))
    stop_thresh_reg = float(getattr(cfg, "stop_thresh_km", 0.0) or 0.03)
    fm = np.asarray(cfg.feat_mean, dtype=np.float64)
    fs = np.asarray(cfg.feat_std, dtype=np.float64)
    mh_mean = np.asarray(cfg.mh_res_mean, dtype=np.float64)   # [H,2]
    mh_std = np.asarray(cfg.mh_res_std, dtype=np.float64)     # [H,2]
    max_ctx = int(cfg.max_len)

    use_files = list(val_files)
    if val_limit and val_limit > 0:
        use_files = use_files[:val_limit]

    items = []
    for p in use_files:
        lon, lat = read_traj(p)
        n = len(lon)
        input_len = min(int(input_len_arg), n - 1)
        steps = min(int(steps_arg), n - input_len)
        if input_len < 2 or steps < 1:
            continue
        hist_lon, hist_lat = lon[:input_len], lat[:input_len]
        truth_lon = lon[input_len:input_len + steps]
        truth_lat = lat[input_len:input_len + steps]
        disp = lonlat_to_disp_km(hist_lon, hist_lat)
        regime = classify_regime(truth_lon, truth_lat, hist_lon, hist_lat,
                                 stop_thresh=stop_thresh_reg)
        items.append(dict(filename=p.name, input_len=input_len, steps=steps,
                          hist_lon=hist_lon, hist_lat=hist_lat,
                          truth_lon=truth_lon, truth_lat=truth_lat,
                          disp=disp, regime=regime))
    if not items:
        return float("nan"), {}

    # input_len ごとにグループ化して1回forward。
    pred_map = {}
    groups = defaultdict(list)
    for it in items:
        groups[it["input_len"]].append(it)

    # AMP: CUDA のときだけ bf16 autocast を有効化(それ以外は無効コンテキスト)。
    amp_on = bool(use_amp) and (device.type == "cuda")
    amp_ctx = (torch.autocast(device_type="cuda", dtype=torch.bfloat16)
               if amp_on else contextlib.nullcontext())

    model.eval()
    with torch.no_grad():
        for ilen, grp in groups.items():
            B = len(grp)
            seq = np.stack([g["disp"] for g in grp], axis=0).astype(np.float64)  # [B,P,2]
            P = seq.shape[1]
            ctx = min(P, max_ctx)
            ctx_disp = seq[:, P - ctx:, :]
            x = (ctx_disp - fm) / fs
            cur_lon = np.array([float(g["hist_lon"][-1]) for g in grp], dtype=np.float64)
            cur_lat = np.array([float(g["hist_lat"][-1]) for g in grp], dtype=np.float64)
            # cv_n=0(アンカー無し変種)は CV項ゼロ。seq[:, -0:] は全体スライスの事故に
            # なるため、明示的にゼロ [B,2] を使い、復元は residual のみにする。
            if cv_n <= 0:
                cv_last = np.zeros((B, 2), dtype=np.float64)                     # [B,2] アンカー無し
            else:
                cv_last = seq[:, -cv_n:, :].mean(axis=1)                         # [B,2]

            out = np.zeros((B, H, 2), dtype=np.float64)
            for s in range(0, B, int(gpu_batch)):
                e = min(B, s + int(gpu_batch))
                xt = torch.from_numpy(x[s:e].astype(np.float32)).to(device)
                pad = torch.zeros(xt.shape[0], ctx, dtype=torch.bool, device=device)
                with amp_ctx:
                    o = model(xt, pad_mask=pad)[:, -1]                          # [b,2*H]
                # bf16出力は float32 に戻してから numpy 化(位置復元は float64)。
                out[s:e] = o.float().cpu().numpy().reshape(e - s, H, 2)

            residual = out * mh_std[None, :, :] + mh_mean[None, :, :]           # [B,H,2]
            h_idx = np.arange(1, H + 1, dtype=np.float64)[None, :, None]        # [1,H,1]
            cum = h_idx * cv_last[:, None, :] + residual                        # [B,H,2]
            lon_scale = np.maximum(111.320 * np.cos(np.radians(cur_lat)), 1e-6)  # km/deg lon
            plon = cur_lon[:, None] + cum[:, :, 0] / lon_scale[:, None]         # [B,H]
            plat = cur_lat[:, None] + cum[:, :, 1] / KM_PER_DEG_LAT             # [B,H]
            for i, g in enumerate(grp):
                s = g["steps"]
                pred_map[g["filename"]] = (plon[i, :s], plat[i, :s])

    ai_maes, cv_maes = [], []
    reg_ai = defaultdict(list)
    for it in items:
        fn = it["filename"]
        truth_lon, truth_lat = it["truth_lon"], it["truth_lat"]
        ai_lon, ai_lat = pred_map[fn]
        ai_err = haversine_km_arr(ai_lon, ai_lat, truth_lon, truth_lat)
        cv_lon, cv_lat = rollout_cv_single(it["hist_lon"], it["hist_lat"], it["steps"], cv_n)
        cv_err = haversine_km_arr(cv_lon, cv_lat, truth_lon, truth_lat)
        ai_maes.append(float(ai_err.mean()))
        cv_maes.append(float(cv_err.mean()))
        reg_ai[it["regime"]].append(float(ai_err.mean()))
    val_mae = float(np.mean(ai_maes))
    extra = {
        "cv_mae": float(np.mean(cv_maes)),
        "n": len(ai_maes),
        "regime": {k: (float(np.mean(v)), len(v)) for k, v in reg_ai.items()},
    }
    return val_mae, extra


# === CLI =======================================================================
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="航跡 decoder-only Transformer【multi-horizon直接予測版】を学習する。")
    p.add_argument("--data-dir", required=True, nargs="+", help="航跡別CSVフォルダ(複数指定可)")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--pattern", default="MMSI_*_traj_*.csv")
    p.add_argument("--feature-cols", default="")
    p.add_argument("--cv-n-last", type=int, default=6, help="等速(CV)予測に使う直近点数")
    p.add_argument("--horizon", type=int, default=20, help="直接予測する未来ステップ数H")
    p.add_argument("--limit-files", type=int, default=0)
    p.add_argument("--max-len", type=int, default=256)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--nhead", type=int, default=8)
    p.add_argument("--num-layers", type=int, default=3)
    p.add_argument("--dim-feedforward", type=int, default=256)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--interval-minutes", type=float, default=3.0)
    p.add_argument("--scaler-sample", type=int, default=2000)
    p.add_argument("--num-workers", type=int, default=0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="")
    # AMP(自動混合精度): bf16 で forward/loss を包む。既定off。
    p.add_argument("--amp", action="store_true",
                   help="学習のforward/lossを bf16 autocast で実行(既定off)。GradScaler不要。")
    # LRスケジュール
    p.add_argument("--warmup-steps", type=int, default=500, help="線形warmupのステップ数")
    p.add_argument("--lr-min", type=float, default=-1.0, help="cosine decay の最終LR。負なら lr/20。")
    # 検証ベースcheckpoint選択
    p.add_argument("--val-dir", default="", help="検証セット(val500)のフォルダ")
    p.add_argument("--val-pattern", default="*.csv")
    p.add_argument("--val-input-len", type=int, default=80)
    p.add_argument("--val-steps", type=int, default=20)
    p.add_argument("--val-gpu-batch", type=int, default=256)
    p.add_argument("--val-limit", type=int, default=0, help="val評価に使う先頭件数(0=全件)。CPUスモークの時短用。")
    return p


def main() -> int:
    args = build_parser().parse_args()
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    H = int(args.horizon)
    files = []
    for d in args.data_dir:
        files += list_traj_files(Path(d), args.pattern, 0)
    if args.limit_files and args.limit_files > 0:
        files = files[:args.limit_files]
    if not files:
        raise FileNotFoundError(f"航跡CSVがありません: {args.data_dir} / {args.pattern}")
    feature_cols = [c.strip() for c in (args.feature_cols.split(",") if args.feature_cols else []) if c.strip()]
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)

    val_files = []
    if args.val_dir:
        val_files = sorted(Path(args.val_dir).glob(args.val_pattern))
        if not val_files:
            print(f"[WARN] val-dir に一致なし: {args.val_dir}/{args.val_pattern}")

    print("=" * 80); print("[TRAIN traj_decoder_only_v1  target=CV残差 multi-horizon  +LRsched +val-checkpoint]")
    print(f"data_dir    : {args.data_dir}")
    print(f"trajectories: {len(files):,}")
    print(f"val_dir     : {args.val_dir or '(なし: train_loss で選択)'}   val_files: {len(val_files):,}  val_limit={args.val_limit}")
    print(f"feature_cols: {feature_cols if feature_cols else '(dx,dy のみ)'}")
    print(f"cv_n_last   : {args.cv_n_last}   horizon(H): {H}   max_len: {args.max_len}  d_model={args.d_model}")
    print(f"epochs={args.epochs}  batch={args.batch_size}  lr={args.lr}  warmup={args.warmup_steps}")
    print("=" * 80)

    print("[1/2] 標準化統計を推定中(disp/feat/multi-horizon CV残差)...")
    disp_mean, disp_std, feat_mean, feat_std = fit_stats(files, feature_cols, args.scaler_sample, args.seed)
    mh_res_mean, mh_res_std = fit_res_stats_mh(files, args.cv_n_last, H, args.scaler_sample, args.seed)
    input_dim = 2 + len(feature_cols)
    out_dim = 2 * H

    cfg = TrajConfig(
        feature_cols=feature_cols, input_dim=input_dim,
        d_model=args.d_model, nhead=args.nhead, num_layers=args.num_layers,
        dim_feedforward=args.dim_feedforward, dropout=args.dropout, max_len=args.max_len,
        interval_minutes=args.interval_minutes,
        disp_mean=disp_mean.tolist(), disp_std=disp_std.tolist(),
        feat_mean=feat_mean.tolist(), feat_std=feat_std.tolist(),
        target_mode="cv_residual_mh", cv_n_last=args.cv_n_last,
        out_dim=out_dim, horizon=H,
        mh_res_mean=mh_res_mean.tolist(), mh_res_std=mh_res_std.tolist(),
    )

    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))

    # AMP(bf16)の有効判定: --amp かつ CUDA かつ bf16対応 のときのみ有効化。
    # bf16なので GradScaler は不要(表現範囲がfp32と同等でオーバーフローしない)。
    use_amp = bool(args.amp)
    if use_amp:
        if device.type != "cuda":
            print("[WARN] --amp は CUDA でのみ有効。CPUのため fp32 にフォールバックします。")
            use_amp = False
        elif not torch.cuda.is_bf16_supported():
            print("[WARN] このGPUは bf16 非対応。fp32 にフォールバックします。")
            use_amp = False
        else:
            print("[AMP] bf16 autocast 有効(forward/loss を bf16、backward/step は fp32)。")

    ds = TrajectoryDataset(files, feature_cols, args.max_len, train=True, seed=args.seed)
    collate = partial(collate_cvres_mh, feat_mean=cfg.feat_mean, feat_std=cfg.feat_std,
                      mh_res_mean=cfg.mh_res_mean, mh_res_std=cfg.mh_res_std,
                      cv_n=cfg.cv_n_last, horizon=H)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
                        collate_fn=collate, pin_memory=(device.type == "cuda"), drop_last=False,
                        persistent_workers=(args.num_workers > 0),
                        prefetch_factor=(4 if args.num_workers > 0 else None))
    model = build_model(cfg).to(device)
    print(f"[MODEL] params={sum(p.numel() for p in model.parameters()):,}  input_dim={input_dim}  out_dim={out_dim}  device={device}")

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    crit = nn.SmoothL1Loss(reduction="none")

    steps_per_epoch = len(loader)
    total_steps = steps_per_epoch * args.epochs
    lr_min = args.lr_min if args.lr_min >= 0 else (args.lr / 20.0)
    lr_min_ratio = (lr_min / args.lr) if args.lr > 0 else 0.05
    lr_lambda = make_warmup_cosine_lambda(total_steps, args.warmup_steps, lr_min_ratio)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_lambda=lr_lambda)
    print(f"[SCHED] steps/epoch={steps_per_epoch}  total_steps={total_steps}  "
          f"warmup={args.warmup_steps}  lr={args.lr:g} -> lr_min={lr_min:g}(比 {lr_min_ratio:.4f})")

    best_val = float("inf"); best_epoch = -1
    best_path = out_dir / "traj_model.pt"
    history = []
    nonfinite_val_streak = 0   # val_MAE が連続で非有限になった回数(2連続で停止)
    print("[2/2] 学習...")
    for epoch in range(1, args.epochs + 1):
        model.train(); losses = []
        grad_skip = 0   # このエポックで勾配が非有限のため step をスキップした回数
        for batch in loader:
            x = batch["x"].to(device); y = batch["y"].to(device)     # y: [B,L,H,2]
            valid = batch["valid"].to(device); pad = batch["pad"].to(device)  # valid: [B,L,H]
            opt.zero_grad(set_to_none=True)
            # AMP: forward と loss 計算のみ bf16 autocast で包む。
            # backward / clip / optimizer step は autocast の外(fp32)で行う。
            amp_ctx = (torch.autocast(device_type="cuda", dtype=torch.bfloat16)
                       if use_amp else contextlib.nullcontext())
            with amp_ctx:
                pred = model(x, pad_mask=pad)                        # [B,L,2*H]
                B, L, _ = pred.shape
                pred = pred.view(B, L, H, 2)                         # [B,L,H,2]
                per = crit(pred, y).sum(dim=-1)                      # [B,L,H] (dx,dy を合算)
                m = valid.float()
                loss = (per * m).sum() / m.sum().clamp_min(1.0)      # 全有効(i,h)平均
            # isfinite ガード(既存のまま維持)。bf16でも loss はスカラーfp32相当。
            # loss が非有限のバッチは backward すら行わずスキップ(勾配汚染を未然に防ぐ)。
            if not torch.isfinite(loss):
                grad_skip += 1
                sched.step()
                continue
            loss.backward()
            # 数値安定化ガード: clip_grad_norm_ の戻り値(total_norm)を受け取り、
            # inf/nan なら opt.step() を行わずスキップ。従来は total_norm を見ずに
            # step していたため、勾配がinf/nanのバッチで clip が NaN を全勾配に伝播し、
            # step() で全重みが汚染 -> val 全航跡 nan という障害が発生していた。
            total_norm = nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            if not torch.isfinite(total_norm):
                # 非有限勾配: step せずに勾配を捨て、このバッチは無かったことにする。
                opt.zero_grad(set_to_none=True)
                grad_skip += 1
                sched.step()
                continue
            opt.step()
            sched.step()
            losses.append(float(loss.item()))
        tr = float(np.mean(losses)) if losses else float("nan")
        cur_lr = opt.param_groups[0]["lr"]

        # 保険: val評価前にモデル重みの有限性をチェック。非有限が残っていれば警告。
        # (直近の正常checkpointからの自動復旧はしない設計のため警告のみ。)
        weights_finite = all(torch.isfinite(p).all() for p in model.parameters())
        if not weights_finite:
            print(f"[WARN] 重みにNaN/Inf検出 (epoch {epoch}, grad_skip={grad_skip})。"
                  f"以降のval評価は汚染された重みで行われる可能性あり。")

        ep_path = out_dir / f"traj_model_ep{epoch}.pt"
        torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, ep_path)

        if val_files:
            model.eval()
            val_mae, extra = evaluate_val_mae_mh(
                model, cfg, val_files, device,
                args.val_input_len, args.val_steps, args.val_gpu_batch, args.val_limit,
                use_amp=use_amp)
            model.train()
            reg = extra.get("regime", {})
            reg_s = "  ".join(f"{k}={v[0]:.3f}(N{v[1]})" for k, v in sorted(reg.items()))
            print(f"[EPOCH {epoch:03d}] train_loss={tr:.6f}  lr={cur_lr:.3e}  "
                  f"val_MAE={val_mae:.4f}km  (val_CV={extra.get('cv_mae', float('nan')):.4f}, "
                  f"N={extra.get('n', 0)})  grad_skip={grad_skip}  [{reg_s}]")
            history.append((epoch, tr, val_mae))
            if np.isfinite(val_mae) and val_mae < best_val:
                best_val = val_mae; best_epoch = epoch
                torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, best_path)
                print(f"[SAVE] {best_path}  best_val_MAE={best_val:.4f}km (ep{best_epoch})")
            # val_MAE が非有限のまま学習を続けるのは無駄なので、2エポック連続で停止。
            if not np.isfinite(val_mae):
                nonfinite_val_streak += 1
                if nonfinite_val_streak >= 2:
                    raise RuntimeError(
                        f"val_MAE が2エポック連続で非有限(epoch {epoch})。"
                        f"重みのNaN/Inf汚染が疑われるため学習を停止します"
                        f"(grad_skip={grad_skip})。")
            else:
                nonfinite_val_streak = 0
        else:
            print(f"[EPOCH {epoch:03d}] train_loss={tr:.6f}  lr={cur_lr:.3e}  grad_skip={grad_skip}")
            history.append((epoch, tr, float("nan")))
            if np.isfinite(tr) and tr < best_val:
                best_val = tr; best_epoch = epoch
                torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, best_path)
                print(f"[SAVE] {best_path}  best_train_loss={best_val:.6f}")

    with (out_dir / "traj_config.json").open("w", encoding="utf-8") as fp:
        json.dump(asdict(cfg), fp, ensure_ascii=False, indent=2)

    with (out_dir / "train_history.json").open("w", encoding="utf-8") as fp:
        json.dump({
            "history": [{"epoch": e, "train_loss": t, "val_mae": v} for (e, t, v) in history],
            "best_epoch": best_epoch, "best_val": best_val,
            "selection": ("val_mae" if val_files else "train_loss"),
        }, fp, ensure_ascii=False, indent=2)

    print("=" * 80)
    print("[SUMMARY] epoch  train_loss   val_MAE(km)")
    for (e, t, v) in history:
        mark = "  <== 選択" if e == best_epoch else ""
        print(f"          {e:5d}  {t:10.6f}   {v:8.4f}{mark}")
    tag = "val_MAE" if val_files else "train_loss"
    print(f"[DONE] model={best_path}  best_epoch={best_epoch}  best_{tag}={best_val:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
