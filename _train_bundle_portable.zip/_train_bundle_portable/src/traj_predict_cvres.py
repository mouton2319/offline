#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡予測【CV残差ターゲット版】の推論スクリプト。

通常版 traj_predict.py との違いは「復元式」だけ(diffで比較しやすいよう別ファイル):
  次の移動量 dxy = 等速予測 cv(直近 cv_n 点の平均移動量) + モデルが出したCV残差
モデル・座標・特徴量は traj_common.py を共有。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\traj_predict_cvres.py `
    --model .\\claude_test\\artifacts_traj_full_cvres\\traj_model.pt `
    --history-csv <航跡CSV> --steps 20 --out .\\claude_test\\pred_cvres.csv --device cuda
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from traj_common import (
    load_model, lonlat_to_disp_km, km_per_deg_lon, KM_PER_DEG_LAT,
    build_feature_matrix, reconstruct_next_extra, unix_seconds,
)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="航跡(前半)から未来を自己回帰生成する【CV残差版】。")
    p.add_argument("--model", required=True)
    p.add_argument("--history-csv", required=True)
    p.add_argument("--steps", type=int, default=20)
    p.add_argument("--out", required=True)
    p.add_argument("--device", default="")
    return p


def main() -> int:
    args = build_parser().parse_args()
    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    model, cfg = load_model(Path(args.model), device)
    cv_n = int(cfg.cv_n_last)

    df = pd.read_csv(args.history_csv)
    if "unix_time" in df.columns:
        df = df.sort_values("unix_time").reset_index(drop=True)
    elif "timestamp" in df.columns:
        df = df.assign(_t=pd.to_datetime(df["timestamp"], utc=True, errors="coerce")).sort_values("_t").reset_index(drop=True)
    lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
    lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
    if len(lon) < 2:
        raise ValueError("入力航跡は2点以上必要です。")

    feature_cols = cfg.feature_cols
    disp = lonlat_to_disp_km(lon, lat)
    seq_disp = list(disp)
    seq_extra = list(build_feature_matrix(df, feature_cols)) if feature_cols else None
    unix = unix_seconds(df); cur_unix = float(unix[-1]) if len(unix) else 0.0
    interval = float(cfg.interval_minutes)

    rm = np.asarray(cfg.res_mean); rstd = np.asarray(cfg.res_std)
    fm = np.asarray(cfg.feat_mean); fstd = np.asarray(cfg.feat_std)
    cur_lon, cur_lat = float(lon[-1]), float(lat[-1])
    pred_rows = []; max_ctx = int(cfg.max_len)
    with torch.no_grad():
        for step in range(int(args.steps)):
            ctx = min(len(seq_disp), max_ctx)
            d = np.stack(seq_disp[-ctx:], axis=0)
            if feature_cols:
                e = np.stack(seq_extra[-ctx:], axis=0)
                feats = np.concatenate([d, e], axis=1)
            else:
                feats = d
            x = (feats - fm) / fstd
            xt = torch.from_numpy(x.astype(np.float32)).unsqueeze(0).to(device)
            pad = torch.zeros(1, ctx, dtype=torch.bool, device=device)
            nxt = model(xt, pad_mask=pad)[0, -1].cpu().numpy()   # CV残差(標準化)
            residual = nxt * rstd + rm
            cv = np.stack(seq_disp[-cv_n:], axis=0).mean(axis=0)  # 等速予測(直近cv_n平均)
            dxy = cv + residual                                  # 復元: CV + 残差
            new_lon = cur_lon + dxy[0] / km_per_deg_lon(cur_lat)
            new_lat = cur_lat + dxy[1] / KM_PER_DEG_LAT
            pred_rows.append((step + 1, new_lon, new_lat))
            prev_dxy = seq_disp[-1] if len(seq_disp) else None
            seq_disp.append(dxy.astype(np.float64))
            if feature_cols:
                cur_unix += interval * 60.0
                seq_extra.append(reconstruct_next_extra(feature_cols, new_lon, new_lat, cur_lon, cur_lat,
                                                        cur_unix, interval, prev_dxy=prev_dxy, cur_dxy=dxy))
            cur_lon, cur_lat = new_lon, new_lat

    out_path = Path(args.out); out_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(pred_rows, columns=["step", "lon", "lat"]).to_csv(out_path, index=False)
    print(f"[DONE] {len(pred_rows)} 点を予測(CV残差) -> {out_path}  (feature_cols={feature_cols if feature_cols else '(dx,dy のみ)'})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
