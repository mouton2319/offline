# split_by_mmsi.py

import argparse
import csv
import json
import os
import re
import sys
from decimal import Decimal
from collections import OrderedDict, defaultdict
from pathlib import Path

try:
    import ijson
except ImportError:
    print("[ERROR] ijson がインストールされていません。", file=sys.stderr)
    print("        次を実行してください: python -m pip install ijson", file=sys.stderr)
    sys.exit(1)


def safe_filename(value) -> str:
    """MMSIなどをWindowsファイル名として安全な文字列にする。

    Args:
        value: ファイル名の一部にしたい値。

    Returns:
        英数字、`_`、`.`、`-`だけを含む文字列。空なら`UNKNOWN`。
    """
    if value is None or value == "":
        value = "UNKNOWN"

    text = str(value)
    text = re.sub(r"[^0-9A-Za-z_.-]+", "_", text)
    return text or "UNKNOWN"

def json_default(obj):
    """ijsonが返すDecimalをjson.dump可能な型に変換する。

    Args:
        obj: json.dumpが標準では扱えなかったオブジェクト。

    Returns:
        Decimalが整数ならint、小数ならfloat。

    Raises:
        TypeError: Decimal以外が渡された場合。

    Notes:
        GeoJSONの座標やShape_Lengthなどの小数値対策。
    """
    if isinstance(obj, Decimal):
        if obj == obj.to_integral_value():
            return int(obj)
        return float(obj)

    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")


class GeoJsonMMSIWriter:
    """MMSIごとにGeoJSON FeatureCollectionを書き出すwriter。

    Notes:
        入力GeoJSONは巨大なため、MMSIごとに全Featureをメモリへ貯めない。
        Featureを読みながら該当MMSIの出力ファイルへ逐次追記する。
        ただしOSが同時に開けるファイル数には上限があるので、
        LRUで古いファイルハンドルを閉じながら処理する。
    """

    def __init__(self, output_dir: Path, max_open_files: int = 128):
        """writerを初期化する。

        Args:
            output_dir: MMSI別GeoJSONの出力先。
            max_open_files: 同時に開いておく出力ファイル数の上限。
        """
        self.output_dir = output_dir
        self.max_open_files = max_open_files

        self.open_files = OrderedDict()
        self.created = set()
        self.counts = defaultdict(int)
        self.labels = {}

    def _tmp_path(self, key: str) -> Path:
        """MMSI keyに対応する一時ファイルパスを返す。

        Args:
            key: `safe_filename()`済みのMMSI文字列。

        Returns:
            `.geojson.tmp`のPath。
        """
        return self.output_dir / f"MMSI_{key}.geojson.tmp"

    def _final_path(self, key: str) -> Path:
        """MMSI keyに対応する最終GeoJSONパスを返す。

        Args:
            key: `safe_filename()`済みのMMSI文字列。

        Returns:
            `.geojson`のPath。
        """
        return self.output_dir / f"MMSI_{key}.geojson"

    def _open(self, key: str, label: str):
        """指定MMSIの出力ファイルを開き、LRU状態を更新する。

        Args:
            key: ファイル名用に安全化したMMSI。
            label: GeoJSON nameに使う元MMSI表示文字列。

        Returns:
            書き込み用ファイルオブジェクト。
        """
        if key in self.open_files:
            # OrderedDictの末尾を「最近使った」扱いにするため、一度popして戻す。
            fp = self.open_files.pop(key)
            self.open_files[key] = fp
            return fp

        while len(self.open_files) >= self.max_open_files:
            # 先頭が最も長く使われていないファイルハンドル。
            # OSのopen file上限を避けるため閉じる。
            _, old_fp = self.open_files.popitem(last=False)
            old_fp.close()

        tmp_path = self._tmp_path(key)

        if key not in self.created:
            # 新規MMSIの最初のFeatureを書き込む前に、
            # GeoJSON FeatureCollectionのヘッダを書いておく。
            fp = tmp_path.open("w", encoding="utf-8", newline="\n")
            name = f"MMSI_{label}"
            fp.write('{"type":"FeatureCollection",')
            fp.write(f'"name":{json.dumps(name, ensure_ascii=False)},')
            fp.write('"features":[\n')

            self.created.add(key)
            self.labels[key] = label
        else:
            fp = tmp_path.open("a", encoding="utf-8", newline="\n")

        self.open_files[key] = fp
        return fp

    def write_feature(self, mmsi, feature: dict):
        """FeatureをMMSI別GeoJSONへ1件書き込む。

        Args:
            mmsi: Feature propertiesのMMSI値。
            feature: GeoJSON Feature dict。

        Returns:
            None。該当MMSIの一時GeoJSONへ追記する。
        """
        label = "UNKNOWN" if mmsi is None or mmsi == "" else str(mmsi)
        key = safe_filename(label)

        fp = self._open(key, label)

        if self.counts[key] > 0:
            fp.write(",\n")

        json.dump(
            feature,
            fp,
            ensure_ascii=False,
            separators=(",", ":"),
            default=json_default,
        )

        self.counts[key] += 1

    def close_all(self):
        """現在開いている全ファイルハンドルを閉じる。

        Returns:
            None。
        """
        for fp in self.open_files.values():
            fp.close()
        self.open_files.clear()

    def finalize(self):
        """各GeoJSONを閉じて`.tmp`から正式ファイル名へ変更する。

        Returns:
            None。

        Notes:
            処理中に中断した場合、未完成ファイルは`.tmp`のまま残る。
            正常終了時だけ閉じ括弧を書いて正式な`.geojson`へ置き換える。
        """
        self.close_all()

        for key in self.created:
            tmp_path = self._tmp_path(key)
            final_path = self._final_path(key)

            with tmp_path.open("a", encoding="utf-8", newline="\n") as fp:
                fp.write("\n]}\n")

            os.replace(tmp_path, final_path)

    def write_summary(self):
        """MMSI別出力件数のsummary CSVを書く。

        Returns:
            summary_by_mmsi.csvのPath。
        """
        summary_path = self.output_dir / "summary_by_mmsi.csv"

        with summary_path.open("w", encoding="utf-8-sig", newline="") as fp:
            writer = csv.writer(fp)
            writer.writerow(["MMSI", "feature_count", "output_file"])

            for key in sorted(self.created):
                label = self.labels.get(key, key)
                writer.writerow([
                    label,
                    self.counts[key],
                    f"MMSI_{key}.geojson",
                ])

        return summary_path


def prepare_output_dir(output_dir: Path, overwrite: bool):
    """出力フォルダを準備し、既存ファイルとの混在を防ぐ。

    Args:
        output_dir: MMSI別GeoJSONの出力先。
        overwrite: Trueなら既存のMMSI別GeoJSONとsummaryを削除する。

    Returns:
        None。

    Raises:
        RuntimeError: 既存出力があり、overwrite=Falseの場合。
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    existing = list(output_dir.glob("MMSI_*.geojson")) + list(output_dir.glob("MMSI_*.geojson.tmp"))

    if existing and not overwrite:
        raise RuntimeError(
            f"出力先 {output_dir} に既存のMMSI別GeoJSONがあります。\n"
            f"混在防止のため停止します。\n"
            f"上書きする場合は --overwrite を付けてください。"
        )

    if overwrite:
        for path in existing:
            path.unlink()

        summary = output_dir / "summary_by_mmsi.csv"
        if summary.exists():
            summary.unlink()


def parse_months(text: str):
    """月指定文字列を`01`形式の月リストへ変換する。

    Args:
        text: `all`, `01,02,03`, `1,2,3`のような指定。

    Returns:
        `["01", "02"]`のような2桁月文字列リスト。

    Raises:
        ValueError: 1〜12以外の月が指定された場合。
    """
    if text.lower() == "all":
        return [f"{m:02d}" for m in range(1, 13)]

    months = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        m = int(part)
        if not 1 <= m <= 12:
            raise ValueError(f"月の指定が不正です: {part}")
        months.append(f"{m:02d}")

    return months


def process_file(
    input_path: Path,
    writer: GeoJsonMMSIWriter,
    only_mmsi: set[str] | None,
    skip_null_mmsi: bool,
    add_source_month: bool,
    progress_every: int,
):
    """1つのTracks_YYYY_MM.geojsonを読み、MMSI別writerへ振り分ける。

    Args:
        input_path: 入力GeoJSONファイル。
        writer: MMSI別GeoJSONを書き出すGeoJsonMMSIWriter。
        only_mmsi: 指定MMSIだけ処理する場合のset。Noneなら全件。
        skip_null_mmsi: MMSI欠損Featureを捨てるか。
        add_source_month: Feature propertiesにSourceFileを追加するか。
        progress_every: 何Featureごとに進捗表示するか。0なら非表示。

    Returns:
        `(total_features, written_features)`。
    """
    print("=" * 80)
    print(f"[INPUT] {input_path}")
    print("=" * 80)

    if not input_path.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {input_path}")

    total_features = 0
    written_features = 0

    with input_path.open("rb") as fp:
        # ijsonでFeatureを1件ずつstreaming読み込みする。
        # 巨大GeoJSON全体をjson.loadするとメモリを大量に使うため避ける。
        for feature in ijson.items(fp, "features.item", use_float=True):
            total_features += 1

            props = feature.get("properties") or {}
            mmsi = props.get("MMSI")

            if mmsi is None or mmsi == "":
                if skip_null_mmsi:
                    continue
                mmsi_key_for_filter = "UNKNOWN"
            else:
                mmsi_key_for_filter = str(mmsi)

            if only_mmsi is not None and mmsi_key_for_filter not in only_mmsi:
                continue

            if add_source_month:
                props["SourceFile"] = input_path.name
                feature["properties"] = props

            writer.write_feature(mmsi, feature)
            written_features += 1

            if progress_every > 0 and total_features % progress_every == 0:
                print(
                    f"[PROGRESS] {input_path.name}: "
                    f"read={total_features:,}, written={written_features:,}"
                )

    print(
        f"[DONE] {input_path.name}: "
        f"read={total_features:,}, written={written_features:,}"
    )

    return total_features, written_features


def main():
    """コマンドライン引数を読み、月別GeoJSONをMMSI別GeoJSONへ分割する入口。

    Args:
        なし。argparseが`sys.argv`から読む。

    Returns:
        None。MMSI別GeoJSONとsummary_by_mmsi.csvを書き出す。
    """
    parser = argparse.ArgumentParser(
        description="Tracks_YYYY_MM.geojson をMMSIごとに分割する"
    )

    parser.add_argument(
        "--input-dir",
        default=".",
        help="Tracks_2016_01.geojson などがあるフォルダ",
    )
    parser.add_argument(
        "--year",
        type=int,
        default=2016,
        help="対象年。例: 2016",
    )
    parser.add_argument(
        "--months",
        default="all",
        help="対象月。all または 01,02,03 のように指定",
    )
    parser.add_argument(
        "--output-dir",
        default="by_mmsi",
        help="MMSI別GeoJSONの出力先",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="既存のMMSI別GeoJSONを削除して作り直す",
    )
    parser.add_argument(
        "--only-mmsi",
        nargs="*",
        default=None,
        help="指定したMMSIだけ抽出する。例: --only-mmsi 1056261 121251121",
    )
    parser.add_argument(
        "--skip-null-mmsi",
        action="store_true",
        help="MMSIがnullのFeatureを出力しない",
    )
    parser.add_argument(
        "--add-source-month",
        action="store_true",
        help="各FeatureのpropertiesにSourceFileを追加する",
    )
    parser.add_argument(
        "--max-open-files",
        type=int,
        default=128,
        help="同時に開く出力ファイル数",
    )
    parser.add_argument(
        "--progress-every",
        type=int,
        default=10000,
        help="何Featureごとに進捗表示するか。0で非表示",
    )

    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)

    months = parse_months(args.months)

    only_mmsi = None
    if args.only_mmsi is not None and len(args.only_mmsi) > 0:
        only_mmsi = {str(x) for x in args.only_mmsi}

    prepare_output_dir(output_dir, overwrite=args.overwrite)

    writer = GeoJsonMMSIWriter(
        output_dir=output_dir,
        max_open_files=args.max_open_files,
    )

    grand_read = 0
    grand_written = 0

    try:
        for mm in months:
            input_path = input_dir / f"Tracks_{args.year}_{mm}.geojson"

            read_count, written_count = process_file(
                input_path=input_path,
                writer=writer,
                only_mmsi=only_mmsi,
                skip_null_mmsi=args.skip_null_mmsi,
                add_source_month=args.add_source_month,
                progress_every=args.progress_every,
            )

            grand_read += read_count
            grand_written += written_count

        writer.finalize()
        summary_path = writer.write_summary()

    except Exception:
        writer.close_all()
        raise

    print("=" * 80)
    print("[ALL DONE]")
    print(f"read features    : {grand_read:,}")
    print(f"written features : {grand_written:,}")
    print(f"unique MMSI files: {len(writer.created):,}")
    print(f"output dir       : {output_dir}")
    print(f"summary          : {summary_path}")


if __name__ == "__main__":
    main()
