#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Predict-only script for UFO4 AZ/EL model.

Loads artifacts produced by ufo4_train_tf.py and runs inference.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np

import ufo4_orbit_predict_tf as core


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Predict UFO4 AZ/EL from trained artifacts (predict only).")

    p.add_argument("--model-dir", default="ufo4_azel_model_artifacts", help="Directory with model/meta/template.")
    p.add_argument("--model-path", default="", help="Override model path.")
    p.add_argument("--meta-path", default="", help="Override meta json path.")
    p.add_argument("--template-path", default="", help="Override template npz path.")

    p.add_argument(
        "--predict-template",
        default="2024_calc_az_el.csv",
        help="Template CSV with date/UNIX columns (used unless range mode).",
    )
    p.add_argument("--predict-start", default="", help='Range mode start JST "YYYY-MM-DD HH:MM:SS".')
    p.add_argument("--predict-end", default="", help='Range mode end JST "YYYY-MM-DD HH:MM:SS".')
    p.add_argument("--predict-step-minutes", type=int, default=1)

    p.add_argument(
        "--truth-file",
        default="",
        help="Optional truth CSV for evaluation. Empty => skip evaluation.",
    )
    p.add_argument("--allow-partial-truth-eval", action="store_true")

    p.add_argument("--output-dir", default="ufo4_prediction_tf")
    p.add_argument("--batch-size", type=int, default=4096)

    # Overrides for geometry/TLE correction behavior
    p.add_argument("--observer-lat", type=float, default=None)
    p.add_argument("--observer-lon", type=float, default=None)
    p.add_argument("--observer-alt-m", type=float, default=None)
    p.add_argument("--geo-radius-km", type=float, default=None)
    p.add_argument("--sat-name", default="")

    p.add_argument("--use-latest-tle-correction", dest="use_latest_tle_correction", action="store_true")
    p.add_argument("--no-latest-tle-correction", dest="use_latest_tle_correction", action="store_false")
    p.add_argument("--latest-tle-dir", default="")
    p.add_argument("--tle-correction-start", default="")
    p.add_argument("--tle-priority-days", type=float, default=None)
    p.add_argument("--tle-max-weight", type=float, default=None)
    p.add_argument("--tle-decay-hours", type=float, default=None)
    p.add_argument("--tle-max-hours", type=float, default=None)

    p.add_argument("--max-plot-points-per-month", type=int, default=12000)

    p.set_defaults(use_latest_tle_correction=None)
    return p.parse_args()


def _get_meta_value(meta: dict, key: str, override):
    if override is not None and override != "":
        return override
    return meta.get(key)


def _load_template_pack(path: Path) -> core.TemplatePack:
    z = np.load(path)
    return core.TemplatePack(
        slot_az_deg=np.asarray(z["slot_az_deg"], dtype=np.float64),
        slot_el_deg=np.asarray(z["slot_el_deg"], dtype=np.float64),
        slot_weight=np.asarray(z["slot_weight"], dtype=np.float64),
        minute_az_deg=np.asarray(z["minute_az_deg"], dtype=np.float64),
        minute_el_deg=np.asarray(z["minute_el_deg"], dtype=np.float64),
        minute_weight=np.asarray(z["minute_weight"], dtype=np.float64),
    )


def main() -> None:
    args = parse_args()
    core.require_tensorflow()
    tf = core.tf

    model_dir = Path(args.model_dir)
    model_dir.mkdir(parents=True, exist_ok=True)

    meta_path = Path(args.meta_path) if str(args.meta_path).strip() else (model_dir / "ufo4_azel_model_meta.json")
    if not meta_path.exists():
        raise FileNotFoundError(f"meta not found: {meta_path}")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))

    model_path = Path(args.model_path) if str(args.model_path).strip() else (model_dir / str(meta.get("model_path", "ufo4_azel_model.keras")))
    template_path = Path(args.template_path) if str(args.template_path).strip() else (model_dir / str(meta.get("template_path", "ufo4_azel_template.npz")))

    if not model_path.exists():
        raise FileNotFoundError(f"model not found: {model_path}")
    if not template_path.exists():
        raise FileNotFoundError(f"template not found: {template_path}")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    monthly_plot_dir = output_dir / "monthly_plots"

    pred_csv_path = output_dir / "predicted_calc_az_el.csv"
    pred_csv_before_tle_path = output_dir / "predicted_calc_az_el_before_tle.csv"
    metrics_json_path = output_dir / "metrics.json"
    metrics_csv_path = output_dir / "metrics_az_el.csv"
    metrics_monthly_csv_path = output_dir / "metrics_monthly_az_el.csv"
    metrics_before_csv_path = output_dir / "metrics_az_el_before_tle.csv"
    metrics_before_monthly_csv_path = output_dir / "metrics_monthly_az_el_before_tle.csv"
    metrics_lla_csv_path = output_dir / "metrics_lla_reconstructed.csv"

    feature_config = meta.get("feature_config", {})
    feat_cfg = core.FeatureConfig(
        daily_harmonics=int(feature_config.get("daily_harmonics", 16)),
        sidereal_harmonics=int(feature_config.get("sidereal_harmonics", 14)),
        yearly_harmonics=int(feature_config.get("yearly_harmonics", 8)),
        weekly_harmonics=int(feature_config.get("weekly_harmonics", 6)),
        monthly_harmonics=int(feature_config.get("monthly_harmonics", 4)),
    )

    base_unix = float(meta["base_unix"])
    y_mean = np.asarray(meta["y_mean"], dtype=np.float64)
    y_std = np.asarray(meta["y_std"], dtype=np.float64)

    alpha = meta.get("alpha_calibration", {})
    calib = core.BiasCalibration(
        alpha_az=float(alpha.get("alpha_az", 1.0)),
        alpha_el=float(alpha.get("alpha_el", 1.0)),
    )

    observer_lat = float(_get_meta_value(meta, "observer_lat", args.observer_lat))
    observer_lon = float(_get_meta_value(meta, "observer_lon", args.observer_lon))
    observer_alt_m = float(_get_meta_value(meta, "observer_alt_m", args.observer_alt_m))
    geo_radius_km = float(_get_meta_value(meta, "geo_radius_km", args.geo_radius_km))
    sat_name = str(_get_meta_value(meta, "sat_name", args.sat_name or None) or "23467")

    meta_use_tle = bool(meta.get("use_latest_tle_correction", True))
    use_tle = bool(args.use_latest_tle_correction) if args.use_latest_tle_correction is not None else meta_use_tle
    latest_tle_dir = str(_get_meta_value(meta, "latest_tle_dir", args.latest_tle_dir) or "pred_tle")
    tle_correction_start = str(_get_meta_value(meta, "tle_correction_start", args.tle_correction_start) or "")
    tle_priority_days = float(_get_meta_value(meta, "tle_priority_days", args.tle_priority_days))
    tle_max_weight = float(_get_meta_value(meta, "tle_max_weight", args.tle_max_weight))
    tle_decay_hours = float(_get_meta_value(meta, "tle_decay_hours", args.tle_decay_hours))
    tle_max_hours = float(_get_meta_value(meta, "tle_max_hours", args.tle_max_hours))

    use_range_mode = bool(str(args.predict_start).strip()) and bool(str(args.predict_end).strip())
    if use_range_mode:
        core.log("Building prediction timeline from --predict-start/--predict-end...")
        pred_dates, pred_unix = core.make_dates_unix_from_range(
            start_jst_str=str(args.predict_start),
            end_jst_str=str(args.predict_end),
            step_minutes=int(args.predict_step_minutes),
        )
    else:
        template_csv = Path(args.predict_template)
        if not template_csv.exists():
            raise FileNotFoundError(
                f"predict-template not found: {template_csv}. "
                "Use --predict-start/--predict-end for range mode."
            )
        pred_dates, pred_unix = core.load_template_with_dates(template_csv)

    template = _load_template_pack(template_path)

    core.log(f"Loading model: {model_path}")
    model = tf.keras.models.load_model(model_path, compile=False)

    pred_base_azel, pred_slot_weight = core.lookup_template_azel(pred_unix, template)
    ds_pred = core.make_predict_dataset(
        unix=pred_unix,
        base_az=pred_base_azel[:, 0],
        base_el=pred_base_azel[:, 1],
        slot_weight=pred_slot_weight,
        base_unix=base_unix,
        cfg=feat_cfg,
        batch_size=int(args.batch_size),
    )

    pred_res_scaled = model.predict(ds_pred, verbose=1)
    pred_res = core.decode_residual_predictions(pred_res_scaled, mean=y_mean, std=y_std)
    pred_azel_model = core.apply_residual_prediction(base_azel=pred_base_azel, residual_pred=pred_res, calib=calib)

    tle_meta = core.TLECorrectionMeta(
        enabled=bool(use_tle),
        applied=False,
        tle_path="",
        tle_epoch_unix=0,
        correction_start_unix=0,
        priority_days=float(tle_priority_days),
        max_weight=float(tle_max_weight),
        decay_hours=float(tle_decay_hours),
        max_hours=float(tle_max_hours),
        tle_count=0,
        segments_used=0,
        rows_corrected=0,
    )

    pred_azel = pred_azel_model.copy()
    if use_tle:
        try:
            pred_azel, _tle_azel, _weights, tle_meta = core.apply_multi_tle_correction(
                pred_unix=pred_unix,
                pred_azel=pred_azel_model,
                tle_dir=Path(latest_tle_dir),
                sat_name=sat_name,
                observer_lat=observer_lat,
                observer_lon=observer_lon,
                correction_start_str=tle_correction_start,
                priority_days=tle_priority_days,
                max_weight=tle_max_weight,
                decay_hours=tle_decay_hours,
                max_hours=tle_max_hours,
            )
            if tle_meta.applied:
                core.log(
                    "Applied multi-TLE correction: "
                    f"tles={tle_meta.tle_count}, segments={tle_meta.segments_used}, rows={tle_meta.rows_corrected}"
                )
            else:
                core.log("TLE correction enabled, but no rows matched correction window.")
        except Exception as e:
            core.log(f"[WARN] TLE correction skipped: {e}")

    pred_lla = core.azel_to_lla_geoshell(
        az_deg=pred_azel[:, 0],
        el_deg=pred_azel[:, 1],
        observer_lat_deg=observer_lat,
        observer_lon_deg=observer_lon,
        observer_alt_m=observer_alt_m,
        geo_radius_km=geo_radius_km,
    )
    pred_full = np.column_stack([pred_lla, pred_azel]).astype(np.float64)

    core.write_prediction_csv(pred_csv_path, pred_dates, pred_unix, pred_lla=pred_lla, pred_azel=pred_azel)

    if use_tle and tle_meta.applied:
        pred_lla_before = core.azel_to_lla_geoshell(
            az_deg=pred_azel_model[:, 0],
            el_deg=pred_azel_model[:, 1],
            observer_lat_deg=observer_lat,
            observer_lon_deg=observer_lon,
            observer_alt_m=observer_alt_m,
            geo_radius_km=geo_radius_km,
        )
        core.write_prediction_csv(
            pred_csv_before_tle_path,
            pred_dates,
            pred_unix,
            pred_lla=pred_lla_before,
            pred_azel=pred_azel_model,
        )

    core.log(f"Saved predicted CSV: {pred_csv_path}")

    truth_path = Path(args.truth_file) if str(args.truth_file).strip() else None
    if truth_path is None:
        core.log("No truth file specified. Skipping evaluation.")
        return
    if not truth_path.exists():
        core.log(f"Truth file not found: {truth_path}. Skipping evaluation.")
        return

    true_unix, true_full = core.load_orbit_numeric_full(truth_path)
    try:
        pred_aligned, true_aligned, unix_aligned = core.align_by_unix(
            pred_unix=pred_unix,
            pred_full=pred_full,
            true_unix=true_unix,
            true_full=true_full,
        )
    except RuntimeError:
        core.log("No overlapping UNIX timestamps with truth. Skipping evaluation.")
        return

    n_pred = int(len(pred_unix))
    n_eval = int(len(unix_aligned))
    if n_eval < n_pred and (not bool(args.allow_partial_truth_eval)):
        cov = 100.0 * float(n_eval) / float(max(1, n_pred))
        core.log(
            "Truth does not fully cover prediction period "
            f"(coverage={n_eval}/{n_pred} = {cov:.2f}%). "
            "Skipping metrics and error plots. "
            "Use --allow-partial-truth-eval to evaluate overlap only."
        )
        return

    if n_eval < n_pred:
        cov = 100.0 * float(n_eval) / float(max(1, n_pred))
        core.log(f"Partial truth coverage: {n_eval}/{n_pred} ({cov:.2f}%). Evaluating overlap only.")

    pred_full_before = pred_full.copy()
    pred_full_before[:, 3] = pred_azel_model[:, 0]
    pred_full_before[:, 4] = pred_azel_model[:, 1]
    pred_before_aligned, _, _ = core.align_by_unix(
        pred_unix=pred_unix,
        pred_full=pred_full_before,
        true_unix=true_unix,
        true_full=true_full,
    )

    metrics_azel = core.compute_metrics_azel(y_true_full=true_aligned, y_pred_full=pred_aligned)
    monthly_azel = core.compute_monthly_azel_metrics(unix=unix_aligned, y_true_full=true_aligned, y_pred_full=pred_aligned)
    metrics_azel_before = core.compute_metrics_azel(y_true_full=true_aligned, y_pred_full=pred_before_aligned)
    monthly_azel_before = core.compute_monthly_azel_metrics(
        unix=unix_aligned,
        y_true_full=true_aligned,
        y_pred_full=pred_before_aligned,
    )
    metrics_lla = core.compute_metrics_lla(y_true_full=true_aligned, y_pred_full=pred_aligned)

    core.write_metrics_json(
        path=metrics_json_path,
        rows_evaluated=true_aligned.shape[0],
        calib=calib,
        overall_azel_final=metrics_azel,
        monthly_azel_final=monthly_azel,
        overall_lla=metrics_lla,
        overall_azel_before_tle=metrics_azel_before,
        monthly_azel_before_tle=monthly_azel_before,
        tle_meta=tle_meta,
    )
    core.write_metrics_csv(metrics_csv_path, metrics_azel)
    core.write_monthly_metrics_csv(metrics_monthly_csv_path, monthly_azel)
    core.write_metrics_csv(metrics_before_csv_path, metrics_azel_before)
    core.write_monthly_metrics_csv(metrics_before_monthly_csv_path, monthly_azel_before)
    core.write_lla_metrics_csv(metrics_lla_csv_path, metrics_lla)

    core.plot_monthly_azel(
        unix=unix_aligned,
        y_true_full=true_aligned,
        y_pred_full=pred_aligned,
        out_dir=monthly_plot_dir,
        max_points_per_month=int(args.max_plot_points_per_month),
    )

    core.log(f"Saved metrics JSON           : {metrics_json_path}")
    core.log(f"Saved metrics CSV (AZ/EL)    : {metrics_csv_path}")
    core.log(f"Saved monthly metrics CSV    : {metrics_monthly_csv_path}")
    core.log(f"Saved before-TLE metrics CSV : {metrics_before_csv_path}")
    core.log(f"Saved before-TLE monthly CSV : {metrics_before_monthly_csv_path}")
    core.log(f"Saved reconstructed LLA CSV  : {metrics_lla_csv_path}")
    core.log(f"Saved monthly plots directory: {monthly_plot_dir}")
    core.log("Predict-only run complete.")


if __name__ == "__main__":
    main()
