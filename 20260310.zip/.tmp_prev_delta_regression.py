import numpy as np
from pathlib import Path
import ufo4_orbit_predict_tf as core
import ufo4_harmonic_azel_tf as hm

# row-wise regression: previous transition delta -> next transition delta

def time_features(unix):
    u=np.asarray(unix,dtype=np.float64)
    ul=u+9*3600.0
    ph_day=2*np.pi*(ul%86400.0)/86400.0
    year_sec=365.2422*86400.0
    ph_year=2*np.pi*((ul%(year_sec))/year_sec)
    cols=[np.ones_like(u)]
    for k in range(1,5):
        cols += [np.sin(k*ph_day), np.cos(k*ph_day)]
    for k in range(1,4):
        cols += [np.sin(k*ph_year), np.cos(k*ph_year)]
    return np.column_stack(cols)


def build_delta_template(unix, delta):
    return core.build_azel_template(unix=unix, azel=delta, weight=np.ones((len(unix),), dtype=np.float32))


def lookup_delta(unix, tpl):
    out,_=core.lookup_template_azel(unix, tpl)
    return out


years={}
for y in range(2017,2025):
    u,f=core.load_orbit_numeric_full(Path(f'/work/{y}_calc_az_el.csv'))
    years[y]=(u.astype(np.float64), f[:,3:5].astype(np.float64))

# transition deltas y-1->y
trans={}
for y in range(2018,2025):
    tpl=core.build_azel_template(years[y-1][0], years[y-1][1], np.ones((len(years[y-1][0]),),dtype=np.float32))
    base,_=core.lookup_template_azel(years[y][0], tpl)
    delta=np.column_stack([hm.angle_diff_deg(years[y][1][:,0], base[:,0]), years[y][1][:,1]-base[:,1]])
    trans[y]={'unix':years[y][0], 'base':base, 'delta':delta}

X=[]; Y=[]
for y in range(2019,2024):
    prev_tpl=build_delta_template(trans[y-1]['unix'], trans[y-1]['delta'])
    prev_delta=lookup_delta(trans[y]['unix'], prev_tpl)
    base=trans[y]['base']
    feat=np.concatenate([
        time_features(trans[y]['unix']),
        hm.azel_to_trig4(base),
        prev_delta,
        prev_delta * np.array([[1.0,0.0]]),
    ], axis=1)
    idx=np.arange(0, feat.shape[0], 5)
    X.append(feat[idx])
    Y.append(trans[y]['delta'][idx])
X=np.concatenate(X, axis=0)
Y=np.concatenate(Y, axis=0)
print('train', X.shape, Y.shape)
# standardize
mu=X.mean(axis=0); sd=X.std(axis=0); sd=np.where(sd<1e-9,1.0,sd)
Xz=(X-mu)/sd
ridge=1e-2
B=np.linalg.solve(Xz.T@Xz + np.eye(Xz.shape[1])*ridge, Xz.T@Y)

# infer 2024
prev_tpl=build_delta_template(trans[2023]['unix'], trans[2023]['delta'])
prev_delta=lookup_delta(trans[2024]['unix'], prev_tpl)
base=trans[2024]['base']
feat=np.concatenate([time_features(trans[2024]['unix']), hm.azel_to_trig4(base), prev_delta, prev_delta*np.array([[1.0,0.0]])], axis=1)
F=(feat-mu)/sd
pred_delta=F@B
# alpha search on prev_delta blend
truth=years[2024][1]
best=None
for a in np.linspace(0,1.5,31):
    out=base.copy()
    d=pred_delta*a
    out[:,0]=core.wrap360(out[:,0]+d[:,0])
    out[:,1]=out[:,1]+d[:,1]
    az=np.abs(hm.angle_diff_deg(out[:,0], truth[:,0])); el=np.abs(out[:,1]-truth[:,1])
    m=float((az.mean()+el.mean())/2); mx=float(max(az.max(), el.max()))
    if best is None or mx<best[2]: best=(a,m,mx)
    print('alpha',a,'mean',m,'max',mx)
print('best',best)
