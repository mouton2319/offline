# Repository Guidelines

## Project Structure & Module Organization
- Top-level Python scripts drive data generation and modeling: `calc_az_el_2023.py`, `calc_az_el_2024.py`, `make_30days_csv_from_each_tle.py`, `calc_orbit_error_vs_true_2023.py`, `orbit_error_ai_ecef.py`, `orbit_error_ai_ecef_1.py`.
- TLE input data lives in year-stamped folders: `23467_2023/`, `23467_2024/` (timestamped `*.txt`).
- Generated CSV outputs are stored in matching folders: `23467_2023_csv/`, `23467_2024_csv/` and root summaries like `2023_calc_az_el.csv`, `2024_calc_az_el.csv`.
- Error/analysis artifacts are organized separately: `23467_2023_error/`, `23467_2024_corrected/plots/`.
- Trained model artifacts are under `orbit_error_model_ecef_mse/` (`*.keras`, `meta.json`).

## Build, Test, and Development Commands
- There is no build system; run scripts directly with Python 3.
- Examples:
  - Generate AZ/EL CSV across a year: `python calc_az_el_2024.py --tle-dir 23467_2024 --out-csv 2024_calc_az_el.csv`.
  - Generate per-TLE 30-day CSVs: `python make_30days_csv_from_each_tle.py --tle-dir 23467_2024 --out-dir 23467_2024_csv --days 30`.
  - Compute orbit error vs. truth: `python calc_orbit_error_vs_true_2023.py --input 2023_calc_az_el.csv` (adjust flags as needed).

## Coding Style & Naming Conventions
- Language: Python 3. Follow PEP 8 with 4-space indentation and ASCII-only identifiers unless already present.
- Filenames use lowercase with underscores (e.g., `calc_orbit_error_vs_true_2023.py`).
- Data files are timestamped as `YYYY-MM-DD_HH-MM-SS.txt` or `.csv`.
- Formatting/linting tools are not configured in this repo; keep changes minimal and consistent with surrounding code.

## Testing Guidelines
- No automated test suite is present.
- Validate changes by running the affected script on a small input set and inspecting the output CSV or plots.

## Commit & Pull Request Guidelines
- This repository does not include Git history or documented conventions.
- Use concise, imperative commit messages (e.g., `Fix TLE timestamp parsing`) and describe input/output changes in PRs.
- If you modify plots or CSV generation, include a brief sample output or summary of deltas.

## Configuration & Data Notes
- Scripts assume local folders exist and use Skyfield for orbit propagation; first run may download IERS data.
- Dependencies are not pinned; typical installs include `numpy`, `pandas`, `skyfield`, `matplotlib`, and `tensorflow` for model scripts.
