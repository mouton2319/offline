#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Hybrid GEO predictor: residual correction + direct truth prediction.

Motivation:
- Pure direct learning (TLE -> truth) is often unstable under year shift.
- Pure correction can overfit and hurt AZ/EL when baseline is already strong.

This script trains two heads simultaneously:
1) residual head: predict (truth - baseline)
2) direct head: predict truth directly

At inference, output is blended around baseline:
  corrected = baseline + alpha * residual_pred + beta * (direct_pred - baseline)

alpha/beta are calibrated on validation split per target and per day-bin.
If a bin does not improve RMSE enough, alpha/beta are forced to 0
(automatic fallback to baseline for that bin/target).
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import math
import os
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import tensorflow as tf
except Exception:
    tf = None

from orbit_error_ai_no_tle_tf import (
    ANGLE_COLS,
    ANTENNA_COLS,
    MINUTES_PER_DAY,
    TARGET_COLS,
    FeatureConfig,
    OnlineMeanVar,
    angle_diff_deg,
    build_baseline_features,
    build_no_features,
    compute_metrics,
    deterministic_split,
    ensure_dir,
    list_stems_with_both,
    load_orbit_csv,
    log,
    now_jst_str,
    parse_tle_file,
    plot_baseline_vs_corrected,
    plot_metric_summary,
    plot_truth_baseline_corrected,
    tle_feature_vector,
    trim_horizon_and_stride,
    wrap180,
    wrap360,
)


def require_tensorflow() -> None:
    if tf is None:
        raise RuntimeError(
            "TensorFlow is required. Run in docker image with TF installed, e.g. orbit-tf-pip:cuda128."
        )


def parse_float_list_csv(s: str) -> List[float]:
    out: List[float] = []
    for p in str(s).split(","):
        t = p.strip()
        if not t:
            continue
        out.append(float(t))
    return out


def parse_hidden_csv(s: str) -> List[int]:
    out = [int(x.strip()) for x in str(s).split(",") if x.strip()]
    if not out:
        out = [512, 512, 256, 128]
    return out


def parse_loss_weights(args: argparse.Namespace) -> np.ndarray:
    w_corr = np.array(
        [
            float(args.loss_weight_corr_lat),
            float(args.loss_weight_corr_lon),
            float(args.loss_weight_corr_alt),
            float(args.loss_weight_corr_az),
            float(args.loss_weight_corr_el),
        ],
        dtype=np.float64,
    )
    w_dir = np.array(
        [
            float(args.loss_weight_direct_lat),
            float(args.loss_weight_direct_lon),
            float(args.loss_weight_direct_alt),
            float(args.loss_weight_direct_az),
            float(args.loss_weight_direct_el),
        ],
        dtype=np.float64,
    )
    w = np.concatenate([w_corr, w_dir], axis=0)
    w = np.where(w > 0, w, 1.0)
    return w


def split_stems(
    all_stems: List[str],
    val_split: float,
    seed: int,
    split_mode: str,
) -> Tuple[List[str], List[str]]:
    mode = str(split_mode).strip().lower()
    if mode == "time":
        n_all = len(all_stems)
        n_val = int(round(float(val_split) * n_all))
        if n_val <= 0:
            n_val = 1
        if n_val >= n_all:
            n_val = max(1, n_all - 1)
        val_stems = all_stems[-n_val:]
        train_stems = all_stems[:-n_val]
    else:
        train_stems = [s for s in all_stems if deterministic_split(s, val_split, seed) == "train"]
        val_stems = [s for s in all_stems if deterministic_split(s, val_split, seed) == "val"]

    if not train_stems:
        train_stems = all_stems
    if not val_stems:
        n = max(1, int(0.1 * len(train_stems)))
        val_stems = train_stems[:n]
    return train_stems, val_stems


def load_truth_df(truth_csv: Path) -> pd.DataFrame:
    t = load_orbit_csv(truth_csv, require_targets=True)
    t = t[["UNIX"] + TARGET_COLS].copy()
    t = t.drop_duplicates("UNIX", keep="last").sort_values("UNIX").reset_index(drop=True)
    return t


def build_hybrid_design_matrix(
    no: np.ndarray,
    total_rows: int,
    tle_file: Path,
    baseline: np.ndarray,
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, List[str]]:
    x_no, no_names, aux = build_no_features(no=no, total_rows=total_rows, cfg=cfg)
    tle = parse_tle_file(tle_file)
    tle_vec, tle_names = tle_feature_vector(tle)
    n = len(no)
    x_tle = np.repeat(tle_vec.reshape(1, -1), n, axis=0)

    feats: List[np.ndarray] = [x_no, x_tle]
    names: List[str] = list(no_names) + list(tle_names)

    if cfg.include_baseline_feature:
        bfeat, bnames = build_baseline_features(baseline_at_no=baseline)
        feats.append(bfeat)
        names.extend(bnames)

    if cfg.include_interactions:
        basis = [
            ("no_norm", aux["no_norm"]),
            ("span_sin_1", aux["span_sin_1"]),
            ("span_cos_1", aux["span_cos_1"]),
        ]
        interact_keys = {
            "tle_inc_deg",
            "tle_raan_sin",
            "tle_raan_cos",
            "tle_ecc",
            "tle_argp_sin",
            "tle_argp_cos",
            "tle_mean_anom_sin",
            "tle_mean_anom_cos",
            "tle_mean_motion_rev_per_day",
            "tle_bstar",
            "tle_ndot",
            "tle_nddot",
        }
        idx = [i for i, name in enumerate(tle_names) if name in interact_keys]
        if idx:
            x_tle_sel = x_tle[:, idx]
            tle_sel_names = [tle_names[i] for i in idx]
            for b_name, b in basis:
                z = b.reshape(-1, 1) * x_tle_sel
                feats.append(z)
                names.extend([f"{b_name}*{tn}" for tn in tle_sel_names])

    x = np.concatenate(feats, axis=1).astype(np.float64)
    return x, names


def merge_baseline_truth(
    baseline_df: pd.DataFrame,
    truth_df: pd.DataFrame,
) -> pd.DataFrame:
    m = (
        baseline_df[["No", "date", "UNIX"] + TARGET_COLS]
        .merge(truth_df, on="UNIX", how="inner", suffixes=("_b", "_t"))
        .sort_values("No")
        .drop_duplicates("No", keep="last")
        .reset_index(drop=True)
    )
    return m


def build_targets(
    baseline: np.ndarray,
    truth: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    y_corr = np.zeros_like(truth, dtype=np.float64)
    y_direct = truth.astype(np.float64).copy()
    for i, col in enumerate(TARGET_COLS):
        if col in ANGLE_COLS:
            y_corr[:, i] = angle_diff_deg(truth[:, i], baseline[:, i])
        else:
            y_corr[:, i] = truth[:, i] - baseline[:, i]
    return y_corr, y_direct


def load_train_pair(
    stem: str,
    tle_dir: Path,
    baseline_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str], pd.DataFrame]:
    base = load_orbit_csv(baseline_dir / f"{stem}.csv", require_targets=True)
    base = trim_horizon_and_stride(
        base,
        days_horizon=days_horizon,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    merged = merge_baseline_truth(base, truth_df)
    if len(merged) == 0:
        return (
            np.zeros((0, 1), dtype=np.float64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0,), dtype=np.int64),
            ["dummy"],
            merged,
        )

    no = merged["No"].to_numpy(np.int64)
    total_rows = int(max(1, int(no.max())))
    baseline = merged[[f"{c}_b" for c in TARGET_COLS]].to_numpy(np.float64)
    truth = merged[[f"{c}_t" for c in TARGET_COLS]].to_numpy(np.float64)
    x, names = build_hybrid_design_matrix(
        no=no,
        total_rows=total_rows,
        tle_file=tle_dir / f"{stem}.txt",
        baseline=baseline,
        cfg=cfg,
    )
    y_corr, y_direct = build_targets(baseline=baseline, truth=truth)
    return x, y_corr, y_direct, baseline, truth, no, names, merged


def load_infer_pair(
    tle_file: Path,
    baseline_csv: Path,
    cfg: FeatureConfig,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray, np.ndarray, List[str]]:
    base = load_orbit_csv(baseline_csv, require_targets=True)
    base = trim_horizon_and_stride(
        base,
        days_horizon=days_horizon,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    if len(base) == 0:
        return base, np.zeros((0, 1), dtype=np.float64), np.zeros((0,), dtype=np.int64), np.zeros((0, len(TARGET_COLS)), dtype=np.float64), ["dummy"]

    no = base["No"].to_numpy(np.int64)
    total_rows = int(max(1, int(no.max())))
    baseline = base[TARGET_COLS].to_numpy(np.float64)
    x, names = build_hybrid_design_matrix(
        no=no,
        total_rows=total_rows,
        tle_file=tle_file,
        baseline=baseline,
        cfg=cfg,
    )
    return base, x, no, baseline, names


def compute_scalers(
    stems: List[str],
    tle_dir: Path,
    baseline_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str], int]:
    x_stat: Optional[OnlineMeanVar] = None
    yc_stat = OnlineMeanVar(dim=len(TARGET_COLS))
    yd_stat = OnlineMeanVar(dim=len(TARGET_COLS))
    names: Optional[List[str]] = None
    rows = 0

    for i, stem in enumerate(stems, start=1):
        try:
            x, y_corr, y_direct, _, _, _, fnames, _ = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                baseline_dir=baseline_dir,
                truth_df=truth_df,
                cfg=cfg,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] scaler skip {stem}: {e}")
            continue

        if len(x) == 0:
            continue

        if x_stat is None:
            x_stat = OnlineMeanVar(dim=x.shape[1])
            names = fnames
        elif x.shape[1] != x_stat.dim:
            raise ValueError(f"feature dim mismatch for {stem}: {x.shape[1]} vs {x_stat.dim}")

        x_stat.update(x)
        yc_stat.update(y_corr)
        yd_stat.update(y_direct)
        rows += len(x)

        if i % 25 == 0:
            log(f"[SCALER] {i}/{len(stems)} files rows={rows}")

    if x_stat is None or names is None or rows == 0:
        raise RuntimeError("no usable rows for scaler")

    x_mean, x_std = x_stat.finalize()
    yc_mean, yc_std = yc_stat.finalize()
    yd_mean, yd_std = yd_stat.finalize()
    x_std = np.where(x_std < 1e-9, 1.0, x_std)
    yc_std = np.where(yc_std < 1e-9, 1.0, yc_std)
    yd_std = np.where(yd_std < 1e-9, 1.0, yd_std)
    return x_mean, x_std, yc_mean, yc_std, yd_mean, yd_std, names, rows


def scale_arr(x: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    return ((x - mean.reshape(1, -1)) / std.reshape(1, -1)).astype(np.float32)


def unscale_arr(x_s: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    return (x_s * std.reshape(1, -1) + mean.reshape(1, -1)).astype(np.float64)


def build_model(input_dim: int, hidden: Sequence[int], dropout: float, l2: float) -> "tf.keras.Model":
    require_tensorflow()
    x_in = tf.keras.Input(shape=(input_dim,), name="x")
    h = x_in
    l2_reg = tf.keras.regularizers.l2(l2) if l2 > 0 else None
    for i, units in enumerate(hidden):
        h = tf.keras.layers.Dense(units, activation=None, kernel_regularizer=l2_reg, name=f"dense_{i}")(h)
        h = tf.keras.layers.LayerNormalization(name=f"ln_{i}")(h)
        h = tf.keras.layers.Activation("swish", name=f"act_{i}")(h)
        if dropout > 0:
            h = tf.keras.layers.Dropout(dropout, name=f"drop_{i}")(h)
    y = tf.keras.layers.Dense(2 * len(TARGET_COLS), activation=None, name="dual_out")(h)
    return tf.keras.Model(inputs=x_in, outputs=y, name="hybrid_direct_residual_mlp")


def build_weighted_huber_loss(delta: float, weights: np.ndarray):
    require_tensorflow()
    d = tf.constant(float(delta), dtype=tf.float32)
    w = tf.constant(np.asarray(weights, dtype=np.float32).reshape(1, -1), dtype=tf.float32)
    # Output order: corr(Lat,Lon,Alt,AZ,EL), direct(Lat,Lon,Alt,AZ,EL)
    angle_idx = {1, 3, 6, 8}

    def _loss(y_true, y_pred):
        e = y_pred - y_true
        cols = []
        for i in range(2 * len(TARGET_COLS)):
            c = e[:, i]
            if i in angle_idx:
                c = tf.math.floormod(c + 180.0, 360.0) - 180.0
            cols.append(c)
        e2 = tf.stack(cols, axis=1)
        ae = tf.abs(e2)
        q = tf.minimum(ae, d)
        lin = ae - q
        huber = 0.5 * tf.square(q) + d * lin
        weighted = huber * w
        return tf.reduce_mean(tf.reduce_sum(weighted, axis=-1))

    return _loss


def predict_dual(
    model: "tf.keras.Model",
    x: np.ndarray,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    yc_mean: np.ndarray,
    yc_std: np.ndarray,
    yd_mean: np.ndarray,
    yd_std: np.ndarray,
    batch_size: int,
) -> Tuple[np.ndarray, np.ndarray]:
    x_s = scale_arr(x, x_mean, x_std)
    y_s = model.predict(x_s, batch_size=int(batch_size), verbose=0)
    yc_s = y_s[:, : len(TARGET_COLS)]
    yd_s = y_s[:, len(TARGET_COLS) :]
    yc = unscale_arr(yc_s, yc_mean, yc_std)
    yd = unscale_arr(yd_s, yd_mean, yd_std)
    return yc, yd


def day_bin_index(no: np.ndarray, edges: np.ndarray) -> np.ndarray:
    day = (np.asarray(no, dtype=np.float64).reshape(-1) - 1.0) / MINUTES_PER_DAY
    idx = np.searchsorted(edges, day, side="right") - 1
    idx = np.clip(idx, 0, len(edges) - 2)
    return idx.astype(np.int64)


def direct_delta_from_pred(direct_pred: np.ndarray, baseline: np.ndarray) -> np.ndarray:
    d = np.zeros_like(direct_pred, dtype=np.float64)
    for i, col in enumerate(TARGET_COLS):
        if col in ANGLE_COLS:
            d[:, i] = angle_diff_deg(direct_pred[:, i], baseline[:, i])
        else:
            d[:, i] = direct_pred[:, i] - baseline[:, i]
    return d


def correction_to_corrected(
    baseline: np.ndarray,
    delta: np.ndarray,
) -> np.ndarray:
    out = np.zeros_like(baseline, dtype=np.float64)
    for i, col in enumerate(TARGET_COLS):
        if col in ANGLE_COLS:
            out[:, i] = wrap360(baseline[:, i] + delta[:, i])
        elif col == "EL":
            out[:, i] = np.clip(baseline[:, i] + delta[:, i], -90.0, 90.0)
        else:
            out[:, i] = baseline[:, i] + delta[:, i]
    return out


def geodetic_to_ecef_km(
    lat_deg: np.ndarray,
    lon_deg: np.ndarray,
    alt_km: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    # WGS84
    a = 6378.137
    f = 1.0 / 298.257223563
    e2 = f * (2.0 - f)

    lat = np.deg2rad(np.asarray(lat_deg, dtype=np.float64))
    lon = np.deg2rad(np.asarray(lon_deg, dtype=np.float64))
    alt = np.asarray(alt_km, dtype=np.float64)

    sl = np.sin(lat)
    cl = np.cos(lat)
    so = np.sin(lon)
    co = np.cos(lon)

    n = a / np.sqrt(1.0 - e2 * sl * sl)
    x = (n + alt) * cl * co
    y = (n + alt) * cl * so
    z = (n * (1.0 - e2) + alt) * sl
    return x, y, z


def recompute_azel_from_lla(
    sat_lat_deg: np.ndarray,
    sat_lon_deg: np.ndarray,
    sat_alt_km: np.ndarray,
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
) -> Tuple[np.ndarray, np.ndarray]:
    sx, sy, sz = geodetic_to_ecef_km(
        lat_deg=sat_lat_deg,
        lon_deg=sat_lon_deg,
        alt_km=sat_alt_km,
    )
    ox, oy, oz = geodetic_to_ecef_km(
        lat_deg=np.asarray([observer_lat_deg], dtype=np.float64),
        lon_deg=np.asarray([observer_lon_deg], dtype=np.float64),
        alt_km=np.asarray([float(observer_alt_m) / 1000.0], dtype=np.float64),
    )

    dx = sx - float(ox[0])
    dy = sy - float(oy[0])
    dz = sz - float(oz[0])

    lat0 = math.radians(float(observer_lat_deg))
    lon0 = math.radians(float(observer_lon_deg))
    sl = math.sin(lat0)
    cl = math.cos(lat0)
    so = math.sin(lon0)
    co = math.cos(lon0)

    e = -so * dx + co * dy
    n = -sl * co * dx - sl * so * dy + cl * dz
    u = cl * co * dx + cl * so * dy + sl * dz

    az = np.rad2deg(np.arctan2(e, n))
    az = np.mod(az + 360.0, 360.0)
    el = np.rad2deg(np.arctan2(u, np.sqrt(e * e + n * n)))
    el = np.clip(el, -90.0, 90.0)
    return az, el


def circular_mix_deg(a_deg: np.ndarray, b_deg: np.ndarray, w_a: float) -> np.ndarray:
    wa = float(w_a)
    wb = 1.0 - wa
    ar = np.deg2rad(np.asarray(a_deg, dtype=np.float64))
    br = np.deg2rad(np.asarray(b_deg, dtype=np.float64))
    s = wa * np.sin(ar) + wb * np.sin(br)
    c = wa * np.cos(ar) + wb * np.cos(br)
    out = np.rad2deg(np.arctan2(s, c))
    return np.mod(out + 360.0, 360.0)


def apply_azel_strategy_to_corrected(
    corrected_raw: np.ndarray,
    baseline: np.ndarray,
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
    strategy_mode: str,
    mix_weight: float,
) -> np.ndarray:
    out = np.asarray(corrected_raw, dtype=np.float64).copy()
    mode = str(strategy_mode).strip().lower()
    az_i = TARGET_COLS.index("AZ")
    el_i = TARGET_COLS.index("EL")
    lat_i = TARGET_COLS.index("Lat")
    lon_i = TARGET_COLS.index("Lon")
    alt_i = TARGET_COLS.index("Alt")

    az_pred = out[:, az_i].astype(np.float64)
    el_pred = out[:, el_i].astype(np.float64)
    az_rec, el_rec = recompute_azel_from_lla(
        sat_lat_deg=out[:, lat_i],
        sat_lon_deg=out[:, lon_i],
        sat_alt_km=out[:, alt_i],
        observer_lat_deg=observer_lat_deg,
        observer_lon_deg=observer_lon_deg,
        observer_alt_m=observer_alt_m,
    )

    if mode == "baseline":
        az_use = np.asarray(baseline[:, az_i], dtype=np.float64)
        el_use = np.asarray(baseline[:, el_i], dtype=np.float64)
    elif mode == "recompute":
        az_use = az_rec
        el_use = el_rec
    elif mode == "mix":
        w = float(np.clip(mix_weight, 0.0, 1.0))
        az_use = circular_mix_deg(az_pred, az_rec, w_a=w)
        el_use = w * el_pred + (1.0 - w) * el_rec
    else:
        az_use = az_pred
        el_use = el_pred

    out[:, az_i] = wrap360(az_use)
    out[:, el_i] = np.clip(el_use, -90.0, 90.0)
    return out


def _azel_pair_rmse(
    truth_az: np.ndarray,
    truth_el: np.ndarray,
    pred_az: np.ndarray,
    pred_el: np.ndarray,
) -> float:
    e_az = angle_diff_deg(np.asarray(pred_az, dtype=np.float64), np.asarray(truth_az, dtype=np.float64))
    e_el = np.asarray(pred_el, dtype=np.float64) - np.asarray(truth_el, dtype=np.float64)
    return float(0.5 * (np.sqrt(np.mean(e_az * e_az)) + np.sqrt(np.mean(e_el * e_el))))


def calibrate_azel_strategy(
    stems: List[str],
    tle_dir: Path,
    baseline_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
    model: "tf.keras.Model",
    x_mean: np.ndarray,
    x_std: np.ndarray,
    yc_mean: np.ndarray,
    yc_std: np.ndarray,
    yd_mean: np.ndarray,
    yd_std: np.ndarray,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    blend_edges_days: np.ndarray,
    alpha_matrix: np.ndarray,
    beta_matrix: np.ndarray,
    azel_cap_deg: Optional[float],
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
    mix_grid: List[float],
    min_improve_pct: float,
) -> Tuple[str, float, Dict[str, float]]:
    truth_az_list: List[np.ndarray] = []
    truth_el_list: List[np.ndarray] = []
    base_az_list: List[np.ndarray] = []
    base_el_list: List[np.ndarray] = []
    pred_az_list: List[np.ndarray] = []
    pred_el_list: List[np.ndarray] = []
    rec_az_list: List[np.ndarray] = []
    rec_el_list: List[np.ndarray] = []

    for stem in stems:
        try:
            x, _, _, baseline, truth, no, _, _ = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                baseline_dir=baseline_dir,
                truth_df=truth_df,
                cfg=cfg,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] azel strategy skip {stem}: {e}")
            continue
        if len(x) == 0:
            continue

        corr_pred, direct_pred = predict_dual(
            model=model,
            x=x,
            x_mean=x_mean,
            x_std=x_std,
            yc_mean=yc_mean,
            yc_std=yc_std,
            yd_mean=yd_mean,
            yd_std=yd_std,
            batch_size=batch_size,
        )
        corrected_raw, _, _, _ = apply_hybrid_blend(
            baseline=baseline,
            corr_pred=corr_pred,
            direct_pred=direct_pred,
            no=no,
            blend_edges_days=blend_edges_days,
            alpha_matrix=alpha_matrix,
            beta_matrix=beta_matrix,
            azel_cap_deg=azel_cap_deg,
        )
        az_i = TARGET_COLS.index("AZ")
        el_i = TARGET_COLS.index("EL")
        lat_i = TARGET_COLS.index("Lat")
        lon_i = TARGET_COLS.index("Lon")
        alt_i = TARGET_COLS.index("Alt")
        az_rec, el_rec = recompute_azel_from_lla(
            sat_lat_deg=corrected_raw[:, lat_i],
            sat_lon_deg=corrected_raw[:, lon_i],
            sat_alt_km=corrected_raw[:, alt_i],
            observer_lat_deg=observer_lat_deg,
            observer_lon_deg=observer_lon_deg,
            observer_alt_m=observer_alt_m,
        )

        truth_az_list.append(truth[:, az_i].astype(np.float64))
        truth_el_list.append(truth[:, el_i].astype(np.float64))
        base_az_list.append(baseline[:, az_i].astype(np.float64))
        base_el_list.append(baseline[:, el_i].astype(np.float64))
        pred_az_list.append(corrected_raw[:, az_i].astype(np.float64))
        pred_el_list.append(corrected_raw[:, el_i].astype(np.float64))
        rec_az_list.append(az_rec.astype(np.float64))
        rec_el_list.append(el_rec.astype(np.float64))

    if not truth_az_list:
        return "baseline", 0.0, {"rmse_baseline": float("nan"), "rmse_best": float("nan")}

    truth_az = np.concatenate(truth_az_list)
    truth_el = np.concatenate(truth_el_list)
    base_az = np.concatenate(base_az_list)
    base_el = np.concatenate(base_el_list)
    pred_az = np.concatenate(pred_az_list)
    pred_el = np.concatenate(pred_el_list)
    rec_az = np.concatenate(rec_az_list)
    rec_el = np.concatenate(rec_el_list)

    score_baseline = _azel_pair_rmse(truth_az, truth_el, base_az, base_el)
    score_predicted = _azel_pair_rmse(truth_az, truth_el, pred_az, pred_el)
    score_recompute = _azel_pair_rmse(truth_az, truth_el, rec_az, rec_el)

    best_mode = "predicted"
    best_w = 1.0
    best_score = score_predicted

    if score_recompute < best_score:
        best_mode = "recompute"
        best_w = 0.0
        best_score = score_recompute

    mix_vals = sorted(set(float(np.clip(v, 0.0, 1.0)) for v in mix_grid))
    for w in mix_vals:
        if w <= 0.0 or w >= 1.0:
            continue
        az_m = circular_mix_deg(pred_az, rec_az, w_a=w)
        el_m = w * pred_el + (1.0 - w) * rec_el
        s = _azel_pair_rmse(truth_az, truth_el, az_m, el_m)
        if s < best_score:
            best_mode = "mix"
            best_w = float(w)
            best_score = float(s)

    improve_pct = 0.0 if score_baseline <= 0 else 100.0 * (score_baseline - best_score) / score_baseline
    if improve_pct < float(min_improve_pct):
        best_mode = "baseline"
        best_w = 0.0
        best_score = score_baseline

    details = {
        "rmse_baseline": float(score_baseline),
        "rmse_predicted": float(score_predicted),
        "rmse_recompute": float(score_recompute),
        "rmse_best": float(best_score),
        "best_mix_weight": float(best_w),
        "improve_pct_vs_baseline": float(improve_pct),
        "min_improve_pct": float(min_improve_pct),
    }
    return best_mode, best_w, details


def apply_hybrid_blend(
    baseline: np.ndarray,
    corr_pred: np.ndarray,
    direct_pred: np.ndarray,
    no: np.ndarray,
    blend_edges_days: np.ndarray,
    alpha_matrix: np.ndarray,
    beta_matrix: np.ndarray,
    azel_cap_deg: Optional[float],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    bidx = day_bin_index(no=no, edges=blend_edges_days)
    arow = alpha_matrix[bidx, :]
    brow = beta_matrix[bidx, :]

    direct_delta = direct_delta_from_pred(direct_pred=direct_pred, baseline=baseline)
    delta = arow * corr_pred + brow * direct_delta

    if azel_cap_deg is not None and azel_cap_deg > 0:
        cap = float(azel_cap_deg)
        for c in ("AZ", "EL"):
            i = TARGET_COLS.index(c)
            delta[:, i] = np.clip(delta[:, i], -cap, cap)

    corrected = correction_to_corrected(baseline=baseline, delta=delta)
    return corrected, delta, arow, brow


def _update_regression_stats_col(
    scc: np.ndarray,
    sdd: np.ndarray,
    scd: np.ndarray,
    sct: np.ndarray,
    sdt: np.ndarray,
    cnt: np.ndarray,
    bidx: np.ndarray,
    c: np.ndarray,
    d: np.ndarray,
    t: np.ndarray,
) -> None:
    nb = len(cnt)
    w = np.bincount(bidx, minlength=nb).astype(np.float64)
    cc = np.bincount(bidx, weights=c * c, minlength=nb).astype(np.float64)
    dd = np.bincount(bidx, weights=d * d, minlength=nb).astype(np.float64)
    cd = np.bincount(bidx, weights=c * d, minlength=nb).astype(np.float64)
    ct = np.bincount(bidx, weights=c * t, minlength=nb).astype(np.float64)
    dt = np.bincount(bidx, weights=d * t, minlength=nb).astype(np.float64)
    cnt[:] += w
    scc[:] += cc
    sdd[:] += dd
    scd[:] += cd
    sct[:] += ct
    sdt[:] += dt


def fit_blend_coefficients(
    stems: List[str],
    tle_dir: Path,
    baseline_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
    model: "tf.keras.Model",
    x_mean: np.ndarray,
    x_std: np.ndarray,
    yc_mean: np.ndarray,
    yc_std: np.ndarray,
    yd_mean: np.ndarray,
    yd_std: np.ndarray,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    blend_edges_days: np.ndarray,
    max_alpha: float,
    max_beta: float,
    max_alpha_azel: float,
    max_beta_azel: float,
    l2_reg: float,
) -> Tuple[np.ndarray, np.ndarray]:
    nb = len(blend_edges_days) - 1
    nt = len(TARGET_COLS)
    scc = np.zeros((nb, nt), dtype=np.float64)
    sdd = np.zeros((nb, nt), dtype=np.float64)
    scd = np.zeros((nb, nt), dtype=np.float64)
    sct = np.zeros((nb, nt), dtype=np.float64)
    sdt = np.zeros((nb, nt), dtype=np.float64)
    cnt = np.zeros((nb, nt), dtype=np.float64)

    for stem in stems:
        try:
            x, _, _, baseline, truth, no, _, _ = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                baseline_dir=baseline_dir,
                truth_df=truth_df,
                cfg=cfg,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] blend-fit skip {stem}: {e}")
            continue
        if len(x) == 0:
            continue

        corr_pred, direct_pred = predict_dual(
            model=model,
            x=x,
            x_mean=x_mean,
            x_std=x_std,
            yc_mean=yc_mean,
            yc_std=yc_std,
            yd_mean=yd_mean,
            yd_std=yd_std,
            batch_size=batch_size,
        )
        ddelta = direct_delta_from_pred(direct_pred=direct_pred, baseline=baseline)
        bidx = day_bin_index(no=no, edges=blend_edges_days)

        for i, col in enumerate(TARGET_COLS):
            if col in ANGLE_COLS:
                t = angle_diff_deg(truth[:, i], baseline[:, i])
            else:
                t = truth[:, i] - baseline[:, i]
            c = corr_pred[:, i]
            d = ddelta[:, i]
            _update_regression_stats_col(
                scc=scc[:, i],
                sdd=sdd[:, i],
                scd=scd[:, i],
                sct=sct[:, i],
                sdt=sdt[:, i],
                cnt=cnt[:, i],
                bidx=bidx,
                c=c,
                d=d,
                t=t,
            )

    alpha = np.zeros((nb, nt), dtype=np.float64)
    beta = np.zeros((nb, nt), dtype=np.float64)
    reg = float(max(1e-12, l2_reg))

    for b in range(nb):
        for i, col in enumerate(TARGET_COLS):
            if cnt[b, i] < 10:
                continue
            a11 = scc[b, i] + reg
            a22 = sdd[b, i] + reg
            a12 = scd[b, i]
            det = a11 * a22 - a12 * a12
            if not np.isfinite(det) or abs(det) < 1e-12:
                continue
            rhs1 = sct[b, i]
            rhs2 = sdt[b, i]
            av = (rhs1 * a22 - rhs2 * a12) / det
            bv = (rhs2 * a11 - rhs1 * a12) / det

            amax = float(max_alpha_azel if col in ANTENNA_COLS else max_alpha)
            bmax = float(max_beta_azel if col in ANTENNA_COLS else max_beta)
            av = float(np.clip(av, 0.0, max(0.0, amax)))
            bv = float(np.clip(bv, 0.0, max(0.0, bmax)))
            alpha[b, i] = av
            beta[b, i] = bv

    return alpha, beta


def apply_min_improve_guard(
    stems: List[str],
    tle_dir: Path,
    baseline_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
    model: "tf.keras.Model",
    x_mean: np.ndarray,
    x_std: np.ndarray,
    yc_mean: np.ndarray,
    yc_std: np.ndarray,
    yd_mean: np.ndarray,
    yd_std: np.ndarray,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    blend_edges_days: np.ndarray,
    alpha_matrix: np.ndarray,
    beta_matrix: np.ndarray,
    min_improve_pct: float,
    azel_cap_deg: Optional[float],
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Dict[str, float]]]:
    nb = len(blend_edges_days) - 1
    nt = len(TARGET_COLS)
    sse_base = np.zeros((nb, nt), dtype=np.float64)
    sse_blend = np.zeros((nb, nt), dtype=np.float64)
    cnt = np.zeros((nb, nt), dtype=np.float64)

    for stem in stems:
        try:
            x, _, _, baseline, truth, no, _, _ = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                baseline_dir=baseline_dir,
                truth_df=truth_df,
                cfg=cfg,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] blend-guard skip {stem}: {e}")
            continue
        if len(x) == 0:
            continue

        corr_pred, direct_pred = predict_dual(
            model=model,
            x=x,
            x_mean=x_mean,
            x_std=x_std,
            yc_mean=yc_mean,
            yc_std=yc_std,
            yd_mean=yd_mean,
            yd_std=yd_std,
            batch_size=batch_size,
        )
        corrected, _, _, _ = apply_hybrid_blend(
            baseline=baseline,
            corr_pred=corr_pred,
            direct_pred=direct_pred,
            no=no,
            blend_edges_days=blend_edges_days,
            alpha_matrix=alpha_matrix,
            beta_matrix=beta_matrix,
            azel_cap_deg=azel_cap_deg,
        )
        bidx = day_bin_index(no=no, edges=blend_edges_days)

        for i, col in enumerate(TARGET_COLS):
            if col in ANGLE_COLS:
                eb = angle_diff_deg(baseline[:, i], truth[:, i])
                ec = angle_diff_deg(corrected[:, i], truth[:, i])
            else:
                eb = baseline[:, i] - truth[:, i]
                ec = corrected[:, i] - truth[:, i]
            for b in range(nb):
                m = bidx == b
                if not np.any(m):
                    continue
                sse_base[b, i] += float(np.sum(eb[m] * eb[m]))
                sse_blend[b, i] += float(np.sum(ec[m] * ec[m]))
                cnt[b, i] += float(np.sum(m))

    details: Dict[str, Dict[str, float]] = {}
    for i, col in enumerate(TARGET_COLS):
        cdet: Dict[str, float] = {}
        for b in range(nb):
            lo = float(blend_edges_days[b])
            hi = float(blend_edges_days[b + 1])
            key = f"{lo:g}-{hi:g}"
            if cnt[b, i] <= 0:
                cdet[key] = float("nan")
                alpha_matrix[b, i] = 0.0
                beta_matrix[b, i] = 0.0
                continue
            rb = float(np.sqrt(sse_base[b, i] / cnt[b, i]))
            rc = float(np.sqrt(sse_blend[b, i] / cnt[b, i]))
            imp = 0.0 if rb <= 0 else 100.0 * (rb - rc) / rb
            if imp < float(min_improve_pct):
                alpha_matrix[b, i] = 0.0
                beta_matrix[b, i] = 0.0
            cdet[key] = float(imp)
        details[col] = cdet
    return alpha_matrix, beta_matrix, details


def evaluate_dataset(
    stems: List[str],
    tle_dir: Path,
    baseline_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
    model: "tf.keras.Model",
    x_mean: np.ndarray,
    x_std: np.ndarray,
    yc_mean: np.ndarray,
    yc_std: np.ndarray,
    yd_mean: np.ndarray,
    yd_std: np.ndarray,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    blend_edges_days: np.ndarray,
    alpha_matrix: np.ndarray,
    beta_matrix: np.ndarray,
    azel_cap_deg: Optional[float],
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
    azel_strategy_mode: str,
    azel_mix_weight: float,
) -> Dict[str, float]:
    if not stems:
        return {}
    sum_base = np.zeros((len(TARGET_COLS),), dtype=np.float64)
    sum_corr = np.zeros((len(TARGET_COLS),), dtype=np.float64)
    rows = 0

    for stem in stems:
        try:
            x, _, _, baseline, truth, no, _, _ = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                baseline_dir=baseline_dir,
                truth_df=truth_df,
                cfg=cfg,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] eval skip {stem}: {e}")
            continue
        if len(x) == 0:
            continue

        corr_pred, direct_pred = predict_dual(
            model=model,
            x=x,
            x_mean=x_mean,
            x_std=x_std,
            yc_mean=yc_mean,
            yc_std=yc_std,
            yd_mean=yd_mean,
            yd_std=yd_std,
            batch_size=batch_size,
        )
        corrected, _, _, _ = apply_hybrid_blend(
            baseline=baseline,
            corr_pred=corr_pred,
            direct_pred=direct_pred,
            no=no,
            blend_edges_days=blend_edges_days,
            alpha_matrix=alpha_matrix,
            beta_matrix=beta_matrix,
            azel_cap_deg=azel_cap_deg,
        )
        corrected = apply_azel_strategy_to_corrected(
            corrected_raw=corrected,
            baseline=baseline,
            observer_lat_deg=observer_lat_deg,
            observer_lon_deg=observer_lon_deg,
            observer_alt_m=observer_alt_m,
            strategy_mode=azel_strategy_mode,
            mix_weight=azel_mix_weight,
        )

        for i, col in enumerate(TARGET_COLS):
            if col in ANGLE_COLS:
                eb = angle_diff_deg(baseline[:, i], truth[:, i])
                ec = angle_diff_deg(corrected[:, i], truth[:, i])
            else:
                eb = baseline[:, i] - truth[:, i]
                ec = corrected[:, i] - truth[:, i]
            sum_base[i] += float(np.sum(eb * eb))
            sum_corr[i] += float(np.sum(ec * ec))
        rows += len(x)

    if rows == 0:
        return {}

    mse_b = sum_base / rows
    mse_c = sum_corr / rows
    rmse_b = np.sqrt(mse_b)
    rmse_c = np.sqrt(mse_c)

    out: Dict[str, float] = {"rows": float(rows)}
    for i, col in enumerate(TARGET_COLS):
        out[f"{col}_MSE_base"] = float(mse_b[i])
        out[f"{col}_MSE_corr"] = float(mse_c[i])
        out[f"{col}_RMSE_base"] = float(rmse_b[i])
        out[f"{col}_RMSE_corr"] = float(rmse_c[i])
    out["global_MSE_base"] = float(np.mean(mse_b))
    out["global_MSE_corr"] = float(np.mean(mse_c))
    out["global_RMSE_base"] = float(np.sqrt(out["global_MSE_base"]))
    out["global_RMSE_corr"] = float(np.sqrt(out["global_MSE_corr"]))
    out["global_RMSE_improve_pct"] = float(
        0.0
        if out["global_RMSE_base"] <= 0
        else 100.0 * (out["global_RMSE_base"] - out["global_RMSE_corr"]) / out["global_RMSE_base"]
    )
    return out


@dataclasses.dataclass
class ModelBundle:
    feature_cfg: FeatureConfig
    feature_names: List[str]
    x_mean: np.ndarray
    x_std: np.ndarray
    yc_mean: np.ndarray
    yc_std: np.ndarray
    yd_mean: np.ndarray
    yd_std: np.ndarray
    blend_edges_days: np.ndarray
    alpha_matrix: np.ndarray
    beta_matrix: np.ndarray
    azel_cap_deg: Optional[float]
    observer_lat_deg: float
    observer_lon_deg: float
    observer_alt_m: float
    azel_strategy_mode: str
    azel_mix_weight: float
    train_rows: int
    train_files: int
    val_files: int


def is_model_file(path: Path) -> bool:
    return path.suffix.lower() in (".keras", ".h5")


def resolve_model_and_meta(model_arg: Path) -> Tuple[Path, Path]:
    if model_arg.is_dir():
        return model_arg / "model.keras", model_arg / "meta.json"
    return model_arg, model_arg.parent / "meta.json"


def save_model_and_meta(
    model: "tf.keras.Model",
    bundle: ModelBundle,
    out_model: Path,
    overwrite: bool,
    extra: Optional[Dict] = None,
) -> Tuple[Path, Path]:
    require_tensorflow()
    if is_model_file(out_model):
        model_path = out_model
        meta_path = out_model.parent / "meta.json"
        ensure_dir(out_model.parent)
    else:
        ensure_dir(out_model)
        model_path = out_model / "model.keras"
        meta_path = out_model / "meta.json"
    if (model_path.exists() or meta_path.exists()) and not overwrite:
        raise FileExistsError(f"exists: {out_model} (use --overwrite)")

    model.save(str(model_path))
    payload = {
        "created_at_jst": now_jst_str(),
        "model_type": "hybrid_direct_residual",
        "feature_cfg": dataclasses.asdict(bundle.feature_cfg),
        "feature_names": bundle.feature_names,
        "target_cols": list(TARGET_COLS),
        "x_mean": bundle.x_mean.tolist(),
        "x_std": bundle.x_std.tolist(),
        "yc_mean": bundle.yc_mean.tolist(),
        "yc_std": bundle.yc_std.tolist(),
        "yd_mean": bundle.yd_mean.tolist(),
        "yd_std": bundle.yd_std.tolist(),
        "blend_edges_days": bundle.blend_edges_days.tolist(),
        "alpha_matrix": bundle.alpha_matrix.tolist(),
        "beta_matrix": bundle.beta_matrix.tolist(),
        "azel_cap_deg": None if bundle.azel_cap_deg is None else float(bundle.azel_cap_deg),
        "observer_lat_deg": float(bundle.observer_lat_deg),
        "observer_lon_deg": float(bundle.observer_lon_deg),
        "observer_alt_m": float(bundle.observer_alt_m),
        "azel_strategy_mode": str(bundle.azel_strategy_mode),
        "azel_mix_weight": float(bundle.azel_mix_weight),
        "train_rows": int(bundle.train_rows),
        "train_files": int(bundle.train_files),
        "val_files": int(bundle.val_files),
    }
    if extra is not None:
        payload["extra"] = extra
    meta_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return model_path, meta_path


def load_model_and_meta(model_arg: Path) -> Tuple["tf.keras.Model", ModelBundle, Dict]:
    require_tensorflow()
    model_path, meta_path = resolve_model_and_meta(model_arg)
    if not model_path.exists():
        raise FileNotFoundError(f"model not found: {model_path}")
    if not meta_path.exists():
        raise FileNotFoundError(f"meta not found: {meta_path}")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    feature_cfg = FeatureConfig(**meta["feature_cfg"])
    alpha = np.asarray(meta["alpha_matrix"], dtype=np.float64)
    beta = np.asarray(meta["beta_matrix"], dtype=np.float64)
    edges = np.asarray(meta["blend_edges_days"], dtype=np.float64).reshape(-1)
    if alpha.ndim != 2 or beta.ndim != 2 or alpha.shape != beta.shape:
        raise ValueError("invalid alpha/beta matrix shape in meta")
    if alpha.shape[1] != len(TARGET_COLS):
        raise ValueError("alpha/beta matrix target dim mismatch")
    if len(edges) != alpha.shape[0] + 1:
        raise ValueError("blend edges size mismatch")

    bundle = ModelBundle(
        feature_cfg=feature_cfg,
        feature_names=list(meta["feature_names"]),
        x_mean=np.asarray(meta["x_mean"], dtype=np.float64),
        x_std=np.asarray(meta["x_std"], dtype=np.float64),
        yc_mean=np.asarray(meta["yc_mean"], dtype=np.float64),
        yc_std=np.asarray(meta["yc_std"], dtype=np.float64),
        yd_mean=np.asarray(meta["yd_mean"], dtype=np.float64),
        yd_std=np.asarray(meta["yd_std"], dtype=np.float64),
        blend_edges_days=edges,
        alpha_matrix=alpha,
        beta_matrix=beta,
        azel_cap_deg=(None if meta.get("azel_cap_deg") is None else float(meta["azel_cap_deg"])),
        observer_lat_deg=float(meta.get("observer_lat_deg", 36.3022)),
        observer_lon_deg=float(meta.get("observer_lon_deg", 137.9031)),
        observer_alt_m=float(meta.get("observer_alt_m", 0.0)),
        azel_strategy_mode=str(meta.get("azel_strategy_mode", "predicted")),
        azel_mix_weight=float(meta.get("azel_mix_weight", 1.0)),
        train_rows=int(meta.get("train_rows", 0)),
        train_files=int(meta.get("train_files", 0)),
        val_files=int(meta.get("val_files", 0)),
    )
    model = tf.keras.models.load_model(str(model_path), compile=False)
    return model, bundle, meta


def format_corrected_df(base_df: pd.DataFrame, corrected: np.ndarray) -> pd.DataFrame:
    out = base_df[["No", "date", "UNIX"]].copy()
    for i, c in enumerate(TARGET_COLS):
        out[c] = corrected[:, i]
    return out


def format_pred_df(
    base_df: pd.DataFrame,
    corr_pred: np.ndarray,
    direct_pred: np.ndarray,
    delta: np.ndarray,
    arow: np.ndarray,
    brow: np.ndarray,
) -> pd.DataFrame:
    out = base_df[["No", "date", "UNIX"]].copy()
    for i, c in enumerate(TARGET_COLS):
        out[f"pred_corr_{c}"] = corr_pred[:, i]
        out[f"pred_direct_{c}"] = direct_pred[:, i]
        out[f"pred_delta_{c}"] = delta[:, i]
        out[f"alpha_{c}"] = arow[:, i]
        out[f"beta_{c}"] = brow[:, i]
    return out


def run_predict_one(
    model: "tf.keras.Model",
    bundle: ModelBundle,
    tle_file: Path,
    baseline_csv: Path,
    out_corrected_csv: Path,
    out_pred_csv: Path,
    truth_df: Optional[pd.DataFrame],
    out_metrics_csv: Optional[Path],
    plot_dir: Optional[Path],
    days: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    plot_sample_every: int,
    mode: str,
    observer_lat_deg: Optional[float],
    observer_lon_deg: Optional[float],
    observer_alt_m: Optional[float],
    azel_strategy_override: Optional[str],
    azel_mix_weight_override: Optional[float],
    overwrite: bool,
    no_plot: bool,
) -> Dict[str, object]:
    base_df, x, no, baseline, names = load_infer_pair(
        tle_file=tle_file,
        baseline_csv=baseline_csv,
        cfg=bundle.feature_cfg,
        days_horizon=days,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    if len(base_df) == 0:
        raise RuntimeError(f"no rows after trim: {baseline_csv}")
    if names != bundle.feature_names:
        raise ValueError("feature names mismatch between model and inference")

    corr_pred, direct_pred = predict_dual(
        model=model,
        x=x,
        x_mean=bundle.x_mean,
        x_std=bundle.x_std,
        yc_mean=bundle.yc_mean,
        yc_std=bundle.yc_std,
        yd_mean=bundle.yd_mean,
        yd_std=bundle.yd_std,
        batch_size=batch_size,
    )

    mode_l = str(mode).strip().lower()
    if mode_l == "corr_only":
        alpha = np.ones_like(bundle.alpha_matrix)
        beta = np.zeros_like(bundle.beta_matrix)
    elif mode_l == "direct_only":
        alpha = np.zeros_like(bundle.alpha_matrix)
        beta = np.ones_like(bundle.beta_matrix)
    else:
        alpha = bundle.alpha_matrix
        beta = bundle.beta_matrix

    corrected, delta, arow, brow = apply_hybrid_blend(
        baseline=baseline,
        corr_pred=corr_pred,
        direct_pred=direct_pred,
        no=no,
        blend_edges_days=bundle.blend_edges_days,
        alpha_matrix=alpha,
        beta_matrix=beta,
        azel_cap_deg=bundle.azel_cap_deg,
    )
    obs_lat = float(bundle.observer_lat_deg if observer_lat_deg is None else observer_lat_deg)
    obs_lon = float(bundle.observer_lon_deg if observer_lon_deg is None else observer_lon_deg)
    obs_alt_m = float(bundle.observer_alt_m if observer_alt_m is None else observer_alt_m)
    azel_mode = str(bundle.azel_strategy_mode).strip().lower()
    if azel_strategy_override is not None:
        azel_mode = str(azel_strategy_override).strip().lower()
    azel_mix_w = float(bundle.azel_mix_weight)
    if azel_mix_weight_override is not None:
        azel_mix_w = float(np.clip(float(azel_mix_weight_override), 0.0, 1.0))
    corrected = apply_azel_strategy_to_corrected(
        corrected_raw=corrected,
        baseline=baseline,
        observer_lat_deg=obs_lat,
        observer_lon_deg=obs_lon,
        observer_alt_m=obs_alt_m,
        strategy_mode=azel_mode,
        mix_weight=azel_mix_w,
    )
    log(f"[INFO] AZEL postprocess: mode={azel_mode}, mix_weight={azel_mix_w:.4g}, observer=({obs_lat:.6f},{obs_lon:.6f},{obs_alt_m:.3f}m)")

    if out_corrected_csv.exists() and not overwrite:
        raise FileExistsError(f"exists: {out_corrected_csv} (use --overwrite)")
    if out_pred_csv.exists() and not overwrite:
        raise FileExistsError(f"exists: {out_pred_csv} (use --overwrite)")

    ensure_dir(out_corrected_csv.parent)
    ensure_dir(out_pred_csv.parent)
    corrected_df = format_corrected_df(base_df=base_df, corrected=corrected)
    pred_df = format_pred_df(
        base_df=base_df,
        corr_pred=corr_pred,
        direct_pred=direct_pred,
        delta=delta,
        arow=arow,
        brow=brow,
    )
    corrected_df.to_csv(out_corrected_csv, index=False)
    pred_df.to_csv(out_pred_csv, index=False)
    log(f"[SAVED] corrected: {out_corrected_csv}")
    log(f"[SAVED] predicted components: {out_pred_csv}")

    summary: Dict[str, object] = {"rows_pred": float(len(base_df))}

    if (not no_plot) and plot_dir is not None:
        plot_baseline_vs_corrected(
            stem=out_corrected_csv.stem,
            baseline_df=base_df,
            corrected_df=corrected_df,
            out_dir=plot_dir,
            sample_every=plot_sample_every,
        )
        log(f"[SAVED] baseline-vs-corrected plots: {plot_dir}")

    if truth_df is not None:
        metrics_df, merged_df = compute_metrics(
            truth_df=truth_df,
            baseline_df=base_df,
            corrected_df=corrected_df,
        )
        mpath = out_metrics_csv or (out_corrected_csv.parent / f"{out_corrected_csv.stem}_metrics.csv")
        if mpath.exists() and not overwrite:
            raise FileExistsError(f"exists: {mpath} (use --overwrite)")
        ensure_dir(mpath.parent)
        metrics_df.to_csv(mpath, index=False)
        log(f"[SAVED] metrics: {mpath}")

        b = metrics_df[metrics_df["kind"] == "baseline"].iloc[0]
        c = metrics_df[metrics_df["kind"] == "corrected"].iloc[0]
        log("[METRIC] MSE/RMSE (baseline -> corrected)")
        for col in TARGET_COLS:
            log(
                f"  {col}: MSE {float(b[f'{col}_MSE']):.6g} -> {float(c[f'{col}_MSE']):.6g} | "
                f"RMSE {float(b[f'{col}_RMSE']):.6g} -> {float(c[f'{col}_RMSE']):.6g}"
            )
        log(
            f"  GLOBAL: MSE {float(b['global_MSE']):.6g} -> {float(c['global_MSE']):.6g} | "
            f"RMSE {float(b['global_RMSE']):.6g} -> {float(c['global_RMSE']):.6g}"
        )

        summary["rows_eval"] = float(b["rows"])
        summary["global_RMSE_base"] = float(b["global_RMSE"])
        summary["global_RMSE_corr"] = float(c["global_RMSE"])
        summary["AZEL_RMSE_base"] = float(0.5 * (float(b["AZ_RMSE"]) + float(b["EL_RMSE"])))
        summary["AZEL_RMSE_corr"] = float(0.5 * (float(c["AZ_RMSE"]) + float(c["EL_RMSE"])))

        if (not no_plot) and plot_dir is not None:
            plot_truth_baseline_corrected(
                stem=out_corrected_csv.stem,
                merged_df=merged_df,
                out_dir=plot_dir,
                sample_every=plot_sample_every,
            )
            plot_metric_summary(
                stem=out_corrected_csv.stem,
                metrics_df=metrics_df,
                out_dir=plot_dir,
            )
            log(f"[SAVED] truth comparison plots: {plot_dir}")

    return summary


def train_cmd(args: argparse.Namespace) -> int:
    require_tensorflow()
    tle_dir = Path(args.tle_dir)
    baseline_dir = Path(args.baseline_dir)
    truth_csv = Path(args.truth_csv)
    out_model = Path(args.out_model)

    if not tle_dir.exists():
        raise FileNotFoundError(f"tle-dir not found: {tle_dir}")
    if not baseline_dir.exists():
        raise FileNotFoundError(f"baseline-dir not found: {baseline_dir}")
    if not truth_csv.exists():
        raise FileNotFoundError(f"truth-csv not found: {truth_csv}")

    all_stems = list_stems_with_both(tle_dir=tle_dir, csv_dir=baseline_dir)
    if not all_stems:
        log("[ERROR] no matching TLE/baseline pairs")
        return 2
    if args.max_files is not None:
        all_stems = all_stems[: int(args.max_files)]
    train_stems, val_stems = split_stems(
        all_stems=all_stems,
        val_split=float(args.val_split),
        seed=int(args.seed),
        split_mode=str(args.split_mode),
    )
    log(
        f"[INFO] files total/train/val={len(all_stems)}/{len(train_stems)}/{len(val_stems)}, "
        f"days={args.days_horizon}, step={args.step_minutes}, sample_every={args.sample_every}"
    )

    truth_df = load_truth_df(truth_csv)
    cfg = FeatureConfig(
        day_harmonics=int(args.day_harmonics),
        span_harmonics=int(args.span_harmonics),
        include_sidereal=(not bool(args.no_sidereal)),
        include_interactions=(not bool(args.no_interactions)),
        include_template_feature=False,
        include_baseline_feature=(not bool(args.no_baseline_feature)),
    )

    x_mean, x_std, yc_mean, yc_std, yd_mean, yd_std, feat_names, scaler_rows = compute_scalers(
        stems=train_stems,
        tle_dir=tle_dir,
        baseline_dir=baseline_dir,
        truth_df=truth_df,
        cfg=cfg,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
    )
    log(f"[INFO] scaler rows={scaler_rows}, input_dim={len(feat_names)}")

    hidden = parse_hidden_csv(args.hidden)
    model = build_model(
        input_dim=len(feat_names),
        hidden=hidden,
        dropout=float(args.dropout),
        l2=float(args.l2),
    )
    loss_weights = parse_loss_weights(args)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=float(args.lr)),
        loss=build_weighted_huber_loss(
            delta=float(args.huber_delta),
            weights=loss_weights,
        ),
    )

    rng = np.random.default_rng(int(args.seed))
    best_score = float("inf")
    best_epoch = -1
    no_improve = 0

    ensure_dir(out_model if out_model.suffix == "" else out_model.parent)
    best_model_path = (out_model if out_model.suffix == "" else out_model.parent) / "_best_model.keras"

    def load_train_arrays(stem: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        x, y_corr, y_direct, _, _, no, _, _ = load_train_pair(
            stem=stem,
            tle_dir=tle_dir,
            baseline_dir=baseline_dir,
            truth_df=truth_df,
            cfg=cfg,
            days_horizon=int(args.days_horizon),
            step_minutes=int(args.step_minutes),
            sample_every=int(args.sample_every),
        )
        if len(x) == 0:
            return np.zeros((0, 1), dtype=np.float32), np.zeros((0, 2 * len(TARGET_COLS)), dtype=np.float32), np.zeros((0,), dtype=np.float64)
        x_s = scale_arr(x, x_mean, x_std)
        yc_s = scale_arr(y_corr, yc_mean, yc_std)
        yd_s = scale_arr(y_direct, yd_mean, yd_std)
        y_s = np.concatenate([yc_s, yd_s], axis=1).astype(np.float32)
        no_norm = (no.astype(np.float64) - 1.0) / max(1.0, float(np.max(no) - 1.0))
        return x_s, y_s, no_norm

    val_eval_stems = val_stems
    if args.val_eval_max_files is not None and int(args.val_eval_max_files) > 0:
        val_eval_stems = val_eval_stems[: int(args.val_eval_max_files)]

    for epoch in range(1, int(args.epochs) + 1):
        stems = list(train_stems)
        rng.shuffle(stems)
        total_loss = 0.0
        total_rows = 0

        for stem in stems:
            try:
                x_s, y_s, no_norm = load_train_arrays(stem)
            except Exception as e:
                log(f"[WARN] train skip {stem}: {e}")
                continue
            n = len(x_s)
            if n == 0:
                continue
            idx = np.arange(n)
            rng.shuffle(idx)
            x_s = x_s[idx]
            y_s = y_s[idx]
            no_norm = no_norm[idx]
            bs = int(args.batch_size)
            for s in range(0, n, bs):
                e = min(n, s + bs)
                xb = x_s[s:e]
                yb = y_s[s:e]
                if float(args.time_weight_power) > 0:
                    w = np.power(np.clip(no_norm[s:e], 0.0, 1.0), float(args.time_weight_power)) + 1e-3
                else:
                    w = None
                loss = model.train_on_batch(xb, yb, sample_weight=w, return_dict=False)
                total_loss += float(loss) * len(xb)
                total_rows += len(xb)

        train_loss = total_loss / max(1, total_rows)

        # Epoch validation score: corr-only AZ/EL RMSE mean
        v_sum = 0.0
        v_cnt = 0
        b_sum = 0.0
        for stem in val_eval_stems:
            try:
                x, _, _, baseline, truth, _, _, _ = load_train_pair(
                    stem=stem,
                    tle_dir=tle_dir,
                    baseline_dir=baseline_dir,
                    truth_df=truth_df,
                    cfg=cfg,
                    days_horizon=int(args.days_horizon),
                    step_minutes=int(args.step_minutes),
                    sample_every=int(args.sample_every),
                )
            except Exception:
                continue
            if len(x) == 0:
                continue
            corr_pred, _ = predict_dual(
                model=model,
                x=x,
                x_mean=x_mean,
                x_std=x_std,
                yc_mean=yc_mean,
                yc_std=yc_std,
                yd_mean=yd_mean,
                yd_std=yd_std,
                batch_size=int(args.batch_size),
            )
            corrected_corr = correction_to_corrected(baseline=baseline, delta=corr_pred)
            eb_az = angle_diff_deg(baseline[:, TARGET_COLS.index("AZ")], truth[:, TARGET_COLS.index("AZ")])
            eb_el = baseline[:, TARGET_COLS.index("EL")] - truth[:, TARGET_COLS.index("EL")]
            ec_az = angle_diff_deg(corrected_corr[:, TARGET_COLS.index("AZ")], truth[:, TARGET_COLS.index("AZ")])
            ec_el = corrected_corr[:, TARGET_COLS.index("EL")] - truth[:, TARGET_COLS.index("EL")]
            b_rmse = 0.5 * (float(np.sqrt(np.mean(eb_az * eb_az))) + float(np.sqrt(np.mean(eb_el * eb_el))))
            c_rmse = 0.5 * (float(np.sqrt(np.mean(ec_az * ec_az))) + float(np.sqrt(np.mean(ec_el * ec_el))))
            b_sum += b_rmse
            v_sum += c_rmse
            v_cnt += 1

        base_rmse = (b_sum / max(1, v_cnt))
        score = (v_sum / max(1, v_cnt))
        log(f"[EPOCH {epoch}/{args.epochs}] train_loss={train_loss:.6g} rows={total_rows}")
        log(f"  [VAL corr-only] AZEL_RMSE_mean {base_rmse:.6g} -> {score:.6g}")

        improved = (best_score - score) > float(args.early_stop_min_delta)
        if improved:
            best_score = score
            best_epoch = epoch
            no_improve = 0
            model.save(str(best_model_path))
        else:
            no_improve += 1

        if int(args.early_stop_patience) > 0 and epoch >= int(args.early_stop_warmup):
            if no_improve >= int(args.early_stop_patience):
                log(
                    f"[EARLY STOP] no improve for {no_improve} epochs. "
                    f"best_epoch={best_epoch} best_score={best_score:.6g}"
                )
                break

    if best_model_path.exists():
        model = tf.keras.models.load_model(str(best_model_path), compile=False)

    # Blend calibration on val split (fallback train split when needed).
    calib_stems = val_stems if val_stems else train_stems
    edges = parse_float_list_csv(str(args.blend_day_edges))
    if len(edges) < 2:
        edges = [0.0, float(args.days_horizon)]
    if edges[0] > 0:
        edges = [0.0] + edges
    horizon = float(args.days_horizon)
    if edges[-1] < horizon:
        edges = edges + [horizon]
    edges = sorted(set(float(x) for x in edges))
    blend_edges_days = np.asarray(edges, dtype=np.float64)

    alpha_mat, beta_mat = fit_blend_coefficients(
        stems=calib_stems,
        tle_dir=tle_dir,
        baseline_dir=baseline_dir,
        truth_df=truth_df,
        cfg=cfg,
        model=model,
        x_mean=x_mean,
        x_std=x_std,
        yc_mean=yc_mean,
        yc_std=yc_std,
        yd_mean=yd_mean,
        yd_std=yd_std,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        blend_edges_days=blend_edges_days,
        max_alpha=float(args.max_alpha),
        max_beta=float(args.max_beta),
        max_alpha_azel=float(args.max_alpha_azel),
        max_beta_azel=float(args.max_beta_azel),
        l2_reg=float(args.blend_l2),
    )

    alpha_mat, beta_mat, guard_details = apply_min_improve_guard(
        stems=calib_stems,
        tle_dir=tle_dir,
        baseline_dir=baseline_dir,
        truth_df=truth_df,
        cfg=cfg,
        model=model,
        x_mean=x_mean,
        x_std=x_std,
        yc_mean=yc_mean,
        yc_std=yc_std,
        yd_mean=yd_mean,
        yd_std=yd_std,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        blend_edges_days=blend_edges_days,
        alpha_matrix=alpha_mat,
        beta_matrix=beta_mat,
        min_improve_pct=float(args.blend_min_improve_pct),
        azel_cap_deg=(float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None),
    )

    observer_lat_deg = float(args.observer_lat)
    observer_lon_deg = float(args.observer_lon)
    observer_alt_m = float(args.observer_alt_m)
    azel_mode_arg = str(args.azel_strategy).strip().lower()
    azel_mix_weight = float(np.clip(float(args.azel_mix_weight), 0.0, 1.0))
    azel_strategy_details: Dict[str, float] = {}
    if azel_mode_arg == "auto":
        mix_grid = parse_float_list_csv(str(args.azel_mix_grid))
        if not mix_grid:
            mix_grid = [0.0, 0.5, 1.0]
        azel_mode, azel_mix_weight, azel_strategy_details = calibrate_azel_strategy(
            stems=calib_stems,
            tle_dir=tle_dir,
            baseline_dir=baseline_dir,
            truth_df=truth_df,
            cfg=cfg,
            model=model,
            x_mean=x_mean,
            x_std=x_std,
            yc_mean=yc_mean,
            yc_std=yc_std,
            yd_mean=yd_mean,
            yd_std=yd_std,
            days_horizon=int(args.days_horizon),
            step_minutes=int(args.step_minutes),
            sample_every=int(args.sample_every),
            batch_size=int(args.batch_size),
            blend_edges_days=blend_edges_days,
            alpha_matrix=alpha_mat,
            beta_matrix=beta_mat,
            azel_cap_deg=(float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None),
            observer_lat_deg=observer_lat_deg,
            observer_lon_deg=observer_lon_deg,
            observer_alt_m=observer_alt_m,
            mix_grid=mix_grid,
            min_improve_pct=float(args.azel_strategy_min_improve_pct),
        )
    else:
        azel_mode = azel_mode_arg
        azel_strategy_details = {}

    log("[INFO] blend day edges: " + ",".join(f"{x:g}" for x in blend_edges_days.tolist()))
    for col in TARGET_COLS:
        i = TARGET_COLS.index(col)
        av = ", ".join(f"{v:.4g}" for v in alpha_mat[:, i].tolist())
        bv = ", ".join(f"{v:.4g}" for v in beta_mat[:, i].tolist())
        log(f"[BLEND:{col}] alpha={av} | beta={bv}")
    log(f"[INFO] AZEL strategy: mode={azel_mode}, mix_weight={azel_mix_weight:.4g}")
    if azel_strategy_details:
        log(
            "[INFO] AZEL strategy scores: "
            f"baseline={azel_strategy_details.get('rmse_baseline', float('nan')):.6g}, "
            f"pred={azel_strategy_details.get('rmse_predicted', float('nan')):.6g}, "
            f"recompute={azel_strategy_details.get('rmse_recompute', float('nan')):.6g}, "
            f"best={azel_strategy_details.get('rmse_best', float('nan')):.6g}"
        )

    train_eval = evaluate_dataset(
        stems=train_stems,
        tle_dir=tle_dir,
        baseline_dir=baseline_dir,
        truth_df=truth_df,
        cfg=cfg,
        model=model,
        x_mean=x_mean,
        x_std=x_std,
        yc_mean=yc_mean,
        yc_std=yc_std,
        yd_mean=yd_mean,
        yd_std=yd_std,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        blend_edges_days=blend_edges_days,
        alpha_matrix=alpha_mat,
        beta_matrix=beta_mat,
        azel_cap_deg=(float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None),
        observer_lat_deg=observer_lat_deg,
        observer_lon_deg=observer_lon_deg,
        observer_alt_m=observer_alt_m,
        azel_strategy_mode=azel_mode,
        azel_mix_weight=azel_mix_weight,
    )
    val_eval = evaluate_dataset(
        stems=val_stems,
        tle_dir=tle_dir,
        baseline_dir=baseline_dir,
        truth_df=truth_df,
        cfg=cfg,
        model=model,
        x_mean=x_mean,
        x_std=x_std,
        yc_mean=yc_mean,
        yc_std=yc_std,
        yd_mean=yd_mean,
        yd_std=yd_std,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        blend_edges_days=blend_edges_days,
        alpha_matrix=alpha_mat,
        beta_matrix=beta_mat,
        azel_cap_deg=(float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None),
        observer_lat_deg=observer_lat_deg,
        observer_lon_deg=observer_lon_deg,
        observer_alt_m=observer_alt_m,
        azel_strategy_mode=azel_mode,
        azel_mix_weight=azel_mix_weight,
    )
    if train_eval:
        log(
            f"[TRAIN] global RMSE {train_eval['global_RMSE_base']:.6g} -> "
            f"{train_eval['global_RMSE_corr']:.6g} ({train_eval['global_RMSE_improve_pct']:.3f}%)"
        )
    if val_eval:
        log(
            f"[VAL] global RMSE {val_eval['global_RMSE_base']:.6g} -> "
            f"{val_eval['global_RMSE_corr']:.6g} ({val_eval['global_RMSE_improve_pct']:.3f}%)"
        )
        for col in TARGET_COLS:
            log(f"  {col}: RMSE {val_eval[f'{col}_RMSE_base']:.6g} -> {val_eval[f'{col}_RMSE_corr']:.6g}")

    bundle = ModelBundle(
        feature_cfg=cfg,
        feature_names=feat_names,
        x_mean=x_mean,
        x_std=x_std,
        yc_mean=yc_mean,
        yc_std=yc_std,
        yd_mean=yd_mean,
        yd_std=yd_std,
        blend_edges_days=blend_edges_days,
        alpha_matrix=alpha_mat,
        beta_matrix=beta_mat,
        azel_cap_deg=(float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None),
        observer_lat_deg=observer_lat_deg,
        observer_lon_deg=observer_lon_deg,
        observer_alt_m=observer_alt_m,
        azel_strategy_mode=azel_mode,
        azel_mix_weight=azel_mix_weight,
        train_rows=int(scaler_rows),
        train_files=int(len(train_stems)),
        val_files=int(len(val_stems)),
    )

    extra = {
        "split_mode": str(args.split_mode),
        "best_epoch": int(best_epoch),
        "best_val_score_azel_corr_only": float(best_score),
        "train_eval": train_eval,
        "val_eval": val_eval,
        "blend_guard_details": guard_details,
        "blend_min_improve_pct": float(args.blend_min_improve_pct),
        "blend_l2": float(args.blend_l2),
        "max_alpha": float(args.max_alpha),
        "max_beta": float(args.max_beta),
        "max_alpha_azel": float(args.max_alpha_azel),
        "max_beta_azel": float(args.max_beta_azel),
        "observer_lat_deg": observer_lat_deg,
        "observer_lon_deg": observer_lon_deg,
        "observer_alt_m": observer_alt_m,
        "azel_strategy_mode": azel_mode,
        "azel_mix_weight": float(azel_mix_weight),
        "azel_strategy_min_improve_pct": float(args.azel_strategy_min_improve_pct),
        "azel_strategy_details": azel_strategy_details,
        "model": {
            "hidden": hidden,
            "dropout": float(args.dropout),
            "l2": float(args.l2),
            "lr": float(args.lr),
            "huber_delta": float(args.huber_delta),
            "loss_weights": parse_loss_weights(args).tolist(),
        },
    }

    model_path, meta_path = save_model_and_meta(
        model=model,
        bundle=bundle,
        out_model=out_model,
        overwrite=bool(args.overwrite),
        extra=extra,
    )
    summary_path = meta_path.parent / "train_summary.json"
    summary_path.write_text(json.dumps(extra, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[SAVED] model: {model_path}")
    log(f"[SAVED] meta: {meta_path}")
    log(f"[SAVED] train summary: {summary_path}")
    return 0


def predict_cmd(args: argparse.Namespace) -> int:
    model, bundle, _ = load_model_and_meta(Path(args.model))
    truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True) if args.truth_csv else None

    out_corr = Path(args.out_corrected_csv)
    out_pred = Path(args.out_pred_csv)
    out_metrics = Path(args.out_metrics_csv) if args.out_metrics_csv else None

    if args.plot_dir:
        plot_dir = Path(args.plot_dir)
    elif args.truth_csv:
        plot_dir = out_corr.parent / "plots"
    else:
        plot_dir = out_corr.parent / "plots"

    run_predict_one(
        model=model,
        bundle=bundle,
        tle_file=Path(args.tle_file),
        baseline_csv=Path(args.baseline_csv),
        out_corrected_csv=out_corr,
        out_pred_csv=out_pred,
        truth_df=truth_df,
        out_metrics_csv=out_metrics,
        plot_dir=plot_dir,
        days=int(args.days),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        plot_sample_every=int(args.plot_sample_every),
        mode=str(args.mode),
        observer_lat_deg=(float(args.observer_lat) if args.observer_lat is not None else None),
        observer_lon_deg=(float(args.observer_lon) if args.observer_lon is not None else None),
        observer_alt_m=(float(args.observer_alt_m) if args.observer_alt_m is not None else None),
        azel_strategy_override=args.azel_strategy_override,
        azel_mix_weight_override=args.azel_mix_weight_override,
        overwrite=bool(args.overwrite),
        no_plot=bool(args.no_plot),
    )
    return 0


def predict_dir_cmd(args: argparse.Namespace) -> int:
    model, bundle, _ = load_model_and_meta(Path(args.model))
    tle_dir = Path(args.tle_dir)
    baseline_dir = Path(args.baseline_dir)
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)
    truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True) if args.truth_csv else None
    plot_dir = out_dir / "plots"

    files = sorted([p for p in baseline_dir.glob(args.glob) if p.is_file()])
    if not files:
        log(f"[ERROR] no baseline CSV found: dir={baseline_dir}, glob={args.glob}")
        return 2

    rows: List[Dict[str, object]] = []
    total = len(files)
    for i, base_path in enumerate(files, start=1):
        stem = base_path.stem
        tle_file = tle_dir / f"{stem}.txt"
        if not tle_file.exists():
            log(f"[SKIP] ({i}/{total}) missing TLE: {tle_file.name}")
            continue
        out_corr = out_dir / f"{stem}.csv"
        out_pred = out_dir / f"{stem}_pred.csv"
        out_metrics = out_dir / f"{stem}_metrics.csv"
        try:
            s = run_predict_one(
                model=model,
                bundle=bundle,
                tle_file=tle_file,
                baseline_csv=base_path,
                out_corrected_csv=out_corr,
                out_pred_csv=out_pred,
                truth_df=truth_df,
                out_metrics_csv=out_metrics,
                plot_dir=plot_dir,
                days=int(args.days),
                step_minutes=int(args.step_minutes),
                sample_every=int(args.sample_every),
                batch_size=int(args.batch_size),
                plot_sample_every=int(args.plot_sample_every),
                mode=str(args.mode),
                observer_lat_deg=(float(args.observer_lat) if args.observer_lat is not None else None),
                observer_lon_deg=(float(args.observer_lon) if args.observer_lon is not None else None),
                observer_alt_m=(float(args.observer_alt_m) if args.observer_alt_m is not None else None),
                azel_strategy_override=args.azel_strategy_override,
                azel_mix_weight_override=args.azel_mix_weight_override,
                overwrite=bool(args.overwrite),
                no_plot=bool(args.no_plot),
            )
            r = {"stem": stem}
            r.update(s)
            rows.append(r)
            log(f"[OK] ({i}/{total}) {stem}")
        except Exception as e:
            log(f"[FAIL] ({i}/{total}) {stem}: {e}")

    if rows:
        summary_path = out_dir / "summary_metrics.csv"
        pd.DataFrame(rows).to_csv(summary_path, index=False)
        log(f"[SAVED] summary: {summary_path}")
    else:
        log("[WARN] no successful predictions")
    return 0


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="orbit_hybrid_direct_tf.py",
        description="Hybrid model (residual + direct) for GEO 30-day prediction",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train", help="Train on 2023 TLE + baseline + truth")
    t.add_argument("--tle-dir", default="23467_2023")
    t.add_argument("--baseline-dir", default="23467_2023_csv")
    t.add_argument("--truth-csv", default="2023_calc_az_el.csv")
    t.add_argument("--out-model", default="orbit_hybrid_direct_model_tf")
    t.add_argument("--days-horizon", type=int, default=30)
    t.add_argument("--step-minutes", type=int, default=1)
    t.add_argument("--sample-every", type=int, default=1)
    t.add_argument("--val-split", type=float, default=0.15)
    t.add_argument("--split-mode", choices=["time", "hash"], default="time")
    t.add_argument("--seed", type=int, default=42)
    t.add_argument("--max-files", type=int, default=None)

    t.add_argument("--day-harmonics", type=int, default=6)
    t.add_argument("--span-harmonics", type=int, default=4)
    t.add_argument("--no-sidereal", action="store_true")
    t.add_argument("--no-interactions", action="store_true")
    t.add_argument("--no-baseline-feature", action="store_true")

    t.add_argument("--hidden", type=str, default="512,512,256,128")
    t.add_argument("--dropout", type=float, default=0.05)
    t.add_argument("--l2", type=float, default=1e-6)
    t.add_argument("--lr", type=float, default=1e-3)
    t.add_argument("--huber-delta", type=float, default=1.0)
    t.add_argument("--epochs", type=int, default=120)
    t.add_argument("--batch-size", type=int, default=2048)
    t.add_argument("--time-weight-power", type=float, default=0.0)
    t.add_argument("--early-stop-patience", type=int, default=15)
    t.add_argument("--early-stop-warmup", type=int, default=8)
    t.add_argument("--early-stop-min-delta", type=float, default=0.0)
    t.add_argument("--val-eval-max-files", type=int, default=None)

    t.add_argument("--loss-weight-corr-lat", type=float, default=1.0)
    t.add_argument("--loss-weight-corr-lon", type=float, default=1.0)
    t.add_argument("--loss-weight-corr-alt", type=float, default=1.0)
    t.add_argument("--loss-weight-corr-az", type=float, default=3.0)
    t.add_argument("--loss-weight-corr-el", type=float, default=3.0)
    t.add_argument("--loss-weight-direct-lat", type=float, default=0.2)
    t.add_argument("--loss-weight-direct-lon", type=float, default=0.2)
    t.add_argument("--loss-weight-direct-alt", type=float, default=0.2)
    t.add_argument("--loss-weight-direct-az", type=float, default=0.6)
    t.add_argument("--loss-weight-direct-el", type=float, default=0.6)

    t.add_argument("--blend-day-edges", type=str, default="0,1,3,7,14,30")
    t.add_argument("--blend-min-improve-pct", type=float, default=0.2)
    t.add_argument("--blend-l2", type=float, default=1e-6)
    t.add_argument("--max-alpha", type=float, default=1.0)
    t.add_argument("--max-beta", type=float, default=0.5)
    t.add_argument("--max-alpha-azel", type=float, default=0.8)
    t.add_argument("--max-beta-azel", type=float, default=0.3)
    t.add_argument("--azel-cap-deg", type=float, default=0.03)
    t.add_argument("--observer-lat", type=float, default=36.3022)
    t.add_argument("--observer-lon", type=float, default=137.9031)
    t.add_argument("--observer-alt-m", type=float, default=0.0)
    t.add_argument("--azel-strategy", choices=["auto", "predicted", "recompute", "mix", "baseline"], default="auto")
    t.add_argument("--azel-mix-weight", type=float, default=0.5,
                   help="Used when --azel-strategy=mix")
    t.add_argument("--azel-mix-grid", type=str, default="0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0",
                   help="Mix-weight candidates for --azel-strategy=auto")
    t.add_argument("--azel-strategy-min-improve-pct", type=float, default=0.2,
                   help="If auto-selected AZEL strategy does not beat baseline by this pct, fallback to baseline")
    t.add_argument("--overwrite", action="store_true")

    pr = sub.add_parser("predict", help="Predict one file")
    pr.add_argument("--model", required=True)
    pr.add_argument("--tle-file", required=True)
    pr.add_argument("--baseline-csv", required=True)
    pr.add_argument("--out-corrected-csv", required=True)
    pr.add_argument("--out-pred-csv", required=True)
    pr.add_argument("--truth-csv", default=None)
    pr.add_argument("--out-metrics-csv", default=None)
    pr.add_argument("--plot-dir", default=None)
    pr.add_argument("--plot-sample-every", type=int, default=5)
    pr.add_argument("--no-plot", action="store_true")
    pr.add_argument("--days", type=int, default=30)
    pr.add_argument("--step-minutes", type=int, default=1)
    pr.add_argument("--sample-every", type=int, default=1)
    pr.add_argument("--batch-size", type=int, default=4096)
    pr.add_argument("--mode", choices=["hybrid", "corr_only", "direct_only"], default="hybrid")
    pr.add_argument("--observer-lat", type=float, default=None,
                    help="Override observer latitude used in AZEL recomputation")
    pr.add_argument("--observer-lon", type=float, default=None,
                    help="Override observer longitude used in AZEL recomputation")
    pr.add_argument("--observer-alt-m", type=float, default=None,
                    help="Override observer altitude[m] used in AZEL recomputation")
    pr.add_argument("--azel-strategy-override", choices=["predicted", "recompute", "mix", "baseline"], default=None)
    pr.add_argument("--azel-mix-weight-override", type=float, default=None)
    pr.add_argument("--overwrite", action="store_true")

    pdm = sub.add_parser("predict-dir", help="Predict all baseline files in a directory")
    pdm.add_argument("--model", required=True)
    pdm.add_argument("--tle-dir", default="23467_2024")
    pdm.add_argument("--baseline-dir", default="23467_2024_csv")
    pdm.add_argument("--out-dir", default="23467_2024_corrected_hybrid")
    pdm.add_argument("--truth-csv", default="2024_calc_az_el.csv")
    pdm.add_argument("--glob", default="*.csv")
    pdm.add_argument("--plot-sample-every", type=int, default=5)
    pdm.add_argument("--no-plot", action="store_true")
    pdm.add_argument("--days", type=int, default=30)
    pdm.add_argument("--step-minutes", type=int, default=1)
    pdm.add_argument("--sample-every", type=int, default=1)
    pdm.add_argument("--batch-size", type=int, default=4096)
    pdm.add_argument("--mode", choices=["hybrid", "corr_only", "direct_only"], default="hybrid")
    pdm.add_argument("--observer-lat", type=float, default=None)
    pdm.add_argument("--observer-lon", type=float, default=None)
    pdm.add_argument("--observer-alt-m", type=float, default=None)
    pdm.add_argument("--azel-strategy-override", choices=["predicted", "recompute", "mix", "baseline"], default=None)
    pdm.add_argument("--azel-mix-weight-override", type=float, default=None)
    pdm.add_argument("--overwrite", action="store_true")

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
    args = make_parser().parse_args(argv)
    if args.cmd == "train":
        return train_cmd(args)
    if args.cmd == "predict":
        return predict_cmd(args)
    if args.cmd == "predict-dir":
        return predict_dir_cmd(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
