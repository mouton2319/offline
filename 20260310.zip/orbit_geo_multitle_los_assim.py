#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GEO-focused multi-TLE fusion + low-rank residual model for AZ/EL.

Why this script:
- Single-TLE SGP4 is already strong for GEO and is hard to beat with naive
  No-index error averaging.
- This script changes direction:
  1) Build a stronger baseline by fusing multiple recent TLE trajectories.
  2) Learn only a low-rank residual curve (AZ/EL) on top of that baseline.
  3) Use conservative gates (OOD confidence + member disagreement) to avoid
     over-correction.

Main assumptions:
- GEO target satellite.
- Training uses 2023 data:
    --tle-dir  : per-epoch TLE txt files
    --pred-dir : per-TLE propagated CSV files (30 days, 1 minute etc.)
    --truth-csv: ground-truth orbit CSV
- Inference uses multiple TLEs from a directory (default: ./pred_tle).
  The latest timestamped TLE is used as anchor, and 30-day prediction starts
  from that anchor time.

About "pseudo observation":
- You requested using AZ/EL from latest TLE as a substitute for same-day
  observation (e.g., if TLE is ~12h before operation time).
- This script supports that as an optional *pseudo-observation anchor*:
  fused baseline is pulled toward latest-TLE AZ/EL in early horizon.
- Note: this is not independent measurement; it stabilizes near-term behavior
  but cannot replace true antenna measurement.
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import json
import math
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from skyfield.api import EarthSatellite, load, wgs84
except Exception:
    EarthSatellite = None
    load = None
    wgs84 = None

from orbit_error_ai_no_tle_tf import (
    TARGET_COLS,
    angle_diff_deg,
    compute_metrics,
    ensure_dir,
    load_orbit_csv,
    log,
    now_jst_str,
    parse_tle_file,
    plot_baseline_vs_corrected,
    plot_metric_summary,
    plot_truth_baseline_corrected,
    tle_feature_vector,
    trim_horizon_and_stride,
    wrap180,
    wrap360,
)


MINUTES_PER_DAY = 1440.0


@dataclasses.dataclass
class StemRecord:
    stem: str
    ts: dt.datetime
    tle_path: Optional[Path]
    csv_path: Optional[Path]


@dataclasses.dataclass
class TrainSample:
    stem: str
    feat: np.ndarray
    coef_az: np.ndarray
    coef_el: np.ndarray
    residual_az: np.ndarray
    residual_el: np.ndarray
    valid_mask: np.ndarray
    std_az_members: np.ndarray
    std_el_members: np.ndarray


def parse_stem_datetime(stem: str) -> Optional[dt.datetime]:
    s = str(stem).strip()
    m = re.search(r"(\d{4}-\d{2}-\d{2})[-_](\d{2})-(\d{2})-(\d{2})", s)
    if m is None:
        return None
    ds = m.group(1)
    hh = int(m.group(2))
    mm = int(m.group(3))
    ss = int(m.group(4))
    try:
        d0 = dt.datetime.strptime(ds, "%Y-%m-%d")
    except Exception:
        return None
    return d0.replace(hour=hh, minute=mm, second=ss)


def parse_float_csv(text: str) -> List[float]:
    vals: List[float] = []
    for tok in str(text).split(","):
        t = tok.strip()
        if not t:
            continue
        vals.append(float(t))
    return vals


def deterministic_split(stem: str, val_split: float, seed: int) -> str:
    import hashlib

    h = hashlib.md5((stem + str(seed)).encode("utf-8")).hexdigest()
    r = int(h[:8], 16) / float(16**8)
    return "val" if r < val_split else "train"


def split_stems(
    stems: List[str],
    val_split: float,
    split_mode: str,
    seed: int,
) -> Tuple[List[str], List[str]]:
    if len(stems) == 0:
        return [], []
    v = float(np.clip(val_split, 0.0, 0.9))
    if v <= 0:
        return list(stems), []
    if split_mode == "hash":
        tr: List[str] = []
        va: List[str] = []
        for s in stems:
            if deterministic_split(s, v, seed) == "val":
                va.append(s)
            else:
                tr.append(s)
        if len(va) == 0 and len(tr) > 1:
            va = [tr.pop(-1)]
        return tr, va
    ss = sorted(stems)
    n_val = max(1, int(round(len(ss) * v)))
    n_val = min(n_val, max(1, len(ss) - 1))
    return ss[:-n_val], ss[-n_val:]


def fit_linear_fill(vals: np.ndarray, mask: np.ndarray) -> np.ndarray:
    out = np.asarray(vals, dtype=np.float64).copy()
    m = np.asarray(mask, dtype=bool)
    idx = np.where(m)[0]
    if len(idx) == 0:
        return np.zeros_like(out)
    if len(idx) == 1:
        out[:] = out[idx[0]]
        return out
    full = np.arange(len(out), dtype=np.float64)
    out[:] = np.interp(full, idx.astype(np.float64), out[idx])
    return out


def fit_angle_fill(vals: np.ndarray, mask: np.ndarray) -> np.ndarray:
    out = np.asarray(vals, dtype=np.float64).copy()
    m = np.asarray(mask, dtype=bool)
    idx = np.where(m)[0]
    if len(idx) == 0:
        return np.zeros_like(out)
    if len(idx) == 1:
        out[:] = out[idx[0]]
        return wrap180(out)
    full = np.arange(len(out), dtype=np.float64)
    rad = np.unwrap(np.deg2rad(out[idx]))
    out[:] = np.rad2deg(np.interp(full, idx.astype(np.float64), rad))
    return wrap180(out)


def circular_blend_deg(a_deg: np.ndarray, b_deg: np.ndarray, w_b: np.ndarray) -> np.ndarray:
    wa = 1.0 - np.asarray(w_b, dtype=np.float64)
    wb = np.asarray(w_b, dtype=np.float64)
    ar = np.deg2rad(np.asarray(a_deg, dtype=np.float64))
    br = np.deg2rad(np.asarray(b_deg, dtype=np.float64))
    s = wa * np.sin(ar) + wb * np.sin(br)
    c = wa * np.cos(ar) + wb * np.cos(br)
    return wrap180(np.rad2deg(np.arctan2(s, c)))


def read_tle_pair_lines(path: Path) -> Tuple[str, str]:
    lines = [ln.strip() for ln in path.read_text(encoding="utf-8", errors="ignore").splitlines() if ln.strip()]
    for i in range(len(lines) - 1):
        if lines[i].startswith("1 ") and lines[i + 1].startswith("2 "):
            return lines[i], lines[i + 1]
    if len(lines) >= 2 and lines[-2].startswith("1 ") and lines[-1].startswith("2 "):
        return lines[-2], lines[-1]
    raise ValueError(f"TLE pair not found: {path}")


def round_to_nearest_minute(d: dt.datetime) -> dt.datetime:
    f = d.replace(second=0, microsecond=0)
    if d - f >= dt.timedelta(seconds=30):
        return f + dt.timedelta(minutes=1)
    return f


def jst_naive_to_unix_seconds(d_jst_naive: dt.datetime) -> int:
    d_utc = d_jst_naive - dt.timedelta(hours=9)
    return int(d_utc.timestamp())


def propagate_tle_to_df(
    tle_path: Path,
    sat_name: str,
    observer_lat: float,
    observer_lon: float,
    days_horizon: int,
    step_minutes: int,
) -> pd.DataFrame:
    if EarthSatellite is None or load is None or wgs84 is None:
        raise RuntimeError("skyfield is not available. install skyfield first.")
    start_jst_raw = parse_stem_datetime(tle_path.stem)
    if start_jst_raw is None:
        raise ValueError(f"timestamp not parseable from tle name: {tle_path.name}")
    start_jst = round_to_nearest_minute(start_jst_raw)

    line1, line2 = read_tle_pair_lines(tle_path)
    ts = load.timescale()
    sat = EarthSatellite(line1, line2, sat_name, ts)
    obs = wgs84.latlon(observer_lat, observer_lon)

    total_rows = int(days_horizon * 24 * 60 // max(1, int(step_minutes)))
    if total_rows <= 0:
        raise ValueError("rows <= 0")

    years: List[int] = []
    months: List[int] = []
    days: List[int] = []
    hours: List[int] = []
    minutes: List[int] = []
    seconds: List[float] = []
    d = start_jst - dt.timedelta(hours=9)  # UTC
    step = dt.timedelta(minutes=step_minutes)
    for _ in range(total_rows):
        years.append(d.year)
        months.append(d.month)
        days.append(d.day)
        hours.append(d.hour)
        minutes.append(d.minute)
        seconds.append(float(d.second))
        d += step
    t = ts.utc(years, months, days, hours, minutes, seconds)

    geoc = sat.at(t)
    lat, lon = wgs84.latlon_of(geoc)
    alt_km = wgs84.height_of(geoc).km

    topo = (sat - obs).at(t)
    alt, az, _ = topo.altaz()

    date_list = [(start_jst + i * step).strftime("%Y-%m-%d %H:%M:%S") for i in range(total_rows)]
    unix0 = jst_naive_to_unix_seconds(start_jst)
    unix = (unix0 + np.arange(total_rows, dtype=np.int64) * int(step.total_seconds())).astype(np.int64)

    df = pd.DataFrame(
        {
            "date": date_list,
            "UNIX": unix,
            "Lat": lat.degrees.astype(np.float64),
            "Lon": lon.degrees.astype(np.float64),
            "Alt": np.asarray(alt_km, dtype=np.float64),
            "AZ": az.degrees.astype(np.float64),
            "EL": alt.degrees.astype(np.float64),
        }
    )
    df.insert(0, "No", np.arange(1, len(df) + 1, dtype=np.int64))
    return df


def make_basis(n_rows: int) -> Tuple[np.ndarray, List[str], np.ndarray, np.ndarray]:
    no = np.arange(1, n_rows + 1, dtype=np.int64)
    t_min = (no - 1).astype(np.float64)
    t_day = t_min / MINUTES_PER_DAY
    t_norm = t_day / max(1e-9, (n_rows - 1) / MINUTES_PER_DAY)

    feats: List[np.ndarray] = []
    names: List[str] = []

    feats.append(np.ones_like(t_norm))
    names.append("bias")
    feats.append(t_norm)
    names.append("t_norm")
    feats.append(t_norm * t_norm)
    names.append("t_norm2")

    # GEO-relevant harmonics
    for k in (1, 2):
        ph = 2.0 * math.pi * k * t_day
        feats.append(np.sin(ph))
        feats.append(np.cos(ph))
        names.append(f"day_sin_{k}")
        names.append(f"day_cos_{k}")

    # Slower drifts
    for p in (7.0, 14.0, 30.0):
        ph = 2.0 * math.pi * (t_day / p)
        feats.append(np.sin(ph))
        feats.append(np.cos(ph))
        names.append(f"p{int(p)}d_sin")
        names.append(f"p{int(p)}d_cos")

    B = np.stack(feats, axis=1).astype(np.float64)
    return B, names, no, t_day


def fit_basis_coeff(
    series: np.ndarray,
    valid_mask: np.ndarray,
    basis: np.ndarray,
    t_day: np.ndarray,
    is_angle: bool,
    time_weight_power: float,
) -> np.ndarray:
    y = np.asarray(series, dtype=np.float64).reshape(-1)
    if len(y) != basis.shape[0]:
        raise ValueError("series length mismatch in fit_basis_coeff")
    v = np.asarray(valid_mask, dtype=bool).reshape(-1)
    if np.sum(v) < 30:
        return np.zeros((basis.shape[1],), dtype=np.float64)

    if is_angle:
        y_use = fit_angle_fill(y, v)
        y_use = np.rad2deg(np.unwrap(np.deg2rad(y_use)))
    else:
        y_use = fit_linear_fill(y, v)

    w = np.zeros_like(y_use, dtype=np.float64)
    w[v] = 1.0 / np.power(1.0 + t_day[v], float(max(0.0, time_weight_power)))
    sw = np.sqrt(np.maximum(w, 0.0))
    A = basis * sw.reshape(-1, 1)
    b = y_use * sw
    ata = A.T @ A + 1e-6 * np.eye(A.shape[1], dtype=np.float64)
    atb = A.T @ b
    return np.linalg.solve(ata, atb)


def reconstruct_from_coeff(coeff: np.ndarray, basis: np.ndarray, is_angle: bool) -> np.ndarray:
    y = basis @ np.asarray(coeff, dtype=np.float64).reshape(-1)
    if is_angle:
        return wrap180(y)
    return y


def ridge_fit_multi(X: np.ndarray, Y: np.ndarray, l2: float) -> np.ndarray:
    # Adds bias as last row in W.
    X1 = np.concatenate([X, np.ones((len(X), 1), dtype=np.float64)], axis=1)
    p = X1.shape[1]
    ata = X1.T @ X1
    reg = np.zeros((p, p), dtype=np.float64)
    reg[: p - 1, : p - 1] = float(l2) * np.eye(p - 1, dtype=np.float64)
    W = np.linalg.solve(ata + reg, X1.T @ Y)
    return W


def ridge_predict_multi(X: np.ndarray, W: np.ndarray) -> np.ndarray:
    X1 = np.concatenate([X, np.ones((len(X), 1), dtype=np.float64)], axis=1)
    return X1 @ W


def align_member_to_anchor(member_df: pd.DataFrame, anchor_unix: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    m = member_df.set_index("UNIX")[["AZ", "EL"]]
    x = m.reindex(anchor_unix)
    az = pd.to_numeric(x["AZ"], errors="coerce").to_numpy(dtype=np.float64)
    el = pd.to_numeric(x["EL"], errors="coerce").to_numpy(dtype=np.float64)
    valid = np.isfinite(az) & np.isfinite(el)
    az_fill = fit_angle_fill(az, valid)
    el_fill = fit_linear_fill(el, valid)
    return az_fill, el_fill, valid


def fuse_members(
    anchor_az: np.ndarray,
    anchor_el: np.ndarray,
    member_az: np.ndarray,
    member_el: np.ndarray,
    member_valid: np.ndarray,
    member_weights: np.ndarray,
    pseudo_hours: float,
    pseudo_decay_hours: float,
    step_minutes: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    # member_* shape=(K,T)
    K, T = member_az.shape
    W = np.asarray(member_weights, dtype=np.float64).reshape(K, 1) * np.asarray(member_valid, dtype=np.float64)
    sumW = np.sum(W, axis=0)
    sumW_safe = np.where(sumW > 1e-12, sumW, 1.0)

    # AZ circular mean
    rad = np.deg2rad(member_az)
    S = np.sum(W * np.sin(rad), axis=0)
    C = np.sum(W * np.cos(rad), axis=0)
    fused_az = wrap180(np.rad2deg(np.arctan2(S, C)))
    R = np.sqrt(S * S + C * C) / sumW_safe
    R = np.clip(R, 1e-12, 1.0)
    std_az = np.rad2deg(np.sqrt(np.maximum(0.0, -2.0 * np.log(R))))

    # EL weighted mean/std
    fused_el = np.sum(W * member_el, axis=0) / sumW_safe
    var_el = np.sum(W * (member_el - fused_el.reshape(1, -1)) ** 2, axis=0) / sumW_safe
    std_el = np.sqrt(np.maximum(0.0, var_el))

    bad = sumW <= 1e-12
    if np.any(bad):
        fused_az[bad] = anchor_az[bad]
        fused_el[bad] = anchor_el[bad]
        std_az[bad] = 0.0
        std_el[bad] = 0.0

    # Pseudo-observation anchoring by latest TLE baseline
    obs_w = np.zeros((T,), dtype=np.float64)
    ph = float(max(0.0, pseudo_hours))
    dh = float(max(1e-6, pseudo_decay_hours))
    if ph > 0.0:
        t_h = np.arange(T, dtype=np.float64) * float(step_minutes) / 60.0
        m = t_h <= ph + 1e-9
        obs_w[m] = np.exp(-t_h[m] / dh)
        obs_w = np.clip(obs_w, 0.0, 1.0)
        fused_az = circular_blend_deg(fused_az, anchor_az, obs_w)
        fused_el = (1.0 - obs_w) * fused_el + obs_w * anchor_el

    return fused_az, fused_el, std_az, std_el, sumW, obs_w


def build_time_gate(
    n_rows: int,
    step_minutes: int,
    decay_hours: float,
    decay_power: float,
) -> np.ndarray:
    if decay_hours <= 0:
        return np.ones((n_rows,), dtype=np.float64)
    t_h = np.arange(n_rows, dtype=np.float64) * float(step_minutes) / 60.0
    gate = np.exp(-np.power(np.maximum(0.0, t_h / max(1e-6, float(decay_hours))), float(max(0.1, decay_power))))
    return np.clip(gate, 0.0, 1.0)


def dynamic_spread_clip(
    pred: np.ndarray,
    std: np.ndarray,
    is_angle: bool,
    spread_mult: float,
    spread_min_deg: float,
    spread_max_deg: float,
) -> Tuple[np.ndarray, np.ndarray]:
    p = np.asarray(pred, dtype=np.float64).copy()
    s = np.asarray(std, dtype=np.float64)
    cap = float(spread_max_deg) if spread_max_deg > 0 else 1e9
    dyn = np.clip(float(spread_mult) * (s + 1e-6), float(max(0.0, spread_min_deg)), cap)
    p = np.clip(p, -dyn, dyn)
    if is_angle:
        p = wrap180(p)
    return p, dyn


def choose_base_mode(
    anchor_az: np.ndarray,
    anchor_el: np.ndarray,
    fused_az: np.ndarray,
    fused_el: np.ndarray,
    std_az: np.ndarray,
    std_el: np.ndarray,
    auto_base_disp_th: float,
) -> Tuple[str, np.ndarray, np.ndarray]:
    disp = 0.5 * float(np.median(np.asarray(std_az, dtype=np.float64))) + 0.5 * float(
        np.median(np.asarray(std_el, dtype=np.float64))
    )
    if disp >= float(max(0.0, auto_base_disp_th)):
        return "fused", fused_az.copy(), fused_el.copy()
    return "anchor", anchor_az.copy(), anchor_el.copy()


def build_anchor_feature(
    anchor_tle_feat: Optional[np.ndarray],
    member_tle_feats: List[np.ndarray],
    member_age_hours: List[float],
    anchor_az: np.ndarray,
    anchor_el: np.ndarray,
    std_az: np.ndarray,
    std_el: np.ndarray,
    step_minutes: int,
) -> Tuple[np.ndarray, List[str]]:
    names: List[str] = []
    feats: List[float] = []

    cur = (
        np.asarray(anchor_tle_feat, dtype=np.float64).reshape(-1)
        if anchor_tle_feat is not None
        else np.zeros((19,), dtype=np.float64)
    )
    if len(cur) != 19:
        cur = np.zeros((19,), dtype=np.float64)
    for i in range(len(cur)):
        names.append(f"tle_cur_{i}")
        feats.append(float(cur[i]))

    if len(member_tle_feats) > 0:
        M = np.stack(member_tle_feats, axis=0).astype(np.float64)
        m_mean = np.mean(M, axis=0)
        m_std = np.std(M, axis=0)
    else:
        m_mean = np.zeros((19,), dtype=np.float64)
        m_std = np.zeros((19,), dtype=np.float64)
    d_cur_mean = cur - m_mean
    for i in range(19):
        names.append(f"tle_ctx_mean_{i}")
        feats.append(float(m_mean[i]))
    for i in range(19):
        names.append(f"tle_ctx_std_{i}")
        feats.append(float(m_std[i]))
    for i in range(19):
        names.append(f"tle_cur_minus_ctxmean_{i}")
        feats.append(float(d_cur_mean[i]))

    if len(member_tle_feats) >= 2:
        prev = np.asarray(member_tle_feats[-2], dtype=np.float64).reshape(-1)
    else:
        prev = cur.copy()
    d_prev = cur - prev
    for i in range(19):
        names.append(f"tle_cur_minus_prev_{i}")
        feats.append(float(d_prev[i]))

    ah = np.asarray(member_age_hours, dtype=np.float64)
    if len(ah) == 0:
        ah = np.array([0.0], dtype=np.float64)
    age_stats = [
        float(len(member_age_hours)),
        float(np.mean(ah)),
        float(np.std(ah)),
        float(np.max(ah)),
    ]
    for n, v in zip(
        ["ctx_count", "ctx_age_mean_h", "ctx_age_std_h", "ctx_age_max_h"],
        age_stats,
    ):
        names.append(n)
        feats.append(v)

    # Anchor baseline dynamics
    n = len(anchor_az)
    i10 = min(n - 1, max(1, int(round(10 / max(1, step_minutes)))))
    i60 = min(n - 1, max(1, int(round(60 / max(1, step_minutes)))))
    i6h = min(n - 1, max(1, int(round(6 * 60 / max(1, step_minutes)))))
    i12h = min(n - 1, max(1, int(round(12 * 60 / max(1, step_minutes)))))

    az_rate_10 = float(angle_diff_deg(anchor_az[i10], anchor_az[0]) / max(1, i10 * step_minutes))
    az_rate_60 = float(angle_diff_deg(anchor_az[i60], anchor_az[0]) / max(1, i60 * step_minutes))
    el_rate_10 = float((anchor_el[i10] - anchor_el[0]) / max(1, i10 * step_minutes))
    el_rate_60 = float((anchor_el[i60] - anchor_el[0]) / max(1, i60 * step_minutes))

    az_u = np.rad2deg(np.unwrap(np.deg2rad(anchor_az[: i12h + 1])))
    az_range_12h = float(np.max(az_u) - np.min(az_u))
    el_range_12h = float(np.max(anchor_el[: i12h + 1]) - np.min(anchor_el[: i12h + 1]))

    dyn = [
        float(anchor_az[0]),
        float(anchor_el[0]),
        az_rate_10,
        az_rate_60,
        el_rate_10,
        el_rate_60,
        az_range_12h,
        el_range_12h,
        float(anchor_az[i6h]),
        float(anchor_el[i6h]),
    ]
    dyn_names = [
        "anchor_az0",
        "anchor_el0",
        "anchor_az_rate_10m",
        "anchor_az_rate_60m",
        "anchor_el_rate_10m",
        "anchor_el_rate_60m",
        "anchor_az_range_12h",
        "anchor_el_range_12h",
        "anchor_az_6h",
        "anchor_el_6h",
    ]
    names.extend(dyn_names)
    feats.extend(dyn)

    # Member disagreement summaries (for gating behavior)
    s_az = np.asarray(std_az, dtype=np.float64)
    s_el = np.asarray(std_el, dtype=np.float64)
    j = max(1, i12h)
    stats = [
        float(np.median(s_az)),
        float(np.percentile(s_az, 90)),
        float(np.median(s_az[:j])),
        float(np.percentile(s_az[:j], 90)),
        float(np.median(s_el)),
        float(np.percentile(s_el, 90)),
        float(np.median(s_el[:j])),
        float(np.percentile(s_el[:j], 90)),
    ]
    stat_names = [
        "std_az_median_all",
        "std_az_p90_all",
        "std_az_median_12h",
        "std_az_p90_12h",
        "std_el_median_all",
        "std_el_p90_all",
        "std_el_median_12h",
        "std_el_p90_12h",
    ]
    names.extend(stat_names)
    feats.extend(stats)

    x = np.asarray(feats, dtype=np.float64)
    return x, names


def load_trimmed_csv(path: Path, days: int, step_minutes: int, sample_every: int) -> pd.DataFrame:
    df = load_orbit_csv(path, require_targets=True)
    df = trim_horizon_and_stride(
        df,
        days_horizon=int(days),
        step_minutes=int(step_minutes),
        sample_every=int(sample_every),
    )
    if "No" not in df.columns:
        df.insert(0, "No", np.arange(1, len(df) + 1, dtype=np.int64))
    return df


def select_members(
    records: List[StemRecord],
    anchor_idx: int,
    lookback_days: float,
    max_members: int,
) -> Tuple[List[StemRecord], List[float]]:
    anchor = records[anchor_idx]
    out: List[StemRecord] = []
    age_h: List[float] = []
    lb_h = float(max(0.0, lookback_days) * 24.0)
    for j in range(anchor_idx, -1, -1):
        r = records[j]
        ah = float((anchor.ts - r.ts).total_seconds() / 3600.0)
        if ah < -1e-9:
            continue
        if ah <= lb_h + 1e-9:
            out.append(r)
            age_h.append(ah)
        if len(out) >= int(max(1, max_members)):
            break
    out = list(reversed(out))
    age_h = list(reversed(age_h))
    return out, age_h


def calibrate_alpha(
    residual_true: List[np.ndarray],
    residual_pred: List[np.ndarray],
    valid_masks: List[np.ndarray],
    alpha_grid: Sequence[float],
    is_angle: bool,
    min_improved_ratio: float,
) -> Tuple[float, float, float, float]:
    best_alpha = 0.0
    best_rmse = math.inf
    best_ratio = 0.0
    base_rmse = 0.0
    if len(residual_true) == 0:
        return 0.0, 0.0, 0.0, 0.0

    for a in alpha_grid:
        a = float(a)
        rmses: List[float] = []
        base: List[float] = []
        improved = 0
        for yt, yp, vm in zip(residual_true, residual_pred, valid_masks):
            m = np.asarray(vm, dtype=bool)
            if np.sum(m) < 10:
                continue
            yt_m = np.asarray(yt, dtype=np.float64)[m]
            yp_m = np.asarray(yp, dtype=np.float64)[m]
            if is_angle:
                err = wrap180(yt_m - a * yp_m)
            else:
                err = yt_m - a * yp_m
            rb = float(np.sqrt(np.mean(yt_m * yt_m)))
            rc = float(np.sqrt(np.mean(err * err)))
            base.append(rb)
            rmses.append(rc)
            if rc < rb:
                improved += 1
        if len(rmses) == 0:
            continue
        rm = float(np.mean(rmses))
        ratio = float(improved / len(rmses))
        if ratio >= float(min_improved_ratio):
            if (rm < best_rmse - 1e-12) or (abs(rm - best_rmse) <= 1e-12 and a < best_alpha):
                best_rmse = rm
                best_alpha = a
                best_ratio = ratio
                base_rmse = float(np.mean(base))

    if not np.isfinite(best_rmse):
        # conservative fallback
        mbase: List[float] = []
        for yt, vm in zip(residual_true, valid_masks):
            m = np.asarray(vm, dtype=bool)
            if np.sum(m) < 10:
                continue
            y = np.asarray(yt, dtype=np.float64)[m]
            mbase.append(float(np.sqrt(np.mean(y * y))))
        base_rmse = float(np.mean(mbase)) if len(mbase) else 0.0
        return 0.0, base_rmse, base_rmse, 0.0

    return float(best_alpha), float(base_rmse), float(best_rmse), float(best_ratio)


def collect_records_from_tle_and_csv(tle_dir: Path, csv_dir: Path) -> List[StemRecord]:
    tle_map = {p.stem: p for p in sorted(tle_dir.glob("*.txt")) if p.is_file()}
    csv_map = {p.stem: p for p in sorted(csv_dir.glob("*.csv")) if p.is_file()}
    stems = sorted(set(tle_map.keys()) & set(csv_map.keys()))
    out: List[StemRecord] = []
    for s in stems:
        t = parse_stem_datetime(s)
        if t is None:
            continue
        out.append(StemRecord(stem=s, ts=t, tle_path=tle_map[s], csv_path=csv_map[s]))
    out.sort(key=lambda r: r.ts)
    return out


def collect_predict_records(
    pred_tle_dir: Path,
    baseline_csv_dir: Optional[Path],
    reference_tle_dir: Optional[Path],
) -> List[StemRecord]:
    bag: Dict[str, StemRecord] = {}

    def ensure(stem: str, ts: dt.datetime) -> StemRecord:
        if stem not in bag:
            bag[stem] = StemRecord(stem=stem, ts=ts, tle_path=None, csv_path=None)
        return bag[stem]

    for p in sorted(pred_tle_dir.glob("*.txt")):
        if not p.is_file():
            continue
        ts = parse_stem_datetime(p.stem)
        if ts is None:
            continue
        rec = ensure(p.stem, ts)
        rec.tle_path = p

    for p in sorted(pred_tle_dir.glob("*.csv")):
        if not p.is_file():
            continue
        ts = parse_stem_datetime(p.stem)
        if ts is None:
            continue
        rec = ensure(p.stem, ts)
        rec.csv_path = p

    if baseline_csv_dir is not None and baseline_csv_dir.exists():
        for stem, rec in list(bag.items()):
            if rec.csv_path is None:
                p = baseline_csv_dir / f"{stem}.csv"
                if p.exists():
                    rec.csv_path = p

    if reference_tle_dir is not None and reference_tle_dir.exists():
        for stem, rec in list(bag.items()):
            if rec.tle_path is None:
                p = reference_tle_dir / f"{stem}.txt"
                if p.exists():
                    rec.tle_path = p

    out = [r for r in bag.values() if (r.tle_path is not None or r.csv_path is not None)]
    out.sort(key=lambda r: r.ts)
    return out


def build_samples(
    records: List[StemRecord],
    truth_idx: pd.DataFrame,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    lookback_days: float,
    max_members: int,
    half_life_hours: float,
    pseudo_hours: float,
    pseudo_decay_hours: float,
    time_weight_power: float,
    min_valid_rows: int,
) -> Tuple[List[TrainSample], List[str]]:
    if len(records) == 0:
        return [], []

    rows = int(days_horizon * 24 * 60 // max(1, int(step_minutes)) // max(1, int(sample_every)))
    if rows <= 0:
        raise ValueError("rows <= 0")
    basis, _basis_names, _no, t_day = make_basis(rows)

    # caches
    csv_cache: Dict[str, pd.DataFrame] = {}
    tle_feat_cache: Dict[str, np.ndarray] = {}
    feat_names: List[str] = []
    out: List[TrainSample] = []

    def get_csv(stem: str, path: Path) -> pd.DataFrame:
        if stem in csv_cache:
            return csv_cache[stem]
        df = load_trimmed_csv(path, days=days_horizon, step_minutes=step_minutes, sample_every=sample_every)
        if len(df) != rows:
            # keep strict shape for stable basis regression
            if len(df) > rows:
                df = df.iloc[:rows].copy()
            else:
                last = df.iloc[[-1]].copy()
                pads = []
                cur_no = int(df["No"].iloc[-1]) if len(df) else 0
                cur_unix = int(df["UNIX"].iloc[-1]) if len(df) else 0
                cur_date = str(df["date"].iloc[-1]) if len(df) else ""
                for i in range(rows - len(df)):
                    rr = last.copy()
                    rr.loc[:, "No"] = cur_no + i + 1
                    rr.loc[:, "UNIX"] = cur_unix + (i + 1) * step_minutes * 60
                    rr.loc[:, "date"] = cur_date
                    pads.append(rr)
                if pads:
                    df = pd.concat([df] + pads, ignore_index=True)
        csv_cache[stem] = df
        return df

    for i, rec in enumerate(records):
        if rec.csv_path is None:
            continue
        try:
            anchor_df = get_csv(rec.stem, rec.csv_path)
        except Exception as e:
            log(f"[WARN] skip {rec.stem}: failed loading anchor csv ({e})")
            continue

        anchor_unix = pd.to_numeric(anchor_df["UNIX"], errors="coerce").to_numpy(dtype=np.int64)
        anchor_az = pd.to_numeric(anchor_df["AZ"], errors="coerce").to_numpy(dtype=np.float64)
        anchor_el = pd.to_numeric(anchor_df["EL"], errors="coerce").to_numpy(dtype=np.float64)

        members, age_h = select_members(records, i, lookback_days=lookback_days, max_members=max_members)
        if len(members) == 0:
            continue

        member_az_list: List[np.ndarray] = []
        member_el_list: List[np.ndarray] = []
        member_valid_list: List[np.ndarray] = []
        member_w: List[float] = []
        member_feats: List[np.ndarray] = []

        for mrec, ah in zip(members, age_h):
            if mrec.csv_path is None:
                continue
            try:
                mdf = get_csv(mrec.stem, mrec.csv_path)
            except Exception:
                continue
            maz, mel, mvalid = align_member_to_anchor(mdf, anchor_unix)
            member_az_list.append(maz)
            member_el_list.append(mel)
            member_valid_list.append(mvalid)
            if half_life_hours > 0:
                ww = float(np.exp(-np.log(2.0) * ah / half_life_hours))
            else:
                ww = 1.0
            member_w.append(ww)
            if mrec.tle_path is not None:
                if mrec.stem not in tle_feat_cache:
                    try:
                        t = parse_tle_file(mrec.tle_path)
                        f, _ = tle_feature_vector(t)
                        tle_feat_cache[mrec.stem] = np.asarray(f, dtype=np.float64)
                    except Exception:
                        tle_feat_cache[mrec.stem] = np.zeros((19,), dtype=np.float64)
                member_feats.append(tle_feat_cache[mrec.stem])

        if len(member_az_list) == 0:
            continue

        M_az = np.stack(member_az_list, axis=0).astype(np.float64)
        M_el = np.stack(member_el_list, axis=0).astype(np.float64)
        M_valid = np.stack(member_valid_list, axis=0)
        W = np.asarray(member_w, dtype=np.float64)

        fused_az, fused_el, std_az, std_el, _sumW, _obs_w = fuse_members(
            anchor_az=anchor_az,
            anchor_el=anchor_el,
            member_az=M_az,
            member_el=M_el,
            member_valid=M_valid,
            member_weights=W,
            pseudo_hours=pseudo_hours,
            pseudo_decay_hours=pseudo_decay_hours,
            step_minutes=step_minutes,
        )

        tv = truth_idx.reindex(anchor_unix)
        truth_az = pd.to_numeric(tv["AZ"], errors="coerce").to_numpy(dtype=np.float64)
        truth_el = pd.to_numeric(tv["EL"], errors="coerce").to_numpy(dtype=np.float64)
        valid = np.isfinite(truth_az) & np.isfinite(truth_el)
        if int(np.sum(valid)) < int(min_valid_rows):
            continue

        residual_az = angle_diff_deg(fused_az, truth_az)
        residual_el = fused_el - truth_el

        coef_az = fit_basis_coeff(
            series=residual_az,
            valid_mask=valid,
            basis=basis,
            t_day=t_day,
            is_angle=True,
            time_weight_power=time_weight_power,
        )
        coef_el = fit_basis_coeff(
            series=residual_el,
            valid_mask=valid,
            basis=basis,
            t_day=t_day,
            is_angle=False,
            time_weight_power=time_weight_power,
        )

        anchor_feat = None
        if rec.tle_path is not None:
            if rec.stem not in tle_feat_cache:
                try:
                    t0 = parse_tle_file(rec.tle_path)
                    f0, _ = tle_feature_vector(t0)
                    tle_feat_cache[rec.stem] = np.asarray(f0, dtype=np.float64)
                except Exception:
                    tle_feat_cache[rec.stem] = np.zeros((19,), dtype=np.float64)
            anchor_feat = tle_feat_cache[rec.stem]

        x, fn = build_anchor_feature(
            anchor_tle_feat=anchor_feat,
            member_tle_feats=member_feats,
            member_age_hours=age_h,
            anchor_az=anchor_az,
            anchor_el=anchor_el,
            std_az=std_az,
            std_el=std_el,
            step_minutes=step_minutes,
        )
        if len(feat_names) == 0:
            feat_names = fn
        if len(x) != len(feat_names):
            # strict guard
            continue

        out.append(
            TrainSample(
                stem=rec.stem,
                feat=x,
                coef_az=coef_az,
                coef_el=coef_el,
                residual_az=np.asarray(residual_az, dtype=np.float64),
                residual_el=np.asarray(residual_el, dtype=np.float64),
                valid_mask=np.asarray(valid, dtype=bool),
                std_az_members=np.asarray(std_az, dtype=np.float64),
                std_el_members=np.asarray(std_el, dtype=np.float64),
            )
        )
    return out, feat_names


def evaluate_with_alpha(
    samples: List[TrainSample],
    pred_res_az: List[np.ndarray],
    pred_res_el: List[np.ndarray],
    alpha_az: float,
    alpha_el: float,
) -> Tuple[float, float, float, float]:
    base_az: List[float] = []
    base_el: List[float] = []
    corr_az: List[float] = []
    corr_el: List[float] = []
    for s, pz, pe in zip(samples, pred_res_az, pred_res_el):
        m = s.valid_mask
        if np.sum(m) < 10:
            continue
        rz = s.residual_az[m]
        re = s.residual_el[m]
        ez = wrap180(rz - float(alpha_az) * pz[m])
        ee = re - float(alpha_el) * pe[m]
        base_az.append(float(np.sqrt(np.mean(rz * rz))))
        base_el.append(float(np.sqrt(np.mean(re * re))))
        corr_az.append(float(np.sqrt(np.mean(ez * ez))))
        corr_el.append(float(np.sqrt(np.mean(ee * ee))))
    if len(base_az) == 0:
        return 0.0, 0.0, 0.0, 0.0
    return (
        float(np.mean(base_az)),
        float(np.mean(corr_az)),
        float(np.mean(base_el)),
        float(np.mean(corr_el)),
    )


def train_cmd(args: argparse.Namespace) -> int:
    tle_dir = Path(args.tle_dir)
    pred_dir = Path(args.pred_dir)
    truth_csv = Path(args.truth_csv)
    out_model = Path(args.out_model)

    if not tle_dir.exists():
        raise FileNotFoundError(f"tle-dir not found: {tle_dir}")
    if not pred_dir.exists():
        raise FileNotFoundError(f"pred-dir not found: {pred_dir}")
    if not truth_csv.exists():
        raise FileNotFoundError(f"truth-csv not found: {truth_csv}")

    recs = collect_records_from_tle_and_csv(tle_dir=tle_dir, csv_dir=pred_dir)
    if len(recs) == 0:
        raise RuntimeError("no matching tle/csv records")
    if args.max_files is not None:
        recs = recs[: int(args.max_files)]
    log(f"[INFO] records: {len(recs)}")

    truth_df = load_orbit_csv(truth_csv, require_targets=True)
    truth_idx = truth_df.drop_duplicates(subset=["UNIX"]).set_index("UNIX")[["AZ", "EL"]]

    samples, feat_names = build_samples(
        records=recs,
        truth_idx=truth_idx,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        lookback_days=float(args.lookback_days),
        max_members=int(args.max_members),
        half_life_hours=float(args.half_life_hours),
        pseudo_hours=float(args.pseudo_hours),
        pseudo_decay_hours=float(args.pseudo_decay_hours),
        time_weight_power=float(args.time_weight_power),
        min_valid_rows=int(args.min_valid_rows),
    )
    if len(samples) < 10:
        raise RuntimeError(f"not enough samples after filtering: {len(samples)}")
    log(f"[INFO] usable samples: {len(samples)}")

    stems = [s.stem for s in samples]
    tr_stems, va_stems = split_stems(
        stems=stems,
        val_split=float(args.val_split),
        split_mode=str(args.split_mode),
        seed=int(args.seed),
    )
    tr_set = set(tr_stems)
    va_set = set(va_stems)
    train_samples = [s for s in samples if s.stem in tr_set]
    val_samples = [s for s in samples if s.stem in va_set]
    if len(val_samples) == 0:
        raise RuntimeError("validation set is empty")
    log(f"[INFO] split train/val = {len(train_samples)}/{len(val_samples)}")

    Xtr = np.stack([s.feat for s in train_samples], axis=0).astype(np.float64)
    Xva = np.stack([s.feat for s in val_samples], axis=0).astype(np.float64)
    Ytr_az = np.stack([s.coef_az for s in train_samples], axis=0).astype(np.float64)
    Ytr_el = np.stack([s.coef_el for s in train_samples], axis=0).astype(np.float64)

    x_mean = np.mean(Xtr, axis=0)
    x_std = np.std(Xtr, axis=0)
    x_std = np.where(x_std < 1e-9, 1.0, x_std)
    Xtr_z = (Xtr - x_mean.reshape(1, -1)) / x_std.reshape(1, -1)
    Xva_z = (Xva - x_mean.reshape(1, -1)) / x_std.reshape(1, -1)

    rows = int(args.days_horizon * 24 * 60 // max(1, int(args.step_minutes)) // max(1, int(args.sample_every)))
    basis, basis_names, _no, _t_day = make_basis(rows)
    cap_deg = float(max(0.0, args.cap_deg))
    z_train_norm = np.sqrt(np.mean(Xtr_z * Xtr_z, axis=1))
    z_ref = float(np.percentile(z_train_norm, 80))
    if not np.isfinite(z_ref) or z_ref <= 1e-9:
        z_ref = 1.0
    ood_conf_floor = float(np.clip(args.ood_conf_floor, 0.0, 1.0))
    min_ood_conf_apply = float(np.clip(args.min_ood_conf_apply, 0.0, 1.0))
    time_gate = build_time_gate(
        n_rows=rows,
        step_minutes=int(args.step_minutes),
        decay_hours=float(args.time_decay_hours),
        decay_power=float(args.time_decay_power),
    )
    spread_clip_mult_az = float(max(0.0, args.spread_clip_mult_az))
    spread_clip_mult_el = float(max(0.0, args.spread_clip_mult_el))
    spread_clip_min_deg = float(max(0.0, args.spread_clip_min_deg))
    auto_correct_disp_th = float(max(0.0, args.auto_correct_disp_th))
    auto_max_capped_ratio = float(np.clip(args.auto_max_capped_ratio, 0.0, 1.0))
    auto_shrink_if_capped = float(np.clip(args.auto_shrink_if_capped, 0.0, 1.0))

    l2_grid = parse_float_csv(args.ridge_l2_grid)
    alpha_grid = parse_float_csv(args.alpha_grid)
    if len(l2_grid) == 0:
        l2_grid = [1.0]
    if len(alpha_grid) == 0:
        alpha_grid = [0.0, 0.25, 0.5, 0.75, 1.0]

    best = None
    best_obj = math.inf

    for l2 in l2_grid:
        Waz = ridge_fit_multi(Xtr_z, Ytr_az, l2=float(l2))
        Wel = ridge_fit_multi(Xtr_z, Ytr_el, l2=float(l2))
        Caz = ridge_predict_multi(Xva_z, Waz)
        Cel = ridge_predict_multi(Xva_z, Wel)

        p_az_list: List[np.ndarray] = []
        p_el_list: List[np.ndarray] = []
        for i, s in enumerate(val_samples):
            pz = reconstruct_from_coeff(Caz[i], basis, is_angle=True)
            pe = reconstruct_from_coeff(Cel[i], basis, is_angle=False)

            # OOD confidence shrink
            zn = float(np.sqrt(np.mean(Xva_z[i] * Xva_z[i])))
            conf_raw = float(np.exp(-((zn / z_ref) ** 2)))
            conf = float(max(ood_conf_floor, conf_raw))
            pz = wrap180(conf * pz)
            pe = conf * pe

            # Member-disagreement gate
            if args.disagreement_sigma_az > 0:
                gaz = np.exp(-((s.std_az_members / float(args.disagreement_sigma_az)) ** 2))
                pz = wrap180(pz * gaz)
            if args.disagreement_sigma_el > 0:
                gel = np.exp(-((s.std_el_members / float(args.disagreement_sigma_el)) ** 2))
                pe = pe * gel
            pz, dcap_az = dynamic_spread_clip(
                pred=pz,
                std=s.std_az_members,
                is_angle=True,
                spread_mult=spread_clip_mult_az,
                spread_min_deg=spread_clip_min_deg,
                spread_max_deg=cap_deg,
            )
            pe, dcap_el = dynamic_spread_clip(
                pred=pe,
                std=s.std_el_members,
                is_angle=False,
                spread_mult=spread_clip_mult_el,
                spread_min_deg=spread_clip_min_deg,
                spread_max_deg=cap_deg,
            )
            pz = wrap180(pz * time_gate)
            pe = pe * time_gate

            disp = 0.5 * float(np.median(s.std_az_members)) + 0.5 * float(np.median(s.std_el_members))
            scale = 1.0
            if conf < min_ood_conf_apply:
                scale = 0.0
            if disp < auto_correct_disp_th:
                scale = 0.0
            if np.sum(np.abs(dcap_az) > 1e-12) > 0:
                capped_ratio_az = float(np.mean(np.abs(pz) >= 0.98 * dcap_az))
            else:
                capped_ratio_az = 0.0
            if np.sum(np.abs(dcap_el) > 1e-12) > 0:
                capped_ratio_el = float(np.mean(np.abs(pe) >= 0.98 * dcap_el))
            else:
                capped_ratio_el = 0.0
            if max(capped_ratio_az, capped_ratio_el) > auto_max_capped_ratio:
                scale *= auto_shrink_if_capped
            pz = wrap180(scale * pz)
            pe = scale * pe

            p_az_list.append(pz)
            p_el_list.append(pe)

        a_az, b_az, c_az, r_az = calibrate_alpha(
            residual_true=[s.residual_az for s in val_samples],
            residual_pred=p_az_list,
            valid_masks=[s.valid_mask for s in val_samples],
            alpha_grid=alpha_grid,
            is_angle=True,
            min_improved_ratio=float(args.min_improved_file_ratio),
        )
        a_el, b_el, c_el, r_el = calibrate_alpha(
            residual_true=[s.residual_el for s in val_samples],
            residual_pred=p_el_list,
            valid_masks=[s.valid_mask for s in val_samples],
            alpha_grid=alpha_grid,
            is_angle=False,
            min_improved_ratio=float(args.min_improved_file_ratio),
        )

        _b_az, _c_az, _b_el, _c_el = evaluate_with_alpha(
            samples=val_samples,
            pred_res_az=p_az_list,
            pred_res_el=p_el_list,
            alpha_az=a_az,
            alpha_el=a_el,
        )
        obj = 0.5 * (_c_az + _c_el)

        log(
            f"[SEARCH] l2={l2:g} | "
            f"AZ {b_az:.6g}->{c_az:.6g} (alpha={a_az:.3f}, improve_ratio={r_az:.3f}) | "
            f"EL {b_el:.6g}->{c_el:.6g} (alpha={a_el:.3f}, improve_ratio={r_el:.3f}) | "
            f"AZEL={obj:.6g}"
        )

        if obj < best_obj:
            best_obj = obj
            best = {
                "l2": float(l2),
                "Waz": Waz,
                "Wel": Wel,
                "alpha_az": float(a_az),
                "alpha_el": float(a_el),
                "val_rmse_az_base": float(_b_az),
                "val_rmse_az_corr": float(_c_az),
                "val_rmse_el_base": float(_b_el),
                "val_rmse_el_corr": float(_c_el),
            }

    if best is None:
        raise RuntimeError("model search failed")

    # Refit on all samples with selected l2
    Xall = np.stack([s.feat for s in samples], axis=0).astype(np.float64)
    Yall_az = np.stack([s.coef_az for s in samples], axis=0).astype(np.float64)
    Yall_el = np.stack([s.coef_el for s in samples], axis=0).astype(np.float64)
    Xall_z = (Xall - x_mean.reshape(1, -1)) / x_std.reshape(1, -1)
    Waz_all = ridge_fit_multi(Xall_z, Yall_az, l2=float(best["l2"]))
    Wel_all = ridge_fit_multi(Xall_z, Yall_el, l2=float(best["l2"]))

    coef_template_az = np.mean(Yall_az, axis=0)
    coef_template_el = np.mean(Yall_el, axis=0)

    meta = {
        "created_jst": now_jst_str(),
        "model_type": "geo_multi_tle_basis_residual_v1",
        "days_horizon": int(args.days_horizon),
        "step_minutes": int(args.step_minutes),
        "sample_every": int(args.sample_every),
        "rows": int(rows),
        "lookback_days": float(args.lookback_days),
        "max_members": int(args.max_members),
        "half_life_hours": float(args.half_life_hours),
        "pseudo_hours": float(args.pseudo_hours),
        "pseudo_decay_hours": float(args.pseudo_decay_hours),
        "time_weight_power": float(args.time_weight_power),
        "disagreement_sigma_az": float(args.disagreement_sigma_az),
        "disagreement_sigma_el": float(args.disagreement_sigma_el),
        "ridge_l2_selected": float(best["l2"]),
        "alpha_az": float(best["alpha_az"]),
        "alpha_el": float(best["alpha_el"]),
        "z_ref": float(z_ref),
        "ood_conf_floor": float(ood_conf_floor),
        "cap_deg": float(cap_deg),
        "min_ood_conf_apply": float(min_ood_conf_apply),
        "time_decay_hours": float(args.time_decay_hours),
        "time_decay_power": float(args.time_decay_power),
        "spread_clip_mult_az": float(spread_clip_mult_az),
        "spread_clip_mult_el": float(spread_clip_mult_el),
        "spread_clip_min_deg": float(spread_clip_min_deg),
        "auto_base_disp_th": float(args.auto_base_disp_th),
        "auto_correct_disp_th": float(auto_correct_disp_th),
        "auto_max_capped_ratio": float(auto_max_capped_ratio),
        "auto_shrink_if_capped": float(auto_shrink_if_capped),
        "feature_names": feat_names,
        "basis_names": basis_names,
        "val_rmse_az_base": float(best["val_rmse_az_base"]),
        "val_rmse_az_corr": float(best["val_rmse_az_corr"]),
        "val_rmse_el_base": float(best["val_rmse_el_base"]),
        "val_rmse_el_corr": float(best["val_rmse_el_corr"]),
        "n_samples": int(len(samples)),
        "n_train": int(len(train_samples)),
        "n_val": int(len(val_samples)),
    }

    ensure_dir(out_model)
    meta_path = out_model / "meta.json"
    bank_path = out_model / "bank.npz"
    summary_path = out_model / "train_summary.json"
    if (meta_path.exists() or bank_path.exists() or summary_path.exists()) and not args.overwrite:
        raise FileExistsError(f"model exists: {out_model} (use --overwrite)")
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    np.savez_compressed(
        bank_path,
        x_mean=x_mean.astype(np.float64),
        x_std=x_std.astype(np.float64),
        Waz=Waz_all.astype(np.float64),
        Wel=Wel_all.astype(np.float64),
        coef_template_az=coef_template_az.astype(np.float64),
        coef_template_el=coef_template_el.astype(np.float64),
    )

    summary = {
        "selected_l2": float(best["l2"]),
        "alpha_az": float(best["alpha_az"]),
        "alpha_el": float(best["alpha_el"]),
        "val_rmse_az_base": float(best["val_rmse_az_base"]),
        "val_rmse_az_corr": float(best["val_rmse_az_corr"]),
        "val_rmse_el_base": float(best["val_rmse_el_base"]),
        "val_rmse_el_corr": float(best["val_rmse_el_corr"]),
        "val_rmse_azel_base_mean": float(0.5 * (best["val_rmse_az_base"] + best["val_rmse_el_base"])),
        "val_rmse_azel_corr_mean": float(0.5 * (best["val_rmse_az_corr"] + best["val_rmse_el_corr"])),
    }
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    log(f"[SAVED] model: {out_model}")
    log(
        f"[VAL] AZ {best['val_rmse_az_base']:.6g}->{best['val_rmse_az_corr']:.6g} | "
        f"EL {best['val_rmse_el_base']:.6g}->{best['val_rmse_el_corr']:.6g}"
    )
    return 0


def load_model(model_dir: Path) -> Tuple[Dict, Dict[str, np.ndarray]]:
    meta_path = model_dir / "meta.json"
    bank_path = model_dir / "bank.npz"
    if not meta_path.exists():
        raise FileNotFoundError(f"meta not found: {meta_path}")
    if not bank_path.exists():
        raise FileNotFoundError(f"bank not found: {bank_path}")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    with np.load(bank_path, allow_pickle=False) as z:
        arrays = {k: z[k] for k in z.files}
    return meta, arrays


def predict_cmd(args: argparse.Namespace) -> int:
    model_dir = Path(args.model)
    meta, arrays = load_model(model_dir)

    pred_tle_dir = Path(args.pred_tle_dir)
    if not pred_tle_dir.exists():
        raise FileNotFoundError(f"pred-tle-dir not found: {pred_tle_dir}")
    baseline_csv_dir = Path(args.baseline_csv_dir) if args.baseline_csv_dir else None
    reference_tle_dir = Path(args.reference_tle_dir) if args.reference_tle_dir else None
    records = collect_predict_records(
        pred_tle_dir=pred_tle_dir,
        baseline_csv_dir=baseline_csv_dir,
        reference_tle_dir=reference_tle_dir,
    )
    if len(records) == 0:
        raise RuntimeError(f"no usable records in {pred_tle_dir}")

    anchor_idx = len(records) - 1
    anchor = records[anchor_idx]

    days = int(args.days if args.days is not None else meta["days_horizon"])
    step_minutes = int(args.step_minutes if args.step_minutes is not None else meta["step_minutes"])
    sample_every = int(args.sample_every if args.sample_every is not None else meta.get("sample_every", 1))
    rows = int(days * 24 * 60 // max(1, step_minutes) // max(1, sample_every))
    if rows <= 0:
        raise ValueError("rows <= 0")
    basis, _basis_names, _no, _t_day = make_basis(rows)

    lookback_days = float(args.lookback_days if args.lookback_days is not None else meta["lookback_days"])
    max_members = int(args.max_members if args.max_members is not None else meta["max_members"])
    half_life = float(args.half_life_hours if args.half_life_hours is not None else meta["half_life_hours"])
    pseudo_hours = float(args.pseudo_hours if args.pseudo_hours is not None else meta["pseudo_hours"])
    pseudo_decay = float(
        args.pseudo_decay_hours if args.pseudo_decay_hours is not None else meta["pseudo_decay_hours"]
    )
    sigma_az = float(
        args.disagreement_sigma_az
        if args.disagreement_sigma_az is not None
        else meta.get("disagreement_sigma_az", 0.25)
    )
    sigma_el = float(
        args.disagreement_sigma_el
        if args.disagreement_sigma_el is not None
        else meta.get("disagreement_sigma_el", 0.15)
    )
    alpha_az = float(args.alpha_az if args.alpha_az is not None else meta["alpha_az"])
    alpha_el = float(args.alpha_el if args.alpha_el is not None else meta["alpha_el"])
    cap_deg = float(
        args.cap_deg if args.cap_deg is not None else meta.get("cap_deg", 0.05)
    )
    min_ood_conf_apply = float(
        args.min_ood_conf_apply if args.min_ood_conf_apply is not None else meta.get("min_ood_conf_apply", 0.2)
    )
    time_decay_hours = float(
        args.time_decay_hours if args.time_decay_hours is not None else meta.get("time_decay_hours", 48.0)
    )
    time_decay_power = float(
        args.time_decay_power if args.time_decay_power is not None else meta.get("time_decay_power", 1.5)
    )
    spread_clip_mult_az = float(
        args.spread_clip_mult_az if args.spread_clip_mult_az is not None else meta.get("spread_clip_mult_az", 20.0)
    )
    spread_clip_mult_el = float(
        args.spread_clip_mult_el if args.spread_clip_mult_el is not None else meta.get("spread_clip_mult_el", 20.0)
    )
    spread_clip_min_deg = float(
        args.spread_clip_min_deg if args.spread_clip_min_deg is not None else meta.get("spread_clip_min_deg", 0.001)
    )
    auto_base_disp_th = float(
        args.auto_base_disp_th if args.auto_base_disp_th is not None else meta.get("auto_base_disp_th", 0.002)
    )
    auto_correct_disp_th = float(
        args.auto_correct_disp_th if args.auto_correct_disp_th is not None else meta.get("auto_correct_disp_th", 0.001)
    )
    auto_max_capped_ratio = float(
        args.auto_max_capped_ratio
        if args.auto_max_capped_ratio is not None
        else meta.get("auto_max_capped_ratio", 0.10)
    )
    auto_shrink_if_capped = float(
        args.auto_shrink_if_capped
        if args.auto_shrink_if_capped is not None
        else meta.get("auto_shrink_if_capped", 0.3)
    )

    members, age_h = select_members(records, anchor_idx, lookback_days=lookback_days, max_members=max_members)

    def load_member_df(rec: StemRecord) -> pd.DataFrame:
        if rec.csv_path is not None and rec.csv_path.exists():
            return load_trimmed_csv(rec.csv_path, days=days, step_minutes=step_minutes, sample_every=sample_every)
        if rec.tle_path is None or not rec.tle_path.exists():
            raise FileNotFoundError(f"no baseline csv nor tle for {rec.stem}")
        df = propagate_tle_to_df(
            tle_path=rec.tle_path,
            sat_name=str(args.sat_name),
            observer_lat=float(args.observer_lat),
            observer_lon=float(args.observer_lon),
            days_horizon=days,
            step_minutes=step_minutes,
        )
        return trim_horizon_and_stride(
            df,
            days_horizon=days,
            step_minutes=step_minutes,
            sample_every=sample_every,
        )

    anchor_df = load_member_df(anchor)
    if len(anchor_df) != rows:
        if len(anchor_df) < rows:
            raise RuntimeError(f"anchor baseline rows {len(anchor_df)} < required {rows}")
        anchor_df = anchor_df.iloc[:rows].copy()
    anchor_unix = pd.to_numeric(anchor_df["UNIX"], errors="coerce").to_numpy(dtype=np.int64)
    anchor_az = pd.to_numeric(anchor_df["AZ"], errors="coerce").to_numpy(dtype=np.float64)
    anchor_el = pd.to_numeric(anchor_df["EL"], errors="coerce").to_numpy(dtype=np.float64)

    member_az: List[np.ndarray] = []
    member_el: List[np.ndarray] = []
    member_valid: List[np.ndarray] = []
    member_w: List[float] = []
    member_feats: List[np.ndarray] = []

    for mrec, ah in zip(members, age_h):
        mdf = load_member_df(mrec)
        maz, mel, mvalid = align_member_to_anchor(mdf, anchor_unix)
        member_az.append(maz)
        member_el.append(mel)
        member_valid.append(mvalid)
        if half_life > 0:
            ww = float(np.exp(-np.log(2.0) * ah / half_life))
        else:
            ww = 1.0
        member_w.append(ww)

        feat = None
        tp = mrec.tle_path
        if tp is None and reference_tle_dir is not None:
            cand = reference_tle_dir / f"{mrec.stem}.txt"
            if cand.exists():
                tp = cand
        if tp is not None and tp.exists():
            try:
                tt = parse_tle_file(tp)
                f, _ = tle_feature_vector(tt)
                feat = np.asarray(f, dtype=np.float64)
            except Exception:
                feat = np.zeros((19,), dtype=np.float64)
        if feat is not None:
            member_feats.append(feat)

    if len(member_az) == 0:
        raise RuntimeError("no valid member trajectory")

    M_az = np.stack(member_az, axis=0).astype(np.float64)
    M_el = np.stack(member_el, axis=0).astype(np.float64)
    M_valid = np.stack(member_valid, axis=0)
    W = np.asarray(member_w, dtype=np.float64)

    fused_az, fused_el, std_az, std_el, _sumW, obs_w = fuse_members(
        anchor_az=anchor_az,
        anchor_el=anchor_el,
        member_az=M_az,
        member_el=M_el,
        member_valid=M_valid,
        member_weights=W,
        pseudo_hours=pseudo_hours,
        pseudo_decay_hours=pseudo_decay,
        step_minutes=step_minutes,
    )

    anchor_tle_feat = None
    tp_anchor = anchor.tle_path
    if tp_anchor is None and reference_tle_dir is not None:
        cand = reference_tle_dir / f"{anchor.stem}.txt"
        if cand.exists():
            tp_anchor = cand
    if tp_anchor is not None and tp_anchor.exists():
        try:
            ta = parse_tle_file(tp_anchor)
            fa, _ = tle_feature_vector(ta)
            anchor_tle_feat = np.asarray(fa, dtype=np.float64)
        except Exception:
            anchor_tle_feat = np.zeros((19,), dtype=np.float64)

    x, _fn = build_anchor_feature(
        anchor_tle_feat=anchor_tle_feat,
        member_tle_feats=member_feats,
        member_age_hours=age_h,
        anchor_az=anchor_az,
        anchor_el=anchor_el,
        std_az=std_az,
        std_el=std_el,
        step_minutes=step_minutes,
    )

    x_mean = arrays["x_mean"].astype(np.float64).reshape(-1)
    x_std = arrays["x_std"].astype(np.float64).reshape(-1)
    if len(x) != len(x_mean):
        raise RuntimeError(f"feature length mismatch: got {len(x)} expected {len(x_mean)}")
    xz = (x - x_mean) / x_std
    Xq = xz.reshape(1, -1)

    Waz = arrays["Waz"].astype(np.float64)
    Wel = arrays["Wel"].astype(np.float64)
    Caz = ridge_predict_multi(Xq, Waz).reshape(-1)
    Cel = ridge_predict_multi(Xq, Wel).reshape(-1)

    pred_res_az = reconstruct_from_coeff(Caz, basis, is_angle=True)
    pred_res_el = reconstruct_from_coeff(Cel, basis, is_angle=False)

    # OOD confidence shrink
    z_ref = float(meta.get("z_ref", 1.0))
    ood_conf_floor = float(
        args.ood_conf_floor if args.ood_conf_floor is not None else meta.get("ood_conf_floor", 0.0)
    )
    z_norm = float(np.sqrt(np.mean(xz * xz)))
    conf_raw = float(np.exp(-((z_norm / max(1e-6, z_ref)) ** 2)))
    conf = float(max(ood_conf_floor, conf_raw))
    pred_res_az = wrap180(conf * pred_res_az)
    pred_res_el = conf * pred_res_el

    # Disagreement gate
    if sigma_az > 0:
        gate_az = np.exp(-((std_az / sigma_az) ** 2))
    else:
        gate_az = np.ones_like(std_az, dtype=np.float64)
    if sigma_el > 0:
        gate_el = np.exp(-((std_el / sigma_el) ** 2))
    else:
        gate_el = np.ones_like(std_el, dtype=np.float64)

    pred_res_az = wrap180(pred_res_az * gate_az)
    pred_res_el = pred_res_el * gate_el

    pred_res_az, dyn_cap_az = dynamic_spread_clip(
        pred=pred_res_az,
        std=std_az,
        is_angle=True,
        spread_mult=spread_clip_mult_az,
        spread_min_deg=spread_clip_min_deg,
        spread_max_deg=cap_deg,
    )
    pred_res_el, dyn_cap_el = dynamic_spread_clip(
        pred=pred_res_el,
        std=std_el,
        is_angle=False,
        spread_mult=spread_clip_mult_el,
        spread_min_deg=spread_clip_min_deg,
        spread_max_deg=cap_deg,
    )

    time_gate = build_time_gate(
        n_rows=rows,
        step_minutes=step_minutes,
        decay_hours=time_decay_hours,
        decay_power=time_decay_power,
    )
    pred_res_az = wrap180(pred_res_az * time_gate)
    pred_res_el = pred_res_el * time_gate

    disp = 0.5 * float(np.median(std_az)) + 0.5 * float(np.median(std_el))
    base_mode, base_az, base_el = choose_base_mode(
        anchor_az=anchor_az,
        anchor_el=anchor_el,
        fused_az=fused_az,
        fused_el=fused_el,
        std_az=std_az,
        std_el=std_el,
        auto_base_disp_th=auto_base_disp_th,
    )

    corr_scale = 1.0
    if conf < min_ood_conf_apply:
        corr_scale = 0.0
    if disp < auto_correct_disp_th:
        corr_scale = 0.0
    if np.sum(np.abs(dyn_cap_az) > 1e-12) > 0:
        capped_ratio_az = float(np.mean(np.abs(pred_res_az) >= 0.98 * dyn_cap_az))
    else:
        capped_ratio_az = 0.0
    if np.sum(np.abs(dyn_cap_el) > 1e-12) > 0:
        capped_ratio_el = float(np.mean(np.abs(pred_res_el) >= 0.98 * dyn_cap_el))
    else:
        capped_ratio_el = 0.0
    if max(capped_ratio_az, capped_ratio_el) > auto_max_capped_ratio:
        corr_scale *= auto_shrink_if_capped

    # Correct selected baseline: residual = base - truth -> truth ~= base - residual
    corrected_az = wrap360(base_az - corr_scale * alpha_az * pred_res_az)
    corrected_el = base_el - corr_scale * alpha_el * pred_res_el

    corrected_df = anchor_df.copy()
    corrected_df["AZ"] = corrected_az
    corrected_df["EL"] = corrected_el

    fused_df = anchor_df.copy()
    fused_df["AZ"] = wrap360(fused_az)
    fused_df["EL"] = fused_el

    base_df = anchor_df.copy()
    base_df["AZ"] = wrap360(base_az)
    base_df["EL"] = base_el

    out_corr = Path(args.out_corrected_csv)
    out_pred = Path(args.out_pred_error_csv)
    if out_corr.exists() and not args.overwrite:
        raise FileExistsError(f"exists: {out_corr} (use --overwrite)")
    if out_pred.exists() and not args.overwrite:
        raise FileExistsError(f"exists: {out_pred} (use --overwrite)")
    ensure_dir(out_corr.parent)
    ensure_dir(out_pred.parent)
    corrected_df.to_csv(out_corr, index=False)

    pred_df = anchor_df[["No", "date", "UNIX"]].copy()
    pred_df["fused_AZ"] = wrap360(fused_az)
    pred_df["fused_EL"] = fused_el
    pred_df["anchor_AZ"] = wrap360(anchor_az)
    pred_df["anchor_EL"] = anchor_el
    pred_df["pred_error_AZ"] = pred_res_az
    pred_df["pred_error_EL"] = pred_res_el
    pred_df["dyn_cap_AZ"] = dyn_cap_az
    pred_df["dyn_cap_EL"] = dyn_cap_el
    pred_df["gate_AZ"] = gate_az
    pred_df["gate_EL"] = gate_el
    pred_df["time_gate"] = time_gate
    pred_df["std_AZ_members"] = std_az
    pred_df["std_EL_members"] = std_el
    pred_df["obs_weight"] = obs_w
    pred_df["ood_conf"] = conf
    pred_df["alpha_AZ"] = float(alpha_az)
    pred_df["alpha_EL"] = float(alpha_el)
    pred_df["corr_scale"] = float(corr_scale)
    pred_df["base_mode"] = str(base_mode)
    pred_df["members_used"] = int(len(members))
    pred_df.to_csv(out_pred, index=False)

    log(f"[INFO] anchor stem: {anchor.stem}")
    log("[INFO] members: " + ", ".join([m.stem for m in members]))
    log(f"[INFO] OOD conf: {conf:.6g}")
    log(f"[INFO] base mode: {base_mode} | disp={disp:.6g} | corr_scale={corr_scale:.6g}")
    log(f"[SAVED] corrected: {out_corr}")
    log(f"[SAVED] pred error: {out_pred}")

    if args.truth_csv:
        truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True)
        # baseline(latest single) -> corrected
        met_bc, merged_bc = compute_metrics(truth_df=truth_df, baseline_df=anchor_df, corrected_df=corrected_df)
        # baseline(latest single) -> fused
        met_bf, _ = compute_metrics(truth_df=truth_df, baseline_df=anchor_df, corrected_df=fused_df)
        # baseline(latest single) -> selected_base
        met_bb, _ = compute_metrics(truth_df=truth_df, baseline_df=anchor_df, corrected_df=base_df)

        b = met_bc[met_bc["kind"] == "baseline"].iloc[0].copy()
        c = met_bc[met_bc["kind"] == "corrected"].iloc[0].copy()
        f = met_bf[met_bf["kind"] == "corrected"].iloc[0].copy()
        bs = met_bb[met_bb["kind"] == "corrected"].iloc[0].copy()
        f["kind"] = "fused"
        bs["kind"] = "selected_base"
        c["kind"] = "corrected"
        out_metrics = pd.DataFrame([b, f, bs, c])

        mpath = Path(args.out_metrics_csv) if args.out_metrics_csv else (out_corr.parent / f"{out_corr.stem}_metrics.csv")
        if mpath.exists() and not args.overwrite:
            raise FileExistsError(f"exists: {mpath} (use --overwrite)")
        ensure_dir(mpath.parent)
        out_metrics.to_csv(mpath, index=False)

        log("[METRIC] RMSE AZ/EL (baseline -> fused -> corrected)")
        log(
            f"  AZ: {float(b['AZ_RMSE']):.6g} -> {float(f['AZ_RMSE']):.6g} -> {float(c['AZ_RMSE']):.6g}"
        )
        log(
            f"  EL: {float(b['EL_RMSE']):.6g} -> {float(f['EL_RMSE']):.6g} -> {float(c['EL_RMSE']):.6g}"
        )
        log(f"  GLOBAL RMSE: {float(b['global_RMSE']):.6g} -> {float(f['global_RMSE']):.6g} -> {float(c['global_RMSE']):.6g}")
        log(f"[SAVED] metrics: {mpath}")

        if not args.no_plot:
            plot_dir = Path(args.plot_dir) if args.plot_dir else (out_corr.parent / "plots")
            plot_baseline_vs_corrected(
                stem=out_corr.stem,
                baseline_df=anchor_df,
                corrected_df=corrected_df,
                out_dir=plot_dir,
                sample_every=int(args.plot_sample_every),
            )
            plot_truth_baseline_corrected(
                stem=out_corr.stem,
                merged_df=merged_bc,
                out_dir=plot_dir,
                sample_every=int(args.plot_sample_every),
            )
            plot_metric_summary(stem=out_corr.stem, metrics_df=met_bc, out_dir=plot_dir)
            log(f"[SAVED] plots: {plot_dir}")
    return 0


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="GEO multi-TLE fusion + low-rank AZ/EL residual model"
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train", help="Train model with 2023 data")
    t.add_argument("--tle-dir", default="23467_2023")
    t.add_argument("--pred-dir", default="23467_2023_csv")
    t.add_argument("--truth-csv", default="2023_calc_az_el.csv")
    t.add_argument("--out-model", default="orbit_geo_multitle_los_model_v1")
    t.add_argument("--days-horizon", type=int, default=30)
    t.add_argument("--step-minutes", type=int, default=1)
    t.add_argument("--sample-every", type=int, default=1)
    t.add_argument("--lookback-days", type=float, default=3.0)
    t.add_argument("--max-members", type=int, default=6)
    t.add_argument("--half-life-hours", type=float, default=24.0)
    t.add_argument("--pseudo-hours", type=float, default=12.0)
    t.add_argument("--pseudo-decay-hours", type=float, default=6.0)
    t.add_argument("--time-weight-power", type=float, default=1.0)
    t.add_argument("--min-valid-rows", type=int, default=10080, help="Minimum truth-overlap rows per sample")
    t.add_argument("--val-split", type=float, default=0.2)
    t.add_argument("--split-mode", choices=["time", "hash"], default="time")
    t.add_argument("--seed", type=int, default=42)
    t.add_argument("--ridge-l2-grid", type=str, default="0.01,0.1,1,3,10,30,100")
    t.add_argument("--alpha-grid", type=str, default="0,0.05,0.1,0.2,0.3,0.4,0.5,0.7,1.0")
    t.add_argument("--min-improved-file-ratio", type=float, default=0.55)
    t.add_argument("--disagreement-sigma-az", type=float, default=0.25)
    t.add_argument("--disagreement-sigma-el", type=float, default=0.15)
    t.add_argument("--ood-conf-floor", type=float, default=0.0,
                   help="Minimum OOD confidence multiplier (0..1)")
    t.add_argument("--min-ood-conf-apply", type=float, default=0.20,
                   help="Disable correction when OOD confidence is below this value")
    t.add_argument("--time-decay-hours", type=float, default=48.0,
                   help="Residual correction decay horizon in hours (<=0 disables)")
    t.add_argument("--time-decay-power", type=float, default=1.5,
                   help="Decay exponent for correction time gate")
    t.add_argument("--spread-clip-mult-az", type=float, default=20.0,
                   help="Dynamic clip multiplier vs member AZ spread")
    t.add_argument("--spread-clip-mult-el", type=float, default=20.0,
                   help="Dynamic clip multiplier vs member EL spread")
    t.add_argument("--spread-clip-min-deg", type=float, default=0.001,
                   help="Minimum dynamic clip (deg)")
    t.add_argument("--auto-base-disp-th", type=float, default=0.002,
                   help="If member dispersion is below this, use anchor as base instead of fused")
    t.add_argument("--auto-correct-disp-th", type=float, default=0.001,
                   help="If member dispersion is below this, disable correction")
    t.add_argument("--auto-max-capped-ratio", type=float, default=0.10,
                   help="If capped ratio exceeds this, correction is shrunk")
    t.add_argument("--auto-shrink-if-capped", type=float, default=0.30,
                   help="Scale factor when capped ratio is too high")
    t.add_argument("--cap-deg", type=float, default=0.05,
                   help="Absolute cap for predicted AZ/EL residual (deg)")
    t.add_argument("--max-files", type=int, default=None)
    t.add_argument("--overwrite", action="store_true")

    pr = sub.add_parser("predict", help="Predict with multiple TLEs in pred_tle dir")
    pr.add_argument("--model", required=True)
    pr.add_argument("--pred-tle-dir", default="pred_tle")
    pr.add_argument("--baseline-csv-dir", default=None,
                    help="Optional baseline CSV directory (used when pred_tle has txt only)")
    pr.add_argument("--reference-tle-dir", default=None,
                    help="Optional fallback TLE directory (used when pred_tle has csv only)")
    pr.add_argument("--sat-name", default="23467")
    pr.add_argument("--observer-lat", type=float, default=36.3022)
    pr.add_argument("--observer-lon", type=float, default=137.9031)
    pr.add_argument("--days", type=int, default=None)
    pr.add_argument("--step-minutes", type=int, default=None)
    pr.add_argument("--sample-every", type=int, default=1)
    pr.add_argument("--lookback-days", type=float, default=None)
    pr.add_argument("--max-members", type=int, default=None)
    pr.add_argument("--half-life-hours", type=float, default=None)
    pr.add_argument("--pseudo-hours", type=float, default=None)
    pr.add_argument("--pseudo-decay-hours", type=float, default=None)
    pr.add_argument("--disagreement-sigma-az", type=float, default=None)
    pr.add_argument("--disagreement-sigma-el", type=float, default=None)
    pr.add_argument("--ood-conf-floor", type=float, default=None)
    pr.add_argument("--min-ood-conf-apply", type=float, default=None)
    pr.add_argument("--time-decay-hours", type=float, default=None)
    pr.add_argument("--time-decay-power", type=float, default=None)
    pr.add_argument("--spread-clip-mult-az", type=float, default=None)
    pr.add_argument("--spread-clip-mult-el", type=float, default=None)
    pr.add_argument("--spread-clip-min-deg", type=float, default=None)
    pr.add_argument("--auto-base-disp-th", type=float, default=None)
    pr.add_argument("--auto-correct-disp-th", type=float, default=None)
    pr.add_argument("--auto-max-capped-ratio", type=float, default=None)
    pr.add_argument("--auto-shrink-if-capped", type=float, default=None)
    pr.add_argument("--cap-deg", type=float, default=None)
    pr.add_argument("--alpha-az", type=float, default=None)
    pr.add_argument("--alpha-el", type=float, default=None)
    pr.add_argument("--out-corrected-csv", required=True)
    pr.add_argument("--out-pred-error-csv", required=True)
    pr.add_argument("--truth-csv", default=None)
    pr.add_argument("--out-metrics-csv", default=None)
    pr.add_argument("--plot-dir", default=None)
    pr.add_argument("--plot-sample-every", type=int, default=5)
    pr.add_argument("--no-plot", action="store_true")
    pr.add_argument("--overwrite", action="store_true")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = make_parser().parse_args(argv)
    if args.cmd == "train":
        return train_cmd(args)
    if args.cmd == "predict":
        return predict_cmd(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
