#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""calc_orbit_error_vs_true_2023.py

23467_2023_csv/ 以下にある各CSV（date, UNIX, Lat, Lon, Alt, AZ, EL）について、
2023_calc_az_el.csv（真値）と **UNIXが完全一致する行だけ** を比較し、
誤差CSV（date, UNIX, Lat, Lon, Alt, AZ, EL = pred-true）を
23467_2023_error/ に「入力CSVと同名」で保存します。

【誤差定義】
  error = (predicted) - (true)

【角度の扱い】
Lon/AZ は 0/360 度の折り返しを考慮し、誤差は [-180, +180) に正規化した最短差分です。

使い方例:
  python calc_orbit_error_vs_true_2023.py \
      --pred-dir 23467_2023_csv \
      --true-csv 2023_calc_az_el.csv \
      --out-dir  23467_2023_error

依存:
  pip install pandas numpy
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd


REQUIRED_COLS = ["date", "UNIX", "Lat", "Lon", "Alt", "AZ", "EL"]


def _norm180_deg(x: np.ndarray) -> np.ndarray:
    """Normalize degrees to [-180, 180)."""
    return (x + 180.0) % 360.0 - 180.0


def _angle_diff_deg(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Shortest signed angular difference a-b in degrees, normalized to [-180, 180)."""
    return _norm180_deg(a - b)


def _read_csv_strict(path: Path) -> pd.DataFrame:
    """Read csv and validate required columns."""
    dtype = {
        "date": "string",
        "UNIX": "float64",
        "Lat": "float64",
        "Lon": "float64",
        "Alt": "float64",
        "AZ": "float64",
        "EL": "float64",
    }

    df = pd.read_csv(path, dtype=dtype)
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise ValueError(
            f"CSVに必要列がありません: {path} missing={missing}, cols={list(df.columns)}"
        )

    # UNIXは秒(整数)として扱う（.0 や浮動小数の誤差吸収のため）
    df["UNIX"] = df["UNIX"].round().astype("int64")
    return df


def _load_truth(true_csv: Path) -> pd.DataFrame:
    """真値CSVを読み込み、UNIXでソートして重複を除去したDataFrameを返す。"""
    df_true = _read_csv_strict(true_csv)

    # UNIXでソート + 重複排除（同じUNIXがある場合は最後を採用）
    df_true = (
        df_true.sort_values("UNIX")
        .drop_duplicates(subset=["UNIX"], keep="last")
        .reset_index(drop=True)
    )

    # UNIX単調増加チェック
    u = df_true["UNIX"].to_numpy(dtype=np.int64)
    if len(u) >= 2 and np.any(np.diff(u) <= 0):
        raise ValueError(
            "真値UNIXが単調増加ではありません（重複除去後でも）: true_csv=%s" % true_csv
        )

    return df_true


def _compute_errors_exact_match(df_pred: pd.DataFrame, df_true: pd.DataFrame) -> pd.DataFrame:
    """UNIXが完全一致する行だけで誤差(=pred-true)を計算する。"""
    merged = df_pred.merge(df_true, on="UNIX", how="inner", suffixes=("_pred", "_true"))

    if merged.empty:
        # 空でもヘッダーは出す（ユーザが気づけるように）
        return df_pred.iloc[0:0][REQUIRED_COLS].copy()

    out = pd.DataFrame(
        {
            "date": merged["date_pred"].astype("string"),
            "UNIX": merged["UNIX"].astype("int64"),
        }
    )

    # 直線差分
    for col in ["Lat", "Alt", "EL"]:
        out[col] = merged[f"{col}_pred"].astype("float64") - merged[f"{col}_true"].astype("float64")

    # 角度差分（最短差分）
    for col in ["Lon", "AZ"]:
        out[col] = _angle_diff_deg(
            merged[f"{col}_pred"].to_numpy(dtype=np.float64),
            merged[f"{col}_true"].to_numpy(dtype=np.float64),
        )

    return out[["date", "UNIX", "Lat", "Lon", "Alt", "AZ", "EL"]]


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "23467_2023_csv の各CSVと 2023_calc_az_el.csv(真値) を比較し、"
            "UNIX完全一致の行だけで誤差CSVを出力します（補間なし）。"
        )
    )
    parser.add_argument(
        "--pred-dir",
        default="23467_2023_csv",
        type=str,
        help="比較対象（推定値）CSVが入ったフォルダ（既定: 23467_2023_csv）",
    )
    parser.add_argument(
        "--true-csv",
        default="2023_calc_az_el.csv",
        type=str,
        help="真値CSVパス（既定: 2023_calc_az_el.csv）",
    )
    parser.add_argument(
        "--out-dir",
        default="23467_2023_error",
        type=str,
        help="誤差CSVの出力先フォルダ（既定: 23467_2023_error）",
    )
    parser.add_argument(
        "--glob",
        default="*.csv",
        help="pred-dir内で処理するファイルパターン（既定: *.csv）",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="既に出力が存在する場合に上書きする",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="進捗表示を抑制する",
    )

    args = parser.parse_args()

    pred_dir = Path(args.pred_dir)
    true_csv = Path(args.true_csv)
    out_dir = Path(args.out_dir)

    if not pred_dir.exists() or not pred_dir.is_dir():
        print(f"[ERROR] pred-dir が見つかりません: {pred_dir}", file=sys.stderr)
        return 2
    if not true_csv.exists():
        print(f"[ERROR] true-csv が見つかりません: {true_csv}", file=sys.stderr)
        return 2

    out_dir.mkdir(parents=True, exist_ok=True)

    # 真値は一度だけ読み込む
    df_true = _load_truth(true_csv)

    pred_files = sorted(pred_dir.glob(args.glob))
    if not pred_files:
        print(
            f"[ERROR] pred-dir 内にファイルがありません: {pred_dir} pattern={args.glob}",
            file=sys.stderr,
        )
        return 2

    if not args.quiet:
        print(f"[INFO] pred-dir : {pred_dir.resolve()}")
        print(f"[INFO] true-csv : {true_csv.resolve()}")
        print(f"[INFO] out-dir  : {out_dir.resolve()}")
        print(f"[INFO] files    : {len(pred_files)}")
        print("[INFO] match    : exact (UNIX完全一致のみ)")

    for i, pred_path in enumerate(pred_files, start=1):
        out_path = out_dir / pred_path.name
        if out_path.exists() and not args.overwrite:
            if not args.quiet:
                print(f"[SKIP] ({i}/{len(pred_files)}) exists: {out_path.name}")
            continue

        try:
            df_pred = _read_csv_strict(pred_path)
            df_err = _compute_errors_exact_match(df_pred, df_true)

            df_err.to_csv(out_path, index=False)
            if not args.quiet:
                print(f"[OK] ({i}/{len(pred_files)}) {pred_path.name} -> rows={len(df_err)}")

        except Exception as e:
            print(f"[FAIL] ({i}/{len(pred_files)}) {pred_path}: {e}", file=sys.stderr)

    if not args.quiet:
        print("[DONE]")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
