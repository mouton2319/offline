import numpy as np
import ufo4_orbit_predict_tf as core
import ufo4_harmonic_azel_tf as hm

pairs=[]
for a,b in [(2021,2022),(2022,2023),(2023,2024)]:
    u0,f0=core.load_orbit_numeric_full(f'{a}_calc_az_el.csv')
    u1,f1=core.load_orbit_numeric_full(f'{b}_calc_az_el.csv')
    tpl=core.build_azel_template(u0, f0[:,3:5], np.ones((len(u0),),dtype=np.float32))
    base,_=core.lookup_template_azel(u1, tpl)
    d_az=hm.angle_diff_deg(f1[:,3], base[:,0])
    d_el=f1[:,4]-base[:,1]
    pairs.append((f'{a}->{b}', d_az, d_el))
for i in range(len(pairs)-1):
    n1,az1,el1=pairs[i]
    n2,az2,el2=pairs[i+1]
    m=min(len(az1),len(az2))
    print(n1,n2,'corr az', float(np.corrcoef(az1[:m],az2[:m])[0,1]), 'el', float(np.corrcoef(el1[:m],el2[:m])[0,1]), 'std', float(np.std(az1[:m])), float(np.std(az2[:m])))
