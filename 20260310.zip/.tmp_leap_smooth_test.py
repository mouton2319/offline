import numpy as np, pandas as pd
import ufo4_orbit_predict_tf as core
import ufo4_harmonic_azel_tf as hm

prev_u, prev=core.load_orbit_numeric_azel('/work/2023_calc_az_el.csv')
truth_u, truth=core.load_orbit_numeric_azel('/work/2024_calc_az_el.csv')
tpl=core.build_azel_template(prev_u, prev, np.ones((len(prev_u),),dtype=np.float32))

# JST unix helpers
import datetime as dt

def jst_ts(s):
    return int((pd.Timestamp(s)-pd.Timedelta(hours=9)).timestamp())

def pred_with_shift(offset_days, ramp0, ramp1):
    u=truth_u.copy()
    w=np.zeros_like(u)
    t0=jst_ts(ramp0); t1=jst_ts(ramp1)
    w[u>=t1]=1.0
    m=(u>t0)&(u<t1)
    if t1>t0:
        w[m]=(u[m]-t0)/(t1-t0)
    u2=u - w*(offset_days*86400.0)
    p,_=core.lookup_template_azel(u2, tpl)
    az=np.abs(hm.angle_diff_deg(p[:,0], truth[:,0])); el=np.abs(p[:,1]-truth[:,1])
    return float((az.mean()+el.mean())/2), float(max(az.max(), el.max()))

for off in [0.25,0.5,0.75,1.0,1.25]:
    for span in [('2024-02-15 00:00:00','2024-03-15 00:00:00'),('2024-02-20 00:00:00','2024-03-20 00:00:00'),('2024-02-25 00:00:00','2024-03-10 00:00:00')]:
        mean,mx=pred_with_shift(off,*span)
        print('off',off,'span',span,'mean',mean,'max',mx)
