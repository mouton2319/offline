#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Periodic harmonic AZ/EL utilities.

Model target representation:
- AZ -> (cos(AZ), sin(AZ)) to avoid angle-wrap instability.
- EL -> EL / 90.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Tuple

import numpy as np

try:
    import tensorflow as tf
except Exception:
    tf = None


SECONDS_PER_DAY = 86400.0
SECONDS_PER_TROPICAL_YEAR = 365.2422 * SECONDS_PER_DAY
SECONDS_PER_SIDEREAL_DAY = 86164.0905
JST_OFFSET_SEC = 9.0 * 3600.0


@dataclass
class HarmonicConfig:
    daily_harmonics: int = 8
    yearly_harmonics: int = 3
    drift_order: int = 2
    period_init_sec: float = SECONDS_PER_SIDEREAL_DAY
    period_min_sec: float = 85000.0
    period_max_sec: float = 87500.0


@dataclass
class ErrorCorrectionConfig:
    daily_harmonics: int = 12
    yearly_harmonics: int = 8
    drift_order: int = 2


@dataclass
class LSTMConfig:
    seq_len: int = 720
    sequence_stride: int = 3
    lstm_units_1: int = 96
    lstm_units_2: int = 48
    dense_units: int = 32
    dropout: float = 0.10
    recurrent_dropout: float = 0.0
    time_yearly_harmonics: int = 2


def cfg_to_dict(cfg: HarmonicConfig) -> Dict[str, float | int]:
    return asdict(cfg)


def cfg_from_dict(d: Dict[str, float | int]) -> HarmonicConfig:
    return sanitize_cfg(
        HarmonicConfig(
            daily_harmonics=int(d.get("daily_harmonics", 8)),
            yearly_harmonics=int(d.get("yearly_harmonics", 3)),
            drift_order=int(d.get("drift_order", 2)),
            period_init_sec=float(d.get("period_init_sec", SECONDS_PER_SIDEREAL_DAY)),
            period_min_sec=float(d.get("period_min_sec", 85000.0)),
            period_max_sec=float(d.get("period_max_sec", 87500.0)),
        )
    )


def ecfg_to_dict(cfg: ErrorCorrectionConfig) -> Dict[str, int]:
    return asdict(cfg)


def lcfg_to_dict(cfg: LSTMConfig) -> Dict[str, int | float]:
    return asdict(cfg)


def ecfg_from_dict(d: Dict[str, int]) -> ErrorCorrectionConfig:
    return ErrorCorrectionConfig(
        daily_harmonics=max(1, int(d.get("daily_harmonics", 12))),
        yearly_harmonics=max(0, int(d.get("yearly_harmonics", 8))),
        drift_order=max(0, int(d.get("drift_order", 2))),
    )


def lcfg_from_dict(d: Dict[str, int | float]) -> LSTMConfig:
    return LSTMConfig(
        seq_len=max(8, int(d.get("seq_len", 720))),
        sequence_stride=max(1, int(d.get("sequence_stride", 3))),
        lstm_units_1=max(8, int(d.get("lstm_units_1", 96))),
        lstm_units_2=max(0, int(d.get("lstm_units_2", 48))),
        dense_units=max(4, int(d.get("dense_units", 32))),
        dropout=float(d.get("dropout", 0.10)),
        recurrent_dropout=float(d.get("recurrent_dropout", 0.0)),
        time_yearly_harmonics=max(0, int(d.get("time_yearly_harmonics", 2))),
    )


def sanitize_cfg(cfg: HarmonicConfig) -> HarmonicConfig:
    out = HarmonicConfig(
        daily_harmonics=max(1, int(cfg.daily_harmonics)),
        yearly_harmonics=max(0, int(cfg.yearly_harmonics)),
        drift_order=max(0, int(cfg.drift_order)),
        period_init_sec=float(cfg.period_init_sec),
        period_min_sec=float(cfg.period_min_sec),
        period_max_sec=float(cfg.period_max_sec),
    )
    if out.period_max_sec <= out.period_min_sec:
        out.period_max_sec = out.period_min_sec + 1.0
    out.period_init_sec = float(np.clip(out.period_init_sec, out.period_min_sec + 1e-6, out.period_max_sec - 1e-6))
    return out


def feature_dim(cfg: HarmonicConfig) -> int:
    cfg = sanitize_cfg(cfg)
    cross = 4 * min(2, cfg.daily_harmonics) if cfg.yearly_harmonics > 0 else 0
    return 1 + cfg.drift_order + 2 * cfg.daily_harmonics + 2 * cfg.yearly_harmonics + cross


def error_feature_dim(cfg: ErrorCorrectionConfig) -> int:
    c = ecfg_from_dict(ecfg_to_dict(cfg))
    cross = 4 * min(3, c.daily_harmonics) if c.yearly_harmonics > 0 else 0
    base_geom = 6
    return 1 + c.drift_order + 2 * c.daily_harmonics + 2 * c.yearly_harmonics + cross + base_geom


def _clip_period(period_sec: float, cfg: HarmonicConfig) -> float:
    cfg = sanitize_cfg(cfg)
    return float(np.clip(float(period_sec), cfg.period_min_sec + 1e-6, cfg.period_max_sec - 1e-6))


def raw_from_period(period_sec: float, cfg: HarmonicConfig) -> float:
    cfg = sanitize_cfg(cfg)
    p = _clip_period(period_sec, cfg)
    z = (p - cfg.period_min_sec) / (cfg.period_max_sec - cfg.period_min_sec)
    z = float(np.clip(z, 1e-6, 1.0 - 1e-6))
    return float(math.log(z / (1.0 - z)))


def period_from_raw_np(raw: float, cfg: HarmonicConfig) -> float:
    cfg = sanitize_cfg(cfg)
    sig = 1.0 / (1.0 + math.exp(-float(raw)))
    return float(cfg.period_min_sec + sig * (cfg.period_max_sec - cfg.period_min_sec))


def period_from_raw_tf(raw: "tf.Tensor", cfg: HarmonicConfig) -> "tf.Tensor":
    cfg = sanitize_cfg(cfg)
    mn = tf.constant(cfg.period_min_sec, dtype=tf.float32)
    mx = tf.constant(cfg.period_max_sec, dtype=tf.float32)
    return mn + tf.sigmoid(raw) * (mx - mn)


def wrap360(deg: np.ndarray) -> np.ndarray:
    return np.mod(np.asarray(deg, dtype=np.float64), 360.0)


def angle_diff_deg(pred: np.ndarray, true: np.ndarray) -> np.ndarray:
    return (np.asarray(pred, dtype=np.float64) - np.asarray(true, dtype=np.float64) + 180.0) % 360.0 - 180.0


def azel_to_targets(azel: np.ndarray) -> np.ndarray:
    a = np.asarray(azel, dtype=np.float64)
    az_rad = np.deg2rad(a[:, 0])
    x = np.cos(az_rad)
    y = np.sin(az_rad)
    el_norm = np.clip(a[:, 1] / 90.0, -1.0, 1.0)
    return np.column_stack([x, y, el_norm]).astype(np.float32)


def azel_to_trig4(azel: np.ndarray) -> np.ndarray:
    a = np.asarray(azel, dtype=np.float64)
    az_rad = np.deg2rad(a[:, 0])
    el_rad = np.deg2rad(a[:, 1])
    return np.column_stack(
        [
            np.sin(az_rad),
            np.cos(az_rad),
            np.sin(el_rad),
            np.cos(el_rad),
        ]
    ).astype(np.float32)


def targets_to_azel(y: np.ndarray) -> np.ndarray:
    t = np.asarray(y, dtype=np.float64)
    az = wrap360(np.rad2deg(np.arctan2(t[:, 1], t[:, 0])))
    el = np.clip(t[:, 2] * 90.0, -90.0, 90.0)
    return np.column_stack([az, el]).astype(np.float64)


def trig4_to_azel(y: np.ndarray) -> np.ndarray:
    t = np.asarray(y, dtype=np.float64)
    az = wrap360(np.rad2deg(np.arctan2(t[:, 0], t[:, 1])))
    el = np.rad2deg(np.arctan2(t[:, 2], t[:, 3]))
    el = np.clip(el, -90.0, 90.0)
    return np.column_stack([az, el]).astype(np.float64)


def normalize_trig4_np(y: np.ndarray, eps: float = 1e-9) -> np.ndarray:
    t = np.asarray(y, dtype=np.float64).copy()
    az_norm = np.sqrt(np.maximum(eps, t[:, 0] * t[:, 0] + t[:, 1] * t[:, 1]))
    el_norm = np.sqrt(np.maximum(eps, t[:, 2] * t[:, 2] + t[:, 3] * t[:, 3]))
    t[:, 0] /= az_norm
    t[:, 1] /= az_norm
    t[:, 2] /= el_norm
    t[:, 3] /= el_norm
    return t.astype(np.float32)


def normalize_trig4_tf(y: "tf.Tensor", eps: float = 1e-9) -> "tf.Tensor":
    t = tf.cast(y, tf.float32)
    az_norm = tf.sqrt(tf.maximum(tf.constant(float(eps), dtype=tf.float32), tf.reduce_sum(tf.square(t[:, 0:2]), axis=1, keepdims=True)))
    el_norm = tf.sqrt(tf.maximum(tf.constant(float(eps), dtype=tf.float32), tf.reduce_sum(tf.square(t[:, 2:4]), axis=1, keepdims=True)))
    az = t[:, 0:2] / az_norm
    el = t[:, 2:4] / el_norm
    return tf.concat([az, el], axis=1)


def build_time_cyclic_features_np(unix: np.ndarray, yearly_harmonics: int = 2) -> np.ndarray:
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    u_local = u + JST_OFFSET_SEC
    two_pi = 2.0 * math.pi
    phase_day = two_pi * u_local / SECONDS_PER_DAY
    phase_sid = two_pi * u_local / SECONDS_PER_SIDEREAL_DAY
    phase_week = two_pi * u_local / (7.0 * SECONDS_PER_DAY)
    phase_month = two_pi * u_local / (30.4375 * SECONDS_PER_DAY)
    phase_year = two_pi * u_local / SECONDS_PER_TROPICAL_YEAR

    cols: list[np.ndarray] = [
        np.sin(phase_day),
        np.cos(phase_day),
        np.sin(phase_sid),
        np.cos(phase_sid),
        np.sin(phase_week),
        np.cos(phase_week),
        np.sin(phase_month),
        np.cos(phase_month),
        np.sin(phase_year),
        np.cos(phase_year),
    ]
    for k in range(2, max(0, int(yearly_harmonics)) + 1):
        arg = phase_year * float(k)
        cols.append(np.sin(arg))
        cols.append(np.cos(arg))
    return np.column_stack(cols).astype(np.float32)


def build_lstm_step_features_np(
    unix: np.ndarray,
    base_azel: np.ndarray,
    slot_weight: np.ndarray | None = None,
    yearly_harmonics: int = 2,
) -> np.ndarray:
    base = np.asarray(base_azel, dtype=np.float64)
    trig = azel_to_trig4(base)
    time_feat = build_time_cyclic_features_np(unix=unix, yearly_harmonics=yearly_harmonics)

    d_az = angle_diff_deg(base[:, 0], np.roll(base[:, 0], 1)) / 180.0
    d_az[0] = d_az[1] if d_az.shape[0] > 1 else 0.0
    d_el = (base[:, 1] - np.roll(base[:, 1], 1)) / 90.0
    d_el[0] = d_el[1] if d_el.shape[0] > 1 else 0.0
    extras = [d_az.reshape(-1, 1).astype(np.float32), d_el.reshape(-1, 1).astype(np.float32)]

    if slot_weight is not None:
        sw = np.log1p(np.asarray(slot_weight, dtype=np.float64)).reshape(-1, 1).astype(np.float32)
        extras.append(sw)

    return np.concatenate([time_feat, trig] + extras, axis=1).astype(np.float32)


def build_features_np(unix: np.ndarray, anchor_unix: float, period_sec: float, cfg: HarmonicConfig) -> np.ndarray:
    cfg = sanitize_cfg(cfg)
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    t_sec = u - float(anchor_unix)
    t_day = t_sec / SECONDS_PER_DAY
    p = _clip_period(period_sec, cfg)
    phase_day = 2.0 * math.pi * t_sec / p
    phase_year = 2.0 * math.pi * t_sec / SECONDS_PER_TROPICAL_YEAR

    cols: list[np.ndarray] = [np.ones_like(t_day, dtype=np.float64)]
    for o in range(1, cfg.drift_order + 1):
        cols.append(np.power(t_day, o))

    for k in range(1, cfg.daily_harmonics + 1):
        arg = float(k) * phase_day
        cols.append(np.sin(arg))
        cols.append(np.cos(arg))

    for k in range(1, cfg.yearly_harmonics + 1):
        arg = float(k) * phase_year
        cols.append(np.sin(arg))
        cols.append(np.cos(arg))

    if cfg.yearly_harmonics > 0:
        sy = np.sin(phase_year)
        cy = np.cos(phase_year)
        for k in range(1, min(2, cfg.daily_harmonics) + 1):
            arg = float(k) * phase_day
            sd = np.sin(arg)
            cd = np.cos(arg)
            cols.append(sd * sy)
            cols.append(sd * cy)
            cols.append(cd * sy)
            cols.append(cd * cy)

    out = np.stack(cols, axis=1).astype(np.float32)
    need = feature_dim(cfg)
    if out.shape[1] != need:
        raise RuntimeError(f"feature dim mismatch: got={out.shape[1]} expected={need}")
    return out


def build_features_tf(
    unix_tf: "tf.Tensor",
    anchor_unix: float,
    raw_period_tf: "tf.Tensor",
    cfg: HarmonicConfig,
) -> Tuple["tf.Tensor", "tf.Tensor"]:
    cfg = sanitize_cfg(cfg)
    u = tf.cast(tf.reshape(unix_tf, [-1]), tf.float32)
    anchor = tf.constant(float(anchor_unix), dtype=tf.float32)
    t_sec = u - anchor
    t_day = t_sec / tf.constant(SECONDS_PER_DAY, dtype=tf.float32)
    period = period_from_raw_tf(raw_period_tf, cfg)
    two_pi = tf.constant(2.0 * math.pi, dtype=tf.float32)
    phase_day = two_pi * t_sec / period
    phase_year = two_pi * t_sec / tf.constant(SECONDS_PER_TROPICAL_YEAR, dtype=tf.float32)

    cols: list["tf.Tensor"] = [tf.ones_like(t_day, dtype=tf.float32)]
    for o in range(1, cfg.drift_order + 1):
        cols.append(tf.pow(t_day, float(o)))

    for k in range(1, cfg.daily_harmonics + 1):
        arg = phase_day * float(k)
        cols.append(tf.sin(arg))
        cols.append(tf.cos(arg))

    for k in range(1, cfg.yearly_harmonics + 1):
        arg = phase_year * float(k)
        cols.append(tf.sin(arg))
        cols.append(tf.cos(arg))

    if cfg.yearly_harmonics > 0:
        sy = tf.sin(phase_year)
        cy = tf.cos(phase_year)
        for k in range(1, min(2, cfg.daily_harmonics) + 1):
            arg = phase_day * float(k)
            sd = tf.sin(arg)
            cd = tf.cos(arg)
            cols.append(sd * sy)
            cols.append(sd * cy)
            cols.append(cd * sy)
            cols.append(cd * cy)

    x = tf.stack(cols, axis=1)
    return x, period


def build_error_features_np(
    unix: np.ndarray,
    anchor_unix: float,
    cfg: ErrorCorrectionConfig,
    base_azel: np.ndarray | None = None,
) -> np.ndarray:
    c = ecfg_from_dict(ecfg_to_dict(cfg))
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    t_sec = u - float(anchor_unix)
    t_day = t_sec / SECONDS_PER_DAY
    u_local = u + JST_OFFSET_SEC
    phase_day = 2.0 * math.pi * u_local / SECONDS_PER_DAY
    phase_year = 2.0 * math.pi * u_local / SECONDS_PER_TROPICAL_YEAR

    cols: list[np.ndarray] = [np.ones_like(t_day, dtype=np.float64)]
    for o in range(1, c.drift_order + 1):
        cols.append(np.power(t_day, o))
    for k in range(1, c.daily_harmonics + 1):
        arg = float(k) * phase_day
        cols.append(np.sin(arg))
        cols.append(np.cos(arg))
    for k in range(1, c.yearly_harmonics + 1):
        arg = float(k) * phase_year
        cols.append(np.sin(arg))
        cols.append(np.cos(arg))
    if c.yearly_harmonics > 0:
        sy = np.sin(phase_year)
        cy = np.cos(phase_year)
        for k in range(1, min(3, c.daily_harmonics) + 1):
            arg = float(k) * phase_day
            sd = np.sin(arg)
            cd = np.cos(arg)
            cols.append(sd * sy)
            cols.append(sd * cy)
            cols.append(cd * sy)
            cols.append(cd * cy)
    if base_azel is None:
        raise ValueError("build_error_features_np requires base_azel for geometry-aware residual modeling.")
    base = np.asarray(base_azel, dtype=np.float64)
    trig = azel_to_trig4(base).astype(np.float64)
    d_az = angle_diff_deg(base[:, 0], np.roll(base[:, 0], 1)) / 180.0
    d_el = (base[:, 1] - np.roll(base[:, 1], 1)) / 90.0
    if d_az.shape[0] > 1:
        d_az[0] = d_az[1]
        d_el[0] = d_el[1]
    else:
        d_az[0] = 0.0
        d_el[0] = 0.0
    cols.append(trig[:, 0])
    cols.append(trig[:, 1])
    cols.append(trig[:, 2])
    cols.append(trig[:, 3])
    cols.append(d_az.astype(np.float64))
    cols.append(d_el.astype(np.float64))
    out = np.stack(cols, axis=1).astype(np.float64)
    need = error_feature_dim(c)
    if out.shape[1] != need:
        raise RuntimeError(f"error feature dim mismatch: got={out.shape[1]} expected={need}")
    return out


def init_params(anchor_unix: float, cfg: HarmonicConfig, seed: int = 42, weight_scale: float = 0.01) -> Dict[str, np.ndarray | float]:
    cfg = sanitize_cfg(cfg)
    rng = np.random.default_rng(int(seed))
    d = feature_dim(cfg)
    w = (rng.standard_normal((d, 3)).astype(np.float32) * float(weight_scale)).astype(np.float32)
    b = np.zeros((3,), dtype=np.float32)
    raw = np.array([raw_from_period(cfg.period_init_sec, cfg)], dtype=np.float32)
    return {
        "anchor_unix": float(anchor_unix),
        "raw_period": raw,
        "W": w,
        "b": b,
    }


def predict_targets_np(unix: np.ndarray, params: Dict[str, np.ndarray | float], cfg: HarmonicConfig) -> np.ndarray:
    raw = float(np.asarray(params["raw_period"]).reshape(-1)[0])
    period = period_from_raw_np(raw, cfg)
    x = build_features_np(unix=unix, anchor_unix=float(params["anchor_unix"]), period_sec=period, cfg=cfg)
    w = np.asarray(params["W"], dtype=np.float32)
    b = np.asarray(params["b"], dtype=np.float32)
    # Bound channels into physical target range and prevent extrapolation blow-up.
    y = np.tanh(x @ w + b.reshape(1, -1))
    return np.asarray(y, dtype=np.float32)


def predict_azel_np(unix: np.ndarray, params: Dict[str, np.ndarray | float], cfg: HarmonicConfig) -> np.ndarray:
    y = predict_targets_np(unix=unix, params=params, cfg=cfg)
    return targets_to_azel(y)


def copy_params(params: Dict[str, np.ndarray | float]) -> Dict[str, np.ndarray | float]:
    return {
        "anchor_unix": float(params["anchor_unix"]),
        "raw_period": np.asarray(params["raw_period"], dtype=np.float32).copy(),
        "W": np.asarray(params["W"], dtype=np.float32).copy(),
        "b": np.asarray(params["b"], dtype=np.float32).copy(),
    }


def save_params(path: Path, params: Dict[str, np.ndarray | float]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        anchor_unix=np.asarray([float(params["anchor_unix"])], dtype=np.float64),
        raw_period=np.asarray(params["raw_period"], dtype=np.float32),
        W=np.asarray(params["W"], dtype=np.float32),
        b=np.asarray(params["b"], dtype=np.float32),
    )


def load_params(path: Path) -> Dict[str, np.ndarray | float]:
    z = np.load(path)
    return {
        "anchor_unix": float(np.asarray(z["anchor_unix"]).reshape(-1)[0]),
        "raw_period": np.asarray(z["raw_period"], dtype=np.float32).reshape(1),
        "W": np.asarray(z["W"], dtype=np.float32),
        "b": np.asarray(z["b"], dtype=np.float32).reshape(3),
    }


def create_tf_variables(params: Dict[str, np.ndarray | float]) -> Tuple["tf.Variable", "tf.Variable", "tf.Variable"]:
    if tf is None:
        raise RuntimeError("TensorFlow is required but unavailable.")
    raw_v = tf.Variable(np.asarray(params["raw_period"], dtype=np.float32).reshape(1), name="raw_period")
    w_v = tf.Variable(np.asarray(params["W"], dtype=np.float32), name="W")
    b_v = tf.Variable(np.asarray(params["b"], dtype=np.float32).reshape(3), name="b")
    return raw_v, w_v, b_v


def pack_params_from_tf(
    raw_v: "tf.Variable",
    w_v: "tf.Variable",
    b_v: "tf.Variable",
    anchor_unix: float,
) -> Dict[str, np.ndarray | float]:
    return {
        "anchor_unix": float(anchor_unix),
        "raw_period": raw_v.numpy().astype(np.float32).reshape(1),
        "W": w_v.numpy().astype(np.float32),
        "b": b_v.numpy().astype(np.float32).reshape(3),
    }


def require_tensorflow() -> None:
    if tf is None:
        raise RuntimeError("TensorFlow is required but unavailable.")
