#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡予測(v1)の推論スクリプト。任意の航跡(前半)を入力し、未来を自己回帰生成する。

追加特徴量(--feature-cols で学習したもの)を使う場合、未来ステップの特徴は
「モデルが出した dx,dy と現在状態」から再構成して次入力に供給する(traj_common)。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\traj_predict.py `
    --model .\\claude_test\\artifacts_traj_full_feat\\traj_model.pt `
    --history-csv <航跡CSV> --steps 20 --out .\\claude_test\\pred.csv --device cuda
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from traj_common import (
    load_model, lonlat_to_disp_km, km_per_deg_lon, KM_PER_DEG_LAT,
    build_feature_matrix, reconstruct_next_extra, unix_seconds,
)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="航跡(前半)から未来を自己回帰生成する(v1)。")
    p.add_argument("--model", required=True, help="traj_model.pt")
    p.add_argument("--history-csv", required=True, help="入力にする航跡(前半)CSV")
    p.add_argument("--steps", type=int, default=20, help="未来を何点伸ばすか")
    p.add_argument("--out", required=True)
    p.add_argument("--device", default="")
    return p


def main() -> int:
    args = build_parser().parse_args()
    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    model, cfg = load_model(Path(args.model), device)

    df = pd.read_csv(args.history_csv)
    if "unix_time" in df.columns:
        df = df.sort_values("unix_time").reset_index(drop=True)
    elif "timestamp" in df.columns:
        df = df.assign(_t=pd.to_datetime(df["timestamp"], utc=True, errors="coerce")).sort_values("_t").reset_index(drop=True)
    lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
    lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
    if len(lon) < 2:
        raise ValueError("入力航跡は2点以上必要です。")

    feature_cols = cfg.feature_cols
    disp = lonlat_to_disp_km(lon, lat)                     # [P,2]
    seq_disp = list(disp)
    # 履歴部分の追加特徴は学習と同じ定義(build_feature_matrix)で用意する。
    seq_extra = list(build_feature_matrix(df, feature_cols)) if feature_cols else None
    unix = unix_seconds(df)
    cur_unix = float(unix[-1]) if len(unix) else 0.0
    interval = float(cfg.interval_minutes)

    dm = np.asarray(cfg.disp_mean); dstd = np.asarray(cfg.disp_std)
    fm = np.asarray(cfg.feat_mean); fstd = np.asarray(cfg.feat_std)

    cur_lon, cur_lat = float(lon[-1]), float(lat[-1])
    pred_rows = []
    max_ctx = int(cfg.max_len)
    with torch.no_grad():
        for step in range(int(args.steps)):
            # 直近 max_len 点だけを文脈に使う(位置符号テーブル長とO(L^2)の上限に収める)。
            ctx = min(len(seq_disp), max_ctx)
            d = np.stack(seq_disp[-ctx:], axis=0)          # [ctx,2]
            if feature_cols:
                e = np.stack(seq_extra[-ctx:], axis=0)     # [ctx,E]
                feats = np.concatenate([d, e], axis=1)
            else:
                feats = d
            x = (feats - fm) / fstd
            xt = torch.from_numpy(x.astype(np.float32)).unsqueeze(0).to(device)  # [1,ctx,F]
            pad = torch.zeros(1, ctx, dtype=torch.bool, device=device)
            nxt = model(xt, pad_mask=pad)[0, -1].cpu().numpy()  # 最後の位置の「次の移動量」(標準化)
            dxy = nxt * dstd + dm                          # km へ戻す

            new_lon = cur_lon + dxy[0] / km_per_deg_lon(cur_lat)
            new_lat = cur_lat + dxy[1] / KM_PER_DEG_LAT
            pred_rows.append((step + 1, new_lon, new_lat))

            prev_dxy = seq_disp[-1] if len(seq_disp) else None   # 直前の移動(turn_rate用)
            seq_disp.append(dxy.astype(np.float64))
            if feature_cols:
                cur_unix += interval * 60.0
                # 生成した移動量と新座標・新時刻から追加特徴を再構成(0埋めにしない)。
                ext = reconstruct_next_extra(feature_cols, new_lon, new_lat, cur_lon, cur_lat,
                                             cur_unix, interval, prev_dxy=prev_dxy, cur_dxy=dxy)
                seq_extra.append(ext)
            cur_lon, cur_lat = new_lon, new_lat

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(pred_rows, columns=["step", "lon", "lat"]).to_csv(out_path, index=False)
    print(f"[DONE] {len(pred_rows)} 点を予測 -> {out_path}  (feature_cols={feature_cols if feature_cols else '(dx,dy のみ)'})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
