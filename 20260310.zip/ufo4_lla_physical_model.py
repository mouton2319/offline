#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Physical GEO predictor based on yearly LLA harmonic coefficients.

The model fits a compact sidereal/yearly harmonic basis to each training year in
Lat/Lon/Alt space, extrapolates those coefficients to future years, and then
recomputes AZ/EL geometrically. A slot-wise residual map from forward backtests
is applied on top to capture persistent next-year biases.
"""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np

import ufo4_orbit_predict_tf as core


SIDEREAL_SECONDS = 86164.0905
PREV_CURVE_DAY_RIDGE = 10.0
PREV_CURVE_DAY_ALPHA = 0.50
PREV_CURVE_DAY_CAP_AZ_DEG = 0.12
PREV_CURVE_DAY_CAP_EL_DEG = 0.10
RECENT_ANOMALY_ALPHA = 0.30
SURFACE_FORECAST_DAY_H = 3
SURFACE_FORECAST_PHASE_H = 4
SURFACE_FORECAST_CROSS_H = 2
SURFACE_FORECAST_RIDGE = 1.0e-4
SURFACE_FORECAST_FUTURE_DECAY = 0.85


@dataclass
class LLAPhysicalConfig:
    sidereal_harmonics: int = 4
    yearly_harmonics: int = 2
    cross_harmonics: int = 2
    ridge: float = 1.0e-5
    extrapolation_recent_years: int = 4
    fit_recent_years: int = 5
    residual_recent_targets: int = 1
    slot_smooth_window: int = 31
    residual_day_smooth_window: int = 21
    residual_phase_smooth_window: int = 11
    slot_alpha: float = 0.40
    overlay_alpha: float = 0.06
    az_cap_deg: float = 0.80
    el_cap_deg: float = 0.80
    future_alpha_decay: float = 0.60
    day_curve_ridge: float = 1.0e-4
    day_curve_cap_deg: float = 0.05
    day_curve_alpha: float = 1.0


def cfg_to_dict(cfg: LLAPhysicalConfig) -> Dict[str, int | float]:
    return asdict(cfg)


def cfg_from_dict(d: Dict[str, int | float]) -> LLAPhysicalConfig:
    return LLAPhysicalConfig(
        sidereal_harmonics=max(1, int(d.get("sidereal_harmonics", 4))),
        yearly_harmonics=max(0, int(d.get("yearly_harmonics", 2))),
        cross_harmonics=max(0, int(d.get("cross_harmonics", 2))),
        ridge=float(d.get("ridge", 1.0e-5)),
        extrapolation_recent_years=max(2, int(d.get("extrapolation_recent_years", 4))),
        fit_recent_years=max(3, int(d.get("fit_recent_years", 5))),
        residual_recent_targets=max(1, int(d.get("residual_recent_targets", 1))),
        slot_smooth_window=max(1, int(d.get("slot_smooth_window", 31))),
        residual_day_smooth_window=max(1, int(d.get("residual_day_smooth_window", 21))),
        residual_phase_smooth_window=max(1, int(d.get("residual_phase_smooth_window", 11))),
        slot_alpha=float(d.get("slot_alpha", 0.40)),
        overlay_alpha=float(d.get("overlay_alpha", 0.06)),
        az_cap_deg=float(d.get("az_cap_deg", 0.80)),
        el_cap_deg=float(d.get("el_cap_deg", 0.80)),
        future_alpha_decay=float(d.get("future_alpha_decay", 0.60)),
        day_curve_ridge=float(d.get("day_curve_ridge", 1.0e-4)),
        day_curve_cap_deg=float(d.get("day_curve_cap_deg", 0.05)),
        day_curve_alpha=float(d.get("day_curve_alpha", 1.0)),
    )


def default_candidate_cfgs() -> List[LLAPhysicalConfig]:
    out: List[LLAPhysicalConfig] = []
    for sid_h, year_h, cross_h in (
        (3, 2, 2),
        (4, 2, 2),
        (5, 2, 2),
    ):
        for ridge in (1.0e-5, 1.0e-4):
            for smooth in (15,):
                for fit_recent_years, extrap_recent_years in (
                    (4, 3),
                    (5, 4),
                ):
                    for alpha in (0.15, 0.25, 0.35):
                        for overlay_alpha in (0.20, 0.30, 0.40):
                            out.append(
                                LLAPhysicalConfig(
                                    sidereal_harmonics=int(sid_h),
                                    yearly_harmonics=int(year_h),
                                    cross_harmonics=int(cross_h),
                                    ridge=float(ridge),
                                    extrapolation_recent_years=int(extrap_recent_years),
                                    fit_recent_years=int(fit_recent_years),
                                    slot_smooth_window=int(smooth),
                                    residual_day_smooth_window=21,
                                    residual_phase_smooth_window=11,
                                    slot_alpha=float(alpha),
                                    overlay_alpha=float(overlay_alpha),
                                )
                            )
    return out


def _metric_block(err: np.ndarray) -> Dict[str, float]:
    x = np.asarray(err, dtype=np.float64)
    return {
        "mae": float(np.mean(np.abs(x))),
        "rmse": float(np.sqrt(np.mean(np.square(x)))),
        "max_abs_error": float(np.max(np.abs(x))),
        "bias": float(np.mean(x)),
    }


def compute_azel_metrics(true_azel: np.ndarray, pred_azel: np.ndarray) -> Dict[str, Dict[str, float]]:
    az_err = core.wrap180(pred_azel[:, 0] - true_azel[:, 0])
    el_err = pred_azel[:, 1] - true_azel[:, 1]
    out = {"AZ": _metric_block(az_err), "EL": _metric_block(el_err)}
    mm = np.maximum(np.abs(az_err), np.abs(el_err))
    out["overall"] = {
        "mae_mean": float((out["AZ"]["mae"] + out["EL"]["mae"]) * 0.5),
        "rmse_mean": float((out["AZ"]["rmse"] + out["EL"]["rmse"]) * 0.5),
        "max_abs_error_max": float(np.max(mm)),
        "p99_abs_error_max": float(np.quantile(mm, 0.99)),
        "bias_mean": float((out["AZ"]["bias"] + out["EL"]["bias"]) * 0.5),
    }
    return out


def score_metrics(metrics: Dict[str, Dict[str, float]]) -> float:
    ov = metrics.get("overall", {})
    return float(
        float(ov.get("max_abs_error_max", 1.0e9))
        + 0.25 * float(ov.get("p99_abs_error_max", 1.0e9))
        + 0.10 * float(ov.get("mae_mean", 0.0))
    )


def robust_forward_score(metrics_list: List[Dict[str, Dict[str, float]]]) -> float:
    if not metrics_list:
        return 1.0e9
    overall = [m.get("overall", {}) for m in metrics_list]
    worst_max = max(float(m.get("max_abs_error_max", 1.0e9)) for m in overall)
    worst_p99 = max(float(m.get("p99_abs_error_max", 1.0e9)) for m in overall)
    late_weights = np.arange(1, len(overall) + 1, dtype=np.float64)
    late_weights = late_weights / np.sum(late_weights)
    w_mae = float(
        np.sum(
            late_weights
            * np.asarray([float(m.get("mae_mean", 1.0e9)) for m in overall], dtype=np.float64)
        )
    )
    w_rmse = float(
        np.sum(
            late_weights
            * np.asarray([float(m.get("rmse_mean", 1.0e9)) for m in overall], dtype=np.float64)
        )
    )
    last = overall[-1]
    last_max = float(last.get("max_abs_error_max", 1.0e9))
    last_p99 = float(last.get("p99_abs_error_max", 1.0e9))
    return float(
        0.60 * worst_max
        + 0.20 * worst_p99
        + 0.10 * last_max
        + 0.05 * last_p99
        + 0.03 * w_rmse
        + 0.02 * w_mae
    )


def _merge_forward_metrics(metrics_list: List[Dict[str, Dict[str, float]]]) -> Dict[str, Dict[str, float]]:
    if not metrics_list:
        raise ValueError("metrics_list is empty")
    w = np.arange(1, len(metrics_list) + 1, dtype=np.float64)
    w = w / np.sum(w)
    out: Dict[str, Dict[str, float]] = {"AZ": {}, "EL": {}, "overall": {}}
    for group in ("AZ", "EL", "overall"):
        keys = metrics_list[0][group].keys()
        for key in keys:
            vals = np.asarray([m[group][key] for m in metrics_list], dtype=np.float64)
            out[group][key] = float(np.sum(w * vals))
    return out


def _compute_local_year(unix: np.ndarray) -> np.ndarray:
    sec_local = np.asarray(np.round(unix), dtype=np.int64) + int(core.JST_OFFSET_SEC)
    dt_y = sec_local.astype("datetime64[s]").astype("datetime64[Y]")
    return (dt_y.astype(np.int64) + 1970).astype(np.int32)


def _compute_common_doy_and_sidereal_phase(unix: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    sec_local = np.asarray(np.round(unix), dtype=np.int64) + int(core.JST_OFFSET_SEC)
    dt_s = sec_local.astype("datetime64[s]")
    dt_d = dt_s.astype("datetime64[D]")
    y0 = dt_s.astype("datetime64[Y]")
    doy = (dt_d - y0).astype(np.int32)
    year_int = y0.astype(np.int64) + 1970
    is_leap = (year_int % 4 == 0) & ((year_int % 100 != 0) | (year_int % 400 == 0))
    doy = doy - ((is_leap) & (doy >= 60)).astype(np.int32)
    doy = np.clip(doy, 0, 364)
    sec_mod = np.mod(sec_local.astype(np.float64), float(SIDEREAL_SECONDS))
    phase = 2.0 * math.pi * sec_mod / float(SIDEREAL_SECONDS)
    return doy.astype(np.int32), phase.astype(np.float64)


def _design_matrix(unix: np.ndarray, cfg: LLAPhysicalConfig) -> np.ndarray:
    doy, phase = _compute_common_doy_and_sidereal_phase(unix)
    year_phase = 2.0 * math.pi * np.asarray(doy, dtype=np.float64) / 365.0
    feats: List[np.ndarray] = [np.ones_like(phase, dtype=np.float64)]
    sid_sin: List[np.ndarray] = []
    sid_cos: List[np.ndarray] = []
    year_sin: List[np.ndarray] = []
    year_cos: List[np.ndarray] = []
    for k in range(1, int(cfg.sidereal_harmonics) + 1):
        arg = float(k) * phase
        ss = np.sin(arg)
        cc = np.cos(arg)
        sid_sin.append(ss)
        sid_cos.append(cc)
        feats.extend([ss, cc])
    for k in range(1, int(cfg.yearly_harmonics) + 1):
        arg = float(k) * year_phase
        ss = np.sin(arg)
        cc = np.cos(arg)
        year_sin.append(ss)
        year_cos.append(cc)
        feats.extend([ss, cc])
    for ai in range(min(int(cfg.cross_harmonics), len(sid_sin))):
        for bi in range(min(int(cfg.cross_harmonics), len(year_sin))):
            feats.extend(
                [
                    sid_sin[ai] * year_sin[bi],
                    sid_sin[ai] * year_cos[bi],
                    sid_cos[ai] * year_sin[bi],
                    sid_cos[ai] * year_cos[bi],
                ]
            )
    return np.column_stack(feats).astype(np.float64)


def _solve_ridge(X: np.ndarray, y: np.ndarray, ridge: float) -> np.ndarray:
    xtx = X.T @ X + float(max(ridge, 1.0e-12)) * np.eye(X.shape[1], dtype=np.float64)
    xty = X.T @ y
    try:
        return np.linalg.solve(xtx, xty)
    except np.linalg.LinAlgError:
        return np.linalg.pinv(xtx) @ xty


def fit_year_coefficients(unix: np.ndarray, lla: np.ndarray, cfg: LLAPhysicalConfig) -> Dict[str, np.ndarray]:
    X = _design_matrix(unix, cfg)
    lat = np.asarray(lla[:, 0], dtype=np.float64)
    lon = np.asarray(lla[:, 1], dtype=np.float64)
    alt = np.asarray(lla[:, 2], dtype=np.float64)
    return {
        "lat": _solve_ridge(X, lat, cfg.ridge),
        "lon_s": _solve_ridge(X, np.sin(np.deg2rad(lon)), cfg.ridge),
        "lon_c": _solve_ridge(X, np.cos(np.deg2rad(lon)), cfg.ridge),
        "alt": _solve_ridge(X, alt, cfg.ridge),
    }


def fit_all_year_coefficients(
    year_data: Dict[int, Tuple[np.ndarray, np.ndarray, np.ndarray]],
    years: Iterable[int],
    cfg: LLAPhysicalConfig,
) -> Dict[int, Dict[str, np.ndarray]]:
    out: Dict[int, Dict[str, np.ndarray]] = {}
    for yy in sorted(int(y) for y in years):
        unix, _, lla = year_data[int(yy)]
        out[int(yy)] = fit_year_coefficients(unix=unix, lla=lla, cfg=cfg)
    return out


def _linear_extrapolate(years: List[int], mats: List[np.ndarray], pred_year: int) -> np.ndarray:
    use = np.asarray(years, dtype=np.float64)
    A = np.stack(mats, axis=0).astype(np.float64)
    x = use - np.mean(use)
    sw = float(len(use))
    sx = float(np.sum(x))
    sxx = float(np.sum(x * x))
    denom = sw * sxx - sx * sx
    sy = np.sum(A, axis=0)
    sxy = np.sum(x[:, None] * A, axis=0)
    if abs(denom) < 1.0e-12:
        slope = np.zeros_like(sy)
        intercept = sy / max(sw, 1.0e-12)
    else:
        slope = (sw * sxy - sx * sy) / denom
        intercept = (sy - slope * sx) / sw
    xpred = float(pred_year) - float(np.mean(use))
    return intercept + slope * xpred


def extrapolate_year_coefficients(
    coef_by_year: Dict[int, Dict[str, np.ndarray]],
    train_years: Iterable[int],
    pred_year: int,
    cfg: LLAPhysicalConfig,
) -> Dict[str, np.ndarray]:
    years = sorted(int(y) for y in train_years if int(y) < int(pred_year))
    if not years:
        years = sorted(int(y) for y in train_years)
    years = years[-int(cfg.extrapolation_recent_years) :]
    keys = list(next(iter(coef_by_year.values())).keys())
    return {k: _linear_extrapolate(years, [coef_by_year[y][k] for y in years], pred_year) for k in keys}


def _geodetic_to_ecef_km(
    lat_deg: np.ndarray,
    lon_deg: np.ndarray,
    alt_km: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    a = 6378.137
    f = 1.0 / 298.257223563
    e2 = f * (2.0 - f)
    lat = np.deg2rad(np.asarray(lat_deg, dtype=np.float64))
    lon = np.deg2rad(np.asarray(lon_deg, dtype=np.float64))
    alt = np.asarray(alt_km, dtype=np.float64)
    sl = np.sin(lat)
    cl = np.cos(lat)
    so = np.sin(lon)
    co = np.cos(lon)
    n = a / np.sqrt(1.0 - e2 * sl * sl)
    x = (n + alt) * cl * co
    y = (n + alt) * cl * so
    z = (n * (1.0 - e2) + alt) * sl
    return x, y, z


def recompute_azel_from_lla(
    sat_lat_deg: np.ndarray,
    sat_lon_deg: np.ndarray,
    sat_alt_km: np.ndarray,
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
) -> Tuple[np.ndarray, np.ndarray]:
    sx, sy, sz = _geodetic_to_ecef_km(sat_lat_deg, sat_lon_deg, sat_alt_km)
    ox, oy, oz = _geodetic_to_ecef_km(
        np.asarray([observer_lat_deg], dtype=np.float64),
        np.asarray([observer_lon_deg], dtype=np.float64),
        np.asarray([float(observer_alt_m) / 1000.0], dtype=np.float64),
    )
    dx = sx - float(ox[0])
    dy = sy - float(oy[0])
    dz = sz - float(oz[0])
    lat0 = math.radians(float(observer_lat_deg))
    lon0 = math.radians(float(observer_lon_deg))
    sl = math.sin(lat0)
    cl = math.cos(lat0)
    so = math.sin(lon0)
    co = math.cos(lon0)
    east = -so * dx + co * dy
    north = -sl * co * dx - sl * so * dy + cl * dz
    up = cl * co * dx + cl * so * dy + sl * dz
    az = np.rad2deg(np.arctan2(east, north))
    az = np.mod(az + 360.0, 360.0)
    el = np.rad2deg(np.arctan2(up, np.sqrt(east * east + north * north)))
    el = np.clip(el, -90.0, 90.0)
    return az, el


def predict_from_coefficients(
    unix: np.ndarray,
    coef: Dict[str, np.ndarray],
    cfg: LLAPhysicalConfig,
    observer_lat: float,
    observer_lon: float,
    observer_alt_m: float,
) -> Tuple[np.ndarray, np.ndarray]:
    X = _design_matrix(unix, cfg)
    lat = X @ np.asarray(coef["lat"], dtype=np.float64)
    lon = np.rad2deg(np.arctan2(X @ np.asarray(coef["lon_s"], dtype=np.float64), X @ np.asarray(coef["lon_c"], dtype=np.float64)))
    lon = ((lon + 180.0) % 360.0) - 180.0
    alt = X @ np.asarray(coef["alt"], dtype=np.float64)
    az, el = recompute_azel_from_lla(
        sat_lat_deg=lat,
        sat_lon_deg=lon,
        sat_alt_km=alt,
        observer_lat_deg=observer_lat,
        observer_lon_deg=observer_lon,
        observer_alt_m=observer_alt_m,
    )
    lla = np.column_stack([lat, lon, alt]).astype(np.float64)
    azel = np.column_stack([az, el]).astype(np.float64)
    return azel, lla


def _candidate_forward_targets(years: List[int], holdout_year: int, n_recent: int) -> List[int]:
    usable = []
    for yy in years:
        if yy >= holdout_year:
            continue
        prev = [pp for pp in years if pp < yy]
        if len(prev) >= 2:
            usable.append(int(yy))
    return usable[-max(1, int(n_recent)) :]


def _smooth_1d_circular(x: np.ndarray, win: int) -> np.ndarray:
    arr = np.asarray(x, dtype=np.float64)
    if int(win) <= 1:
        return arr.copy()
    ww = int(win)
    if ww % 2 == 0:
        ww += 1
    pad = ww // 2
    ker = np.ones((ww,), dtype=np.float64) / float(ww)
    ext = np.concatenate([arr[-pad:], arr, arr[:pad]])
    return np.convolve(ext, ker, mode="valid")


def _smooth_1d_edge(x: np.ndarray, win: int) -> np.ndarray:
    arr = np.asarray(x, dtype=np.float64)
    if int(win) <= 1:
        return arr.copy()
    ww = int(win)
    if ww % 2 == 0:
        ww += 1
    pad = ww // 2
    ker = np.ones((ww,), dtype=np.float64) / float(ww)
    ext = np.concatenate([np.repeat(arr[:1], pad), arr, np.repeat(arr[-1:], pad)])
    return np.convolve(ext, ker, mode="valid")


def _smooth_2d_day_phase(arr: np.ndarray, day_win: int, phase_win: int) -> np.ndarray:
    out = np.asarray(arr, dtype=np.float64).copy()
    if int(day_win) > 1:
        out = np.apply_along_axis(lambda v: _smooth_1d_edge(v, int(day_win)), 0, out)
    if int(phase_win) > 1:
        out = np.apply_along_axis(lambda v: _smooth_1d_circular(v, int(phase_win)), 1, out)
    return out


def _fill_day_phase_missing(
    saz: np.ndarray,
    sel: np.ndarray,
    sw: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    az = np.asarray(saz, dtype=np.float64).copy()
    el = np.asarray(sel, dtype=np.float64).copy()
    ww = np.asarray(sw, dtype=np.float64)
    valid = ww > 0.0
    n_day, n_phase = az.shape
    phase_idx = np.arange(n_phase, dtype=np.int32)
    day_idx = np.arange(n_day, dtype=np.int32)
    for dd in range(n_day):
        v = valid[dd]
        if np.any(v) and not np.all(v):
            az[dd, ~v] = np.interp(phase_idx[~v], phase_idx[v], az[dd, v])
            el[dd, ~v] = np.interp(phase_idx[~v], phase_idx[v], el[dd, v])
    for pp in range(n_phase):
        v = valid[:, pp]
        if np.any(v) and not np.all(v):
            az[~v, pp] = np.interp(day_idx[~v], day_idx[v], az[v, pp])
            el[~v, pp] = np.interp(day_idx[~v], day_idx[v], el[v, pp])
    return az, el


def _downsample_year_data(
    year_data: Dict[int, Tuple[np.ndarray, np.ndarray, np.ndarray]],
    stride: int,
) -> Dict[int, Tuple[np.ndarray, np.ndarray, np.ndarray]]:
    out: Dict[int, Tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
    step = max(1, int(stride))
    for yy, (unix, azel, lla) in year_data.items():
        out[int(yy)] = (
            np.asarray(unix[::step], dtype=np.float64),
            np.asarray(azel[::step], dtype=np.float64),
            np.asarray(lla[::step], dtype=np.float64),
        )
    return out


def _build_slot_residual_pack(
    year_data: Dict[int, Tuple[np.ndarray, np.ndarray, np.ndarray]],
    coef_by_year: Dict[int, Dict[str, np.ndarray]],
    train_years: List[int],
    forward_targets: List[int],
    cfg: LLAPhysicalConfig,
    observer_lat: float,
    observer_lon: float,
    observer_alt_m: float,
) -> Dict[str, np.ndarray | float]:
    n_slots = int(core.SLOTS_PER_YEAR)
    n_day = int(core.COMMON_DAYS_PER_YEAR)
    n_phase = int(core.MINUTES_PER_DAY)
    sum_az = np.zeros((n_slots,), dtype=np.float64)
    sum_el = np.zeros((n_slots,), dtype=np.float64)
    sum_w = np.zeros((n_slots,), dtype=np.float64)
    sum_az_2d = np.zeros((n_day, n_phase), dtype=np.float64)
    sum_el_2d = np.zeros((n_day, n_phase), dtype=np.float64)
    sum_w_2d = np.zeros((n_day, n_phase), dtype=np.float64)
    fwd = [int(x) for x in forward_targets]
    if not fwd:
        fwd = []
    recency_weights = np.arange(1, len(fwd) + 1, dtype=np.float64)
    if recency_weights.size > 0:
        recency_weights = recency_weights / np.sum(recency_weights)
    for idx_fwd, target_year in enumerate(fwd):
        prev_years = [yy for yy in train_years if yy < int(target_year)]
        if len(prev_years) < 2:
            continue
        coef_pred = extrapolate_year_coefficients(
            coef_by_year=coef_by_year,
            train_years=prev_years,
            pred_year=int(target_year),
            cfg=cfg,
        )
        unix_t, true_azel_t, _ = year_data[int(target_year)]
        pred_azel_t, _ = predict_from_coefficients(
            unix=unix_t,
            coef=coef_pred,
            cfg=cfg,
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            observer_alt_m=observer_alt_m,
        )
        az_err = core.wrap180(true_azel_t[:, 0] - pred_azel_t[:, 0])
        el_err = true_azel_t[:, 1] - pred_azel_t[:, 1]
        slot_idx = core.compute_slot_index(unix_t)
        day_idx = slot_idx // int(core.MINUTES_PER_DAY)
        phase_idx = slot_idx % int(core.MINUTES_PER_DAY)
        ww = float(recency_weights[idx_fwd]) if recency_weights.size == len(fwd) else 1.0
        np.add.at(sum_az, slot_idx, ww * az_err)
        np.add.at(sum_el, slot_idx, ww * el_err)
        np.add.at(sum_w, slot_idx, ww)
        np.add.at(sum_az_2d, (day_idx, phase_idx), ww * az_err)
        np.add.at(sum_el_2d, (day_idx, phase_idx), ww * el_err)
        np.add.at(sum_w_2d, (day_idx, phase_idx), ww)

    mean_az = np.divide(sum_az, np.maximum(sum_w, 1.0))
    mean_el = np.divide(sum_el, np.maximum(sum_w, 1.0))
    valid = sum_w > 0.0
    if np.any(valid):
        idx = np.arange(n_slots, dtype=np.int32)
        mean_az[~valid] = np.interp(idx[~valid], idx[valid], mean_az[valid])
        mean_el[~valid] = np.interp(idx[~valid], idx[valid], mean_el[valid])
    smooth = int(max(1, cfg.slot_smooth_window))
    if smooth > 1:
        if smooth % 2 == 0:
            smooth += 1
        pad = smooth // 2
        ker = np.ones((smooth,), dtype=np.float64) / float(smooth)
        ext_az = np.concatenate([mean_az[-pad:], mean_az, mean_az[:pad]])
        ext_el = np.concatenate([mean_el[-pad:], mean_el, mean_el[:pad]])
        mean_az = np.convolve(ext_az, ker, mode="valid")
        mean_el = np.convolve(ext_el, ker, mode="valid")
    mean_az = np.clip(mean_az, -abs(float(cfg.az_cap_deg)), abs(float(cfg.az_cap_deg)))
    mean_el = np.clip(mean_el, -abs(float(cfg.el_cap_deg)), abs(float(cfg.el_cap_deg)))
    mean_az_2d = np.divide(sum_az_2d, np.maximum(sum_w_2d, 1.0))
    mean_el_2d = np.divide(sum_el_2d, np.maximum(sum_w_2d, 1.0))
    mean_az_2d, mean_el_2d = _fill_day_phase_missing(mean_az_2d, mean_el_2d, sum_w_2d)
    mean_az_2d = _smooth_2d_day_phase(
        mean_az_2d,
        day_win=int(cfg.residual_day_smooth_window),
        phase_win=int(cfg.residual_phase_smooth_window),
    )
    mean_el_2d = _smooth_2d_day_phase(
        mean_el_2d,
        day_win=int(cfg.residual_day_smooth_window),
        phase_win=int(cfg.residual_phase_smooth_window),
    )
    mean_az_2d = np.clip(mean_az_2d, -abs(float(cfg.az_cap_deg)), abs(float(cfg.az_cap_deg)))
    mean_el_2d = np.clip(mean_el_2d, -abs(float(cfg.el_cap_deg)), abs(float(cfg.el_cap_deg)))
    return {
        "slot_az_bias_deg": mean_az.astype(np.float64),
        "slot_el_bias_deg": mean_el.astype(np.float64),
        "slot_weight": sum_w.astype(np.float64),
        "overlay_az_bias_deg_2d": mean_az_2d.astype(np.float64),
        "overlay_el_bias_deg_2d": mean_el_2d.astype(np.float64),
        "overlay_weight_2d": sum_w_2d.astype(np.float64),
        "overlay_alpha": float(cfg.overlay_alpha),
        "slot_alpha": float(cfg.slot_alpha),
        "forward_targets": np.asarray(forward_targets, dtype=np.int32),
    }


def apply_overlay_surface(
    pred_unix: np.ndarray,
    pred_azel: np.ndarray,
    slot_pack: Dict[str, np.ndarray | float] | None,
    cfg: LLAPhysicalConfig,
) -> np.ndarray:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if slot_pack is None:
        return out
    ov_az = slot_pack.get("overlay_az_bias_deg_2d", None)
    ov_el = slot_pack.get("overlay_el_bias_deg_2d", None)
    if ov_az is None or ov_el is None:
        return out
    overlay_alpha = float(slot_pack.get("overlay_alpha", cfg.overlay_alpha))
    if abs(overlay_alpha) <= 1.0e-12:
        return out
    slot_idx = core.compute_slot_index(pred_unix)
    day_idx = slot_idx // int(core.MINUTES_PER_DAY)
    phase_idx = slot_idx % int(core.MINUTES_PER_DAY)
    corr_az = np.asarray(ov_az, dtype=np.float64)[day_idx, phase_idx]
    corr_el = np.asarray(ov_el, dtype=np.float64)[day_idx, phase_idx]
    out[:, 0] = np.mod(out[:, 0] + overlay_alpha * corr_az + 360.0, 360.0)
    out[:, 1] = np.clip(out[:, 1] + overlay_alpha * corr_el, -90.0, 90.0)
    return out


def _build_day_curve_feature_matrix(
    unix: np.ndarray,
    pred_azel: np.ndarray,
    pred_lla: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    slot_idx = core.compute_slot_index(unix)
    day_idx = slot_idx // int(core.MINUTES_PER_DAY)
    rows: List[List[float]] = []
    for dd in range(int(core.COMMON_DAYS_PER_YEAR)):
        mask = day_idx == dd
        az = np.asarray(pred_azel[mask, 0], dtype=np.float64)
        el = np.asarray(pred_azel[mask, 1], dtype=np.float64)
        lat = np.asarray(pred_lla[mask, 0], dtype=np.float64)
        lon = np.deg2rad(np.asarray(pred_lla[mask, 1], dtype=np.float64))
        alt = np.asarray(pred_lla[mask, 2], dtype=np.float64)
        yarg = 2.0 * math.pi * float(dd) / float(core.COMMON_DAYS_PER_YEAR)
        rows.append(
            [
                1.0,
                math.sin(yarg),
                math.cos(yarg),
                math.sin(2.0 * yarg),
                math.cos(2.0 * yarg),
                math.sin(3.0 * yarg),
                math.cos(3.0 * yarg),
                float(np.mean(az) / 180.0),
                float(np.mean(el) / 90.0),
                float((np.max(az) - np.min(az)) / 10.0),
                float((np.max(el) - np.min(el)) / 10.0),
                float(np.mean(lat) / 10.0),
                float(np.mean(np.sin(lon))),
                float(np.mean(np.cos(lon))),
                float(np.mean((alt - 35786.0) / 300.0)),
            ]
        )
    return np.asarray(rows, dtype=np.float64), day_idx.astype(np.int32)


def _solve_small_ridge(X: np.ndarray, y: np.ndarray, ridge: float) -> np.ndarray:
    mat = X.T @ X + float(max(ridge, 1.0e-12)) * np.eye(X.shape[1], dtype=np.float64)
    rhs = X.T @ y
    try:
        return np.linalg.solve(mat, rhs)
    except np.linalg.LinAlgError:
        return np.linalg.pinv(mat) @ rhs


def _fit_day_curve_model(
    records: List[Dict[str, np.ndarray]],
    cfg: LLAPhysicalConfig,
) -> Dict[str, np.ndarray] | None:
    if not records:
        return None
    feats: List[np.ndarray] = []
    az_targets: List[np.ndarray] = []
    el_targets: List[np.ndarray] = []
    for rec in records:
        unix = np.asarray(rec["unix"], dtype=np.float64)
        true_azel = np.asarray(rec["true_azel"], dtype=np.float64)
        pred_azel = np.asarray(rec["pred_azel"], dtype=np.float64)
        pred_lla = np.asarray(rec["pred_lla"], dtype=np.float64)
        X_day, day_idx = _build_day_curve_feature_matrix(unix, pred_azel, pred_lla)
        az_err = core.wrap180(true_azel[:, 0] - pred_azel[:, 0])
        el_err = true_azel[:, 1] - pred_azel[:, 1]
        da = np.zeros((int(core.COMMON_DAYS_PER_YEAR),), dtype=np.float64)
        de = np.zeros((int(core.COMMON_DAYS_PER_YEAR),), dtype=np.float64)
        for dd in range(int(core.COMMON_DAYS_PER_YEAR)):
            mask = day_idx == dd
            da[dd] = float(np.mean(az_err[mask]))
            de[dd] = float(np.mean(el_err[mask]))
        feats.append(X_day)
        az_targets.append(da)
        el_targets.append(de)
    X = np.vstack(feats)
    y_az = np.concatenate(az_targets)
    y_el = np.concatenate(el_targets)
    return {
        "coef_az": _solve_small_ridge(X, y_az, cfg.day_curve_ridge).astype(np.float64),
        "coef_el": _solve_small_ridge(X, y_el, cfg.day_curve_ridge).astype(np.float64),
    }


def apply_day_curve_model(
    pred_unix: np.ndarray,
    pred_azel: np.ndarray,
    pred_lla: np.ndarray,
    model: Dict[str, np.ndarray] | None,
    cfg: LLAPhysicalConfig,
) -> np.ndarray:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if model is None:
        return out
    X_day, day_idx = _build_day_curve_feature_matrix(pred_unix, pred_azel, pred_lla)
    cap = abs(float(cfg.day_curve_cap_deg))
    alpha = float(cfg.day_curve_alpha)
    corr_az_day = alpha * np.clip(X_day @ np.asarray(model["coef_az"], dtype=np.float64), -cap, cap)
    corr_el_day = alpha * np.clip(X_day @ np.asarray(model["coef_el"], dtype=np.float64), -cap, cap)
    out[:, 0] = np.mod(out[:, 0] + corr_az_day[day_idx] + 360.0, 360.0)
    out[:, 1] = np.clip(out[:, 1] + corr_el_day[day_idx], -90.0, 90.0)
    return out


def _extract_day_curve_and_anomaly(
    unix: np.ndarray,
    true_azel: np.ndarray,
    pred_azel: np.ndarray,
) -> Dict[str, np.ndarray]:
    slot_idx = core.compute_slot_index(unix)
    day_idx = slot_idx // int(core.MINUTES_PER_DAY)
    phase_idx = slot_idx % int(core.MINUTES_PER_DAY)
    az_err = core.wrap180(true_azel[:, 0] - pred_azel[:, 0])
    el_err = true_azel[:, 1] - pred_azel[:, 1]
    n_day = int(core.COMMON_DAYS_PER_YEAR)
    n_phase = int(core.MINUTES_PER_DAY)
    day_curve_az = np.zeros((n_day,), dtype=np.float64)
    day_curve_el = np.zeros((n_day,), dtype=np.float64)
    for dd in range(n_day):
        mask = day_idx == dd
        day_curve_az[dd] = float(np.mean(az_err[mask]))
        day_curve_el[dd] = float(np.mean(el_err[mask]))
    saz = np.zeros((n_day, n_phase), dtype=np.float64)
    sel = np.zeros((n_day, n_phase), dtype=np.float64)
    sw = np.zeros((n_day, n_phase), dtype=np.float64)
    np.add.at(saz, (day_idx, phase_idx), az_err - day_curve_az[day_idx])
    np.add.at(sel, (day_idx, phase_idx), el_err - day_curve_el[day_idx])
    np.add.at(sw, (day_idx, phase_idx), 1.0)
    saz = np.divide(saz, np.maximum(sw, 1.0))
    sel = np.divide(sel, np.maximum(sw, 1.0))
    saz, sel = _fill_day_phase_missing(saz, sel, sw)
    saz = _smooth_2d_day_phase(saz, day_win=15, phase_win=15)
    sel = _smooth_2d_day_phase(sel, day_win=15, phase_win=15)
    return {
        "curve_az": day_curve_az.astype(np.float64),
        "curve_el": day_curve_el.astype(np.float64),
        "anom_az": saz.astype(np.float64),
        "anom_el": sel.astype(np.float64),
    }


def _build_prev_curve_day_feature_matrix(
    unix: np.ndarray,
    pred_azel: np.ndarray,
    pred_lla: np.ndarray,
    prev_curve_az: List[np.ndarray],
    prev_curve_el: List[np.ndarray],
) -> Tuple[np.ndarray, np.ndarray]:
    X_day, day_idx = _build_day_curve_feature_matrix(unix, pred_azel, pred_lla)
    cols: List[np.ndarray] = [X_day]
    for arr in prev_curve_az:
        cols.append(np.asarray(arr, dtype=np.float64).reshape(-1, 1))
    for arr in prev_curve_el:
        cols.append(np.asarray(arr, dtype=np.float64).reshape(-1, 1))
    return np.hstack(cols).astype(np.float64), day_idx.astype(np.int32)


def _fit_prev_curve_day_model(
    records: List[Dict[str, np.ndarray]],
) -> Dict[str, np.ndarray] | None:
    if len(records) < 2:
        return None
    feats: List[np.ndarray] = []
    targ_az: List[np.ndarray] = []
    targ_el: List[np.ndarray] = []
    hist_years: List[int] = []
    hist_curve_az: List[np.ndarray] = []
    hist_curve_el: List[np.ndarray] = []
    hist_anom_az: List[np.ndarray] = []
    hist_anom_el: List[np.ndarray] = []
    for rec in records:
        extra = _extract_day_curve_and_anomaly(
            unix=np.asarray(rec["unix"], dtype=np.float64),
            true_azel=np.asarray(rec["true_azel"], dtype=np.float64),
            pred_azel=np.asarray(rec["pred_azel"], dtype=np.float64),
        )
        rec["curve_az"] = extra["curve_az"]
        rec["curve_el"] = extra["curve_el"]
        rec["anom_az"] = extra["anom_az"]
        rec["anom_el"] = extra["anom_el"]
    for idx, rec in enumerate(records):
        year = int(np.asarray(rec["year"], dtype=np.int32).reshape(-1)[0])
        prev_az: List[np.ndarray] = []
        prev_el: List[np.ndarray] = []
        for back in (1, 2, 3):
            yy = year - back
            found = next((r for r in records[:idx] if int(np.asarray(r["year"]).reshape(-1)[0]) == yy), None)
            if found is None:
                prev_az.append(np.zeros((int(core.COMMON_DAYS_PER_YEAR),), dtype=np.float64))
                prev_el.append(np.zeros((int(core.COMMON_DAYS_PER_YEAR),), dtype=np.float64))
            else:
                prev_az.append(np.asarray(found["curve_az"], dtype=np.float64))
                prev_el.append(np.asarray(found["curve_el"], dtype=np.float64))
        X_day, _ = _build_prev_curve_day_feature_matrix(
            unix=np.asarray(rec["unix"], dtype=np.float64),
            pred_azel=np.asarray(rec["pred_azel"], dtype=np.float64),
            pred_lla=np.asarray(rec["pred_lla"], dtype=np.float64),
            prev_curve_az=prev_az,
            prev_curve_el=prev_el,
        )
        feats.append(X_day)
        targ_az.append(np.asarray(rec["curve_az"], dtype=np.float64))
        targ_el.append(np.asarray(rec["curve_el"], dtype=np.float64))
    for rec in records[-3:]:
        hist_years.append(int(np.asarray(rec["year"], dtype=np.int32).reshape(-1)[0]))
        hist_curve_az.append(np.asarray(rec["curve_az"], dtype=np.float64))
        hist_curve_el.append(np.asarray(rec["curve_el"], dtype=np.float64))
        hist_anom_az.append(np.asarray(rec["anom_az"], dtype=np.float64))
        hist_anom_el.append(np.asarray(rec["anom_el"], dtype=np.float64))
    mean_anom_az = np.mean(np.stack(hist_anom_az[-2:], axis=0), axis=0) if len(hist_anom_az) >= 2 else np.asarray(hist_anom_az[-1], dtype=np.float64)
    mean_anom_el = np.mean(np.stack(hist_anom_el[-2:], axis=0), axis=0) if len(hist_anom_el) >= 2 else np.asarray(hist_anom_el[-1], dtype=np.float64)
    X = np.vstack(feats)
    y_az = np.concatenate(targ_az)
    y_el = np.concatenate(targ_el)
    return {
        "coef_az": _solve_small_ridge(X, y_az, PREV_CURVE_DAY_RIDGE).astype(np.float64),
        "coef_el": _solve_small_ridge(X, y_el, PREV_CURVE_DAY_RIDGE).astype(np.float64),
        "recent_years": np.asarray(hist_years, dtype=np.int32),
        "recent_curve_az": np.stack(hist_curve_az, axis=0).astype(np.float64),
        "recent_curve_el": np.stack(hist_curve_el, axis=0).astype(np.float64),
        "recent_mean_anom_az": mean_anom_az.astype(np.float64),
        "recent_mean_anom_el": mean_anom_el.astype(np.float64),
    }


def apply_prev_curve_day_model(
    pred_unix: np.ndarray,
    pred_azel: np.ndarray,
    pred_lla: np.ndarray,
    model: Dict[str, np.ndarray] | None,
    latest_train_year: int,
) -> Tuple[np.ndarray, Dict[int, Dict[str, np.ndarray]]]:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if model is None:
        return out, {}
    pred_years = _compute_local_year(pred_unix)
    hist_az = [np.asarray(x, dtype=np.float64) for x in np.asarray(model["recent_curve_az"], dtype=np.float64)]
    hist_el = [np.asarray(x, dtype=np.float64) for x in np.asarray(model["recent_curve_el"], dtype=np.float64)]
    predicted_curves: Dict[int, Dict[str, np.ndarray]] = {}
    for yy in sorted(int(v) for v in np.unique(pred_years)):
        if yy <= int(latest_train_year):
            continue
        mask = pred_years == int(yy)
        if int(yy) == int(latest_train_year) + 1 and len(hist_az) >= 3:
            prev_az = [hist_az[-1], hist_az[-2], hist_az[-3]]
            prev_el = [hist_el[-1], hist_el[-2], hist_el[-3]]
        elif len(hist_az) >= 3:
            prev_az = [hist_az[-1], hist_az[-2], hist_az[-3]]
            prev_el = [hist_el[-1], hist_el[-2], hist_el[-3]]
        else:
            continue
        X_day, day_idx = _build_prev_curve_day_feature_matrix(
            unix=pred_unix[mask],
            pred_azel=out[mask],
            pred_lla=pred_lla[mask],
            prev_curve_az=prev_az,
            prev_curve_el=prev_el,
        )
        corr_az_day = PREV_CURVE_DAY_ALPHA * np.clip(
            X_day @ np.asarray(model["coef_az"], dtype=np.float64),
            -PREV_CURVE_DAY_CAP_AZ_DEG,
            PREV_CURVE_DAY_CAP_AZ_DEG,
        )
        corr_el_day = PREV_CURVE_DAY_ALPHA * np.clip(
            X_day @ np.asarray(model["coef_el"], dtype=np.float64),
            -PREV_CURVE_DAY_CAP_EL_DEG,
            PREV_CURVE_DAY_CAP_EL_DEG,
        )
        out[mask, 0] = np.mod(out[mask, 0] + corr_az_day[day_idx] + 360.0, 360.0)
        out[mask, 1] = np.clip(out[mask, 1] + corr_el_day[day_idx], -90.0, 90.0)
        predicted_curves[int(yy)] = {
            "curve_az": corr_az_day.astype(np.float64),
            "curve_el": corr_el_day.astype(np.float64),
        }
        hist_az.append(corr_az_day.astype(np.float64))
        hist_el.append(corr_el_day.astype(np.float64))
    return out, predicted_curves


def apply_recent_anomaly_surface(
    pred_unix: np.ndarray,
    pred_azel: np.ndarray,
    anomaly_pack: Dict[str, np.ndarray] | None,
    latest_train_year: int,
) -> np.ndarray:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if anomaly_pack is None:
        return out
    saz = np.asarray(anomaly_pack.get("recent_mean_anom_az", np.zeros((0, 0), dtype=np.float64)), dtype=np.float64)
    sel = np.asarray(anomaly_pack.get("recent_mean_anom_el", np.zeros((0, 0), dtype=np.float64)), dtype=np.float64)
    if saz.size == 0 or sel.size == 0:
        return out
    slot_idx = core.compute_slot_index(pred_unix)
    day_idx = slot_idx // int(core.MINUTES_PER_DAY)
    phase_idx = slot_idx % int(core.MINUTES_PER_DAY)
    pred_years = _compute_local_year(pred_unix)
    gap = np.maximum(1, pred_years - int(latest_train_year))
    alpha = float(RECENT_ANOMALY_ALPHA) * np.power(0.8, np.maximum(0, gap - 1))
    out[:, 0] = np.mod(out[:, 0] + alpha * saz[day_idx, phase_idx] + 360.0, 360.0)
    out[:, 1] = np.clip(out[:, 1] + alpha * sel[day_idx, phase_idx], -90.0, 90.0)
    return out


def _build_surface_lowrank_basis(
    day_h: int = SURFACE_FORECAST_DAY_H,
    phase_h: int = SURFACE_FORECAST_PHASE_H,
    cross_h: int = SURFACE_FORECAST_CROSS_H,
) -> np.ndarray:
    day = np.arange(int(core.COMMON_DAYS_PER_YEAR), dtype=np.float64)
    phase = np.arange(int(core.MINUTES_PER_DAY), dtype=np.float64)
    day_phi = 2.0 * math.pi * day / float(core.COMMON_DAYS_PER_YEAR)
    phase_phi = 2.0 * math.pi * phase / float(core.MINUTES_PER_DAY)
    feats: List[np.ndarray] = [np.ones((int(core.COMMON_DAYS_PER_YEAR), int(core.MINUTES_PER_DAY)), dtype=np.float64)]
    day_sin: List[np.ndarray] = []
    day_cos: List[np.ndarray] = []
    phase_sin: List[np.ndarray] = []
    phase_cos: List[np.ndarray] = []
    for k in range(1, int(day_h) + 1):
        ss = np.sin(float(k) * day_phi)[:, None].repeat(int(core.MINUTES_PER_DAY), axis=1)
        cc = np.cos(float(k) * day_phi)[:, None].repeat(int(core.MINUTES_PER_DAY), axis=1)
        feats.extend([ss, cc])
        day_sin.append(ss)
        day_cos.append(cc)
    for k in range(1, int(phase_h) + 1):
        ss = np.sin(float(k) * phase_phi)[None, :].repeat(int(core.COMMON_DAYS_PER_YEAR), axis=0)
        cc = np.cos(float(k) * phase_phi)[None, :].repeat(int(core.COMMON_DAYS_PER_YEAR), axis=0)
        feats.extend([ss, cc])
        phase_sin.append(ss)
        phase_cos.append(cc)
    for ai in range(min(int(cross_h), len(day_sin))):
        for bi in range(min(int(cross_h), len(phase_sin))):
            feats.extend(
                [
                    day_sin[ai] * phase_sin[bi],
                    day_sin[ai] * phase_cos[bi],
                    day_cos[ai] * phase_sin[bi],
                    day_cos[ai] * phase_cos[bi],
                ]
            )
    return np.column_stack([x.reshape(-1) for x in feats]).astype(np.float64)


def _fit_surface_lowrank_coeff(surface: np.ndarray, basis: np.ndarray) -> np.ndarray:
    y = np.asarray(surface, dtype=np.float64).reshape(-1)
    return _solve_small_ridge(basis, y, SURFACE_FORECAST_RIDGE).astype(np.float64)


def _reconstruct_surface_lowrank(coeff: np.ndarray, basis: np.ndarray) -> np.ndarray:
    surf = basis @ np.asarray(coeff, dtype=np.float64).reshape(-1)
    return np.asarray(surf, dtype=np.float64).reshape(int(core.COMMON_DAYS_PER_YEAR), int(core.MINUTES_PER_DAY))


def _forecast_surface_coeff(
    hist: List[np.ndarray],
    method: str,
    beta: float,
) -> np.ndarray:
    if not hist:
        raise ValueError("surface coeff history is empty")
    if str(method) == "last" or len(hist) < 2:
        return np.asarray(hist[-1], dtype=np.float64)
    return np.asarray(hist[-1], dtype=np.float64) + float(beta) * (
        np.asarray(hist[-1], dtype=np.float64) - np.asarray(hist[-2], dtype=np.float64)
    )


def _surface_agreement_gate(
    last_surface: np.ndarray,
    prev_surface: np.ndarray,
    tau: float,
) -> np.ndarray:
    if not np.isfinite(float(tau)) or float(tau) <= 0.0:
        return np.ones_like(last_surface, dtype=np.float64)
    diff = np.abs(np.asarray(last_surface, dtype=np.float64) - np.asarray(prev_surface, dtype=np.float64))
    return np.exp(-diff / float(tau))


def _fit_surface_forecast_model(records: List[Dict[str, np.ndarray]]) -> Dict[str, np.ndarray | float | str] | None:
    if len(records) < 2:
        return None
    basis = _build_surface_lowrank_basis()
    rec_sorted = sorted(records, key=lambda r: int(np.asarray(r["year"], dtype=np.int32).reshape(-1)[0]))
    years: List[int] = []
    coeff_hist_az: List[np.ndarray] = []
    coeff_hist_el: List[np.ndarray] = []
    surfaces: List[Dict[str, np.ndarray]] = []
    for rec in rec_sorted:
        extra = _extract_day_curve_and_anomaly(
            unix=np.asarray(rec["unix"], dtype=np.float64),
            true_azel=np.asarray(rec["true_azel"], dtype=np.float64),
            pred_azel=np.asarray(rec["pred_azel"], dtype=np.float64),
        )
        surf_az = np.asarray(extra["curve_az"], dtype=np.float64)[:, None] + np.asarray(extra["anom_az"], dtype=np.float64)
        surf_el = np.asarray(extra["curve_el"], dtype=np.float64)[:, None] + np.asarray(extra["anom_el"], dtype=np.float64)
        years.append(int(np.asarray(rec["year"], dtype=np.int32).reshape(-1)[0]))
        coeff_hist_az.append(_fit_surface_lowrank_coeff(surf_az, basis))
        coeff_hist_el.append(_fit_surface_lowrank_coeff(surf_el, basis))
        surfaces.append({"az": surf_az, "el": surf_el})

    best_pack = None
    best_score = None
    for method, beta in [("last", 0.0), ("trend", -0.5), ("trend", 0.0), ("trend", 0.25), ("trend", 0.5), ("trend", 0.75), ("trend", 1.0)]:
        for alpha in (0.05, 0.10, 0.15, 0.20, 0.25, 0.30):
            for cap_az in (0.08, 0.10, 0.12, 0.15):
                for cap_el in (0.06, 0.08, 0.10, 0.12):
                    for tau in (0.03, 0.05, 0.08, 0.12, 0.20, 1.0e9):
                        metrics_list: List[Dict[str, Dict[str, float]]] = []
                        for idx, rec in enumerate(rec_sorted):
                            hist_az = coeff_hist_az[:idx]
                            hist_el = coeff_hist_el[:idx]
                            if not hist_az:
                                continue
                            coeff_pred_az = _forecast_surface_coeff(hist_az, method=method, beta=beta)
                            coeff_pred_el = _forecast_surface_coeff(hist_el, method=method, beta=beta)
                            surf_pred_az = _reconstruct_surface_lowrank(coeff_pred_az, basis)
                            surf_pred_el = _reconstruct_surface_lowrank(coeff_pred_el, basis)
                            if len(hist_az) >= 2:
                                surf_last_az = _reconstruct_surface_lowrank(np.asarray(hist_az[-1], dtype=np.float64), basis)
                                surf_prev_az = _reconstruct_surface_lowrank(np.asarray(hist_az[-2], dtype=np.float64), basis)
                                surf_last_el = _reconstruct_surface_lowrank(np.asarray(hist_el[-1], dtype=np.float64), basis)
                                surf_prev_el = _reconstruct_surface_lowrank(np.asarray(hist_el[-2], dtype=np.float64), basis)
                                gate_az = _surface_agreement_gate(surf_last_az, surf_prev_az, tau=float(tau))
                                gate_el = _surface_agreement_gate(surf_last_el, surf_prev_el, tau=float(tau))
                            else:
                                gate_az = np.ones_like(surf_pred_az, dtype=np.float64)
                                gate_el = np.ones_like(surf_pred_el, dtype=np.float64)
                            slot_idx = core.compute_slot_index(np.asarray(rec["unix"], dtype=np.float64))
                            day_idx = slot_idx // int(core.MINUTES_PER_DAY)
                            phase_idx = slot_idx % int(core.MINUTES_PER_DAY)
                            pred = np.asarray(rec["pred_azel"], dtype=np.float64).copy()
                            pred[:, 0] = np.mod(
                                pred[:, 0]
                                + float(alpha)
                                * gate_az[day_idx, phase_idx]
                                * np.clip(surf_pred_az[day_idx, phase_idx], -float(cap_az), float(cap_az))
                                + 360.0,
                                360.0,
                            )
                            pred[:, 1] = np.clip(
                                pred[:, 1]
                                + float(alpha)
                                * gate_el[day_idx, phase_idx]
                                * np.clip(surf_pred_el[day_idx, phase_idx], -float(cap_el), float(cap_el)),
                                -90.0,
                                90.0,
                            )
                            metrics_list.append(
                                compute_azel_metrics(
                                    np.asarray(rec["true_azel"], dtype=np.float64),
                                    pred,
                                )
                            )
                        if not metrics_list:
                            continue
                        merged = _merge_forward_metrics(metrics_list)
                        score = robust_forward_score(metrics_list)
                        if best_score is None or float(score) < float(best_score):
                            best_score = float(score)
                            best_pack = {
                                "years": np.asarray(years, dtype=np.int32),
                                "coeff_hist_az": np.stack(coeff_hist_az, axis=0).astype(np.float64),
                                "coeff_hist_el": np.stack(coeff_hist_el, axis=0).astype(np.float64),
                                "method": str(method),
                                "beta": float(beta),
                                "alpha": float(alpha),
                                "cap_az_deg": float(cap_az),
                                "cap_el_deg": float(cap_el),
                                "tau": float(tau),
                                "day_h": int(SURFACE_FORECAST_DAY_H),
                                "phase_h": int(SURFACE_FORECAST_PHASE_H),
                                "cross_h": int(SURFACE_FORECAST_CROSS_H),
                                "forward_metrics": merged,
                                "selection_score": float(score),
                            }
    return best_pack


def apply_surface_forecast_model(
    pred_unix: np.ndarray,
    pred_azel: np.ndarray,
    surface_model: Dict[str, np.ndarray | float | str] | None,
    latest_train_year: int,
) -> np.ndarray:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if surface_model is None:
        return out
    coeff_hist_az = [np.asarray(x, dtype=np.float64) for x in np.asarray(surface_model.get("coeff_hist_az", np.zeros((0, 0), dtype=np.float64)), dtype=np.float64)]
    coeff_hist_el = [np.asarray(x, dtype=np.float64) for x in np.asarray(surface_model.get("coeff_hist_el", np.zeros((0, 0), dtype=np.float64)), dtype=np.float64)]
    if not coeff_hist_az or not coeff_hist_el:
        return out
    method = str(surface_model.get("method", "last"))
    beta = float(surface_model.get("beta", 0.0))
    alpha = float(surface_model.get("alpha", 0.0))
    cap_az = float(surface_model.get("cap_az_deg", 0.0))
    cap_el = float(surface_model.get("cap_el_deg", 0.0))
    tau = float(surface_model.get("tau", 1.0e9))
    basis = _build_surface_lowrank_basis(
        day_h=int(surface_model.get("day_h", SURFACE_FORECAST_DAY_H)),
        phase_h=int(surface_model.get("phase_h", SURFACE_FORECAST_PHASE_H)),
        cross_h=int(surface_model.get("cross_h", SURFACE_FORECAST_CROSS_H)),
    )
    pred_years = _compute_local_year(pred_unix)
    slot_idx = core.compute_slot_index(pred_unix)
    day_idx = slot_idx // int(core.MINUTES_PER_DAY)
    phase_idx = slot_idx % int(core.MINUTES_PER_DAY)
    hist_az = list(coeff_hist_az)
    hist_el = list(coeff_hist_el)
    for yy in sorted(int(v) for v in np.unique(pred_years)):
        if yy <= int(latest_train_year):
            continue
        coeff_pred_az = _forecast_surface_coeff(hist_az, method=method, beta=beta)
        coeff_pred_el = _forecast_surface_coeff(hist_el, method=method, beta=beta)
        surf_pred_az = _reconstruct_surface_lowrank(coeff_pred_az, basis)
        surf_pred_el = _reconstruct_surface_lowrank(coeff_pred_el, basis)
        if len(hist_az) >= 2:
            surf_last_az = _reconstruct_surface_lowrank(np.asarray(hist_az[-1], dtype=np.float64), basis)
            surf_prev_az = _reconstruct_surface_lowrank(np.asarray(hist_az[-2], dtype=np.float64), basis)
            surf_last_el = _reconstruct_surface_lowrank(np.asarray(hist_el[-1], dtype=np.float64), basis)
            surf_prev_el = _reconstruct_surface_lowrank(np.asarray(hist_el[-2], dtype=np.float64), basis)
            gate_az = _surface_agreement_gate(surf_last_az, surf_prev_az, tau=tau)
            gate_el = _surface_agreement_gate(surf_last_el, surf_prev_el, tau=tau)
        else:
            gate_az = np.ones_like(surf_pred_az, dtype=np.float64)
            gate_el = np.ones_like(surf_pred_el, dtype=np.float64)
        mask = pred_years == int(yy)
        gap = max(1, int(yy - latest_train_year))
        alpha_eff = float(alpha) * (float(SURFACE_FORECAST_FUTURE_DECAY) ** max(0, gap - 1))
        out[mask, 0] = np.mod(
            out[mask, 0]
            + alpha_eff
            * gate_az[day_idx[mask], phase_idx[mask]]
            * np.clip(surf_pred_az[day_idx[mask], phase_idx[mask]], -cap_az, cap_az)
            + 360.0,
            360.0,
        )
        out[mask, 1] = np.clip(
            out[mask, 1]
            + alpha_eff
            * gate_el[day_idx[mask], phase_idx[mask]]
            * np.clip(surf_pred_el[day_idx[mask], phase_idx[mask]], -cap_el, cap_el),
            -90.0,
            90.0,
        )
        hist_az.append(coeff_pred_az.astype(np.float64))
        hist_el.append(coeff_pred_el.astype(np.float64))
    return out


def apply_slot_residual(
    pred_unix: np.ndarray,
    pred_azel: np.ndarray,
    slot_pack: Dict[str, np.ndarray | float] | None,
    latest_train_year: int,
    cfg: LLAPhysicalConfig,
) -> np.ndarray:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if slot_pack is None:
        return out
    slot_idx = core.compute_slot_index(pred_unix)
    pred_years = _compute_local_year(pred_unix)
    alpha_base = float(slot_pack.get("slot_alpha", cfg.slot_alpha))
    saz = np.asarray(slot_pack["slot_az_bias_deg"], dtype=np.float64)
    sel = np.asarray(slot_pack["slot_el_bias_deg"], dtype=np.float64)
    gap = np.maximum(1, pred_years - int(latest_train_year))
    alpha = alpha_base * np.power(float(cfg.future_alpha_decay), np.maximum(0, gap - 1))
    corr_az = saz[slot_idx]
    corr_el = sel[slot_idx]
    out[:, 0] = np.mod(out[:, 0] + alpha * corr_az + 360.0, 360.0)
    out[:, 1] = np.clip(out[:, 1] + alpha * corr_el, -90.0, 90.0)
    return out


def fit_and_select_model(
    year_data: Dict[int, Tuple[np.ndarray, np.ndarray, np.ndarray]],
    train_years: Iterable[int],
    observer_lat: float,
    observer_lon: float,
    observer_alt_m: float,
    candidate_cfgs: List[LLAPhysicalConfig] | None = None,
) -> Tuple[Dict[str, np.ndarray | float | Dict[str, float]], Dict[str, object]]:
    years = sorted(int(y) for y in train_years)
    if len(years) < 4:
        raise RuntimeError("LLA physical model requires at least 4 yearly CSVs.")
    base_cfg = (candidate_cfgs or default_candidate_cfgs())[0]
    fit_recent_years = max(3, int(base_cfg.fit_recent_years))
    active_years = years[-fit_recent_years:]
    if len(active_years) < 4:
        active_years = years
    holdout_year = int(years[-1])
    if holdout_year not in active_years:
        holdout_year = int(active_years[-1])
    hist_years = [yy for yy in active_years if yy < holdout_year]
    candidates = candidate_cfgs or default_candidate_cfgs()
    search_year_data = _downsample_year_data(year_data, stride=5)
    eval_targets = [yy for yy in active_years if len([pp for pp in active_years if pp < yy]) >= 2]

    best_pack = None
    best_meta = None
    for cfg in candidates:
        coef_all = fit_all_year_coefficients(year_data=search_year_data, years=active_years, cfg=cfg)
        forward_metrics: List[Dict[str, Dict[str, float]]] = []
        prior_forward_records: List[Dict[str, np.ndarray]] = []
        for target_year in eval_targets:
            hist = [yy for yy in active_years if yy < int(target_year)]
            coef_target = extrapolate_year_coefficients(
                coef_by_year=coef_all,
                train_years=hist,
                pred_year=int(target_year),
                cfg=cfg,
            )
            unix_val, true_azel_val, _ = search_year_data[int(target_year)]
            pred_raw, lla_val = predict_from_coefficients(
                unix=unix_val,
                coef=coef_target,
                cfg=cfg,
                observer_lat=observer_lat,
                observer_lon=observer_lon,
                observer_alt_m=observer_alt_m,
            )
            targets = _candidate_forward_targets(hist, holdout_year=int(target_year), n_recent=cfg.residual_recent_targets)
            slot_pack = _build_slot_residual_pack(
                year_data=search_year_data,
                coef_by_year=coef_all,
                train_years=hist,
                forward_targets=targets,
                cfg=cfg,
                observer_lat=observer_lat,
                observer_lon=observer_lon,
                observer_alt_m=observer_alt_m,
            )
            pred_val = apply_slot_residual(
                pred_unix=unix_val,
                pred_azel=pred_raw,
                slot_pack=slot_pack,
                latest_train_year=max(hist),
                cfg=cfg,
            )
            pred_val = apply_overlay_surface(
                pred_unix=unix_val,
                pred_azel=pred_val,
                slot_pack=slot_pack,
                cfg=cfg,
            )
            day_model = _fit_day_curve_model(prior_forward_records, cfg)
            pred_val = apply_day_curve_model(
                pred_unix=unix_val,
                pred_azel=pred_val,
                pred_lla=lla_val,
                model=day_model,
                cfg=cfg,
            )
            forward_metrics.append(compute_azel_metrics(true_azel_val, pred_val))
            prior_forward_records.append(
                {
                    "unix": np.asarray(unix_val, dtype=np.float64),
                    "true_azel": np.asarray(true_azel_val, dtype=np.float64),
                    "pred_azel": np.asarray(pred_val, dtype=np.float64),
                    "pred_lla": np.asarray(lla_val, dtype=np.float64),
                }
            )

        metrics = _merge_forward_metrics(forward_metrics)
        score = robust_forward_score(forward_metrics)
        if best_meta is None or score < float(best_meta["score"]):
            best_pack = {
                "config": cfg_to_dict(cfg),
                "coef_hist": coef_all,
                "holdout_year": int(holdout_year),
            }
            best_meta = {
                "score": float(score),
                "holdout_metrics_azel": forward_metrics[-1],
                "forward_mean_metrics_azel": metrics,
                "forward_selection_score": float(score),
                "holdout_year": int(holdout_year),
                "selected_cfg": cfg_to_dict(cfg),
                "forward_eval_targets": [int(x) for x in eval_targets],
                "selection_objective": "robust_forward_score",
            }

    if best_pack is None or best_meta is None:
        raise RuntimeError("No LLA physical model candidate succeeded.")

    best_cfg = cfg_from_dict(best_pack["config"])
    coef_full = fit_all_year_coefficients(year_data=year_data, years=active_years, cfg=best_cfg)
    final_targets = _candidate_forward_targets(active_years, holdout_year=10**9, n_recent=best_cfg.residual_recent_targets)
    final_slot_pack = _build_slot_residual_pack(
        year_data=year_data,
        coef_by_year=coef_full,
        train_years=active_years,
        forward_targets=final_targets,
        cfg=best_cfg,
        observer_lat=observer_lat,
        observer_lon=observer_lon,
        observer_alt_m=observer_alt_m,
    )
    final_day_records: List[Dict[str, np.ndarray]] = []
    for target_year in eval_targets:
        hist = [yy for yy in active_years if yy < int(target_year)]
        coef_target = extrapolate_year_coefficients(
            coef_by_year=coef_full,
            train_years=hist,
            pred_year=int(target_year),
            cfg=best_cfg,
        )
        unix_val, true_azel_val, _ = year_data[int(target_year)]
        pred_raw, lla_val = predict_from_coefficients(
            unix=unix_val,
            coef=coef_target,
            cfg=best_cfg,
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            observer_alt_m=observer_alt_m,
        )
        targets = _candidate_forward_targets(hist, holdout_year=int(target_year), n_recent=best_cfg.residual_recent_targets)
        slot_pack = _build_slot_residual_pack(
            year_data=year_data,
            coef_by_year=coef_full,
            train_years=hist,
            forward_targets=targets,
            cfg=best_cfg,
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            observer_alt_m=observer_alt_m,
        )
        pred_val = apply_slot_residual(
            pred_unix=unix_val,
            pred_azel=pred_raw,
            slot_pack=slot_pack,
            latest_train_year=max(hist),
            cfg=best_cfg,
        )
        pred_val = apply_overlay_surface(
            pred_unix=unix_val,
            pred_azel=pred_val,
            slot_pack=slot_pack,
            cfg=best_cfg,
        )
        day_model = _fit_day_curve_model(final_day_records, best_cfg)
        pred_val = apply_day_curve_model(
            pred_unix=unix_val,
            pred_azel=pred_val,
            pred_lla=lla_val,
            model=day_model,
            cfg=best_cfg,
        )
        final_day_records.append(
            {
                "year": np.asarray([int(target_year)], dtype=np.int32),
                "unix": np.asarray(unix_val, dtype=np.float64),
                "true_azel": np.asarray(true_azel_val, dtype=np.float64),
                "pred_azel": np.asarray(pred_val, dtype=np.float64),
                "pred_lla": np.asarray(lla_val, dtype=np.float64),
            }
        )
    final_day_model = _fit_day_curve_model(final_day_records, best_cfg)
    prev_curve_day_model = _fit_prev_curve_day_model(final_day_records)
    surface_records: List[Dict[str, np.ndarray]] = []
    for target_year in eval_targets:
        hist = [yy for yy in active_years if yy < int(target_year)]
        coef_target = extrapolate_year_coefficients(
            coef_by_year=coef_full,
            train_years=hist,
            pred_year=int(target_year),
            cfg=best_cfg,
        )
        unix_val, true_azel_val, _ = year_data[int(target_year)]
        pred_raw, lla_val = predict_from_coefficients(
            unix=unix_val,
            coef=coef_target,
            cfg=best_cfg,
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            observer_alt_m=observer_alt_m,
        )
        targets = _candidate_forward_targets(hist, holdout_year=int(target_year), n_recent=best_cfg.residual_recent_targets)
        slot_pack = _build_slot_residual_pack(
            year_data=year_data,
            coef_by_year=coef_full,
            train_years=hist,
            forward_targets=targets,
            cfg=best_cfg,
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            observer_alt_m=observer_alt_m,
        )
        pred_val = apply_slot_residual(
            pred_unix=unix_val,
            pred_azel=pred_raw,
            slot_pack=slot_pack,
            latest_train_year=max(hist),
            cfg=best_cfg,
        )
        pred_val = apply_overlay_surface(
            pred_unix=unix_val,
            pred_azel=pred_val,
            slot_pack=slot_pack,
            cfg=best_cfg,
        )
        day_model = _fit_day_curve_model(surface_records, best_cfg)
        pred_val = apply_day_curve_model(
            pred_unix=unix_val,
            pred_azel=pred_val,
            pred_lla=lla_val,
            model=day_model,
            cfg=best_cfg,
        )
        prev_model = _fit_prev_curve_day_model(surface_records)
        if prev_model is not None:
            pred_val, _ = apply_prev_curve_day_model(
                pred_unix=unix_val,
                pred_azel=pred_val,
                pred_lla=lla_val,
                model=prev_model,
                latest_train_year=max(hist),
            )
            pred_val = apply_recent_anomaly_surface(
                pred_unix=unix_val,
                pred_azel=pred_val,
                anomaly_pack=prev_model,
                latest_train_year=max(hist),
            )
        surface_records.append(
            {
                "year": np.asarray([int(target_year)], dtype=np.int32),
                "unix": np.asarray(unix_val, dtype=np.float64),
                "true_azel": np.asarray(true_azel_val, dtype=np.float64),
                "pred_azel": np.asarray(pred_val, dtype=np.float64),
                "pred_lla": np.asarray(lla_val, dtype=np.float64),
            }
        )
    surface_forecast_model = _fit_surface_forecast_model(surface_records)
    final_pack = {
        "config": cfg_to_dict(best_cfg),
        "years": np.asarray(active_years, dtype=np.int32),
        "coef_lat": np.stack([coef_full[y]["lat"] for y in active_years], axis=0).astype(np.float64),
        "coef_lon_s": np.stack([coef_full[y]["lon_s"] for y in active_years], axis=0).astype(np.float64),
        "coef_lon_c": np.stack([coef_full[y]["lon_c"] for y in active_years], axis=0).astype(np.float64),
        "coef_alt": np.stack([coef_full[y]["alt"] for y in active_years], axis=0).astype(np.float64),
        "slot_az_bias_deg": np.asarray(final_slot_pack["slot_az_bias_deg"], dtype=np.float64),
        "slot_el_bias_deg": np.asarray(final_slot_pack["slot_el_bias_deg"], dtype=np.float64),
        "slot_weight": np.asarray(final_slot_pack["slot_weight"], dtype=np.float64),
        "overlay_az_bias_deg_2d": np.asarray(final_slot_pack["overlay_az_bias_deg_2d"], dtype=np.float64),
        "overlay_el_bias_deg_2d": np.asarray(final_slot_pack["overlay_el_bias_deg_2d"], dtype=np.float64),
        "overlay_weight_2d": np.asarray(final_slot_pack["overlay_weight_2d"], dtype=np.float64),
        "overlay_alpha": np.asarray([float(final_slot_pack["overlay_alpha"])], dtype=np.float64),
        "slot_alpha": np.asarray([float(final_slot_pack["slot_alpha"])], dtype=np.float64),
        "forward_targets": np.asarray(final_targets, dtype=np.int32),
        "day_curve_coef_az": np.asarray(final_day_model["coef_az"], dtype=np.float64) if final_day_model is not None else np.zeros((0,), dtype=np.float64),
        "day_curve_coef_el": np.asarray(final_day_model["coef_el"], dtype=np.float64) if final_day_model is not None else np.zeros((0,), dtype=np.float64),
        "prev_curve_day_coef_az": np.asarray(prev_curve_day_model["coef_az"], dtype=np.float64) if prev_curve_day_model is not None else np.zeros((0,), dtype=np.float64),
        "prev_curve_day_coef_el": np.asarray(prev_curve_day_model["coef_el"], dtype=np.float64) if prev_curve_day_model is not None else np.zeros((0,), dtype=np.float64),
        "prev_curve_recent_years": np.asarray(prev_curve_day_model["recent_years"], dtype=np.int32) if prev_curve_day_model is not None else np.zeros((0,), dtype=np.int32),
        "prev_curve_recent_curve_az": np.asarray(prev_curve_day_model["recent_curve_az"], dtype=np.float64) if prev_curve_day_model is not None else np.zeros((0, int(core.COMMON_DAYS_PER_YEAR)), dtype=np.float64),
        "prev_curve_recent_curve_el": np.asarray(prev_curve_day_model["recent_curve_el"], dtype=np.float64) if prev_curve_day_model is not None else np.zeros((0, int(core.COMMON_DAYS_PER_YEAR)), dtype=np.float64),
        "recent_mean_anom_az": np.asarray(prev_curve_day_model["recent_mean_anom_az"], dtype=np.float64) if prev_curve_day_model is not None else np.zeros((0, 0), dtype=np.float64),
        "recent_mean_anom_el": np.asarray(prev_curve_day_model["recent_mean_anom_el"], dtype=np.float64) if prev_curve_day_model is not None else np.zeros((0, 0), dtype=np.float64),
        "surface_forecast_years": np.asarray(surface_forecast_model["years"], dtype=np.int32) if surface_forecast_model is not None else np.zeros((0,), dtype=np.int32),
        "surface_forecast_coeff_hist_az": np.asarray(surface_forecast_model["coeff_hist_az"], dtype=np.float64) if surface_forecast_model is not None else np.zeros((0, 0), dtype=np.float64),
        "surface_forecast_coeff_hist_el": np.asarray(surface_forecast_model["coeff_hist_el"], dtype=np.float64) if surface_forecast_model is not None else np.zeros((0, 0), dtype=np.float64),
        "surface_forecast_method_code": np.asarray([0 if surface_forecast_model is None or str(surface_forecast_model["method"]) == "last" else 1], dtype=np.int32),
        "surface_forecast_beta": np.asarray([float(surface_forecast_model["beta"])], dtype=np.float64) if surface_forecast_model is not None else np.asarray([0.0], dtype=np.float64),
        "surface_forecast_alpha": np.asarray([float(surface_forecast_model["alpha"])], dtype=np.float64) if surface_forecast_model is not None else np.asarray([0.0], dtype=np.float64),
        "surface_forecast_cap_az_deg": np.asarray([float(surface_forecast_model["cap_az_deg"])], dtype=np.float64) if surface_forecast_model is not None else np.asarray([0.0], dtype=np.float64),
        "surface_forecast_cap_el_deg": np.asarray([float(surface_forecast_model["cap_el_deg"])], dtype=np.float64) if surface_forecast_model is not None else np.asarray([0.0], dtype=np.float64),
        "surface_forecast_tau": np.asarray([float(surface_forecast_model["tau"])], dtype=np.float64) if surface_forecast_model is not None else np.asarray([1.0e9], dtype=np.float64),
        "surface_forecast_day_h": np.asarray([int(surface_forecast_model["day_h"])], dtype=np.int32) if surface_forecast_model is not None else np.asarray([int(SURFACE_FORECAST_DAY_H)], dtype=np.int32),
        "surface_forecast_phase_h": np.asarray([int(surface_forecast_model["phase_h"])], dtype=np.int32) if surface_forecast_model is not None else np.asarray([int(SURFACE_FORECAST_PHASE_H)], dtype=np.int32),
        "surface_forecast_cross_h": np.asarray([int(surface_forecast_model["cross_h"])], dtype=np.int32) if surface_forecast_model is not None else np.asarray([int(SURFACE_FORECAST_CROSS_H)], dtype=np.int32),
    }
    final_meta = dict(best_meta)
    final_meta["final_forward_targets"] = [int(x) for x in final_targets]
    final_meta["trained_years"] = [int(x) for x in active_years]
    final_meta["use_as_primary_no_tle"] = True
    if surface_forecast_model is not None:
        final_meta["surface_forecast_model"] = {
            "enabled": True,
            "method": str(surface_forecast_model["method"]),
            "beta": float(surface_forecast_model["beta"]),
            "alpha": float(surface_forecast_model["alpha"]),
            "cap_az_deg": float(surface_forecast_model["cap_az_deg"]),
            "cap_el_deg": float(surface_forecast_model["cap_el_deg"]),
            "tau": float(surface_forecast_model["tau"]),
            "forward_metrics": summary_to_jsonable(surface_forecast_model["forward_metrics"]),
        }
    return final_pack, final_meta


def save_model(path: Path, pack: Dict[str, np.ndarray | float | Dict[str, float]]) -> None:
    cfg = cfg_from_dict(pack["config"])
    np.savez_compressed(
        path,
        years=np.asarray(pack["years"], dtype=np.int32),
        coef_lat=np.asarray(pack["coef_lat"], dtype=np.float32),
        coef_lon_s=np.asarray(pack["coef_lon_s"], dtype=np.float32),
        coef_lon_c=np.asarray(pack["coef_lon_c"], dtype=np.float32),
        coef_alt=np.asarray(pack["coef_alt"], dtype=np.float32),
        slot_az_bias_deg=np.asarray(pack["slot_az_bias_deg"], dtype=np.float32),
        slot_el_bias_deg=np.asarray(pack["slot_el_bias_deg"], dtype=np.float32),
        slot_weight=np.asarray(pack["slot_weight"], dtype=np.float32),
        overlay_az_bias_deg_2d=np.asarray(pack["overlay_az_bias_deg_2d"], dtype=np.float32),
        overlay_el_bias_deg_2d=np.asarray(pack["overlay_el_bias_deg_2d"], dtype=np.float32),
        overlay_weight_2d=np.asarray(pack["overlay_weight_2d"], dtype=np.float32),
        overlay_alpha=np.asarray(pack["overlay_alpha"], dtype=np.float32),
        slot_alpha=np.asarray(pack["slot_alpha"], dtype=np.float32),
        forward_targets=np.asarray(pack["forward_targets"], dtype=np.int32),
        sidereal_harmonics=np.asarray([int(cfg.sidereal_harmonics)], dtype=np.int32),
        yearly_harmonics=np.asarray([int(cfg.yearly_harmonics)], dtype=np.int32),
        cross_harmonics=np.asarray([int(cfg.cross_harmonics)], dtype=np.int32),
        ridge=np.asarray([float(cfg.ridge)], dtype=np.float32),
        extrapolation_recent_years=np.asarray([int(cfg.extrapolation_recent_years)], dtype=np.int32),
        fit_recent_years=np.asarray([int(cfg.fit_recent_years)], dtype=np.int32),
        residual_recent_targets=np.asarray([int(cfg.residual_recent_targets)], dtype=np.int32),
        slot_smooth_window=np.asarray([int(cfg.slot_smooth_window)], dtype=np.int32),
        residual_day_smooth_window=np.asarray([int(cfg.residual_day_smooth_window)], dtype=np.int32),
        residual_phase_smooth_window=np.asarray([int(cfg.residual_phase_smooth_window)], dtype=np.int32),
        az_cap_deg=np.asarray([float(cfg.az_cap_deg)], dtype=np.float32),
        el_cap_deg=np.asarray([float(cfg.el_cap_deg)], dtype=np.float32),
        future_alpha_decay=np.asarray([float(cfg.future_alpha_decay)], dtype=np.float32),
        day_curve_ridge=np.asarray([float(cfg.day_curve_ridge)], dtype=np.float32),
        day_curve_cap_deg=np.asarray([float(cfg.day_curve_cap_deg)], dtype=np.float32),
        day_curve_alpha=np.asarray([float(cfg.day_curve_alpha)], dtype=np.float32),
        day_curve_coef_az=np.asarray(pack["day_curve_coef_az"], dtype=np.float32),
        day_curve_coef_el=np.asarray(pack["day_curve_coef_el"], dtype=np.float32),
        prev_curve_day_coef_az=np.asarray(pack["prev_curve_day_coef_az"], dtype=np.float32),
        prev_curve_day_coef_el=np.asarray(pack["prev_curve_day_coef_el"], dtype=np.float32),
        prev_curve_recent_years=np.asarray(pack["prev_curve_recent_years"], dtype=np.int32),
        prev_curve_recent_curve_az=np.asarray(pack["prev_curve_recent_curve_az"], dtype=np.float32),
        prev_curve_recent_curve_el=np.asarray(pack["prev_curve_recent_curve_el"], dtype=np.float32),
        recent_mean_anom_az=np.asarray(pack["recent_mean_anom_az"], dtype=np.float32),
        recent_mean_anom_el=np.asarray(pack["recent_mean_anom_el"], dtype=np.float32),
        surface_forecast_years=np.asarray(pack["surface_forecast_years"], dtype=np.int32),
        surface_forecast_coeff_hist_az=np.asarray(pack["surface_forecast_coeff_hist_az"], dtype=np.float32),
        surface_forecast_coeff_hist_el=np.asarray(pack["surface_forecast_coeff_hist_el"], dtype=np.float32),
        surface_forecast_method_code=np.asarray(pack["surface_forecast_method_code"], dtype=np.int32),
        surface_forecast_beta=np.asarray(pack["surface_forecast_beta"], dtype=np.float32),
        surface_forecast_alpha=np.asarray(pack["surface_forecast_alpha"], dtype=np.float32),
        surface_forecast_cap_az_deg=np.asarray(pack["surface_forecast_cap_az_deg"], dtype=np.float32),
        surface_forecast_cap_el_deg=np.asarray(pack["surface_forecast_cap_el_deg"], dtype=np.float32),
        surface_forecast_tau=np.asarray(pack["surface_forecast_tau"], dtype=np.float32),
        surface_forecast_day_h=np.asarray(pack["surface_forecast_day_h"], dtype=np.int32),
        surface_forecast_phase_h=np.asarray(pack["surface_forecast_phase_h"], dtype=np.int32),
        surface_forecast_cross_h=np.asarray(pack["surface_forecast_cross_h"], dtype=np.int32),
    )


def load_model(path: Path) -> Dict[str, np.ndarray | LLAPhysicalConfig]:
    z = np.load(path)
    cfg = LLAPhysicalConfig(
        sidereal_harmonics=int(np.asarray(z["sidereal_harmonics"]).reshape(-1)[0]),
        yearly_harmonics=int(np.asarray(z["yearly_harmonics"]).reshape(-1)[0]),
        cross_harmonics=int(np.asarray(z["cross_harmonics"]).reshape(-1)[0]),
        ridge=float(np.asarray(z["ridge"]).reshape(-1)[0]),
        extrapolation_recent_years=int(np.asarray(z["extrapolation_recent_years"]).reshape(-1)[0]),
        fit_recent_years=int(np.asarray(z["fit_recent_years"]).reshape(-1)[0]),
        residual_recent_targets=int(np.asarray(z["residual_recent_targets"]).reshape(-1)[0]),
        slot_smooth_window=int(np.asarray(z["slot_smooth_window"]).reshape(-1)[0]),
        residual_day_smooth_window=int(np.asarray(z["residual_day_smooth_window"]).reshape(-1)[0]) if "residual_day_smooth_window" in z else 21,
        residual_phase_smooth_window=int(np.asarray(z["residual_phase_smooth_window"]).reshape(-1)[0]) if "residual_phase_smooth_window" in z else 11,
        slot_alpha=float(np.asarray(z["slot_alpha"]).reshape(-1)[0]),
        overlay_alpha=float(np.asarray(z["overlay_alpha"]).reshape(-1)[0]) if "overlay_alpha" in z else 0.06,
        az_cap_deg=float(np.asarray(z["az_cap_deg"]).reshape(-1)[0]),
        el_cap_deg=float(np.asarray(z["el_cap_deg"]).reshape(-1)[0]),
        future_alpha_decay=float(np.asarray(z["future_alpha_decay"]).reshape(-1)[0]),
        day_curve_ridge=float(np.asarray(z["day_curve_ridge"]).reshape(-1)[0]) if "day_curve_ridge" in z else 1.0e-4,
        day_curve_cap_deg=float(np.asarray(z["day_curve_cap_deg"]).reshape(-1)[0]) if "day_curve_cap_deg" in z else 0.05,
        day_curve_alpha=float(np.asarray(z["day_curve_alpha"]).reshape(-1)[0]) if "day_curve_alpha" in z else 1.0,
    )
    return {
        "config": cfg,
        "years": np.asarray(z["years"], dtype=np.int32),
        "coef_lat": np.asarray(z["coef_lat"], dtype=np.float64),
        "coef_lon_s": np.asarray(z["coef_lon_s"], dtype=np.float64),
        "coef_lon_c": np.asarray(z["coef_lon_c"], dtype=np.float64),
        "coef_alt": np.asarray(z["coef_alt"], dtype=np.float64),
        "slot_az_bias_deg": np.asarray(z["slot_az_bias_deg"], dtype=np.float64),
        "slot_el_bias_deg": np.asarray(z["slot_el_bias_deg"], dtype=np.float64),
        "slot_weight": np.asarray(z["slot_weight"], dtype=np.float64),
        "overlay_az_bias_deg_2d": np.asarray(z["overlay_az_bias_deg_2d"], dtype=np.float64) if "overlay_az_bias_deg_2d" in z else None,
        "overlay_el_bias_deg_2d": np.asarray(z["overlay_el_bias_deg_2d"], dtype=np.float64) if "overlay_el_bias_deg_2d" in z else None,
        "overlay_weight_2d": np.asarray(z["overlay_weight_2d"], dtype=np.float64) if "overlay_weight_2d" in z else None,
        "overlay_alpha": np.asarray(z["overlay_alpha"], dtype=np.float64) if "overlay_alpha" in z else np.asarray([0.0], dtype=np.float64),
        "slot_alpha": np.asarray(z["slot_alpha"], dtype=np.float64),
        "forward_targets": np.asarray(z["forward_targets"], dtype=np.int32),
        "day_curve_coef_az": np.asarray(z["day_curve_coef_az"], dtype=np.float64) if "day_curve_coef_az" in z else np.zeros((0,), dtype=np.float64),
        "day_curve_coef_el": np.asarray(z["day_curve_coef_el"], dtype=np.float64) if "day_curve_coef_el" in z else np.zeros((0,), dtype=np.float64),
        "prev_curve_day_coef_az": np.asarray(z["prev_curve_day_coef_az"], dtype=np.float64) if "prev_curve_day_coef_az" in z else np.zeros((0,), dtype=np.float64),
        "prev_curve_day_coef_el": np.asarray(z["prev_curve_day_coef_el"], dtype=np.float64) if "prev_curve_day_coef_el" in z else np.zeros((0,), dtype=np.float64),
        "prev_curve_recent_years": np.asarray(z["prev_curve_recent_years"], dtype=np.int32) if "prev_curve_recent_years" in z else np.zeros((0,), dtype=np.int32),
        "prev_curve_recent_curve_az": np.asarray(z["prev_curve_recent_curve_az"], dtype=np.float64) if "prev_curve_recent_curve_az" in z else np.zeros((0, int(core.COMMON_DAYS_PER_YEAR)), dtype=np.float64),
        "prev_curve_recent_curve_el": np.asarray(z["prev_curve_recent_curve_el"], dtype=np.float64) if "prev_curve_recent_curve_el" in z else np.zeros((0, int(core.COMMON_DAYS_PER_YEAR)), dtype=np.float64),
        "recent_mean_anom_az": np.asarray(z["recent_mean_anom_az"], dtype=np.float64) if "recent_mean_anom_az" in z else np.zeros((0, 0), dtype=np.float64),
        "recent_mean_anom_el": np.asarray(z["recent_mean_anom_el"], dtype=np.float64) if "recent_mean_anom_el" in z else np.zeros((0, 0), dtype=np.float64),
        "surface_forecast_years": np.asarray(z["surface_forecast_years"], dtype=np.int32) if "surface_forecast_years" in z else np.zeros((0,), dtype=np.int32),
        "surface_forecast_coeff_hist_az": np.asarray(z["surface_forecast_coeff_hist_az"], dtype=np.float64) if "surface_forecast_coeff_hist_az" in z else np.zeros((0, 0), dtype=np.float64),
        "surface_forecast_coeff_hist_el": np.asarray(z["surface_forecast_coeff_hist_el"], dtype=np.float64) if "surface_forecast_coeff_hist_el" in z else np.zeros((0, 0), dtype=np.float64),
        "surface_forecast_method_code": np.asarray(z["surface_forecast_method_code"], dtype=np.int32) if "surface_forecast_method_code" in z else np.asarray([0], dtype=np.int32),
        "surface_forecast_beta": np.asarray(z["surface_forecast_beta"], dtype=np.float64) if "surface_forecast_beta" in z else np.asarray([0.0], dtype=np.float64),
        "surface_forecast_alpha": np.asarray(z["surface_forecast_alpha"], dtype=np.float64) if "surface_forecast_alpha" in z else np.asarray([0.0], dtype=np.float64),
        "surface_forecast_cap_az_deg": np.asarray(z["surface_forecast_cap_az_deg"], dtype=np.float64) if "surface_forecast_cap_az_deg" in z else np.asarray([0.0], dtype=np.float64),
        "surface_forecast_cap_el_deg": np.asarray(z["surface_forecast_cap_el_deg"], dtype=np.float64) if "surface_forecast_cap_el_deg" in z else np.asarray([0.0], dtype=np.float64),
        "surface_forecast_tau": np.asarray(z["surface_forecast_tau"], dtype=np.float64) if "surface_forecast_tau" in z else np.asarray([1.0e9], dtype=np.float64),
        "surface_forecast_day_h": np.asarray(z["surface_forecast_day_h"], dtype=np.int32) if "surface_forecast_day_h" in z else np.asarray([int(SURFACE_FORECAST_DAY_H)], dtype=np.int32),
        "surface_forecast_phase_h": np.asarray(z["surface_forecast_phase_h"], dtype=np.int32) if "surface_forecast_phase_h" in z else np.asarray([int(SURFACE_FORECAST_PHASE_H)], dtype=np.int32),
        "surface_forecast_cross_h": np.asarray(z["surface_forecast_cross_h"], dtype=np.int32) if "surface_forecast_cross_h" in z else np.asarray([int(SURFACE_FORECAST_CROSS_H)], dtype=np.int32),
    }


def predict_with_model(
    model: Dict[str, np.ndarray | LLAPhysicalConfig],
    unix: np.ndarray,
    observer_lat: float,
    observer_lon: float,
    observer_alt_m: float,
) -> Tuple[np.ndarray, np.ndarray]:
    cfg = model["config"]
    if not isinstance(cfg, LLAPhysicalConfig):
        cfg = cfg_from_dict(cfg)
    pred_unix = np.asarray(unix, dtype=np.float64).reshape(-1)
    pred_years = _compute_local_year(pred_unix)
    train_years = [int(x) for x in np.asarray(model["years"], dtype=np.int32).reshape(-1)]
    coef_by_year = {
        int(yy): {
            "lat": np.asarray(model["coef_lat"], dtype=np.float64)[ii],
            "lon_s": np.asarray(model["coef_lon_s"], dtype=np.float64)[ii],
            "lon_c": np.asarray(model["coef_lon_c"], dtype=np.float64)[ii],
            "alt": np.asarray(model["coef_alt"], dtype=np.float64)[ii],
        }
        for ii, yy in enumerate(train_years)
    }
    pred_azel = np.zeros((pred_unix.shape[0], 2), dtype=np.float64)
    pred_lla = np.zeros((pred_unix.shape[0], 3), dtype=np.float64)
    for yy in sorted(int(v) for v in np.unique(pred_years)):
        mask = pred_years == int(yy)
        coef = extrapolate_year_coefficients(coef_by_year=coef_by_year, train_years=train_years, pred_year=int(yy), cfg=cfg)
        azel_y, lla_y = predict_from_coefficients(
            unix=pred_unix[mask],
            coef=coef,
            cfg=cfg,
            observer_lat=observer_lat,
            observer_lon=observer_lon,
            observer_alt_m=observer_alt_m,
        )
        pred_azel[mask] = azel_y
        pred_lla[mask] = lla_y
    pred_azel = apply_slot_residual(
        pred_unix=pred_unix,
        pred_azel=pred_azel,
        slot_pack={
            "slot_az_bias_deg": np.asarray(model["slot_az_bias_deg"], dtype=np.float64),
            "slot_el_bias_deg": np.asarray(model["slot_el_bias_deg"], dtype=np.float64),
            "slot_alpha": float(np.asarray(model["slot_alpha"], dtype=np.float64).reshape(-1)[0]),
            "overlay_az_bias_deg_2d": model.get("overlay_az_bias_deg_2d", None),
            "overlay_el_bias_deg_2d": model.get("overlay_el_bias_deg_2d", None),
            "overlay_alpha": float(np.asarray(model.get("overlay_alpha", np.asarray([0.0], dtype=np.float64)), dtype=np.float64).reshape(-1)[0]),
        },
        latest_train_year=max(train_years),
        cfg=cfg,
    )
    pred_azel = apply_overlay_surface(
        pred_unix=pred_unix,
        pred_azel=pred_azel,
        slot_pack={
            "overlay_az_bias_deg_2d": model.get("overlay_az_bias_deg_2d", None),
            "overlay_el_bias_deg_2d": model.get("overlay_el_bias_deg_2d", None),
            "overlay_alpha": float(np.asarray(model.get("overlay_alpha", np.asarray([0.0], dtype=np.float64)), dtype=np.float64).reshape(-1)[0]),
        },
        cfg=cfg,
    )
    day_curve_coef_az = np.asarray(model.get("day_curve_coef_az", np.zeros((0,), dtype=np.float64)), dtype=np.float64)
    day_curve_coef_el = np.asarray(model.get("day_curve_coef_el", np.zeros((0,), dtype=np.float64)), dtype=np.float64)
    if day_curve_coef_az.size > 0 and day_curve_coef_el.size > 0:
        pred_azel = apply_day_curve_model(
            pred_unix=pred_unix,
            pred_azel=pred_azel,
            pred_lla=pred_lla,
            model={"coef_az": day_curve_coef_az, "coef_el": day_curve_coef_el},
            cfg=cfg,
        )
    prev_curve_day_coef_az = np.asarray(model.get("prev_curve_day_coef_az", np.zeros((0,), dtype=np.float64)), dtype=np.float64)
    prev_curve_day_coef_el = np.asarray(model.get("prev_curve_day_coef_el", np.zeros((0,), dtype=np.float64)), dtype=np.float64)
    if prev_curve_day_coef_az.size > 0 and prev_curve_day_coef_el.size > 0:
        pred_azel, _ = apply_prev_curve_day_model(
            pred_unix=pred_unix,
            pred_azel=pred_azel,
            pred_lla=pred_lla,
            model={
                "coef_az": prev_curve_day_coef_az,
                "coef_el": prev_curve_day_coef_el,
                "recent_curve_az": np.asarray(model.get("prev_curve_recent_curve_az", np.zeros((0, int(core.COMMON_DAYS_PER_YEAR)), dtype=np.float64)), dtype=np.float64),
                "recent_curve_el": np.asarray(model.get("prev_curve_recent_curve_el", np.zeros((0, int(core.COMMON_DAYS_PER_YEAR)), dtype=np.float64)), dtype=np.float64),
            },
            latest_train_year=max(train_years),
        )
        pred_azel = apply_recent_anomaly_surface(
            pred_unix=pred_unix,
            pred_azel=pred_azel,
            anomaly_pack={
                "recent_mean_anom_az": np.asarray(model.get("recent_mean_anom_az", np.zeros((0, 0), dtype=np.float64)), dtype=np.float64),
                "recent_mean_anom_el": np.asarray(model.get("recent_mean_anom_el", np.zeros((0, 0), dtype=np.float64)), dtype=np.float64),
            },
            latest_train_year=max(train_years),
        )
    surface_hist_az = np.asarray(model.get("surface_forecast_coeff_hist_az", np.zeros((0, 0), dtype=np.float64)), dtype=np.float64)
    surface_hist_el = np.asarray(model.get("surface_forecast_coeff_hist_el", np.zeros((0, 0), dtype=np.float64)), dtype=np.float64)
    if surface_hist_az.size > 0 and surface_hist_el.size > 0:
        pred_azel = apply_surface_forecast_model(
            pred_unix=pred_unix,
            pred_azel=pred_azel,
            surface_model={
                "coeff_hist_az": surface_hist_az,
                "coeff_hist_el": surface_hist_el,
                "method": "last" if int(np.asarray(model.get("surface_forecast_method_code", np.asarray([0], dtype=np.int32)), dtype=np.int32).reshape(-1)[0]) == 0 else "trend",
                "beta": float(np.asarray(model.get("surface_forecast_beta", np.asarray([0.0], dtype=np.float64)), dtype=np.float64).reshape(-1)[0]),
                "alpha": float(np.asarray(model.get("surface_forecast_alpha", np.asarray([0.0], dtype=np.float64)), dtype=np.float64).reshape(-1)[0]),
                "cap_az_deg": float(np.asarray(model.get("surface_forecast_cap_az_deg", np.asarray([0.0], dtype=np.float64)), dtype=np.float64).reshape(-1)[0]),
                "cap_el_deg": float(np.asarray(model.get("surface_forecast_cap_el_deg", np.asarray([0.0], dtype=np.float64)), dtype=np.float64).reshape(-1)[0]),
                "tau": float(np.asarray(model.get("surface_forecast_tau", np.asarray([1.0e9], dtype=np.float64)), dtype=np.float64).reshape(-1)[0]),
                "day_h": int(np.asarray(model.get("surface_forecast_day_h", np.asarray([int(SURFACE_FORECAST_DAY_H)], dtype=np.int32)), dtype=np.int32).reshape(-1)[0]),
                "phase_h": int(np.asarray(model.get("surface_forecast_phase_h", np.asarray([int(SURFACE_FORECAST_PHASE_H)], dtype=np.int32)), dtype=np.int32).reshape(-1)[0]),
                "cross_h": int(np.asarray(model.get("surface_forecast_cross_h", np.asarray([int(SURFACE_FORECAST_CROSS_H)], dtype=np.int32)), dtype=np.int32).reshape(-1)[0]),
            },
            latest_train_year=max(train_years),
        )
    return pred_azel.astype(np.float64), pred_lla.astype(np.float64)


def summary_to_jsonable(summary: Dict[str, object]) -> Dict[str, object]:
    return json.loads(json.dumps(summary, ensure_ascii=False, default=float))
