# AGENTS.md

## Project overview

このプロジェクトは、MarineCadastre / AIS Vessel Tracks 由来の航跡データを使い、船舶の過去位置・船舶属性・日時情報から、その後の航跡を予測するAIを構築するプロジェクトである。

主な入力データは、`resampled_3min` フォルダ内の `MMSI_*_resampled_3min.csv` である。各CSVは、MMSI別・`block_id` 別に整理された3分間隔のAIS航跡データで、主に以下の列を持つ。

- `mmsi`
- `block_id`
- `step_index`
- `timestamp`
- `unix_time`
- `lon`
- `lat`
- `vessel_type`
- `length`
- `width`
- `draft`
- `duration_minutes`
- `vessel_group`
- `shape_length`
- `source_geojson`
- `source_file`
- `sequence_id`
- `interpolation_ratio`

現在の中心スクリプトは `ais_seq2seq_resampled3min.py` である。モデルはLSTM Encoder-Decoder型のseq2seqで、過去の航跡系列から未来の `lon, lat` を予測する。

## Project goal

最終ゴールは、過去数十分〜数時間分のAIS航跡と船舶属性を入力し、未来1時間程度の船舶位置をできるだけ高精度に予測することである。

具体的には、以下を達成する。

- MMSI別の3分間隔AIS時系列CSVを学習データとして使用する。
- `mmsi`, `vessel_type`, `length`, `width`, `draft`, `vessel_group`, `timestamp`, `lon`, `lat` を特徴量として活用する。
- 過去の航跡履歴から、未来20ステップ、つまり3分間隔なら未来60分の `lon, lat` を予測する。
- 予測航跡と実航跡をCSVおよび地図画像として比較できるようにする。
- Claude Code / Codex で安全に改修できるよう、変更目的・設計方針・テスト方針を明確にする。

## Current implementation summary

現在の実装は、おおむね以下の処理を行う。

1. `resampled_3min` フォルダ内のMMSI別CSVを読み込む。
2. `block_id` ごとに時系列を分ける。
3. `input_len + pred_len` 以上の長さを持つblockから学習窓を作る。
4. 入力特徴量として以下を使う。
   - `lon`
   - `lat`
   - `dlon`
   - `dlat`
   - `speed_deg_per_min`
   - `vessel_type`
   - `length`
   - `width`
   - `draft`
   - `tod_sin`
   - `tod_cos`
   - `doy_sin`
   - `doy_cos`
5. `mmsi` と `vessel_group` はembeddingとして扱う。
6. 未来位置は、最後の入力点からの `delta_lon, delta_lat` として学習する。
7. 評価指標として `val_mae_km` を出力する。
8. 最良の `val_mae_km` を更新したモデルを `ais_seq2seq.pt` として保存する。

## Known issues

現在の予測結果では、実航跡と予測航跡の間に数百m〜数km程度のズレが出るケースがある。特に、湾内・港湾・航路制約のある場所や、船が旋回している場面で、予測航跡が実航跡の曲がり方を追従できないことがある。

主な問題点は以下である。

### 1. 旋回情報が弱い

現在の特徴量には `dlon`, `dlat`, `speed_deg_per_min` はあるが、方位角や旋回率が明示的に入っていない。

改善候補:

- `speed_kmh`
- `course_sin`
- `course_cos`
- `accel_kmh`
- `turn_rate`
- `turn_sin`
- `turn_cos`

### 2. 速度が度数ベースになっている

現在の `speed_deg_per_min` は緯度経度の度数ベースである。経度1度あたりの距離は緯度によって変わるため、速度特徴としては物理的意味が不安定である。

改善候補:

- `dx_km`
- `dy_km`
- `speed_kmh`

### 3. 予測対象が `delta_lon, delta_lat` である

現在は最後の入力点から未来点までの `delta_lon, delta_lat` を予測している。絶対座標を直接予測するよりはよいが、緯度によって経度方向の距離意味が変化する。

改善候補:

- 最後の入力点を原点とした局所座標 `x_km, y_km` に変換する。
- 未来位置も `future_x_km, future_y_km` として学習する。
- 推論後に `x_km, y_km` を `lon, lat` に戻す。

### 4. 等速直線ベースラインを使っていない

現在のモデルは、未来航跡をニューラルネットワークが直接予測している。短期AIS予測では、最後の数点から算出した一定速度・一定方位の外挿が強いベースラインになる。

改善候補:

- 最後の5〜10点から平均速度ベクトルを求める。
- 一定速度で未来20点を外挿する。
- AIはその外挿航跡からの補正量、つまりresidualを予測する。
- 最終予測を `constant_velocity_baseline + residual` とする。

### 5. 直線航行データに偏りやすい

AISデータの多くは直線的な航行である。普通にランダムサンプリングすると、旋回・減速・港湾内航行などの重要ケースが薄まりやすい。

改善候補:

- 学習窓ごとに `turn_score` を計算する。
- 旋回量が大きい窓を優先的に採用する。
- 直線区間を適度に間引く。
- `turn_score` 別に評価指標を出す。

### 6. `input_len` と評価用CSV長の不整合

`input_len=80`, `pred_len=20`, `interval=3min` のモデルは、過去4時間から未来1時間を予測する設計である。この場合、比較には最低100点、つまり5時間分の連続航跡が必要である。

2時間CSVなど短いセグメントで評価する場合、先頭パディングにより推論は可能だが、学習時の分布と異なるため精度が落ちやすい。

改善候補:

- `input_len=20`, `40`, `80` の複数モデルを作る。
- 2時間セグメントでは `input_len=20, pred_len=20` を使う。
- 5時間セグメントでは `input_len=80, pred_len=20` を使う。
- 直近旋回率が大きい場合は短い入力長モデルを重視する。

### 7. 評価方法が甘くなりやすい

現在の学習コードはwindowを作成した後に `random_split` で学習・検証を分ける。近い時刻や同じMMSIの似た航跡が学習側と検証側に混ざる可能性がある。

改善候補:

- 2016年で学習し、2017年で評価する。
- 2016年1〜9月で学習し、2016年10〜12月で検証する。
- MMSI単位または時系列単位で検証分割する。
- `val_mae_km` だけでなく、外部評価CSVでの `error_km` を重視する。

## Desired improvements

Claude Code / Codex で今後修正する場合、優先順位は以下とする。

### Priority 1: Baseline evaluation

まず、AI予測だけでなく、以下のベースラインを実装して比較する。

- last position hold
- constant velocity
- constant turn rate

出力すべき指標:

- AI MAE km
- constant velocity MAE km
- constant turn rate MAE km
- max error km
- stepごとのerror_km

AIがconstant velocityに負けるケースでは、モデル構造より先に予測方式を見直す。

### Priority 2: Add physical motion features

`prepare_block_features()` を拡張し、以下を追加する。

- `dx_km`
- `dy_km`
- `speed_kmh`
- `course_sin`
- `course_cos`
- `accel_kmh`
- `turn_rate`
- `turn_sin`
- `turn_cos`

この変更では `NUMERIC_FEATURES` も更新する。入力次元が変わるため、既存の `ais_seq2seq.pt` は互換性がなくなる。必ず再学習する。

### Priority 3: Residual prediction against constant velocity baseline

現在の目的変数は `future_abs - anchor` である。これを、一定速度外挿との差分に変更する。

新しい考え方:

```text
baseline_future_xy = constant_velocity_extrapolation(last N points)
target_residual_xy = true_future_xy - baseline_future_xy
model_output       = target_residual_xy
final_prediction   = baseline_future_xy + model_output
```

最初はlon/latベースでもよいが、できれば局所km座標で行う。

### Priority 4: Use local xy km target

最後の入力点を基準に、局所座標を作る。

```text
x_km = east-west distance from anchor
y_km = north-south distance from anchor
```

予測対象も `delta_lon, delta_lat` ではなく `x_km, y_km` または `residual_x_km, residual_y_km` にする。

### Priority 5: Improve sampling

旋回・減速・航路変更の窓を増やす。

実装案:

- 各windowの末尾側で `turn_score` を計算する。
- `turn_score` が大きいwindowを優先採用する。
- 直線航行windowは一定割合で間引く。
- `max_windows` の中で旋回ケースが十分入るようにする。

### Priority 6: Multi-model or ensemble

以下の複数入力長で学習する。

- `input_len=20`, `pred_len=20`
- `input_len=40`, `pred_len=20`
- `input_len=80`, `pred_len=20`

比較時には、以下の方針を検討する。

- 通常時は `input_len=80` を使用。
- 旋回率が大きい場合は `input_len=20` または `input_len=40` を重視。
- 複数モデルの平均または重み付き平均を使う。

## Current useful commands

### Train current stronger model

```bat
python ais_seq2seq_resampled3min.py train ^
  --data-dir timeseries_by_mmsi\resampled_3min ^
  --pattern "MMSI_*_resampled_3min.csv" ^
  --out-dir artifacts_ais_seq2seq_2016_3min_v2 ^
  --input-len 80 ^
  --pred-len 20 ^
  --interval-minutes 3 ^
  --epochs 80 ^
  --batch-size 256 ^
  --hidden-size 256 ^
  --num-layers 3 ^
  --mmsi-emb-dim 32 ^
  --group-emb-dim 16 ^
  --dropout 0.15 ^
  --lr 5e-4 ^
  --weight-decay 1e-5 ^
  --stride 1 ^
  --max-windows 800000 ^
  --teacher-forcing-start 0.8 ^
  --teacher-forcing-end 0.05 ^
  --shuffle-files ^
  --device cuda
```

### Train shorter-context model

```bat
python ais_seq2seq_resampled3min.py train ^
  --data-dir timeseries_by_mmsi\resampled_3min ^
  --pattern "MMSI_*_resampled_3min.csv" ^
  --out-dir artifacts_ais_seq2seq_2016_3min_in40 ^
  --input-len 40 ^
  --pred-len 20 ^
  --interval-minutes 3 ^
  --epochs 80 ^
  --batch-size 256 ^
  --hidden-size 256 ^
  --num-layers 3 ^
  --mmsi-emb-dim 32 ^
  --group-emb-dim 16 ^
  --dropout 0.15 ^
  --lr 5e-4 ^
  --weight-decay 1e-5 ^
  --stride 1 ^
  --max-windows 800000 ^
  --teacher-forcing-start 0.8 ^
  --teacher-forcing-end 0.05 ^
  --shuffle-files ^
  --device cuda
```

### Predict and compare with flexible script

```bat
python predict_compare_plot_ais_flexible.py ^
  --model artifacts_ais_seq2seq_2016_3min_v2\ais_seq2seq.pt ^
  --history-csv path\to\comparison_segment.csv ^
  --out-dir compare_output ^
  --device cuda
```

### Predict only

```bat
python predict_compare_plot_ais_flexible.py ^
  --model artifacts_ais_seq2seq_2016_3min_v2\ais_seq2seq.pt ^
  --history-csv path\to\history.csv ^
  --out-dir predict_output ^
  --predict-only ^
  --device cuda
```

## Development rules for Claude Code / Codex

- 既存の設計方針を勝手に大きく変えない。
- 変更前に、対象ファイルと変更理由を明記する。
- 変更は小さく分割し、1回の修正で複数の大改造を混ぜない。
- 学習済みモデルとの互換性が壊れる変更では、必ずその旨を説明する。
- `NUMERIC_FEATURES`, `TIME_FEATURES`, `X_FEATURES`, `TrainConfig`, `save_checkpoint`, `load_checkpoint` の整合性を壊さない。
- 入力CSVの列名互換性を維持する。列がない場合は安全に0または `UNKNOWN` で補完する。
- WindowsのPowerShell / cmdで動くコマンド例を残す。
- GPU使用時は `--device cuda` を使う。
- APIキー、秘密情報、個人情報をコミットしない。
- 大きなデータファイル、学習済みモデル、生成画像、巨大CSVを不用意にGit管理しない。
- 変更後は最低限、軽量データで `inspect`, `train`, `predict-csv` または比較スクリプトを動作確認する。
- 動作確認コマンドをREADMEまたはこのファイルに追記する。

## Minimum test checklist

変更後は、少なくとも以下を確認する。

### 1. Import check

```bat
python -m py_compile ais_seq2seq_resampled3min.py
python -m py_compile predict_compare_plot_ais_flexible.py
```

### 2. Inspect small dataset

```bat
python ais_seq2seq_resampled3min.py inspect ^
  --data-dir timeseries_by_mmsi\resampled_3min ^
  --pattern "MMSI_*_resampled_3min.csv" ^
  --limit-files 10
```

### 3. Tiny training run

```bat
python ais_seq2seq_resampled3min.py train ^
  --data-dir timeseries_by_mmsi\resampled_3min ^
  --pattern "MMSI_*_resampled_3min.csv" ^
  --out-dir artifacts_test_tiny ^
  --input-len 20 ^
  --pred-len 10 ^
  --interval-minutes 3 ^
  --epochs 1 ^
  --batch-size 32 ^
  --hidden-size 64 ^
  --num-layers 1 ^
  --stride 2 ^
  --max-windows 1000 ^
  --limit-files 50 ^
  --device cuda
```

### 4. Prediction comparison

```bat
python predict_compare_plot_ais_flexible.py ^
  --model artifacts_test_tiny\ais_seq2seq.pt ^
  --history-csv path\to\sample_resampled_3min.csv ^
  --out-dir compare_test ^
  --device cuda ^
  --no-cartopy
```

## Expected outcome

改善後に目指す状態は以下である。

- 直線航行だけでなく、旋回・減速・港湾内航行での予測が改善する。
- AI単体予測がconstant velocity baselineに負けるケースを減らす。
- 予測結果の `MAE km` と `Max error km` が改善する。
- 予測航跡が実航跡の曲がり方により自然に追従する。
- 2016年学習、2017年評価など、年を跨いだ評価でも破綻しにくい。
