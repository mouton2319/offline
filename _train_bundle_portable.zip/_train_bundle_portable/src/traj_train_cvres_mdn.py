#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡予測【multi-horizon 確率版(Laplace混合密度 = MDN)】の学習スクリプト。

土台は traj_train_cvres_mh.py。LRスケジュール(warmup+cosine)・AMP・勾配ガード・
val評価・エポック毎checkpoint保存の機構はそのまま維持し、出力ヘッドと損失だけを
「horizon別 K成分の2次元Laplace混合密度」に置き換える。

=== 背景・狙い(MH版との違い) ===
MH版は各位置から h=1..H の累積CV残差を1点推定(SmoothL1)していた。しかし旋回や
cruise加減速のテールでは分岐(左右どちらか)による二峰性が生じ、点推定の中央値が
モードの谷間(存在しない中間位置)に落ちる。本版は horizon別に K=mdn_k の2次元
Laplace混合を出力し、推論では最大重みモードのμにコミットすることで、谷間ではなく
どちらかのモードにコミットする。さらに最大重み w_max が小さい(不確実な)horizonは
純CVへフォールバックできるようにする(eval_batch.py の --mdn-fallback)。

=== ターゲット定義 ===
MH版と完全に同一。各位置 i(0..L-2)、各 h=1..H について:
  - 累積変位  cum[i,h] = disp[i+1] + ... + disp[i+h]   (km)
  - CV累積    = h * cv[i]
  - ターゲット residual[i,h] = (cum[i,h] - h*cv[i] - mh_res_mean[h]) / mh_res_std[h]
  - 有効マスク: i+h <= L-1
標準化統計(mh_res_mean/std)もMH版と同じものを使う(同じ collate/fit を流用)。

=== 出力・損失(MDN) ===
モデル出力 [B, L, H*K*5] -> view [B, L, H, K, 5]。各成分は
  logit(1) + μ(2) + log_b(2)  (b はLaplaceスケール、log_b で出力し expで正)。
horizon h・成分 k の重み  w_{h,k} = softmax_k(logit_{h,k})。
負対数尤度(有効(i,h)平均):
  Laplace対数尤度  ll_k = Σ_d [ -|y_d - μ_{k,d}| / b_{k,d} - log(2 b_{k,d}) ]   (d=x,y)
  mix_ll = logsumexp_k( log_softmax(logit)_k + ll_k )
  loss   = - mean_{valid(i,h)} mix_ll
数値安定化: log_b を clamp(-4, 4)(b ∈ [0.018, 54.6])。logit はそのまま
(log_softmax が数値安定)。NaNガード(grad_skip機構)は土台のまま維持。

=== val評価(エポック毎) ===
推論復元(eval_batch.py の cv_residual_mdn 分岐と同一式):各val航跡の input_len 点を
モデルに入れ、最終位置の出力 [H,K,5] から各hで w=softmax(logit) の argmaxモードの
μを採用し、mh_res で非標準化 -> dxy_cum[h]=h*cv_last+residual -> 位置化。集計・レジーム
表示はMH版と同一。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\traj_train_cvres_mdn.py `
    --data-dir .\\claude_test\\trajectories_full `
    --out-dir .\\claude_test\\artifacts_mdn `
    --val-dir .\\claude_test\\val500 `
    --cv-n-last 6 --horizon 20 --mdn-k 3 --max-len 256 --batch-size 128 `
    --num-workers 16 --scaler-sample 3000 `
    --d-model 512 --nhead 8 --num-layers 10 --dim-feedforward 2048 `
    --epochs 6 --lr 2e-4 --warmup-steps 1500 --amp --device cuda
"""

from __future__ import annotations

import argparse
import contextlib
import json
import math
import random
import sys
from collections import defaultdict
from dataclasses import asdict
from functools import partial
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parent))
from traj_common import (   # noqa: E402
    TrajConfig, TrajectoryDataset, build_model, fit_stats, list_traj_files,
    cv_disp_from_seq, lonlat_to_disp_km, km_per_deg_lon, KM_PER_DEG_LAT,
)
# ターゲット collate・残差統計・LRスケジュールは MH版のものをそのまま流用
# (ターゲット定義はMDNでも完全に同一)。
from traj_train_cvres_mh import (   # noqa: E402
    collate_cvres_mh, fit_res_stats_mh, make_warmup_cosine_lambda,
)
# val評価は eval_batch.py の前処理・レジーム分類・haversine を再利用。
from eval_batch import (   # noqa: E402
    read_traj, classify_regime, rollout_cv_single, haversine_km_arr,
)


# === MDN 損失(2次元Laplace混合の負対数尤度)==================================
# log_b のクランプ範囲。b=exp(log_b) ∈ [exp(-4), exp(4)] = [0.0183, 54.6]。
# 標準化残差スケール(std≈1)に対し十分広い範囲を確保しつつ、b->0 の発散を防ぐ。
LOG_B_MIN = -4.0
LOG_B_MAX = 4.0


def mdn_nll(pred, y, valid, H, K):
    """horizon別 K成分の2次元Laplace混合の負対数尤度(有効(i,h)平均)を返す。

    pred : [B, L, H*K*5]  (view -> [B,L,H,K,5]: logit,μx,μy,log_bx,log_by)
    y    : [B, L, H, 2]   (標準化済み累積CV残差ターゲット)
    valid: [B, L, H]      (bool マスク)
    戻り値: スカラー損失(有効(i,h)が無ければ 0)。

    mix_ll = logsumexp_k( log_softmax(logit)_k + Σ_d[-|y_d-μ_{k,d}|/b_{k,d} - log(2 b_{k,d})] )
    loss   = - mean_{valid} mix_ll
    """
    B, L, _ = pred.shape
    p = pred.view(B, L, H, K, 5)
    logit = p[..., 0]                                   # [B,L,H,K]
    mu = p[..., 1:3]                                    # [B,L,H,K,2]
    log_b = p[..., 3:5].clamp(LOG_B_MIN, LOG_B_MAX)     # [B,L,H,K,2] 数値安定化
    b = torch.exp(log_b)

    yb = y.unsqueeze(3)                                 # [B,L,H,1,2] -> ブロードキャスト
    # 成分ごとの Laplace 対数尤度(次元和)
    #   -|y-μ|/b - log(2b) を d=x,y で合算
    comp_ll = (-(yb - mu).abs() / b - torch.log(2.0 * b)).sum(dim=-1)   # [B,L,H,K]
    logw = F.log_softmax(logit, dim=-1)                 # [B,L,H,K] 混合重みの対数
    mix_ll = torch.logsumexp(logw + comp_ll, dim=-1)    # [B,L,H] 混合の対数尤度

    m = valid.float()                                   # [B,L,H]
    nll = -(mix_ll * m).sum() / m.sum().clamp_min(1.0)  # 有効(i,h)平均の負対数尤度
    return nll


def mdn_argmax_mu(out, H, K):
    """MDN出力から各horizonの最大重みモードのμと重みを取り出す(numpy、推論復元用)。

    out    : [B, H*K*5] (最終位置の生出力、numpy)
    戻り値 : mu_sel [B,H,2](標準化残差スケールのμ), w_max [B,H](argmaxモードの重み)
    eval_batch.py の cv_residual_mdn 分岐と厳密に同一の式を使う。
    """
    B = out.shape[0]
    p = out.reshape(B, H, K, 5)
    logit = p[..., 0]                                   # [B,H,K]
    mu = p[..., 1:3]                                    # [B,H,K,2]
    # 重み w = softmax_k(logit)
    m = logit - logit.max(axis=2, keepdims=True)        # オーバーフロー回避
    ex = np.exp(m)
    w = ex / ex.sum(axis=2, keepdims=True)              # [B,H,K]
    kbest = np.argmax(w, axis=2)                        # [B,H] 最大重みモード
    bi = np.arange(B)[:, None]
    hi = np.arange(H)[None, :]
    mu_sel = mu[bi, hi, kbest]                          # [B,H,2]
    w_max = w[bi, hi, kbest]                            # [B,H]
    return mu_sel, w_max


# === val評価(MDN: 1回forward、argmaxモードのμで復元)=========================
def evaluate_val_mae_mdn(model, cfg, val_files, device, input_len_arg, steps_arg,
                         gpu_batch, val_limit, use_amp=False):
    """val セットの平均 ai_mae(km)を返す。MDNのargmaxモード復元式で予測。

    集計・レジーム表示は MH版 evaluate_val_mae_mh と同一。自己回帰は行わない。
    最終位置の [H,K,5] から各hで最大重みモードのμを採用し、mh_res で非標準化して復元。
    """
    cv_n = int(cfg.cv_n_last)
    H = int(getattr(cfg, "horizon", 20))
    K = int(getattr(cfg, "mdn_k", 3))
    stop_thresh_reg = float(getattr(cfg, "stop_thresh_km", 0.0) or 0.03)
    fm = np.asarray(cfg.feat_mean, dtype=np.float64)
    fs = np.asarray(cfg.feat_std, dtype=np.float64)
    mh_mean = np.asarray(cfg.mh_res_mean, dtype=np.float64)   # [H,2]
    mh_std = np.asarray(cfg.mh_res_std, dtype=np.float64)     # [H,2]
    max_ctx = int(cfg.max_len)

    use_files = list(val_files)
    if val_limit and val_limit > 0:
        use_files = use_files[:val_limit]

    items = []
    for p in use_files:
        lon, lat = read_traj(p)
        n = len(lon)
        input_len = min(int(input_len_arg), n - 1)
        steps = min(int(steps_arg), n - input_len)
        if input_len < 2 or steps < 1:
            continue
        hist_lon, hist_lat = lon[:input_len], lat[:input_len]
        truth_lon = lon[input_len:input_len + steps]
        truth_lat = lat[input_len:input_len + steps]
        disp = lonlat_to_disp_km(hist_lon, hist_lat)
        regime = classify_regime(truth_lon, truth_lat, hist_lon, hist_lat,
                                 stop_thresh=stop_thresh_reg)
        items.append(dict(filename=p.name, input_len=input_len, steps=steps,
                          hist_lon=hist_lon, hist_lat=hist_lat,
                          truth_lon=truth_lon, truth_lat=truth_lat,
                          disp=disp, regime=regime))
    if not items:
        return float("nan"), {}

    # input_len ごとにグループ化して1回forward。
    pred_map = {}
    groups = defaultdict(list)
    for it in items:
        groups[it["input_len"]].append(it)

    amp_on = bool(use_amp) and (device.type == "cuda")
    amp_ctx = (torch.autocast(device_type="cuda", dtype=torch.bfloat16)
               if amp_on else contextlib.nullcontext())

    model.eval()
    with torch.no_grad():
        for ilen, grp in groups.items():
            B = len(grp)
            seq = np.stack([g["disp"] for g in grp], axis=0).astype(np.float64)  # [B,P,2]
            P = seq.shape[1]
            ctx = min(P, max_ctx)
            ctx_disp = seq[:, P - ctx:, :]
            x = (ctx_disp - fm) / fs
            cur_lon = np.array([float(g["hist_lon"][-1]) for g in grp], dtype=np.float64)
            cur_lat = np.array([float(g["hist_lat"][-1]) for g in grp], dtype=np.float64)
            cv_last = seq[:, -cv_n:, :].mean(axis=1)                             # [B,2]

            out = np.zeros((B, H * K * 5), dtype=np.float64)
            for s in range(0, B, int(gpu_batch)):
                e = min(B, s + int(gpu_batch))
                xt = torch.from_numpy(x[s:e].astype(np.float32)).to(device)
                pad = torch.zeros(xt.shape[0], ctx, dtype=torch.bool, device=device)
                with amp_ctx:
                    o = model(xt, pad_mask=pad)[:, -1]                          # [b,H*K*5]
                out[s:e] = o.float().cpu().numpy()

            # 各hで最大重みモードのμを採用(標準化残差スケール)
            mu_sel, _wmax = mdn_argmax_mu(out, H, K)                            # [B,H,2]
            residual = mu_sel * mh_std[None, :, :] + mh_mean[None, :, :]        # [B,H,2]
            h_idx = np.arange(1, H + 1, dtype=np.float64)[None, :, None]        # [1,H,1]
            cum = h_idx * cv_last[:, None, :] + residual                        # [B,H,2]
            lon_scale = np.maximum(111.320 * np.cos(np.radians(cur_lat)), 1e-6)
            plon = cur_lon[:, None] + cum[:, :, 0] / lon_scale[:, None]         # [B,H]
            plat = cur_lat[:, None] + cum[:, :, 1] / KM_PER_DEG_LAT             # [B,H]
            for i, g in enumerate(grp):
                s = g["steps"]
                pred_map[g["filename"]] = (plon[i, :s], plat[i, :s])

    ai_maes, cv_maes = [], []
    reg_ai = defaultdict(list)
    for it in items:
        fn = it["filename"]
        truth_lon, truth_lat = it["truth_lon"], it["truth_lat"]
        ai_lon, ai_lat = pred_map[fn]
        ai_err = haversine_km_arr(ai_lon, ai_lat, truth_lon, truth_lat)
        cv_lon, cv_lat = rollout_cv_single(it["hist_lon"], it["hist_lat"], it["steps"], cv_n)
        cv_err = haversine_km_arr(cv_lon, cv_lat, truth_lon, truth_lat)
        ai_maes.append(float(ai_err.mean()))
        cv_maes.append(float(cv_err.mean()))
        reg_ai[it["regime"]].append(float(ai_err.mean()))
    val_mae = float(np.mean(ai_maes))
    extra = {
        "cv_mae": float(np.mean(cv_maes)),
        "n": len(ai_maes),
        "regime": {k: (float(np.mean(v)), len(v)) for k, v in reg_ai.items()},
    }
    return val_mae, extra


# === MDNヘッド初期化(モード崩壊対策)=========================================
def init_mdn_head(model, cfg):
    """MDNヘッド最終層のバイアスを初期化し、モード崩壊(全成分が同一μへ収束)を防ぐ。

    build_model のヘッドは Sequential(...,Linear(d_model, out_dim))。最終 Linear の
    バイアスを [B,L,H,K,5] レイアウトで解釈し、
      - log_b バイアス = 0 (b=1、標準化残差スケールに整合)
      - μ バイアス = 成分ごとに小さな異なるオフセット(K成分の対称性を破る)
      - logit バイアス = 0 (均等重みから開始)
    最終層の重みは既定の小さな初期値のままにし、バイアスで対称性のみ破る。
    """
    H = int(cfg.horizon); K = int(cfg.mdn_k)
    lin = None
    for m in reversed(list(model.head.modules())):
        if isinstance(m, nn.Linear):
            lin = m
            break
    if lin is None or lin.bias is None:
        return
    with torch.no_grad():
        bias = lin.bias.view(H, K, 5)                   # [H,K,5]
        bias.zero_()
        # μバイアスを成分ごとに小さくずらして対称性を破る(標準化スケールで ±0.5 程度)。
        # 角度を成分ごとに変え、2次元的に散らす。
        for k in range(K):
            ang = 2.0 * math.pi * k / max(K, 1)
            bias[:, k, 1] = 0.5 * math.cos(ang)         # μx
            bias[:, k, 2] = 0.5 * math.sin(ang)         # μy
        # log_b, logit は 0 のまま(b=1、均等重み)。


# === CLI =======================================================================
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="航跡 decoder-only Transformer【multi-horizon 確率版 MDN】を学習する。")
    p.add_argument("--data-dir", required=True, nargs="+", help="航跡別CSVフォルダ(複数指定可)")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--pattern", default="MMSI_*_traj_*.csv")
    p.add_argument("--feature-cols", default="")
    p.add_argument("--cv-n-last", type=int, default=6, help="等速(CV)予測に使う直近点数")
    p.add_argument("--horizon", type=int, default=20, help="直接予測する未来ステップ数H")
    p.add_argument("--mdn-k", type=int, default=3, help="horizon別の混合成分数K(Laplace混合)")
    p.add_argument("--limit-files", type=int, default=0)
    p.add_argument("--max-len", type=int, default=256)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--nhead", type=int, default=8)
    p.add_argument("--num-layers", type=int, default=3)
    p.add_argument("--dim-feedforward", type=int, default=256)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--interval-minutes", type=float, default=3.0)
    p.add_argument("--scaler-sample", type=int, default=2000)
    p.add_argument("--num-workers", type=int, default=0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="")
    p.add_argument("--amp", action="store_true",
                   help="学習のforward/lossを bf16 autocast で実行(既定off)。GradScaler不要。")
    p.add_argument("--warmup-steps", type=int, default=500, help="線形warmupのステップ数")
    p.add_argument("--lr-min", type=float, default=-1.0, help="cosine decay の最終LR。負なら lr/20。")
    p.add_argument("--val-dir", default="", help="検証セット(val500)のフォルダ")
    p.add_argument("--val-pattern", default="*.csv")
    p.add_argument("--val-input-len", type=int, default=80)
    p.add_argument("--val-steps", type=int, default=20)
    p.add_argument("--val-gpu-batch", type=int, default=256)
    p.add_argument("--val-limit", type=int, default=0, help="val評価に使う先頭件数(0=全件)。CPUスモークの時短用。")
    return p


def main() -> int:
    args = build_parser().parse_args()
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    H = int(args.horizon)
    K = int(args.mdn_k)
    if K < 1:
        raise ValueError(f"--mdn-k は 1 以上(MDN版)。K={K}")
    files = []
    for d in args.data_dir:
        files += list_traj_files(Path(d), args.pattern, 0)
    if args.limit_files and args.limit_files > 0:
        files = files[:args.limit_files]
    if not files:
        raise FileNotFoundError(f"航跡CSVがありません: {args.data_dir} / {args.pattern}")
    feature_cols = [c.strip() for c in (args.feature_cols.split(",") if args.feature_cols else []) if c.strip()]
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)

    val_files = []
    if args.val_dir:
        val_files = sorted(Path(args.val_dir).glob(args.val_pattern))
        if not val_files:
            print(f"[WARN] val-dir に一致なし: {args.val_dir}/{args.val_pattern}")

    print("=" * 80); print("[TRAIN traj_decoder_only_v1  target=CV残差 multi-horizon MDN(Laplace混合)  +LRsched +val-checkpoint]")
    print(f"data_dir    : {args.data_dir}")
    print(f"trajectories: {len(files):,}")
    print(f"val_dir     : {args.val_dir or '(なし: train_loss で選択)'}   val_files: {len(val_files):,}  val_limit={args.val_limit}")
    print(f"feature_cols: {feature_cols if feature_cols else '(dx,dy のみ)'}")
    print(f"cv_n_last   : {args.cv_n_last}   horizon(H): {H}   mdn_k(K): {K}   max_len: {args.max_len}  d_model={args.d_model}")
    print(f"epochs={args.epochs}  batch={args.batch_size}  lr={args.lr}  warmup={args.warmup_steps}")
    print("=" * 80)

    print("[1/2] 標準化統計を推定中(disp/feat/multi-horizon CV残差)...")
    disp_mean, disp_std, feat_mean, feat_std = fit_stats(files, feature_cols, args.scaler_sample, args.seed)
    # 残差統計はMH版と同一(MDNも同じ標準化ターゲットを使う)。
    mh_res_mean, mh_res_std = fit_res_stats_mh(files, args.cv_n_last, H, args.scaler_sample, args.seed)
    input_dim = 2 + len(feature_cols)
    out_dim = H * K * 5   # 各horizon×成分ごとに logit(1)+μ(2)+log_b(2)

    cfg = TrajConfig(
        feature_cols=feature_cols, input_dim=input_dim,
        d_model=args.d_model, nhead=args.nhead, num_layers=args.num_layers,
        dim_feedforward=args.dim_feedforward, dropout=args.dropout, max_len=args.max_len,
        interval_minutes=args.interval_minutes,
        disp_mean=disp_mean.tolist(), disp_std=disp_std.tolist(),
        feat_mean=feat_mean.tolist(), feat_std=feat_std.tolist(),
        target_mode="cv_residual_mdn", cv_n_last=args.cv_n_last,
        out_dim=out_dim, horizon=H, mdn_k=K,
        mh_res_mean=mh_res_mean.tolist(), mh_res_std=mh_res_std.tolist(),
    )

    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))

    use_amp = bool(args.amp)
    if use_amp:
        if device.type != "cuda":
            print("[WARN] --amp は CUDA でのみ有効。CPUのため fp32 にフォールバックします。")
            use_amp = False
        elif not torch.cuda.is_bf16_supported():
            print("[WARN] このGPUは bf16 非対応。fp32 にフォールバックします。")
            use_amp = False
        else:
            print("[AMP] bf16 autocast 有効(forward/loss を bf16、backward/step は fp32)。")

    ds = TrajectoryDataset(files, feature_cols, args.max_len, train=True, seed=args.seed)
    # ターゲット collate はMH版と同一(residualターゲット [B,L,H,2] とマスクを作る)。
    collate = partial(collate_cvres_mh, feat_mean=cfg.feat_mean, feat_std=cfg.feat_std,
                      mh_res_mean=cfg.mh_res_mean, mh_res_std=cfg.mh_res_std,
                      cv_n=cfg.cv_n_last, horizon=H)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
                        collate_fn=collate, pin_memory=(device.type == "cuda"), drop_last=False,
                        persistent_workers=(args.num_workers > 0),
                        prefetch_factor=(4 if args.num_workers > 0 else None))
    model = build_model(cfg).to(device)
    # MDNヘッドのバイアス初期化(モード崩壊対策: 成分ごとにμオフセットを散らす)。
    init_mdn_head(model, cfg)
    print(f"[MODEL] params={sum(p.numel() for p in model.parameters()):,}  input_dim={input_dim}  out_dim={out_dim}  device={device}")

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    steps_per_epoch = len(loader)
    total_steps = steps_per_epoch * args.epochs
    lr_min = args.lr_min if args.lr_min >= 0 else (args.lr / 20.0)
    lr_min_ratio = (lr_min / args.lr) if args.lr > 0 else 0.05
    lr_lambda = make_warmup_cosine_lambda(total_steps, args.warmup_steps, lr_min_ratio)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_lambda=lr_lambda)
    print(f"[SCHED] steps/epoch={steps_per_epoch}  total_steps={total_steps}  "
          f"warmup={args.warmup_steps}  lr={args.lr:g} -> lr_min={lr_min:g}(比 {lr_min_ratio:.4f})")

    best_val = float("inf"); best_epoch = -1
    best_path = out_dir / "traj_model.pt"
    history = []
    nonfinite_val_streak = 0
    print("[2/2] 学習...")
    for epoch in range(1, args.epochs + 1):
        model.train(); losses = []
        grad_skip = 0
        for batch in loader:
            x = batch["x"].to(device); y = batch["y"].to(device)     # y: [B,L,H,2]
            valid = batch["valid"].to(device); pad = batch["pad"].to(device)  # valid: [B,L,H]
            opt.zero_grad(set_to_none=True)
            amp_ctx = (torch.autocast(device_type="cuda", dtype=torch.bfloat16)
                       if use_amp else contextlib.nullcontext())
            with amp_ctx:
                pred = model(x, pad_mask=pad)                        # [B,L,H*K*5]
                loss = mdn_nll(pred, y, valid, H, K)                 # MDN 負対数尤度
            # isfinite ガード(MH版と同一): loss が非有限のバッチは backward せずスキップ。
            if not torch.isfinite(loss):
                grad_skip += 1
                sched.step()
                continue
            loss.backward()
            # clip_grad_norm_ の total_norm が非有限なら step せず勾配を捨てる(汚染防止)。
            total_norm = nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            if not torch.isfinite(total_norm):
                opt.zero_grad(set_to_none=True)
                grad_skip += 1
                sched.step()
                continue
            opt.step()
            sched.step()
            losses.append(float(loss.item()))
        tr = float(np.mean(losses)) if losses else float("nan")
        cur_lr = opt.param_groups[0]["lr"]

        weights_finite = all(torch.isfinite(p).all() for p in model.parameters())
        if not weights_finite:
            print(f"[WARN] 重みにNaN/Inf検出 (epoch {epoch}, grad_skip={grad_skip})。"
                  f"以降のval評価は汚染された重みで行われる可能性あり。")

        ep_path = out_dir / f"traj_model_ep{epoch}.pt"
        torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, ep_path)

        if val_files:
            model.eval()
            val_mae, extra = evaluate_val_mae_mdn(
                model, cfg, val_files, device,
                args.val_input_len, args.val_steps, args.val_gpu_batch, args.val_limit,
                use_amp=use_amp)
            model.train()
            reg = extra.get("regime", {})
            reg_s = "  ".join(f"{k}={v[0]:.3f}(N{v[1]})" for k, v in sorted(reg.items()))
            print(f"[EPOCH {epoch:03d}] train_NLL={tr:.6f}  lr={cur_lr:.3e}  "
                  f"val_MAE={val_mae:.4f}km  (val_CV={extra.get('cv_mae', float('nan')):.4f}, "
                  f"N={extra.get('n', 0)})  grad_skip={grad_skip}  [{reg_s}]")
            history.append((epoch, tr, val_mae))
            if np.isfinite(val_mae) and val_mae < best_val:
                best_val = val_mae; best_epoch = epoch
                torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, best_path)
                print(f"[SAVE] {best_path}  best_val_MAE={best_val:.4f}km (ep{best_epoch})")
            if not np.isfinite(val_mae):
                nonfinite_val_streak += 1
                if nonfinite_val_streak >= 2:
                    raise RuntimeError(
                        f"val_MAE が2エポック連続で非有限(epoch {epoch})。"
                        f"重みのNaN/Inf汚染が疑われるため学習を停止します"
                        f"(grad_skip={grad_skip})。")
            else:
                nonfinite_val_streak = 0
        else:
            print(f"[EPOCH {epoch:03d}] train_NLL={tr:.6f}  lr={cur_lr:.3e}  grad_skip={grad_skip}")
            history.append((epoch, tr, float("nan")))
            if np.isfinite(tr) and tr < best_val:
                best_val = tr; best_epoch = epoch
                torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, best_path)
                print(f"[SAVE] {best_path}  best_train_NLL={best_val:.6f}")

    with (out_dir / "traj_config.json").open("w", encoding="utf-8") as fp:
        json.dump(asdict(cfg), fp, ensure_ascii=False, indent=2)

    with (out_dir / "train_history.json").open("w", encoding="utf-8") as fp:
        json.dump({
            "history": [{"epoch": e, "train_loss": t, "val_mae": v} for (e, t, v) in history],
            "best_epoch": best_epoch, "best_val": best_val,
            "selection": ("val_mae" if val_files else "train_loss"),
        }, fp, ensure_ascii=False, indent=2)

    print("=" * 80)
    print("[SUMMARY] epoch  train_NLL    val_MAE(km)")
    for (e, t, v) in history:
        mark = "  <== 選択" if e == best_epoch else ""
        print(f"          {e:5d}  {t:10.6f}   {v:8.4f}{mark}")
    tag = "val_MAE" if val_files else "train_NLL"
    print(f"[DONE] model={best_path}  best_epoch={best_epoch}  best_{tag}={best_val:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
