#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
リサンプリング済みAIS CSVから、モデル入力用の特徴量CSVを作成するスクリプト。

学習スクリプト(ais_seq2seq_resampled3min.py)と比較スクリプト
(pred/predict_compare_plot_ais_flexible.py)は、これらの特徴量列が
「すでにCSVに存在している」ことを前提とする。
リサンプリング後にこのスクリプトを1回実行し、その出力フォルダを
学習用・推論用データの入力先として指定する(責務の分離)。

実行例:
  python src/prepare_ai_feature_csv.py ^
    --input-dir src\\timeseries_by_mmsi_turn\\resampled_3min ^
    --output-dir src\\timeseries_by_mmsi_turn\\resampled_3min_ai_features ^
    --interval-minutes 3
"""

from __future__ import annotations

import argparse
import math
import re
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd


# CSVに必ず存在していなければならない必須列。
REQUIRED_COLUMNS = ["mmsi", "block_id", "timestamp", "lon", "lat"]

# モデルに入力する数値特徴量の一覧。
# この並び・個数は学習スクリプト側のX_FEATURESと一致させる必要がある。
# (変えると入力次元が変わり、学習済みモデルと互換性がなくなる)
NUMERIC_FEATURES = [
    "lon",                          # 経度(絶対位置)
    "lat",                          # 緯度(絶対位置)
    "dlon",                         # 1つ前の点からの経度差
    "dlat",                         # 1つ前の点からの緯度差
    "speed_deg_per_min",            # 度数ベースの速度(1分あたり)
    "heading_sin",                  # 進行方位のsin成分
    "heading_cos",                  # 進行方位のcos成分
    "turn_rate_deg_per_min",        # 旋回角速度(度/分、符号つき)
    "abs_turn_rate_deg_per_min",    # 旋回角速度の絶対値(旋回の強さ)
    "vessel_type",                  # 船種(数値属性)
    "length",                       # 船長
    "width",                        # 船幅
    "draft",                        # 喫水
    "dx_km",                        # 東西方向の移動距離(km)
    "dy_km",                        # 南北方向の移動距離(km)
    "speed_kmh",                    # km/h単位の速度(物理的に安定)
    "course_sin",                   # 進行方位のsin成分(headingと同値)
    "course_cos",                   # 進行方位のcos成分(headingと同値)
    "accel_kmh",                    # 加速度(speed_kmhの変化量)
    "turn_rate",                    # 旋回角速度(turn_rate_deg_per_minと同値)
    "turn_sin",                     # 旋回率を角度とみなしたsin成分
    "turn_cos",                     # 旋回率を角度とみなしたcos成分
    "speed_kmh_avg3",               # speed_kmhの3点移動平均(操船判別の手がかり)
    "accel_kmh_avg3",               # accel_kmhの3点移動平均
    "turn_rate_avg3",               # turn_rateの3点移動平均
    # --- 急停止・減速検出(v5で追加) ---
    "is_slow",                      # 低速(2km/h未満)フラグ。停泊・接岸の兆候
    "speed_min3",                   # 直近3点の最小速度。止まりかけの検出
    "decel_ratio",                  # 直近speed/3点前speed。減速中なら1未満
    # --- 地理特徴量(--add-geo 指定時のみ意味を持つ。未指定なら0埋め) ---
    "coast_dist_km",                # 最寄り海岸線までの距離(km)。沿岸・港湾で小
    "coast_dist_inv",               # 1/(1+coast_dist_km)。港湾接近で1に近づく
    "is_on_land",                   # 陸地ポリゴン内なら1(補間誤差・接岸の検出)
]

# 時刻に関する周期特徴量。日内周期と年内周期をsin/cosで表す。
TIME_FEATURES = [
    "tod_sin",                      # 1日の中の時刻(time of day)のsin
    "tod_cos",                      # 1日の中の時刻のcos
    "doy_sin",                      # 1年の中の日付(day of year)のsin
    "doy_cos",                      # 1年の中の日付のcos
]

# 実際にモデルへ渡す入力特徴量 = 数値特徴量 + 時刻特徴量。
X_FEATURES = NUMERIC_FEATURES + TIME_FEATURES

# add_motion_features()で作成し、出力CSVに書き出す運動系の列の一覧。
# 出力列の並び順を決めるときに使う(ordered_output_columns参照)。
MOTION_OUTPUT_COLUMNS = [
    "dlon",
    "dlat",
    "speed_deg_per_min",
    "course_deg",
    "heading_sin",
    "heading_cos",
    "turn_rate_deg_per_min",
    "abs_turn_rate_deg_per_min",
    "dx_km",
    "dy_km",
    "speed_kmh",
    "course_sin",
    "course_cos",
    "accel_kmh",
    "turn_rate",
    "turn_sin",
    "turn_cos",
    "speed_kmh_avg3",
    "accel_kmh_avg3",
    "turn_rate_avg3",
    "is_slow",
    "speed_min3",
    "decel_ratio",
]

# 地理特徴量の列名(geo_features.GEO_FEATURES と一致させる)。
GEO_OUTPUT_COLUMNS = ["coast_dist_km", "coast_dist_inv", "is_on_land"]

# 欠損時に0で補完する船舶属性の列。
MODEL_ATTRIBUTE_COLUMNS = ["vessel_type", "length", "width", "draft"]

# 緯度1度あたりの距離(km)。地球を球とみなした近似値。
KM_PER_DEG_LAT = 110.574
# 赤道上での経度1度あたりの距離(km)。実際は緯度に応じてcos(lat)倍する。
KM_PER_DEG_LON_AT_EQUATOR = 111.320


def infer_mmsi_from_filename(path: Path) -> str:
    """ファイル名からMMSIらしき文字列を推定する。

    Args:
        path: `MMSI_123_resampled_3min.csv` のようなファイルパス。

    Returns:
        ファイル名から取り出したMMSI文字列。形式が違う場合はstem全体を返す。
    """
    stem = path.stem
    # 例: MMSI_123_resampled_3min -> 123
    m = re.match(r"^MMSI_(.+?)_resampled_", stem)
    if m:
        return m.group(1)
    if stem.startswith("MMSI_"):
        return stem[5:]
    return stem


def normalize_mmsi(value, fallback: str = "UNKNOWN") -> str:
    """MMSI値を安定した文字列に正規化する。

    Args:
        value: CSVから読んだMMSI値。
        fallback: 欠損や空文字のときに使う代替値。

    Returns:
        `367002350` のような文字列。`123.0` は `123` に直す。
    """
    if pd.isna(value):
        return fallback
    text = str(value).strip()
    if text == "":
        return fallback
    # CSVで 123.0 のように小数化された値を整数文字列へ戻す。
    try:
        f = float(text)
        if math.isfinite(f) and f.is_integer():
            return str(int(f))
    except Exception:
        pass
    return text


def normalize_group(value) -> str:
    """vessel_group(船舶グループ)を空でない文字列に正規化する。

    Args:
        value: CSVから読んだvessel_group値。

    Returns:
        正規化済みのgroup文字列。欠損や空文字は `UNKNOWN` にする。
    """
    if pd.isna(value):
        return "UNKNOWN"
    text = str(value).strip()
    return text if text else "UNKNOWN"


def add_time_features(dt_series: pd.Series) -> pd.DataFrame:
    """タイムスタンプ列を、日内周期・年内周期のsin/cos特徴量に変換する。

    時刻や日付は周期的なので、sin/cosのペアにすることで
    「23:59と00:01が近い」といった連続性をモデルが扱えるようにする。

    Args:
        dt_series: timestamp列(文字列またはdatetime)。

    Returns:
        tod_sin/tod_cos/doy_sin/doy_cos の4列を持つDataFrame。
    """
    dt = pd.to_datetime(dt_series, utc=True, errors="coerce")

    # 0時からの経過秒数(0〜86400)。microsecondは100万で割って秒に直す。
    seconds_of_day = (
        dt.dt.hour.astype(float) * 3600.0
        + dt.dt.minute.astype(float) * 60.0
        + dt.dt.second.astype(float)
        + dt.dt.microsecond.astype(float) / 1e6
    )
    # 1日を1周(2π)とみなした角度。
    tod_angle = 2.0 * np.pi * seconds_of_day / 86400.0

    # 年内通算日(1月1日=1)を0始まりにし、日の途中も小数で加味する。
    day_of_year = dt.dt.dayofyear.astype(float)
    seconds_in_day = seconds_of_day / 86400.0
    # 1年を1周(2π)とみなした角度。365.2425は平均年日数。
    doy_angle = 2.0 * np.pi * (day_of_year - 1.0 + seconds_in_day) / 365.2425

    return pd.DataFrame({
        "tod_sin": np.sin(tod_angle),
        "tod_cos": np.cos(tod_angle),
        "doy_sin": np.sin(doy_angle),
        "doy_cos": np.cos(doy_angle),
    })


def add_motion_features(block: pd.DataFrame, interval_minutes: float) -> pd.DataFrame:
    """1つのblock(連続航跡区間)に、移動量・速度・方位・旋回率などの列を追加する。

    Args:
        block: 同一block_idに属するDataFrame。
        interval_minutes: AIS点の時間間隔(分)。速度・加速度の時間換算に使う。

    Returns:
        運動系の特徴量列を追加したDataFrame(timestamp順)。
    """
    g = block.sort_values(["timestamp", "step_index"]).copy()
    interval = max(float(interval_minutes), 1e-6)   # 0除算を避けるため下限を設ける
    interval_hours = interval / 60.0                # 1ステップの時間(時間単位)

    # 1つ前の点からの経度・緯度差。block先頭は差分なしなので0で補完。
    g["dlon"] = g["lon"].diff().fillna(0.0)
    g["dlat"] = g["lat"].diff().fillna(0.0)
    # 度数ベースの速度(1分あたりの移動量)。物理的には不完全な指標。
    g["speed_deg_per_min"] = np.sqrt(g["dlon"] ** 2 + g["dlat"] ** 2) / interval

    dlon = g["dlon"].to_numpy(dtype=np.float64)
    dlat = g["dlat"].to_numpy(dtype=np.float64)
    lat = g["lat"].to_numpy(dtype=np.float64)

    # 経度方向の距離は緯度によって変わるので cos(lat) で補正してkmに換算。
    lon_scale = KM_PER_DEG_LON_AT_EQUATOR * np.cos(np.radians(lat))
    g["dx_km"] = dlon * lon_scale                   # 東西方向の移動距離(km)
    g["dy_km"] = dlat * KM_PER_DEG_LAT              # 南北方向の移動距離(km)
    # km/h単位の速度。speed_deg_per_minより物理的に安定。
    g["speed_kmh"] = np.sqrt(g["dx_km"] ** 2 + g["dy_km"] ** 2) / max(interval_hours, 1e-6)
    # 加速度(speed_kmhの変化量を時間で割ったもの)。
    g["accel_kmh"] = g["speed_kmh"].diff().fillna(0.0) / max(interval_hours, 1e-6)

    # 局所移動ベクトルから進行方位(heading)を求める。
    # arctan2(east, north) は北で0rad、東で+pi/2rad になる。
    east = g["dx_km"].to_numpy(dtype=np.float64)
    north = g["dy_km"].to_numpy(dtype=np.float64)
    movement = np.sqrt(east ** 2 + north ** 2)
    heading_rad = np.full(len(g), np.nan, dtype=np.float64)
    moving = movement > 1e-12                       # ほぼ静止の点は方位を計算しない
    heading_rad[moving] = np.arctan2(east[moving], north[moving])
    # 静止点はNaNになるので、直前の方位で前方補完し、残りは0にする。
    heading_rad = pd.Series(heading_rad, index=g.index).ffill().fillna(0.0).to_numpy(dtype=np.float64)

    g["course_deg"] = (np.degrees(heading_rad) + 360.0) % 360.0   # 0〜360度の進行方向
    g["heading_sin"] = np.sin(heading_rad)
    g["heading_cos"] = np.cos(heading_rad)
    # course_sin/cosはheading_sin/cosと同じ値(モデル入力名の互換用)。
    g["course_sin"] = g["heading_sin"]
    g["course_cos"] = g["heading_cos"]

    # 旋回量。方位の階差を[-pi, pi]に正規化してから度/分へ換算する。
    # (359度→1度のような不連続を正しく小さな差として扱うため)
    turn_delta = np.zeros(len(g), dtype=np.float64)
    if len(g) > 1:
        raw_delta = np.diff(heading_rad)
        turn_delta[1:] = np.arctan2(np.sin(raw_delta), np.cos(raw_delta))

    turn_rate = np.degrees(turn_delta) / interval
    g["turn_rate_deg_per_min"] = turn_rate
    g["abs_turn_rate_deg_per_min"] = np.abs(turn_rate)
    g["turn_rate"] = turn_rate                      # turn_rate_deg_per_minと同値(入力名互換)
    turn_rate_rad = np.radians(turn_rate)
    g["turn_sin"] = np.sin(turn_rate_rad)
    g["turn_cos"] = np.cos(turn_rate_rad)

    # 直近3点の移動平均。AIS特有の細かなブレを均し、
    # 「巡航中か操船中(港湾・旋回)か」をモデルが見分ける手がかりになる。
    g["speed_kmh_avg3"] = g["speed_kmh"].rolling(window=3, min_periods=1).mean()
    g["accel_kmh_avg3"] = g["accel_kmh"].rolling(window=3, min_periods=1).mean()
    g["turn_rate_avg3"] = g["turn_rate"].rolling(window=3, min_periods=1).mean()

    # --- 急停止・減速検出用の特徴量 ---
    # 「動いていた船が急に止まる」ケースは予測が難しい。停止の兆候を明示的に渡す。
    sp = g["speed_kmh"].to_numpy(dtype=np.float64)

    # is_slow: 低速(2km/h未満)なら1。停泊・接岸・極低速の兆候。
    g["is_slow"] = (sp < 2.0).astype(np.float32)

    # speed_min3: 直近3点の最小速度。1点でも止まりかけていれば小さくなる。
    g["speed_min3"] = g["speed_kmh"].rolling(window=3, min_periods=1).min().astype(np.float32)

    # decel_ratio: 直近の速度 / 3点前の速度。1未満なら減速中、0近傍なら停止寸前。
    #   過去speedが0だと不定になるので分母に小さな下駄を履かせ、1.5でクリップ。
    prev3 = g["speed_kmh"].shift(3)
    ratio = sp / (prev3.to_numpy(dtype=np.float64) + 0.5)
    ratio = np.nan_to_num(ratio, nan=1.0, posinf=1.5, neginf=0.0)
    g["decel_ratio"] = np.clip(ratio, 0.0, 1.5).astype(np.float32)

    return g


def format_timestamp_z(values: pd.Series) -> pd.Series:
    """UTCタイムスタンプを、ミリ秒+Z付きのコンパクトなISO文字列に整形する。

    Args:
        values: timestamp列。

    Returns:
        `2016-01-01T00:00:00.000Z` 形式の文字列Series。
    """
    dt = pd.to_datetime(values, utc=True, errors="coerce")
    text = dt.dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    # マイクロ秒(6桁)をミリ秒(3桁)に丸めてから末尾Zを付け直す。
    return text.str.replace(r"(\.\d{3})\d+Z$", r"\1Z", regex=True)


def read_resampled_csv(path: Path) -> pd.DataFrame:
    """リサンプリング済みAIS CSVを1つ読み込み、特徴量作成前の正規化を行う。

    Args:
        path: 読み込むCSVファイル。

    Returns:
        必須列の型変換・欠損補完・座標範囲チェック・ソート済みのDataFrame。
        元の列順は df.attrs["original_columns"] に保存する。

    Raises:
        ValueError: 必須列が足りない場合。
    """
    df = pd.read_csv(path)

    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"{path} に必要列がありません: {missing}")

    fallback_mmsi = infer_mmsi_from_filename(path)
    original_columns = list(df.columns)             # 出力時に元の列順を保つため控えておく

    # 必須列の正規化・型変換。
    df["mmsi"] = df["mmsi"].apply(lambda x: normalize_mmsi(x, fallback=fallback_mmsi))
    df["block_id"] = df["block_id"].astype(str)
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    df["lon"] = pd.to_numeric(df["lon"], errors="coerce")
    df["lat"] = pd.to_numeric(df["lat"], errors="coerce")

    # 時刻・座標が壊れている行を除外し、緯度経度の範囲外も除く。
    df = df.dropna(subset=["timestamp", "lon", "lat"]).copy()
    df = df[(df["lon"] >= -180) & (df["lon"] <= 180) & (df["lat"] >= -90) & (df["lat"] <= 90)].copy()

    # 船舶属性などの数値列。無ければ0で補完する。
    for col in MODEL_ATTRIBUTE_COLUMNS + ["duration_minutes", "shape_length"]:
        if col not in df.columns:
            df[col] = 0.0
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

    # vessel_groupが無ければUNKNOWNで補完。
    if "vessel_group" not in df.columns:
        df["vessel_group"] = "UNKNOWN"
    df["vessel_group"] = df["vessel_group"].apply(normalize_group)

    # step_indexが無ければ連番を振る。
    if "step_index" not in df.columns:
        df["step_index"] = np.arange(len(df), dtype=np.int64)
    else:
        df["step_index"] = pd.to_numeric(df["step_index"], errors="coerce").fillna(0).astype(np.int64)

    df.attrs["original_columns"] = original_columns
    # block_id -> timestamp -> step_index の順でソートして時系列を整える。
    return df.sort_values(["block_id", "timestamp", "step_index"]).reset_index(drop=True)


def prepare_features(
    df: pd.DataFrame,
    interval_minutes: float,
    add_geo: bool = False,
    geo_grid_path: Optional[str] = None,
) -> pd.DataFrame:
    """正規化済みCSVに対し、AI入力用の全特徴量列を作成する。

    Args:
        df: read_resampled_csv()で正規化したDataFrame。
        interval_minutes: AIS点の時間間隔(分)。
        add_geo: Trueなら地理特徴量(海岸線距離・陸海判定)を付与する。
                 Falseなら地理特徴量列は0で埋める(列自体は常に出力)。
        geo_grid_path: 事前計算した地理グリッド(.npz)のパス。Noneなら既定パス。

    Returns:
        運動特徴量・時刻特徴量・(任意で)地理特徴量を追加し、X_FEATURESをfloat32化したDataFrame。
    """
    if df.empty:
        return df.copy()

    # block_idごとに運動特徴量を計算する(blockをまたいだ差分を作らないため)。
    blocks = []
    for _, block in df.groupby("block_id", sort=False):
        blocks.append(add_motion_features(block, interval_minutes=interval_minutes))

    out = pd.concat(blocks, ignore_index=True)
    out = out.sort_values(["block_id", "timestamp", "step_index"]).reset_index(drop=True)

    # 時刻特徴量はblockに依存しないので全体でまとめて計算する。
    time_df = add_time_features(out["timestamp"])
    for col in TIME_FEATURES:
        out[col] = time_df[col].values

    # 地理特徴量(海岸線距離・陸海判定)。--add-geo指定時のみ付与、未指定は0埋め。
    # 事前計算グリッド(.npz)を引くだけなので高速。
    if add_geo:
        from geo_features import add_geo_features as _add_geo
        _add_geo(out, grid_path=geo_grid_path)
    else:
        for col in GEO_OUTPUT_COLUMNS:
            out[col] = np.float32(0.0)

    # 入力特徴量を数値化・欠損補完し、float32に統一する。
    for col in X_FEATURES:
        if col not in out.columns:
            out[col] = 0.0
        out[col] = pd.to_numeric(out[col], errors="coerce").fillna(0.0).astype(np.float32)

    # timestampは読みやすいISO文字列に整形して書き出す。
    out["timestamp"] = format_timestamp_z(out["timestamp"])
    return out


def ordered_output_columns(df: pd.DataFrame, original_columns: List[str]) -> List[str]:
    """出力CSVの列順を決める。元の列順を保ちつつ、新規列を後ろに追加する。

    Args:
        df: 出力対象のDataFrame。
        original_columns: 入力CSVの元の列順。

    Returns:
        出力に使う列名のリスト(元の列 → 新規生成列 → 残りの列)。
    """
    # 今回新たに生成した(または再計算した)列。
    generated = (
        MODEL_ATTRIBUTE_COLUMNS + ["vessel_group", "step_index"]
        + MOTION_OUTPUT_COLUMNS + GEO_OUTPUT_COLUMNS + TIME_FEATURES
    )
    # まず元の列順を維持する。
    columns = [c for c in original_columns if c in df.columns]
    # 元の列に無い新規生成列を後ろに足す。
    columns.extend(c for c in generated if c in df.columns and c not in columns)
    # それでも漏れた列があれば最後に足す。
    columns.extend(c for c in df.columns if c not in columns)
    return columns


def prepare_one_file(
    path: Path,
    output_dir: Path,
    interval_minutes: float,
    overwrite: bool,
    add_geo: bool = False,
    geo_grid_path: Optional[str] = None,
) -> Dict[str, object]:
    """1つのCSVを特徴量化し、同じファイル名でoutput_dirへ書き出す。

    Args:
        path: 入力CSV。
        output_dir: 出力フォルダ。
        interval_minutes: AIS点の時間間隔(分)。
        overwrite: Trueなら既存の出力を上書きする。Falseなら存在時はスキップ。
        add_geo: Trueなら地理特徴量(海岸線距離・陸海判定)も付与する。
        geo_grid_path: 事前計算した地理グリッド(.npz)のパス。

    Returns:
        処理結果(ok/skipped/path/out_path/rows/blocks/error)を持つdict。
    """
    out_path = output_dir / path.name
    # 上書き指定が無く、既に出力が存在する場合はスキップする。
    if out_path.exists() and not overwrite:
        return {
            "ok": True,
            "skipped": True,
            "path": path.name,
            "out_path": str(out_path),
            "rows": 0,
            "blocks": 0,
            "error": "",
        }

    df = read_resampled_csv(path)
    original_columns = list(df.attrs.get("original_columns", df.columns))
    out = prepare_features(
        df, interval_minutes=interval_minutes,
        add_geo=add_geo, geo_grid_path=geo_grid_path,
    )
    out = out[ordered_output_columns(out, original_columns)]

    output_dir.mkdir(parents=True, exist_ok=True)
    out.to_csv(out_path, index=False)

    return {
        "ok": True,
        "skipped": False,
        "path": path.name,
        "out_path": str(out_path),
        "rows": len(out),
        "blocks": int(out["block_id"].nunique()) if "block_id" in out.columns else 0,
        "error": "",
    }


def _prepare_one_file_worker(args) -> Dict[str, object]:
    """prepare_one_file()をProcessPoolから呼ぶためのラッパー。

    Args:
        args: `(path_text, output_dir_text, interval_minutes, overwrite,
                add_geo, geo_grid_path)` のタプル。
              別プロセスへ渡すため、PathではなくpickleしやすいタプルとPath文字列にする。

    Returns:
        prepare_one_file()の戻り値。例外時はok=Falseのdictにして返す。
    """
    path_text, output_dir_text, interval_minutes, overwrite, add_geo, geo_grid_path = args
    try:
        return prepare_one_file(
            path=Path(path_text),
            output_dir=Path(output_dir_text),
            interval_minutes=interval_minutes,
            overwrite=overwrite,
            add_geo=add_geo,
            geo_grid_path=geo_grid_path,
        )
    except Exception as e:
        return {
            "ok": False,
            "skipped": False,
            "path": Path(path_text).name,
            "out_path": "",
            "rows": 0,
            "blocks": 0,
            "error": str(e),
        }


def list_csv_files(input_dir: Path, pattern: str, limit_files: int) -> List[Path]:
    """処理対象のCSVファイル一覧を作る。

    Args:
        input_dir: 入力フォルダ。
        pattern: `MMSI_*_resampled_3min.csv` のようなglobパターン。
        limit_files: 0より大きい場合、先頭からこの件数だけ使う(テスト用)。

    Returns:
        条件に合うPathのリスト(ファイル名順)。
    """
    files = sorted(input_dir.glob(pattern))
    if limit_files and limit_files > 0:
        files = files[:limit_files]
    return files


def write_manifest(output_dir: Path, rows: List[Dict[str, object]]) -> None:
    """生成した特徴量CSVの一覧(マニフェスト)を書き出す。

    Args:
        output_dir: 出力フォルダ。
        rows: 各ファイルの処理結果dictのリスト。

    Returns:
        None。`feature_manifest.csv` を書き込む。
    """
    if not rows:
        return
    manifest_path = output_dir / "feature_manifest.csv"
    pd.DataFrame(rows).to_csv(manifest_path, index=False)


def build_parser() -> argparse.ArgumentParser:
    """コマンドライン引数の定義を作る。

    Returns:
        argparse.ArgumentParser。
    """
    parser = argparse.ArgumentParser(
        description="resampled_3min のAIS CSVから、AI入力用の特徴量CSVを作成する。"
    )
    parser.add_argument("--input-dir", required=True, help="リサンプリング済みCSVが入っているフォルダ。")
    parser.add_argument("--output-dir", default="", help="特徴量CSVを書き出すフォルダ(input-dirとは別にする)。--build-geo-grid時は不要。")
    parser.add_argument("--pattern", default="MMSI_*_resampled_3min.csv", help="入力ファイルのglobパターン。")
    parser.add_argument("--interval-minutes", type=float, default=3.0, help="AISのサンプリング間隔(分)。")
    parser.add_argument("--limit-files", type=int, default=0, help="先頭N件だけ処理する。0なら全件。")
    parser.add_argument("--workers", type=int, default=0, help="並列ワーカープロセス数。0または1で従来どおり逐次処理。")
    parser.add_argument("--overwrite", action="store_true", help="output-dirに既存ファイルがあっても上書きする。")
    parser.add_argument("--progress-every", type=int, default=100, help="N件処理するごとに進捗を表示する。")
    parser.add_argument("--add-geo", action="store_true",
                        help="地理特徴量(海岸線距離・陸海判定)を付与する。事前に --build-geo-grid でグリッドを作っておく。未指定なら該当列は0埋め。")
    parser.add_argument("--geo-grid", default="",
                        help="事前計算した地理グリッド(.npz)のパス。空なら src/geo_coast_grid.npz。")
    parser.add_argument("--build-geo-grid", action="store_true",
                        help="このモードでは特徴量CSVは作らず、入力データのbboxから地理グリッド(.npz)を構築して終了する。")
    parser.add_argument("--geo-step-deg", type=float, default=0.005,
                        help="(--build-geo-grid用)グリッド解像度(度)。0.005≒550m。")
    parser.add_argument("--geo-resolution", default="10m", choices=["10m", "50m", "110m"],
                        help="(--build-geo-grid用)Natural Earthの海岸線解像度。")
    parser.add_argument("--geo-bbox-sample", type=int, default=500,
                        help="(--build-geo-grid用)bbox推定にサンプリングするファイル数。")
    return parser


def main() -> int:
    """スクリプトの入口。引数を解析し、各CSVを特徴量化して書き出す。

    Returns:
        終了コード。失敗ファイルがあれば1、なければ0。
    """
    parser = build_parser()
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    if args.interval_minutes <= 0:
        parser.error("--interval-minutes は正の値にしてください。")

    files = list_csv_files(input_dir, args.pattern, args.limit_files)
    if not files:
        raise RuntimeError(f"対象CSVがありません: {input_dir / args.pattern}")

    # 既定の地理グリッドパス(--geo-grid 未指定時)。
    from geo_features import DEFAULT_GRID_PATH
    geo_grid_path = str(args.geo_grid) if args.geo_grid else str(DEFAULT_GRID_PATH)

    # --- 地理グリッド構築モード: 特徴量CSVは作らず、グリッド(.npz)だけ作って終了 ---
    if args.build_geo_grid:
        from geo_features import build_distance_grid
        n_sample = max(1, int(args.geo_bbox_sample))
        sample_files = files if len(files) <= n_sample else [
            files[i] for i in np.linspace(0, len(files) - 1, num=n_sample).round().astype(int)
        ]
        lon_min, lon_max, lat_min, lat_max = 1e9, -1e9, 1e9, -1e9
        for p in sample_files:
            try:
                d = pd.read_csv(p, usecols=["lon", "lat"])
            except Exception:
                continue
            d = d[(d["lon"].between(-180, 180)) & (d["lat"].between(-90, 90))]
            if d.empty:
                continue
            lon_min = min(lon_min, float(d["lon"].min())); lon_max = max(lon_max, float(d["lon"].max()))
            lat_min = min(lat_min, float(d["lat"].min())); lat_max = max(lat_max, float(d["lat"].max()))
        print("=" * 80)
        print("[BUILD GEO GRID]")
        print(f"input_dir   : {input_dir}")
        print(f"sample_files: {len(sample_files):,}")
        print(f"bbox        : lon[{lon_min:.2f},{lon_max:.2f}] lat[{lat_min:.2f},{lat_max:.2f}]")
        print(f"grid_out    : {geo_grid_path}  step={args.geo_step_deg} res={args.geo_resolution}")
        build_distance_grid(
            lon_min, lon_max, lat_min, lat_max,
            step_deg=float(args.geo_step_deg), resolution=str(args.geo_resolution),
            out_path=Path(geo_grid_path),
        )
        return 0

    # --- 通常の特徴量CSV作成モード ---
    if not args.output_dir:
        parser.error("--output-dir は必須です(--build-geo-grid 時を除く)。")
    output_dir = Path(args.output_dir)
    # 入力と出力が同じだと元データを壊すため禁止する。
    if input_dir.resolve() == output_dir.resolve():
        parser.error("--input-dir と --output-dir は別にしてください。特徴量CSVは新しいフォルダへ書き出します。")
    if args.add_geo and not Path(geo_grid_path).exists():
        parser.error(f"地理グリッドがありません: {geo_grid_path}\n先に --build-geo-grid で作成してください。")

    output_dir.mkdir(parents=True, exist_ok=True)
    workers = max(0, int(args.workers or 0))
    progress_every = max(1, int(args.progress_every or 1))

    print("=" * 80)
    print("[PREPARE AI FEATURES]")
    print(f"input_dir        : {input_dir}")        # 入力フォルダ
    print(f"output_dir       : {output_dir}")       # 出力フォルダ
    print(f"pattern          : {args.pattern}")     # 対象globパターン
    print(f"files            : {len(files):,}")     # 対象ファイル数
    print(f"interval_minutes : {args.interval_minutes:g}")  # AIS間隔(分)
    print(f"workers          : {workers}")          # 並列数
    print(f"overwrite        : {bool(args.overwrite)}")     # 上書き可否
    print(f"add_geo          : {bool(args.add_geo)}  grid={geo_grid_path if args.add_geo else '-'}")  # 地理特徴量

    add_geo = bool(args.add_geo)

    results: List[Dict[str, object]] = []
    failed = 0

    if workers > 1:
        # 並列処理。各ファイルを別プロセスで特徴量化する。
        task_args = [(str(path), str(output_dir), args.interval_minutes, bool(args.overwrite), add_geo, geo_grid_path) for path in files]
        with ProcessPoolExecutor(max_workers=workers) as executor:
            for i, result in enumerate(executor.map(_prepare_one_file_worker, task_args), 1):
                results.append(result)
                if not result["ok"]:
                    failed += 1
                    print(f"[WARN] failed {result['path']}: {result['error']}", file=sys.stderr)
                if i % progress_every == 0:
                    print(f"[PREP] files={i:,}/{len(files):,}, failed={failed:,}")
    else:
        # 逐次処理。1ファイルずつ順番に特徴量化する。
        for i, path in enumerate(files, 1):
            result = _prepare_one_file_worker((str(path), str(output_dir), args.interval_minutes, bool(args.overwrite), add_geo, geo_grid_path))
            results.append(result)
            if not result["ok"]:
                failed += 1
                print(f"[WARN] failed {result['path']}: {result['error']}", file=sys.stderr)
            if i % progress_every == 0:
                print(f"[PREP] files={i:,}/{len(files):,}, failed={failed:,}")

    write_manifest(output_dir, results)

    # 集計してサマリを表示する。
    written = sum(1 for r in results if r["ok"] and not r["skipped"])    # 新規書き込み数
    skipped = sum(1 for r in results if r["ok"] and r["skipped"])        # スキップ数
    rows = sum(int(r["rows"]) for r in results if r["ok"])               # 出力した総行数

    print("=" * 80)
    print("[DONE]")
    print(f"written  : {written:,}")
    print(f"skipped  : {skipped:,}")
    print(f"failed   : {failed:,}")
    print(f"rows     : {rows:,}")
    print(f"manifest : {output_dir / 'feature_manifest.csv'}")

    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
