import numpy as np, pandas as pd

years=range(2017,2025)
frames={}
for y in years:
    df=pd.read_csv(f'/work/{y}_calc_az_el.csv', usecols=['date','AZ','EL'])
    dt=pd.to_datetime(df['date'])
    df['key']=dt.dt.strftime('%m-%d %H:%M')
    frames[y]=df[['key','AZ','EL']]

truth=frames[2024].set_index('key')

for target in ['AZ','EL']:
    pivot=pd.concat([frames[y].assign(year=y) for y in range(2017,2024)]).pivot(index='key', columns='year', values=target)
    t=truth[target]
    common=t.index.intersection(pivot.index)
    Y=pivot.loc[common]
    y_true=t.loc[common].to_numpy()

    pred=Y[2023].to_numpy()
    diff=pred-y_true
    print(target,'repeat',float(np.mean(np.abs(diff))),float(np.max(np.abs(diff))), flush=True)

    mask_all=Y.notna().all(axis=1)
    Yall=Y[mask_all].to_numpy()
    yall_true=y_true[mask_all.to_numpy()]
    x=np.arange(2017,2024).astype(float)

    X=np.vstack([np.ones_like(x), x]).T
    B=np.linalg.lstsq(X, Yall.T, rcond=None)[0]
    pred=(np.array([1,2024.0])@B)
    diff=pred-yall_true
    print(target,'linear',float(np.mean(np.abs(diff))),float(np.max(np.abs(diff))), 'rows', len(diff), flush=True)

    X2=np.vstack([np.ones_like(x), x, x*x]).T
    B2=np.linalg.lstsq(X2, Yall.T, rcond=None)[0]
    pred2=(np.array([1,2024.0,2024.0*2024.0])@B2)
    diff2=pred2-yall_true
    print(target,'quad',float(np.mean(np.abs(diff2))),float(np.max(np.abs(diff2))), flush=True)

    X3=np.vstack([
        np.ones_like(x), x,
        np.sin(2*np.pi*(x-2017)/2), np.cos(2*np.pi*(x-2017)/2),
        np.sin(2*np.pi*(x-2017)/3), np.cos(2*np.pi*(x-2017)/3),
    ]).T
    B3=np.linalg.lstsq(X3, Yall.T, rcond=None)[0]
    xt=np.array([1,2024.0,np.sin(2*np.pi*(2024-2017)/2),np.cos(2*np.pi*(2024-2017)/2),np.sin(2*np.pi*(2024-2017)/3),np.cos(2*np.pi*(2024-2017)/3)])
    pred3=xt@B3
    diff3=pred3-yall_true
    print(target,'lin+cyc',float(np.mean(np.abs(diff3))),float(np.max(np.abs(diff3))), flush=True)
