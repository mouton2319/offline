import numpy as np, pandas as pd, math
MAX_SHIFT=20

def wrap180(x):
    return ((x + 180.0) % 360.0) - 180.0

def load(y):
    df=pd.read_csv(f'/work/{y}_calc_az_el.csv', usecols=['date','AZ','EL'])
    dt=pd.to_datetime(df['date'])
    df['day']=dt.dt.strftime('%m-%d')
    df['minute']=dt.dt.hour*60+dt.dt.minute
    return df

def shift_arr(a, s):
    if s>=0:
        return np.r_[np.full(s,np.nan), a[:len(a)-s]] if s else a.copy()
    ss=-s
    return np.r_[a[ss:], np.full(ss,np.nan)]

def fit_params(prev, cur):
    out={}
    grp_prev={d:g.set_index('minute')[['AZ','EL']].reindex(range(1440)) for d,g in prev.groupby('day')}
    grp_cur={d:g.set_index('minute')[['AZ','EL']].reindex(range(1440)) for d,g in cur.groupby('day')}
    for d,c in grp_cur.items():
        p=grp_prev.get(d)
        if p is None: continue
        p_az=p['AZ'].to_numpy(); p_el=p['EL'].to_numpy(); c_az=c['AZ'].to_numpy(); c_el=c['EL'].to_numpy()
        best=None
        for s in range(-MAX_SHIFT, MAX_SHIFT+1):
            pa=shift_arr(p_az,s); pe=shift_arr(p_el,s)
            m=np.isfinite(pa)&np.isfinite(pe)&np.isfinite(c_az)&np.isfinite(c_el)
            if m.sum()<1000: continue
            da=wrap180(c_az[m]-pa[m]); de=c_el[m]-pe[m]
            azo=np.median(da); elo=np.median(de)
            rem=np.maximum(np.abs(wrap180(pa[m]+azo-c_az[m])), np.abs(pe[m]+elo-c_el[m]))
            sc=np.quantile(rem,0.99)
            if best is None or sc<best[0]: best=(s,float(azo),float(elo),float(rem.max()),float(rem.mean()))
        if best is not None: out[d]=best
    return out, grp_prev, grp_cur

def apply_and_eval(prev_grp, cur_grp, param_map):
    az=[]; el=[]
    for d,c in cur_grp.items():
        p=prev_grp.get(d)
        if p is None or d not in param_map: continue
        s,azo,elo=param_map[d]
        pa=shift_arr(p['AZ'].to_numpy(), int(round(s)))
        pe=shift_arr(p['EL'].to_numpy(), int(round(s)))
        pa=pd.Series(pa).interpolate(limit_direction='both').to_numpy()
        pe=pd.Series(pe).interpolate(limit_direction='both').to_numpy()
        c_az=c['AZ'].to_numpy(); c_el=c['EL'].to_numpy()
        m=np.isfinite(pa)&np.isfinite(pe)&np.isfinite(c_az)&np.isfinite(c_el)
        da=np.abs(wrap180((pa[m]+azo)-c_az[m])); de=np.abs((pe[m]+elo)-c_el[m])
        az.append(da); el.append(de)
    az=np.concatenate(az); el=np.concatenate(el)
    return float((az.mean()+el.mean())/2), float(max(az.max(), el.max()))

def day_features(day, year):
    # use 2001 leap year for day ordering to include 02-29
    ts=pd.Timestamp(f'2004-{day} 00:00:00')
    doy=ts.dayofyear
    ph=2*np.pi*doy/366.0
    y=float(year)
    cols=[1.0, y-2020.0]
    for k in range(1,5):
        cols += [math.sin(k*ph), math.cos(k*ph)]
    cols += [math.sin(math.pi*(y-2018.0)), math.cos(math.pi*(y-2018.0))]
    cols += [math.sin(2*math.pi*(y-2018.0)/3.0), math.cos(2*math.pi*(y-2018.0)/3.0)]
    return np.array(cols, dtype=float)

def ridge_fit(X, y, l2=1e-1):
    return np.linalg.solve(X.T@X + np.eye(X.shape[1])*l2, X.T@y)

frames={y:load(y) for y in range(2017,2025)}
params={}
for y in range(2018,2025):
    params[y], _, _ = fit_params(frames[y-1], frames[y])

X=[]; ys=[]; ya=[]; ye=[]
for y in range(2018,2024):
    for d,(s,azo,elo,_,_) in params[y].items():
        X.append(day_features(d,y))
        ys.append(s); ya.append(azo); ye.append(elo)
X=np.vstack(X); ys=np.array(ys); ya=np.array(ya); ye=np.array(ye)
bs=ridge_fit(X,ys,1.0)
ba=ridge_fit(X,ya,1.0)
be=ridge_fit(X,ye,1.0)

pred24={}
for d in params[2024].keys():
    f=day_features(d,2024)
    s=float(np.clip(f@bs,-MAX_SHIFT,MAX_SHIFT))
    azo=float(f@ba)
    elo=float(f@be)
    pred24[d]=(s,azo,elo)

# smooth over neighboring days in cyclic order
keys=sorted(pred24.keys(), key=lambda d: pd.Timestamp(f'2004-{d}').dayofyear)
arr=np.array([pred24[k] for k in keys], dtype=float)
for j in range(3):
    ext=np.r_[arr[-7:,j], arr[:,j], arr[:7,j]]
    ker=np.array([1,2,3,4,3,2,1],dtype=float); ker/=ker.sum()
    sm=np.convolve(ext, ker, mode='same')[7:-7]
    arr[:,j]=sm
pred24={k:(arr[i,0],arr[i,1],arr[i,2]) for i,k in enumerate(keys)}

# evaluate 2024
prev_grp={d:g.set_index('minute')[['AZ','EL']].reindex(range(1440)) for d,g in frames[2023].groupby('day')}
cur_grp={d:g.set_index('minute')[['AZ','EL']].reindex(range(1440)) for d,g in frames[2024].groupby('day')}
print('smooth day-param model', apply_and_eval(prev_grp, cur_grp, pred24))
# compare last actual day params
p_last={d:(v[0],v[1],v[2]) for d,v in params[2023].items()}
print('last params', apply_and_eval(prev_grp, cur_grp, p_last))
