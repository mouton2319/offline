#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
rolling_forecast.py — ローリング修正型予測エンジンとその評価。

=== 核心アイデア ===
因果Transformer+MH(multi-horizon直接予測、target_mode="cv_residual_mh", H=20)は、
系列 [1,L] を1回forwardすると「全位置i」の出力が同時に得られる。位置iの出力は
「iまでの履歴で作った h=1..20 の累積CV残差予測」である。つまり航跡1本の
「全時点でのローリング予測(観測が増えるたびに20歩先まで更新される様子)」は、
末尾256点で収まるなら 1 forward で全部出る。

=== 位置iの復元(eval_batch の _predict_mh_cum / mh版 val 評価と厳密に一致)===
  cv_i        = 位置iまでの直近 cv_n(=6) 点の移動量平均(cv_disp_from_seq(disp,cv_n)[i])
  residual_h  = out[i,h] * mh_res_std[h] + mh_res_mean[h]    (非標準化)
  cum[i,h]    = h * cv_i + residual_h                        (起点iからの累積変位 km)
  lon_h       = lon_i + cum_x[i,h] / km_per_deg_lon(lat_i)
  lat_h       = lat_i + cum_y[i,h] / KM_PER_DEG_LAT
アンサンブルは各モデルの cum[i,h](物理量km)を平均してから位置化(eval_batch と同一)。

=== 窓処理 ===
履歴が max_len(=256) を超える長い航跡は、末尾256点の窓で処理する。位置iを予測する
には「iまでの履歴(末尾256点)」が必要。全位置を覆うには窓を跨いで複数forward する。
本実装は「窓の右端 = 位置i」となるよう、必要な位置を max_len 刻みのブロックに分け、
各ブロックにつき1回 forward して窓内の全有効位置を一括で埋める(_rolling_cum 参照)。

サブコマンド:
  forecast : 1航跡のローリング予測CSVを出力(運用デモ用)
  evaluate : 多数航跡でローリング品質を集計(リードタイム/固定ターゲット収束/機動イベント回復)

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\src\rolling_forecast.py forecast `
    --models A.pt,B.pt --traj-csv <path> --min-history 20 --out-csv <path> --device cuda
  python .\src\rolling_forecast.py evaluate `
    --models A.pt,B.pt --data-dir .\claude_test\holdout2017 --min-len 150 --limit 300 `
    --min-history 20 --out-dir .\claude_test\eval_results\rolling --device cuda
"""

from __future__ import annotations

import argparse
import math
import random
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from traj_common import (   # noqa: E402
    load_model, lonlat_to_disp_km, cv_disp_from_seq, KM_PER_DEG_LAT,
)
from eval_batch import read_traj, haversine_km_arr, _km_per_deg_lon_arr   # noqa: E402


# ===========================================================================
# ローリング予測の中核: 1航跡の「全位置i × 全horizon h」の累積変位 cum を計算
# ===========================================================================
def _rolling_cum_one_model(model, cfg, disp, positions, device, gpu_batch):
    """1モデルで、指定位置 positions の各iについて累積変位 cum[i,h](km)を返す。

    disp: [L,2] 航跡全体の移動量(先頭0を含む)。
    positions: 予測を出したい位置iの配列(昇順、各 i は 0..L-1、i>=1 が実質有効)。
    返り値: cum [len(positions), H, 2](起点iからの累積変位km、位置変換前の物理量)。

    === 窓処理(eval_batch と厳密一致させるための要点)===
    位置iの予測は「iを右端とする末尾 min(i+1, max_ctx) 点の窓」を入力し、その窓の
    最終位置(=右端i)の出力 [H,2] を採用する。これは eval_batch の _predict_mh_cum が
    「末尾 max_ctx 点を入力し [:, -1] を取る」のと完全に同一。
    複数位置を1窓に相乗りさせて中間位置の出力を流用すると、その位置から見た窓左端と
    絶対位置符号が eval_batch と変わり出力がずれる(検証で確認済み)ため、位置ごとに
    「iを右端とする窓」を切る。効率化として、窓長が同じ位置(i+1>=max_ctx なら全て
    窓長 max_ctx で揃う)を gpu_batch 単位でまとめて1回の forward に載せる。
    """
    import torch
    max_ctx = int(cfg.max_len)
    cv_n = int(cfg.cv_n_last)
    H = int(getattr(cfg, "horizon", 20))
    fm = np.asarray(cfg.feat_mean, dtype=np.float64)         # [2] (dx,dy)
    fs = np.asarray(cfg.feat_std, dtype=np.float64)
    mh_mean = np.asarray(cfg.mh_res_mean, dtype=np.float64)  # [H,2]
    mh_std = np.asarray(cfg.mh_res_std, dtype=np.float64)    # [H,2]

    disp = np.asarray(disp, dtype=np.float64)                # [L,2]
    L = disp.shape[0]
    positions = np.asarray(positions, dtype=np.int64)
    NP = len(positions)
    # 位置iまでの直近cv_n点平均(全位置分を一括計算)。cv_disp_from_seq と同一定義。
    # cfg.cv_n_last==0 は「アンカー無し変種」: CV項ゼロ。cv_disp_from_seq は cv_n=0 で
    # ゼロ割になるため呼ばず、明示ゼロ [L,2] を使う(累積変位は residual のみで復元)。
    if cv_n <= 0:
        cv_all = np.zeros((L, 2), dtype=np.float64)          # [L,2] アンカー無し
    else:
        cv_all = cv_disp_from_seq(disp, cv_n)                # [L,2]

    out_std = np.zeros((NP, H, 2), dtype=np.float64)         # 標準化スケールのモデル出力

    # 各位置iの窓長 ctx_i = min(i+1, max_ctx)。窓長が同じ位置をまとめてバッチ forward する。
    ctx_len = np.minimum(positions + 1, max_ctx)             # [NP]
    from collections import defaultdict
    by_ctx = defaultdict(list)
    for k in range(NP):
        by_ctx[int(ctx_len[k])].append(k)

    model.eval()
    with torch.no_grad():
        for ctx, ks in by_ctx.items():
            ks = np.asarray(ks, dtype=np.int64)
            # このグループの各位置iについて窓 [i-ctx+1, i] を切る(全て同じ窓長 ctx)。
            for s in range(0, len(ks), int(gpu_batch)):
                e = min(len(ks), s + int(gpu_batch))
                sub = ks[s:e]
                ii = positions[sub]                          # [b] 窓右端(=起点)
                # バッチの各サンプルの窓 disp を積む [b, ctx, 2]。
                xb = np.empty((len(sub), ctx, 2), dtype=np.float64)
                for bi, i in enumerate(ii):
                    xb[bi] = disp[i - ctx + 1:i + 1]
                x = (xb - fm) / fs                           # 標準化(dx,dy のみ)
                xt = torch.from_numpy(x.astype(np.float32)).to(device)     # [b,ctx,2]
                pad = torch.zeros(xt.shape[0], ctx, dtype=torch.bool, device=device)
                o = model(xt, pad_mask=pad)[:, -1].cpu().numpy()           # [b, 2*H] 右端出力
                out_std[sub] = o.reshape(len(sub), H, 2)

    # 標準化解除 -> 累積変位 cum[i,h] = h*cv_i + residual
    residual = out_std * mh_std[None, :, :] + mh_mean[None, :, :]     # [NP,H,2]
    h_idx = np.arange(1, H + 1, dtype=np.float64)[None, :, None]      # [1,H,1]
    cv_pos = cv_all[positions]                                        # [NP,2]
    cum = h_idx * cv_pos[:, None, :] + residual                      # [NP,H,2]
    return cum


def rolling_forecast_positions(models, cfgs, lon, lat, positions, device, gpu_batch):
    """複数モデルのアンサンブルで、指定位置 positions の各iについて
    h=1..H の予測位置 (pred_lon, pred_lat) を返す。

    アンサンブル則(eval_batch と同一): 各モデルの累積変位 cum[i,h](km)を平均してから
    位置化する。cv_i / lon_i / lat_i は履歴のみから決まりモデル非依存。
    返り値: pred_lon [NP,H], pred_lat [NP,H], H。
    """
    lon = np.asarray(lon, dtype=np.float64)
    lat = np.asarray(lat, dtype=np.float64)
    disp = lonlat_to_disp_km(lon, lat)                       # [L,2]
    positions = np.asarray(positions, dtype=np.int64)

    cums = [_rolling_cum_one_model(m, c, disp, positions, device, gpu_batch)
            for m, c in zip(models, cfgs)]
    cum = np.mean(np.stack(cums, axis=0), axis=0)            # [NP,H,2] 平均累積変位km

    lon_i = lon[positions]                                   # [NP] 起点(観測)位置
    lat_i = lat[positions]
    lon_scale = _km_per_deg_lon_arr(lat_i)                   # [NP]
    pred_lon = lon_i[:, None] + cum[:, :, 0] / lon_scale[:, None]     # [NP,H]
    pred_lat = lat_i[:, None] + cum[:, :, 1] / KM_PER_DEG_LAT         # [NP,H]
    H = cum.shape[1]
    return pred_lon, pred_lat, H


# ===========================================================================
# (a) forecast: 1航跡のローリング予測CSV
# ===========================================================================
def cmd_forecast(args) -> int:
    import torch
    device = torch.device(args.device if args.device else
                          ("cuda" if torch.cuda.is_available() else "cpu"))
    model_paths = [s.strip() for s in str(args.models).split(",") if s.strip()]
    models, cfgs = [], []
    for mp in model_paths:
        m, c = load_model(Path(mp), device)
        models.append(m); cfgs.append(c)
    _check_mh(cfgs, model_paths)

    lon, lat = read_traj(Path(args.traj_csv))
    L = len(lon)
    min_hist = int(args.min_history)
    # 予測起点 i は min-history 以上の全位置(ただし i <= L-1)。
    positions = np.arange(min_hist, L, dtype=np.int64)
    if len(positions) == 0:
        print(f"[ERROR] 航跡が短すぎます(L={L}, min_history={min_hist})。", file=sys.stderr)
        return 2

    pred_lon, pred_lat, H = rolling_forecast_positions(
        models, cfgs, lon, lat, positions, device, int(args.gpu_batch))

    rows = []
    for k, i in enumerate(positions):
        for h in range(1, H + 1):
            rows.append({
                "rev_i": int(i),
                "rev_lon": float(lon[i]),
                "rev_lat": float(lat[i]),
                "h": int(h),
                "pred_lon": float(pred_lon[k, h - 1]),
                "pred_lat": float(pred_lat[k, h - 1]),
            })
    df = pd.DataFrame(rows)
    out_csv = Path(args.out_csv)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)
    print(f"[forecast] 航跡 {Path(args.traj_csv).name}  L={L}  起点数={len(positions)}  H={H}")
    print(f"[forecast] CSV -> {out_csv}  ({len(df)} 行)")
    return 0


# ===========================================================================
# 機動イベント検出(実測のみから、モデル出力に依存しない)
# ===========================================================================
def detect_events(lon, lat):
    """実測航跡から機動イベントの発生歩 e を検出する。

    速度 speed[t] = 点 t-1 -> t の移動量 |disp[t]| (km/step)。方位は移動ベクトルから。
    返り値: dict(kind -> [e, ...])。e は「イベントが発生する歩」(disp/位置のインデックス)。

      stop_onset: 直前5歩の平均速度 >= 0.15 km/step かつ
                  当該歩以降3歩の速度がすべて < 0.03 km/step になる最初の歩
      reversal  : 移動中(速度>=0.05)で、3歩以内に累積方位変化が120度を超える起点
      sharp_turn: 移動中で1歩の方位変化が45度以上
    """
    lon = np.asarray(lon, dtype=np.float64)
    lat = np.asarray(lat, dtype=np.float64)
    disp = lonlat_to_disp_km(lon, lat)                  # [L,2], disp[0]=0
    L = len(disp)
    speed = np.hypot(disp[:, 0], disp[:, 1])            # [L] km/step (speed[0]=0)
    heading = np.arctan2(disp[:, 0], disp[:, 1])        # [L] 北=0,東=+ (rad)
    # 1歩ごとの方位変化 dh[t] = heading[t] - heading[t-1] (t>=2で意味を持つ)
    dh = np.zeros(L, dtype=np.float64)
    if L >= 2:
        d = np.diff(heading)
        d = np.arctan2(np.sin(d), np.cos(d))            # [-pi,pi]
        dh[1:] = d
    dh_deg = np.degrees(dh)

    events = {"stop_onset": [], "reversal": [], "sharp_turn": []}

    # --- stop_onset ---
    # e は「当該歩」。直前5歩 = speed[e-5..e-1]、以降3歩 = speed[e..e+2]。
    stop_flag = np.zeros(L, dtype=bool)
    for e in range(5, L - 2):
        prev5 = speed[e - 5:e]
        if prev5.size < 5:
            continue
        if float(prev5.mean()) >= 0.15 and np.all(speed[e:e + 3] < 0.03):
            stop_flag[e] = True
    # 「最初の歩」= 連続する停止開始のうち先頭のみ採用(直前歩が非停止開始)。
    for e in range(L):
        if stop_flag[e] and not (e > 0 and stop_flag[e - 1]):
            events["stop_onset"].append(int(e))

    # --- reversal ---
    # 移動中(speed>=0.05)の起点 e から、3歩以内(e+1,e+2,e+3)の累積方位変化が120度超。
    rev_flag = np.zeros(L, dtype=bool)
    for e in range(1, L - 1):
        if speed[e] < 0.05:
            continue
        cum_turn = 0.0
        hit = False
        for w in range(1, 4):
            t = e + w
            if t >= L:
                break
            # t で移動していないと方位が不定なので、移動している歩のみ加算。
            if speed[t] < 0.05:
                continue
            cum_turn += dh_deg[t]
            if abs(cum_turn) > 120.0:
                hit = True
                break
        if hit:
            rev_flag[e] = True
    for e in range(L):
        if rev_flag[e] and not (e > 0 and rev_flag[e - 1]):
            events["reversal"].append(int(e))

    # --- sharp_turn ---
    # 移動中(両側の歩が speed>=0.05)で1歩の方位変化が45度以上。e=その歩。
    st_flag = np.zeros(L, dtype=bool)
    for e in range(2, L):
        if speed[e] >= 0.05 and speed[e - 1] >= 0.05 and abs(dh_deg[e]) >= 45.0:
            st_flag[e] = True
    for e in range(L):
        if st_flag[e] and not (e > 0 and st_flag[e - 1]):
            events["sharp_turn"].append(int(e))

    return events


# ===========================================================================
# (b) evaluate: 多数航跡でローリング品質を集計
# ===========================================================================
def _check_mh(cfgs, model_paths):
    bad = [mp for mp, c in zip(model_paths, cfgs)
           if getattr(c, "target_mode", "disp") != "cv_residual_mh"]
    if bad:
        raise SystemExit(f"[ERROR] このツールは target_mode='cv_residual_mh' 専用です。"
                         f"非対応モデル: {bad}")


def cmd_evaluate(args) -> int:
    import torch
    device = torch.device(args.device if args.device else
                          ("cuda" if torch.cuda.is_available() else "cpu"))
    model_paths = [s.strip() for s in str(args.models).split(",") if s.strip()]
    models, cfgs = [], []
    for mp in model_paths:
        m, c = load_model(Path(mp), device)
        models.append(m); cfgs.append(c)
    _check_mh(cfgs, model_paths)
    H = int(getattr(cfgs[0], "horizon", 20))
    min_hist = int(args.min_history)

    # --- 対象航跡の選定: min-len 以上 -> 名前順 -> シャッフル(seed42) -> limit 件 ---
    data_dir = Path(args.data_dir)
    all_files = sorted(data_dir.glob(args.pattern))   # 名前順
    long_files = []
    for p in all_files:
        # 点数チェック(高速: 行数カウント)。
        try:
            n = sum(1 for _ in open(p, encoding="utf-8", errors="ignore")) - 1
        except Exception:
            continue
        if n >= int(args.min_len):
            long_files.append(p)
    rng = random.Random(42)
    rng.shuffle(long_files)
    sel_files = long_files[:int(args.limit)] if args.limit and args.limit > 0 else long_files
    print(f"[evaluate] min-len>={args.min_len} の航跡 {len(long_files)} 件 -> "
          f"シャッフル(seed42) -> 対象 {len(sel_files)} 件")

    # --- 誤差アキュムレータ ---
    # 1. リードタイム曲線: err[i,h] を全(航跡,i)で平均 -> h の関数。
    lead_sum = np.zeros(H, dtype=np.float64)
    lead_cnt = np.zeros(H, dtype=np.int64)
    # 2. 固定ターゲット収束: err[j-h, h](ターゲットjをh歩前に予測)を h で平均。
    fixed_sum = np.zeros(H, dtype=np.float64)
    fixed_cnt = np.zeros(H, dtype=np.int64)
    # 3. 機動イベント回復: kind -> h(5,10) -> k(-10..+10) -> [errリスト]
    K_RANGE = list(range(-10, 11))                   # k = i - e
    H_SET = [5, 10]
    ev_kinds = ["stop_onset", "reversal", "sharp_turn"]
    ev_sum = {kind: {h: {k: 0.0 for k in K_RANGE} for h in H_SET} for kind in ev_kinds}
    ev_cnt = {kind: {h: {k: 0 for k in K_RANGE} for h in H_SET} for kind in ev_kinds}
    ev_count = {kind: 0 for kind in ev_kinds}        # 検出イベント数(集計に寄与したもの)
    ev_count_raw = {kind: 0 for kind in ev_kinds}    # 検出イベント総数

    n_traj = 0
    for p in sel_files:
        lon, lat = read_traj(p)
        L = len(lon)
        if L < min_hist + 2:
            continue
        n_traj += 1
        # 有効起点 i: min_hist <= i <= L-2 (i+1..i+H の一部が実測に存在)。
        positions = np.arange(min_hist, L - 1, dtype=np.int64)
        if len(positions) == 0:
            continue
        pred_lon, pred_lat, Hh = rolling_forecast_positions(
            models, cfgs, lon, lat, positions, device, int(args.gpu_batch))

        # err[k_pos, h-1] = haversine(位置iからのh歩予測, 実測[i+h])。i+h<=L-1 のみ有効。
        NP = len(positions)
        err = np.full((NP, Hh), np.nan, dtype=np.float64)
        for k, i in enumerate(positions):
            hmax = min(Hh, (L - 1) - i)              # i+h<=L-1
            if hmax < 1:
                continue
            tl = lon[i + 1:i + hmax + 1]
            ta = lat[i + 1:i + hmax + 1]
            e = haversine_km_arr(pred_lon[k, :hmax], pred_lat[k, :hmax], tl, ta)
            err[k, :hmax] = e

        # 1. リードタイム曲線
        for h in range(Hh):
            col = err[:, h]
            valid = col[~np.isnan(col)]
            lead_sum[h] += valid.sum()
            lead_cnt[h] += valid.size

        # 2. 固定ターゲット収束: 各ターゲット時刻 j に対し err[j-h, h] を「何歩前の
        #    予測か h」の関数で平均。「同じ地点に近づくほどどれだけ良くなるか」を見る。
        #    公平な収束曲線にするため、全 h=1..H で予測起点 i=j-h が有効(有効起点かつ
        #    err[i,h] が有効)なターゲット j のみを対象にする。こうすると各 h が「同一の
        #    ターゲット集合」で平均され、hによる母集団差なしに収束が読める。
        #    有効起点は positions(min_hist<=i<=L-2)。i=j-h が positions に入り、
        #    かつ i+h=j<=L-1(=ターゲットが実測に存在)が全 h で成るのは、
        #    j-H >= min_hist かつ j <= L-1 のとき。
        pos_index_ft = {int(i): k for k, i in enumerate(positions)}
        for j in range(min_hist + Hh, L):   # j-Hh>=min_hist かつ j<=L-1
            ok = True
            vals = np.empty(Hh, dtype=np.float64)
            for h in range(1, Hh + 1):
                i = j - h
                kk = pos_index_ft.get(i, None)
                if kk is None:
                    ok = False; break
                v = err[kk, h - 1]
                if np.isnan(v):
                    ok = False; break
                vals[h - 1] = v
            if ok:
                fixed_sum += vals
                fixed_cnt += 1

        # 3. 機動イベント回復分析
        events = detect_events(lon, lat)
        pos_index = {int(i): k for k, i in enumerate(positions)}
        for kind in ev_kinds:
            for e in events[kind]:
                ev_count_raw[kind] += 1
                contributed = False
                for h in H_SET:
                    for k in K_RANGE:
                        i = e + k
                        # i は有効起点(min_hist<=i<=L-2)かつ err[i,h] が有効(i+h<=L-1)。
                        if i not in pos_index:
                            continue
                        kk = pos_index[i]
                        if i + h > L - 1:
                            continue
                        v = err[kk, h - 1]
                        if np.isnan(v):
                            continue
                        ev_sum[kind][h][k] += v
                        ev_cnt[kind][h][k] += 1
                        contributed = True
                if contributed:
                    ev_count[kind] += 1

    # --- 集計 & 出力 ---
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. リードタイム曲線 CSV
    lead_mean = np.where(lead_cnt > 0, lead_sum / np.maximum(lead_cnt, 1), np.nan)
    df_lead = pd.DataFrame({
        "h": np.arange(1, H + 1),
        "mean_err_km": lead_mean,
        "n": lead_cnt,
    })
    df_lead.to_csv(out_dir / "leadtime_curve.csv", index=False)

    # 2. 固定ターゲット収束 CSV
    fixed_mean = np.where(fixed_cnt > 0, fixed_sum / np.maximum(fixed_cnt, 1), np.nan)
    df_fixed = pd.DataFrame({
        "steps_ahead_h": np.arange(1, H + 1),
        "mean_err_km": fixed_mean,
        "n": fixed_cnt,
    })
    df_fixed.to_csv(out_dir / "fixed_target_convergence.csv", index=False)

    # 3. 機動イベント回復曲線 CSV(種別 × h × k)
    rec_rows = []
    for kind in ev_kinds:
        for h in H_SET:
            for k in K_RANGE:
                c = ev_cnt[kind][h][k]
                m = (ev_sum[kind][h][k] / c) if c > 0 else np.nan
                rec_rows.append({
                    "event": kind, "h": h, "k": k,
                    "mean_err_km": m, "n": c,
                })
    df_rec = pd.DataFrame(rec_rows)
    df_rec.to_csv(out_dir / "maneuver_recovery.csv", index=False)

    # --- 標準出力サマリ ---
    print("=" * 72)
    print(f"[SUMMARY] 対象航跡数 N={n_traj}  min_history={min_hist}  H={H}")
    print(f"  モデル(アンサンブル {len(models)}):")
    for mp in model_paths:
        print(f"    - {mp}")
    print("-" * 72)
    print("  イベント検出数(種別ごと、括弧内=集計に寄与した数):")
    for kind in ev_kinds:
        print(f"    {kind:11s}: {ev_count_raw[kind]:5d} (寄与 {ev_count[kind]})")
    print("-" * 72)
    print("  リードタイム曲線 (全(航跡,i)平均 err vs h):")
    for h in (1, 2, 3, 5, 10, 15, 20):
        if h <= H:
            print(f"    h={h:2d}: {lead_mean[h - 1]:.4f} km  (n={lead_cnt[h - 1]})")
    print("  固定ターゲット収束 (h歩前の予測の平均誤差):")
    for h in (1, 2, 3, 5, 10, 15, 20):
        if h <= H:
            print(f"    h={h:2d}前: {fixed_mean[h - 1]:.4f} km  (n={fixed_cnt[h - 1]})")
    print("-" * 72)
    print("  機動イベント回復曲線 (k=i-e の関数、h=10 の平均誤差 km):")
    print("    k<0=発生前(不意打ち), k>=0=発生後(回復過程)")
    k_show = [-10, -5, -2, 0, 2, 5, 10]
    header = "    " + f"{'event':11s}" + "".join(f" k={k:+d}" for k in k_show)
    print(header)
    for kind in ev_kinds:
        cells = []
        for k in k_show:
            c = ev_cnt[kind][10][k]
            m = (ev_sum[kind][10][k] / c) if c > 0 else float("nan")
            cells.append(f"{m:6.3f}" if c > 0 else "   -- ")
        print(f"    {kind:11s}" + " ".join(cells))
    print("  (h=5 の同曲線は maneuver_recovery.csv 参照)")
    print("=" * 72)
    print(f"[evaluate] CSV出力先: {out_dir}")
    print(f"    - leadtime_curve.csv")
    print(f"    - fixed_target_convergence.csv")
    print(f"    - maneuver_recovery.csv")

    # --- (c) デモ航跡の選定情報を返す(呼び出し側で forecast 実行用) ---
    # stop_onset または reversal を含む代表航跡を2本、名前を出力(後段で forecast する)。
    demo_files = []
    for p in sel_files:
        lon, lat = read_traj(p)
        ev = detect_events(lon, lat)
        if ev["stop_onset"] or ev["reversal"]:
            demo_files.append(p.name)
        if len(demo_files) >= 2:
            break
    if demo_files:
        print(f"[evaluate] デモ候補(stop_onset/reversal含む): {demo_files}")
    with (out_dir / "demo_candidates.txt").open("w", encoding="utf-8") as fp:
        for name in demo_files:
            fp.write(name + "\n")
    return 0


# ===========================================================================
# CLI
# ===========================================================================
def main() -> int:
    p = argparse.ArgumentParser(description="ローリング修正型予測エンジン(MH×アンサンブル)。")
    sub = p.add_subparsers(dest="cmd", required=True)

    pf = sub.add_parser("forecast", help="1航跡のローリング予測CSVを出力")
    pf.add_argument("--models", required=True, help="traj_model.pt をカンマ区切り(アンサンブル)")
    pf.add_argument("--traj-csv", required=True)
    pf.add_argument("--min-history", type=int, default=20)
    pf.add_argument("--out-csv", required=True)
    pf.add_argument("--gpu-batch", type=int, default=256)
    pf.add_argument("--device", default="")

    pe = sub.add_parser("evaluate", help="多数航跡でローリング品質を集計")
    pe.add_argument("--models", required=True, help="traj_model.pt をカンマ区切り(アンサンブル)")
    pe.add_argument("--data-dir", required=True)
    pe.add_argument("--pattern", default="*.csv")
    pe.add_argument("--min-len", type=int, default=150)
    pe.add_argument("--limit", type=int, default=300)
    pe.add_argument("--min-history", type=int, default=20)
    pe.add_argument("--out-dir", required=True)
    pe.add_argument("--gpu-batch", type=int, default=256)
    pe.add_argument("--device", default="")

    args = p.parse_args()
    if args.cmd == "forecast":
        return cmd_forecast(args)
    if args.cmd == "evaluate":
        return cmd_evaluate(args)
    p.error("不明なサブコマンド")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
