import numpy as np, pandas as pd

def load_year(y):
    df=pd.read_csv(f'{y}_calc_az_el.csv', usecols=['date','AZ','EL'])
    dt=pd.to_datetime(df['date'])
    df['day_key']=dt.dt.strftime('%m-%d')
    df['minute']=dt.dt.hour*60+dt.dt.minute
    return df

def fit_day(minute, values, H):
    t=minute.to_numpy(dtype=float)
    y=values.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/1440.0
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    return np.linalg.lstsq(X,y,rcond=None)[0]

def eval_day(minute, beta, H):
    t=minute.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/1440.0
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    return X@beta

frames={y:load_year(y) for y in range(2017,2025)}
for H in [1,2,3,4,5,6,8]:
    coefs={y:{} for y in range(2017,2025)}
    for y,df in frames.items():
        for day,g in df.groupby('day_key'):
            coefs[y][day]=(fit_day(g['minute'], g['AZ'], H), fit_day(g['minute'], g['EL'], H))
    truth=frames[2024]
    for method in ['repeat','linear_recent4']:
        pred_az=[]; pred_el=[]; true_az=[]; true_el=[]
        for day,g in truth.groupby('day_key'):
            hist=[]
            for y in range(2017,2024):
                if day in coefs[y]: hist.append((y,coefs[y][day]))
            years=np.array([y for y,_ in hist], dtype=float)
            az_mat=np.stack([c[0] for _,c in hist], axis=0)
            el_mat=np.stack([c[1] for _,c in hist], axis=0)
            if method=='repeat':
                b_az=az_mat[-1]; b_el=el_mat[-1]
            else:
                yrs=years[-4:] if len(years)>=4 else years
                A=np.c_[np.ones_like(yrs), yrs]
                B=np.linalg.lstsq(A, az_mat[-len(yrs):], rcond=None)[0]; b_az=np.array([1,2024.0])@B
                B=np.linalg.lstsq(A, el_mat[-len(yrs):], rcond=None)[0]; b_el=np.array([1,2024.0])@B
            paz=eval_day(g['minute'], b_az, H)
            pel=eval_day(g['minute'], b_el, H)
            pred_az.append(paz); pred_el.append(pel)
            true_az.append(g['AZ'].to_numpy()); true_el.append(g['EL'].to_numpy())
        az=np.abs(np.concatenate(pred_az)-np.concatenate(true_az))
        el=np.abs(np.concatenate(pred_el)-np.concatenate(true_el))
        print('H',H,method,'mean',float((az.mean()+el.mean())/2),'max',float(max(az.max(), el.max())))
