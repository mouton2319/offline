#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
trajectory_transformer.py(v1)の予測を「実測 vs 予測」で地図可視化するツール。

1本の航跡CSVを「前半(入力)」と「後半(正解)」に分け、
  - 前半をモデルに入力 → 未来を自己回帰予測(AI)
  - 等速直線(CV)ベースラインも外挿
  - 実測の後半(正解)と重ねて cartopy 地図に描画
  - 各ステップの haversine 誤差(km)を集計
する。AIがCVベースラインや実測にどれだけ追従できるかを目視・数値で確認できる。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\visualize_trajectory_prediction.py `
    --model .\\claude_test\\artifacts_traj_smoke\\traj_model.pt `
    --traj-csv .\\claude_test\\trajectories_smoke\\MMSI_xxx_traj_0000.csv `
    --input-len 80 --steps 20 --out-dir .\\claude_test\\viz --device cuda
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")               # GUI不要・ファイル保存のみ
import matplotlib.pyplot as plt

# 同じ src フォルダの trajectory_transformer をモジュールとして使う。
sys.path.insert(0, str(Path(__file__).resolve().parent))
from traj_common import (   # noqa: E402
    load_model, lonlat_to_disp_km, km_per_deg_lon, KM_PER_DEG_LAT,
    build_feature_matrix, reconstruct_next_extra, unix_seconds,
)


def haversine_km_arr(lon1, lat1, lon2, lat2) -> np.ndarray:
    """2点間の球面距離(km)。配列対応。"""
    R = 6371.0088
    lon1, lat1, lon2, lat2 = map(lambda a: np.radians(np.asarray(a, dtype=np.float64)),
                                 (lon1, lat1, lon2, lat2))
    dlon, dlat = lon2 - lon1, lat2 - lat1
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return 2.0 * R * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def rollout_ai(model, cfg, hist_df, steps, device, stop_gate="soft"):
    """前半航跡(hist_df)から未来 steps 点を自己回帰予測する(traj_predict と同じロジック)。
    stop_gate: 停止ゲート版の復元方式。"soft"=(1-p)*(cv+res) / "hard"=p>0.5なら移動量0(L1最適)。"""
    import torch
    lon = pd.to_numeric(hist_df["lon"], errors="coerce").to_numpy(dtype=np.float64)
    lat = pd.to_numeric(hist_df["lat"], errors="coerce").to_numpy(dtype=np.float64)
    disp = lonlat_to_disp_km(lon, lat)                     # [P,2]
    seq_disp = list(disp)
    seq_extra = list(build_feature_matrix(hist_df, cfg.feature_cols)) if cfg.feature_cols else None
    unix = unix_seconds(hist_df)
    cur_unix = float(unix[-1]) if len(unix) else 0.0
    interval = float(cfg.interval_minutes)
    dm, ds = np.asarray(cfg.disp_mean), np.asarray(cfg.disp_std)
    fm, fs = np.asarray(cfg.feat_mean), np.asarray(cfg.feat_std)
    cur_lon, cur_lat = float(lon[-1]), float(lat[-1])
    max_ctx = int(cfg.max_len)
    out_lon, out_lat = [], []
    model.eval()
    with torch.no_grad():
        for _ in range(int(steps)):
            ctx = min(len(seq_disp), max_ctx)
            d = np.stack(seq_disp[-ctx:], axis=0)
            if cfg.feature_cols:
                e = np.stack(seq_extra[-ctx:], axis=0)
                feats = np.concatenate([d, e], axis=1)
            else:
                feats = d
            x = (feats - fm) / fs
            xt = torch.from_numpy(x.astype(np.float32)).unsqueeze(0).to(device)
            pad = torch.zeros(1, ctx, dtype=torch.bool, device=device)
            nxt = model(xt, pad_mask=pad)[0, -1].cpu().numpy()
            mode = getattr(cfg, "target_mode", "disp")
            if mode == "cv_residual":
                # CV残差版: 等速予測(直近cv_n平均) + モデル残差
                residual = nxt * np.asarray(cfg.res_std) + np.asarray(cfg.res_mean)
                cv = np.stack(seq_disp[-int(cfg.cv_n_last):], axis=0).mean(axis=0)
                dxy = cv + residual
            elif mode == "cv_residual_stop":
                # 停止ゲート版: soft=(1-p)*(cv+残差) / hard=p>0.5なら停止(L1最適な中央値に対応)
                residual = nxt[:2] * np.asarray(cfg.res_std) + np.asarray(cfg.res_mean)
                p_stop = 1.0 / (1.0 + math.exp(-float(nxt[2])))
                cv = np.stack(seq_disp[-int(cfg.cv_n_last):], axis=0).mean(axis=0)
                if stop_gate == "hard":
                    dxy = np.zeros(2) if p_stop > 0.5 else (cv + residual)
                else:
                    dxy = (1.0 - p_stop) * (cv + residual)
            else:
                dxy = nxt * ds + dm
            new_lon = cur_lon + dxy[0] / km_per_deg_lon(cur_lat)
            new_lat = cur_lat + dxy[1] / KM_PER_DEG_LAT
            out_lon.append(new_lon); out_lat.append(new_lat)
            prev_dxy = seq_disp[-1] if len(seq_disp) else None   # 直前の移動(turn_rate用)
            seq_disp.append(dxy.astype(np.float64))
            if cfg.feature_cols:
                cur_unix += interval * 60.0
                seq_extra.append(reconstruct_next_extra(cfg.feature_cols, new_lon, new_lat, cur_lon, cur_lat,
                                                        cur_unix, interval, prev_dxy=prev_dxy, cur_dxy=dxy))
            cur_lon, cur_lat = new_lon, new_lat
    return np.asarray(out_lon), np.asarray(out_lat)


def rollout_cv(hist_lon, hist_lat, steps, n_last):
    """等速直線(CV)ベースライン: 前半末尾 n_last 点の平均速度で外挿。"""
    disp = lonlat_to_disp_km(hist_lon, hist_lat)
    if len(disp) < 2:
        return np.full(steps, hist_lon[-1]), np.full(steps, hist_lat[-1])
    n = max(1, min(int(n_last), len(disp) - 1))
    v = disp[-n:].mean(axis=0)                              # 平均移動量(km/step)
    cur_lon, cur_lat = float(hist_lon[-1]), float(hist_lat[-1])
    out_lon, out_lat = [], []
    for _ in range(int(steps)):
        cur_lon = cur_lon + v[0] / km_per_deg_lon(cur_lat)
        cur_lat = cur_lat + v[1] / KM_PER_DEG_LAT
        out_lon.append(cur_lon); out_lat.append(cur_lat)
    return np.asarray(out_lon), np.asarray(out_lat)


def plot_map(hist, truth, pred, cv, title, out_png, use_cartopy):
    """入力・実測・予測・CV を1枚の地図に重ねて保存する。"""
    all_lon = np.concatenate([hist[0], truth[0], pred[0], cv[0]])
    all_lat = np.concatenate([hist[1], truth[1], pred[1], cv[1]])
    mlon = max(0.01, (all_lon.max() - all_lon.min()) * 0.15)
    mlat = max(0.01, (all_lat.max() - all_lat.min()) * 0.15)
    extent = [all_lon.min() - mlon, all_lon.max() + mlon,
              all_lat.min() - mlat, all_lat.max() + mlat]

    ax = None
    if use_cartopy:
        try:
            import cartopy.crs as ccrs
            import cartopy.feature as cfeature
            fig = plt.figure(figsize=(9, 8))
            ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
            ax.set_extent(extent, crs=ccrs.PlateCarree())
            ax.set_facecolor("#d8ecf3")   # 海は背景色で表現(OCEANポリゴンはDL回避のため使わない)
            ax.add_feature(cfeature.LAND.with_scale("10m"), facecolor="#efe9dd", zorder=0)
            ax.coastlines(resolution="10m", linewidth=0.6, color="#888")
            gl = ax.gridlines(draw_labels=True, linewidth=0.3, color="gray", alpha=0.5)
            gl.top_labels = gl.right_labels = False
            tk = {"transform": ccrs.PlateCarree()}
        except Exception as e:
            print(f"[WARN] cartopy描画に失敗、簡易プロットに切替: {e}", file=sys.stderr)
            ax = None
    if ax is None:
        fig, ax = plt.subplots(figsize=(9, 8))
        ax.set_xlim(extent[0], extent[1]); ax.set_ylim(extent[2], extent[3])
        ax.set_xlabel("lon"); ax.set_ylabel("lat")
        tk = {}

    ax.plot(hist[0], hist[1], "-", color="#1f77b4", lw=1.5, label="input (history)", **tk)
    ax.plot([hist[0][-1]], [hist[1][-1]], "o", color="#1f77b4", ms=9, mec="k", label="anchor", **tk)
    ax.plot(truth[0], truth[1], "-o", color="#2ca02c", lw=2, ms=4, label="truth (actual future)", **tk)
    ax.plot(pred[0], pred[1], "-x", color="#d62728", lw=2, ms=6, label="AI prediction", **tk)
    ax.plot(cv[0], cv[1], "--", color="#7f7f7f", lw=1.5, label="constant-velocity", **tk)
    ax.set_title(title, fontsize=11)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(out_png, dpi=130)
    plt.close(fig)


def main() -> int:
    p = argparse.ArgumentParser(description="航跡予測(v1)を 実測 vs 予測 で地図可視化する。")
    p.add_argument("--model", required=True, help="traj_model.pt")
    p.add_argument("--traj-csv", required=True, help="1航跡の完全なCSV")
    p.add_argument("--input-len", type=int, default=80, help="前半(入力)として使う点数")
    p.add_argument("--steps", type=int, default=20, help="未来予測の点数(実測がそれ未満なら自動で縮める)")
    p.add_argument("--cv-n-last", type=int, default=6, help="CVベースラインに使う直近点数")
    p.add_argument("--out-dir", default="claude_test/viz")
    p.add_argument("--no-cartopy", action="store_true", help="cartopyを使わず簡易プロットにする")
    p.add_argument("--stop-gate", default="soft", choices=["soft", "hard"],
                   help="停止ゲート版の復元方式(soft=(1-p)*(cv+res) / hard=p>0.5で移動量0)")
    p.add_argument("--device", default="")
    args = p.parse_args()

    import torch
    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    model, cfg = load_model(Path(args.model), device)

    df = pd.read_csv(args.traj_csv)
    if "unix_time" in df.columns:
        df = df.sort_values("unix_time").reset_index(drop=True)
    elif "timestamp" in df.columns:
        df = df.assign(_t=pd.to_datetime(df["timestamp"], utc=True, errors="coerce")).sort_values("_t").reset_index(drop=True)
    lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
    lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
    n = len(lon)

    input_len = min(int(args.input_len), n - 1)
    steps = min(int(args.steps), n - input_len)
    if input_len < 2 or steps < 1:
        raise ValueError(f"航跡が短すぎます(点数={n})。input-len/steps を小さくしてください。")

    hist_lon, hist_lat = lon[:input_len], lat[:input_len]
    truth_lon, truth_lat = lon[input_len:input_len + steps], lat[input_len:input_len + steps]

    # 前半(input_len点)のDataFrameを入力にして自己回帰予測(追加特徴も学習と同じ定義で供給)。
    hist_df = df.iloc[:input_len].reset_index(drop=True)
    pred_lon, pred_lat = rollout_ai(model, cfg, hist_df, steps, device, stop_gate=args.stop_gate)
    cv_lon, cv_lat = rollout_cv(hist_lon, hist_lat, steps, args.cv_n_last)

    ai_err = haversine_km_arr(pred_lon, pred_lat, truth_lon, truth_lat)
    cv_err = haversine_km_arr(cv_lon, cv_lat, truth_lon, truth_lat)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = Path(args.traj_csv).stem
    title = (f"{stem}  in={input_len} steps={steps}\n"
             f"AI MAE={ai_err.mean():.3f} km   CV MAE={cv_err.mean():.3f} km   "
             f"(AI final={ai_err[-1]:.3f}, CV final={cv_err[-1]:.3f})")
    out_png = out_dir / f"{stem}_pred.png"
    plot_map((hist_lon, hist_lat), (truth_lon, truth_lat), (pred_lon, pred_lat),
             (cv_lon, cv_lat), title, str(out_png), use_cartopy=not args.no_cartopy)

    # 各ステップの誤差をCSVにも保存。
    rows = pd.DataFrame({
        "step": np.arange(1, steps + 1),
        "truth_lon": truth_lon, "truth_lat": truth_lat,
        "pred_lon": pred_lon, "pred_lat": pred_lat,
        "cv_lon": cv_lon, "cv_lat": cv_lat,
        "ai_err_km": ai_err, "cv_err_km": cv_err,
    })
    out_csv = out_dir / f"{stem}_pred.csv"
    rows.to_csv(out_csv, index=False)

    print(f"[VIZ] {stem}: AI MAE={ai_err.mean():.3f} km  CV MAE={cv_err.mean():.3f} km")
    print(f"      map -> {out_png}")
    print(f"      csv -> {out_csv}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
