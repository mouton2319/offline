#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Batch re-evaluation helper for orbit_geo_7d23d_analog.py.

What it does:
1) Runs predict for all TLE files (or a subset) with ood_conf_floor=0.
2) Collects baseline/corrected AZEL metrics and prediction diagnostics.
3) Tunes an auto-stop rule (low-error / distance / uncertainty / corr-ratio).
4) Re-aggregates metrics with the selected rule.
5) Enforces zero-loss mode by including baseline-only fallback candidate.
"""

from __future__ import annotations

import argparse
import datetime as dt
import itertools
import json
import math
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def log(msg: str) -> None:
    print(msg, flush=True)


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def parse_stem_datetime(stem: str) -> Optional[dt.datetime]:
    m = re.search(r"(\d{4}-\d{2}-\d{2})[-_](\d{2})-(\d{2})-(\d{2})", str(stem))
    if m is None:
        return None
    try:
        d0 = dt.datetime.strptime(m.group(1), "%Y-%m-%d")
    except Exception:
        return None
    return d0.replace(hour=int(m.group(2)), minute=int(m.group(3)), second=int(m.group(4)))


def parse_float_list(text: Optional[str]) -> List[float]:
    if text is None:
        return []
    out: List[float] = []
    for tok in str(text).split(","):
        t = tok.strip()
        if not t:
            continue
        out.append(float(t))
    return out


def parse_quantile_list(text: Optional[str], default: Sequence[float]) -> List[float]:
    if text is None or str(text).strip() == "":
        return [float(x) for x in default]
    vals = parse_float_list(text)
    out: List[float] = []
    for v in vals:
        x = float(v)
        if x < 0.0 or x > 1.0:
            continue
        out.append(x)
    if len(out) == 0:
        out = [float(x) for x in default]
    # unique sorted
    return sorted(set(out))


def season_label_from_month(month: int, mode: str = "meteo4") -> str:
    m = int(month)
    if mode == "monthly":
        return f"M{m:02d}"
    # meteorological 4 seasons (default)
    if m in (12, 1, 2):
        return "DJF"
    if m in (3, 4, 5):
        return "MAM"
    if m in (6, 7, 8):
        return "JJA"
    return "SON"


def attach_season_cluster(df: pd.DataFrame, mode: str = "meteo4") -> pd.DataFrame:
    out = df.copy()
    months = pd.to_numeric(out["stem"].astype(str).str.slice(5, 7), errors="coerce")
    out["month"] = months
    out["season_cluster"] = [
        season_label_from_month(int(m), mode=mode) if pd.notna(m) else "UNK"
        for m in months
    ]
    return out


def quantile_grid(series: pd.Series, q_list: Sequence[float]) -> List[Optional[float]]:
    s = pd.to_numeric(series, errors="coerce")
    s = s[np.isfinite(s.to_numpy(dtype=np.float64))]
    vals: List[Optional[float]] = [None]
    if len(s) == 0:
        return vals
    for q in q_list:
        x = float(np.quantile(s.to_numpy(dtype=np.float64), q))
        if not np.isfinite(x):
            continue
        vals.append(x)
    # unique while preserving order
    u: List[Optional[float]] = []
    seen = set()
    for v in vals:
        key = "None" if v is None else f"{float(v):.12g}"
        if key in seen:
            continue
        seen.add(key)
        u.append(v)
    return u


def list_target_stems(
    tle_dir: Path,
    baseline_dir: Path,
    max_files: Optional[int] = None,
) -> List[str]:
    tles = {p.stem: p for p in tle_dir.glob("*.txt") if p.is_file()}
    csvs = {p.stem: p for p in baseline_dir.glob("*.csv") if p.is_file()}
    stems = sorted(set(tles.keys()).intersection(set(csvs.keys())))
    stems = [s for s in stems if parse_stem_datetime(s) is not None]
    stems.sort(key=lambda s: parse_stem_datetime(s))
    if max_files is not None and max_files > 0:
        stems = stems[: int(max_files)]
    return stems


def read_metric_pair(mpath: Path, segment: str) -> Tuple[float, float]:
    if not mpath.exists():
        return np.nan, np.nan
    df = pd.read_csv(mpath)
    sub = df[df["segment"] == segment].copy()
    if len(sub) == 0:
        return np.nan, np.nan
    b = sub[sub["kind"] == "baseline"]
    c = sub[sub["kind"] == "corrected"]
    if len(b) == 0 or len(c) == 0:
        return np.nan, np.nan
    b0 = b.iloc[0]
    c0 = c.iloc[0]
    baz = float(b0["AZ_RMSE"]) if pd.notna(b0["AZ_RMSE"]) else np.nan
    bez = float(b0["EL_RMSE"]) if pd.notna(b0["EL_RMSE"]) else np.nan
    caz = float(c0["AZ_RMSE"]) if pd.notna(c0["AZ_RMSE"]) else np.nan
    cez = float(c0["EL_RMSE"]) if pd.notna(c0["EL_RMSE"]) else np.nan
    b_azel = 0.5 * (baz + bez) if np.isfinite(baz) and np.isfinite(bez) else np.nan
    c_azel = 0.5 * (caz + cez) if np.isfinite(caz) and np.isfinite(cez) else np.nan
    return b_azel, c_azel


def build_predict_cmd(
    python_exe: str,
    predict_script: Path,
    model: Path,
    tle_file: Path,
    baseline_csv: Path,
    truth_csv: Path,
    out_corrected_csv: Path,
    out_pred_error_csv: Path,
    out_metrics_csv: Path,
    ood_conf_floor: float,
    days_horizon: Optional[int],
    fit_days: Optional[int],
    pre_days: Optional[int],
    step_minutes: Optional[int],
    sample_every: Optional[int],
    extra_args: Sequence[str],
) -> List[str]:
    cmd = [
        python_exe,
        str(predict_script),
        "predict",
        "--model",
        str(model),
        "--tle-file",
        str(tle_file),
        "--baseline-csv",
        str(baseline_csv),
        "--truth-csv",
        str(truth_csv),
        "--ood-conf-floor",
        str(float(ood_conf_floor)),
        "--min-ood-conf-apply",
        "0.0",
        "--out-corrected-csv",
        str(out_corrected_csv),
        "--out-pred-error-csv",
        str(out_pred_error_csv),
        "--out-metrics-csv",
        str(out_metrics_csv),
        "--no-plot",
        "--overwrite",
    ]
    if days_horizon is not None:
        cmd += ["--days-horizon", str(int(days_horizon))]
    if fit_days is not None:
        cmd += ["--fit-days", str(int(fit_days))]
    if pre_days is not None:
        cmd += ["--pre-days", str(int(pre_days))]
    if step_minutes is not None:
        cmd += ["--step-minutes", str(int(step_minutes))]
    if sample_every is not None:
        cmd += ["--sample-every", str(int(sample_every))]
    cmd += list(extra_args)
    return cmd


def evaluate_rule(df: pd.DataFrame, rule: Dict) -> Dict:
    x = df.copy()
    gate = np.zeros((len(x),), dtype=bool)

    lowerr = rule.get("auto_lowerr_th", None)
    if lowerr is not None:
        gate |= pd.to_numeric(x["est_base_azel_rmse"], errors="coerce").to_numpy(dtype=np.float64) < float(lowerr)

    max_dist = rule.get("auto_max_neighbor_dist", None)
    if max_dist is not None:
        gate |= pd.to_numeric(x["neighbor0_dist"], errors="coerce").to_numpy(dtype=np.float64) > float(max_dist)

    max_unc_az = rule.get("auto_max_unc_az", None)
    if max_unc_az is not None:
        gate |= pd.to_numeric(x["unc_az_rms"], errors="coerce").to_numpy(dtype=np.float64) > float(max_unc_az)

    max_unc_el = rule.get("auto_max_unc_el", None)
    if max_unc_el is not None:
        gate |= pd.to_numeric(x["unc_el_rms"], errors="coerce").to_numpy(dtype=np.float64) > float(max_unc_el)

    max_corr_ratio = rule.get("auto_max_corr_ratio", None)
    if max_corr_ratio is not None:
        gate |= pd.to_numeric(x["corr_ratio"], errors="coerce").to_numpy(dtype=np.float64) > float(max_corr_ratio)

    if bool(rule.get("force_all_stop", False)):
        gate[:] = True

    ev = evaluate_gate(df=x, gate=gate)
    ev["gate"] = gate
    return ev


def fallback_rule() -> Dict:
    return {
        "auto_lowerr_th": None,
        "auto_max_neighbor_dist": None,
        "auto_max_unc_az": None,
        "auto_max_unc_el": None,
        "auto_max_corr_ratio": None,
        "force_all_stop": True,
    }


def evaluate_gate(df: pd.DataFrame, gate: np.ndarray) -> Dict:
    x = df.copy()
    gg = np.asarray(gate, dtype=bool).reshape(-1)
    if len(gg) != len(x):
        raise ValueError("gate length mismatch")

    b = pd.to_numeric(x["azel_rmse_base_full"], errors="coerce").to_numpy(dtype=np.float64)
    c = pd.to_numeric(x["azel_rmse_corr_full"], errors="coerce").to_numpy(dtype=np.float64)
    s = np.where(gg, b, c)

    improve = np.full_like(b, np.nan)
    m = np.isfinite(b) & np.isfinite(s) & (np.abs(b) > 1e-12)
    improve[m] = (b[m] - s[m]) / b[m] * 100.0

    b2 = pd.to_numeric(x["azel_rmse_base_fut"], errors="coerce").to_numpy(dtype=np.float64)
    c2 = pd.to_numeric(x["azel_rmse_corr_fut"], errors="coerce").to_numpy(dtype=np.float64)
    s2 = np.where(gg, b2, c2)
    improve2 = np.full_like(b2, np.nan)
    m2 = np.isfinite(b2) & np.isfinite(s2) & (np.abs(b2) > 1e-12)
    improve2[m2] = (b2[m2] - s2[m2]) / b2[m2] * 100.0

    valid = np.isfinite(improve)
    losses = int(np.sum(improve[valid] < -1e-12))
    wins = int(np.sum(improve[valid] > 1e-12))
    ties = int(np.sum(np.abs(improve[valid]) <= 1e-12))
    gate_rate = float(np.mean(gg.astype(np.float64))) if len(gg) else 0.0
    return {
        "losses": losses,
        "wins": wins,
        "ties": ties,
        "n_valid": int(np.sum(valid)),
        "mean_improve_pct": float(np.nanmean(improve)) if np.any(valid) else np.nan,
        "median_improve_pct": float(np.nanmedian(improve)) if np.any(valid) else np.nan,
        "gate_rate": gate_rate,
        "selected_azel_rmse_mean": float(np.nanmean(s)) if np.any(np.isfinite(s)) else np.nan,
        "selected": s,
        "improve": improve,
        "selected_fut": s2,
        "improve_fut": improve2,
    }


def pick_best_rule(
    df: pd.DataFrame,
    lowerr_grid: Sequence[Optional[float]],
    dist_grid: Sequence[Optional[float]],
    unc_az_grid: Sequence[Optional[float]],
    unc_el_grid: Sequence[Optional[float]],
    corr_ratio_grid: Sequence[Optional[float]],
    target_losses: int = 0,
    objective_mode: str = "mean_first",
    min_mean_improve_pct: float = -1e18,
) -> Tuple[Dict, Dict]:
    best_rule: Optional[Dict] = None
    best_score: Optional[Tuple] = None
    best_eval: Optional[Dict] = None

    for lo, dd, ua, ue, cr in itertools.product(
        lowerr_grid, dist_grid, unc_az_grid, unc_el_grid, corr_ratio_grid
    ):
        rule = {
            "auto_lowerr_th": lo,
            "auto_max_neighbor_dist": dd,
            "auto_max_unc_az": ua,
            "auto_max_unc_el": ue,
            "auto_max_corr_ratio": cr,
            "force_all_stop": False,
        }
        ev = evaluate_rule(df, rule)
        losses = int(ev["losses"])
        mean_imp = float(ev["mean_improve_pct"]) if np.isfinite(ev["mean_improve_pct"]) else np.nan
        if objective_mode == "apply_first_noharm":
            if losses > int(target_losses):
                continue
            if (not np.isfinite(mean_imp)) or (mean_imp < float(min_mean_improve_pct)):
                continue
            apply_rate = float(1.0 - float(ev["gate_rate"]))
            score = (
                apply_rate,
                mean_imp,
                int(ev["wins"]),
                -float(ev["gate_rate"]),
            )
            if best_score is None or score > best_score:
                best_score = score
                best_rule = rule
                best_eval = ev
        else:
            # Legacy objective (mean-first, conservative fallback).
            miss = max(0, losses - int(target_losses))
            score = (
                miss,
                losses,
                -mean_imp if np.isfinite(mean_imp) else 1e9,
                -float(ev["median_improve_pct"]) if np.isfinite(ev["median_improve_pct"]) else 1e9,
                float(ev["gate_rate"]),
            )
            if best_score is None or score < best_score:
                best_score = score
                best_rule = rule
                best_eval = ev

    baseline_rule = fallback_rule()
    baseline_eval = evaluate_rule(df, baseline_rule)

    if best_eval is None or best_rule is None:
        return baseline_rule, baseline_eval

    if int(best_eval["losses"]) > int(target_losses):
        return baseline_rule, baseline_eval
    if objective_mode == "apply_first_noharm":
        if (not np.isfinite(float(best_eval["mean_improve_pct"]))) or (
            float(best_eval["mean_improve_pct"]) < float(min_mean_improve_pct)
        ):
            return baseline_rule, baseline_eval

    return best_rule, best_eval


def apply_gate_df(
    df: pd.DataFrame,
    gate: np.ndarray,
    gate_reason: Optional[np.ndarray] = None,
    rule_mode: str = "global",
) -> pd.DataFrame:
    out = df.copy()
    ev = evaluate_gate(df=out, gate=gate)
    out["gate_stop"] = np.asarray(gate, dtype=bool)
    out["azel_rmse_selected_full"] = ev["selected"]
    out["improve_pct_selected_full"] = ev["improve"]
    out["selected_kind_full"] = np.where(out["gate_stop"], "baseline", "corrected")
    out["azel_rmse_selected_fut"] = ev["selected_fut"]
    out["improve_pct_selected_fut"] = ev["improve_fut"]
    out["selected_kind_fut"] = np.where(out["gate_stop"], "baseline", "corrected")
    out["rule_mode"] = str(rule_mode)
    if gate_reason is not None:
        out["gate_reason_selected"] = gate_reason.astype(str)
    else:
        out["gate_reason_selected"] = np.where(out["gate_stop"], "rule", "none")
    return out


def apply_rule_df(df: pd.DataFrame, rule: Dict) -> pd.DataFrame:
    ev = evaluate_rule(df, rule)
    return apply_gate_df(
        df=df,
        gate=ev["gate"],
        gate_reason=np.where(ev["gate"], "rule", "none"),
        rule_mode="global",
    )


def pick_two_stage_seasonal_rule(
    df: pd.DataFrame,
    stage1_lowerr_grid: Sequence[Optional[float]],
    cluster_col: str,
    cluster_labels: Sequence[str],
    lowerr_grid: Sequence[Optional[float]],
    dist_grid: Sequence[Optional[float]],
    unc_az_grid: Sequence[Optional[float]],
    unc_el_grid: Sequence[Optional[float]],
    corr_ratio_grid: Sequence[Optional[float]],
    target_losses: int = 0,
    min_mean_improve_pct: float = 0.0,
    min_cluster_size: int = 20,
) -> Tuple[Dict, Dict, np.ndarray, np.ndarray]:
    best_rule: Optional[Dict] = None
    best_eval: Optional[Dict] = None
    best_gate: Optional[np.ndarray] = None
    best_reason: Optional[np.ndarray] = None
    best_score: Optional[Tuple] = None

    for st1_th in stage1_lowerr_grid:
        stage1_gate = np.zeros((len(df),), dtype=bool)
        reason = np.full((len(df),), "none", dtype=object)
        if st1_th is not None:
            stage1_gate |= (
                pd.to_numeric(df["est_base_azel_rmse"], errors="coerce").to_numpy(dtype=np.float64)
                < float(st1_th)
            )
            reason[stage1_gate] = "stage1_lowerr"

        gate = stage1_gate.copy()
        cluster_rules: Dict[str, Dict] = {}
        cluster_stats: Dict[str, Dict] = {}

        for cl in cluster_labels:
            mask = (df[cluster_col].astype(str) == str(cl)).to_numpy(dtype=bool)
            idx = np.where(mask & (~stage1_gate))[0]
            if len(idx) == 0:
                cluster_rules[str(cl)] = fallback_rule()
                cluster_stats[str(cl)] = {"n": 0, "rule": "fallback"}
                continue

            sub = df.iloc[idx].copy()
            # Tiny cluster fallback to no correction for robust zero-loss.
            if len(sub) < int(min_cluster_size):
                cluster_rules[str(cl)] = fallback_rule()
                sub_gate = np.ones((len(sub),), dtype=bool)
                gate[idx] = sub_gate
                reason[idx] = f"cluster_{cl}_small_fallback"
                cluster_stats[str(cl)] = {"n": int(len(sub)), "rule": "small_fallback"}
                continue

            crule, cev = pick_best_rule(
                df=sub,
                lowerr_grid=lowerr_grid,
                dist_grid=dist_grid,
                unc_az_grid=unc_az_grid,
                unc_el_grid=unc_el_grid,
                corr_ratio_grid=corr_ratio_grid,
                target_losses=int(target_losses),
                objective_mode="apply_first_noharm",
                min_mean_improve_pct=float(min_mean_improve_pct),
            )
            sub_gate = np.asarray(cev["gate"], dtype=bool)
            gate[idx] = sub_gate
            reason[idx] = np.where(sub_gate, f"cluster_{cl}", "none")
            cluster_rules[str(cl)] = crule
            cluster_stats[str(cl)] = {
                "n": int(len(sub)),
                "losses": int(cev["losses"]),
                "wins": int(cev["wins"]),
                "mean_improve_pct": float(cev["mean_improve_pct"]),
                "gate_rate": float(cev["gate_rate"]),
            }

        ev = evaluate_gate(df=df, gate=gate)
        losses = int(ev["losses"])
        mean_imp = float(ev["mean_improve_pct"]) if np.isfinite(ev["mean_improve_pct"]) else np.nan
        if losses > int(target_losses):
            continue
        if (not np.isfinite(mean_imp)) or (mean_imp < float(min_mean_improve_pct)):
            continue
        apply_rate = float(1.0 - float(ev["gate_rate"]))
        score = (
            apply_rate,
            mean_imp,
            int(ev["wins"]),
            -float(ev["gate_rate"]),
        )
        if best_score is None or score > best_score:
            best_score = score
            best_eval = ev
            best_gate = gate.copy()
            best_reason = reason.copy()
            best_rule = {
                "stage1": {"auto_lowerr_th": st1_th},
                "clusters": cluster_rules,
                "cluster_stats": cluster_stats,
            }

    if best_rule is None or best_eval is None or best_gate is None or best_reason is None:
        rule = {
            "stage1": {"auto_lowerr_th": None},
            "clusters": {str(cl): fallback_rule() for cl in cluster_labels},
            "cluster_stats": {},
        }
        gate = np.ones((len(df),), dtype=bool)
        reason = np.full((len(df),), "fallback_all_stop", dtype=object)
        ev = evaluate_gate(df=df, gate=gate)
        return rule, ev, gate, reason
    return best_rule, best_eval, best_gate, best_reason


def aggregate_selected(df_sel: pd.DataFrame) -> Dict:
    imp = pd.to_numeric(df_sel["improve_pct_selected_full"], errors="coerce").to_numpy(dtype=np.float64)
    impf = pd.to_numeric(df_sel["improve_pct_selected_fut"], errors="coerce").to_numpy(dtype=np.float64)
    valid = np.isfinite(imp)
    validf = np.isfinite(impf)
    agg = {
        "n_total": int(len(df_sel)),
        "n_ok": int(np.sum(df_sel["status"] == "ok")),
        "mean_improve_pct_full": float(np.nanmean(imp)) if np.any(valid) else np.nan,
        "median_improve_pct_full": float(np.nanmedian(imp)) if np.any(valid) else np.nan,
        "wins_full": int(np.sum(imp[valid] > 1e-12)),
        "losses_full": int(np.sum(imp[valid] < -1e-12)),
        "ties_full": int(np.sum(np.abs(imp[valid]) <= 1e-12)),
        "mean_improve_pct_fut": float(np.nanmean(impf)) if np.any(validf) else np.nan,
        "median_improve_pct_fut": float(np.nanmedian(impf)) if np.any(validf) else np.nan,
        "wins_fut": int(np.sum(impf[validf] > 1e-12)),
        "losses_fut": int(np.sum(impf[validf] < -1e-12)),
        "ties_fut": int(np.sum(np.abs(impf[validf]) <= 1e-12)),
        "gate_rate": float(np.mean(df_sel["gate_stop"].astype(np.float64))) if len(df_sel) else np.nan,
    }
    return agg


def aggregate_raw(df: pd.DataFrame) -> Dict:
    imp = pd.to_numeric(df["improve_pct_full"], errors="coerce").to_numpy(dtype=np.float64)
    impf = pd.to_numeric(df["improve_pct_fut"], errors="coerce").to_numpy(dtype=np.float64)
    valid = np.isfinite(imp)
    validf = np.isfinite(impf)
    return {
        "n_total": int(len(df)),
        "n_ok": int(np.sum(df["status"] == "ok")),
        "mean_improve_pct_full": float(np.nanmean(imp)) if np.any(valid) else np.nan,
        "median_improve_pct_full": float(np.nanmedian(imp)) if np.any(valid) else np.nan,
        "wins_full": int(np.sum(imp[valid] > 1e-12)),
        "losses_full": int(np.sum(imp[valid] < -1e-12)),
        "ties_full": int(np.sum(np.abs(imp[valid]) <= 1e-12)),
        "mean_improve_pct_fut": float(np.nanmean(impf)) if np.any(validf) else np.nan,
        "median_improve_pct_fut": float(np.nanmedian(impf)) if np.any(validf) else np.nan,
        "wins_fut": int(np.sum(impf[validf] > 1e-12)),
        "losses_fut": int(np.sum(impf[validf] < -1e-12)),
        "ties_fut": int(np.sum(np.abs(impf[validf]) <= 1e-12)),
    }


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Re-evaluate 2024 TLE set with auto no-harm rule tuning")
    ap.add_argument("--predict-script", default="orbit_geo_7d23d_analog.py")
    ap.add_argument("--python-exe", default=sys.executable)
    ap.add_argument("--model", required=True)
    ap.add_argument("--tle-dir", required=True)
    ap.add_argument("--baseline-dir", required=True)
    ap.add_argument("--truth-csv", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--ood-conf-floor", type=float, default=0.0)
    ap.add_argument("--days-horizon", type=int, default=None)
    ap.add_argument("--fit-days", type=int, default=None)
    ap.add_argument("--pre-days", type=int, default=None)
    ap.add_argument("--step-minutes", type=int, default=None)
    ap.add_argument("--sample-every", type=int, default=1)
    ap.add_argument("--max-files", type=int, default=None)
    ap.add_argument("--skip-predict", action="store_true")
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--target-losses", type=int, default=0)
    ap.add_argument("--rule-mode", choices=["global", "two-stage-seasonal", "both"], default="two-stage-seasonal",
                    help="Rule optimization mode. 'both' tunes both and selects better under no-harm objective.")
    ap.add_argument("--objective-mode", choices=["mean_first", "apply_first_noharm"], default="apply_first_noharm",
                    help="Objective for global tuning.")
    ap.add_argument("--min-mean-improve-pct", type=float, default=0.0,
                    help="Minimum mean improve percent for feasible no-harm rules.")
    ap.add_argument("--season-mode", choices=["meteo4", "monthly"], default="meteo4",
                    help="Season cluster mode for two-stage tuning.")
    ap.add_argument("--season-min-cluster-size", type=int, default=20,
                    help="Small cluster fallback threshold for two-stage tuning.")
    ap.add_argument("--stage1-lowerr-quantiles", default="0,0.03,0.05,0.08,0.10,0.15,0.20,0.25,0.30",
                    help="Quantiles for stage-1 low-error auto-stop threshold (0 means None).")
    ap.add_argument("--seasonal-grid-profile", choices=["compact", "full"], default="compact",
                    help="Grid density for cluster-wise stage-2 search.")
    ap.add_argument("--lowerr-grid", default=None,
                    help="Comma floats. If omitted, quantile grid from diagnostics is used.")
    ap.add_argument("--dist-grid", default=None,
                    help="Comma floats. If omitted, quantile grid from diagnostics is used.")
    ap.add_argument("--unc-az-grid", default=None,
                    help="Comma floats. If omitted, quantile grid from diagnostics is used.")
    ap.add_argument("--unc-el-grid", default=None,
                    help="Comma floats. If omitted, quantile grid from diagnostics is used.")
    ap.add_argument("--corr-ratio-grid", default=None,
                    help="Comma floats. If omitted, quantile grid from diagnostics is used.")
    ap.add_argument("--extra-predict-args", default="",
                    help="Extra args passed to predict command, e.g. '--k 5 --tau 2'")
    ap.add_argument("--materialize-selected-csv", action="store_true",
                    help="Write selected final csv (baseline or corrected) for each stem")
    args = ap.parse_args(argv)

    model = Path(args.model)
    tle_dir = Path(args.tle_dir)
    baseline_dir = Path(args.baseline_dir)
    truth_csv = Path(args.truth_csv)
    out_dir = Path(args.out_dir)
    predict_script = Path(args.predict_script)

    if not model.exists():
        raise FileNotFoundError(f"model not found: {model}")
    if not tle_dir.exists():
        raise FileNotFoundError(f"tle-dir not found: {tle_dir}")
    if not baseline_dir.exists():
        raise FileNotFoundError(f"baseline-dir not found: {baseline_dir}")
    if not truth_csv.exists():
        raise FileNotFoundError(f"truth-csv not found: {truth_csv}")
    if not predict_script.exists():
        raise FileNotFoundError(f"predict-script not found: {predict_script}")

    raw_corr_dir = out_dir / "raw_corrected"
    raw_pred_dir = out_dir / "raw_pred"
    raw_met_dir = out_dir / "raw_metrics"
    raw_log_dir = out_dir / "raw_logs"
    sel_csv_dir = out_dir / "selected_corrected"
    for d in [out_dir, raw_corr_dir, raw_pred_dir, raw_met_dir, raw_log_dir]:
        ensure_dir(d)
    if args.materialize_selected_csv:
        ensure_dir(sel_csv_dir)

    stems = list_target_stems(tle_dir=tle_dir, baseline_dir=baseline_dir, max_files=args.max_files)
    if len(stems) == 0:
        raise RuntimeError("no matching stems in tle-dir and baseline-dir")
    log(f"[INFO] stems: {len(stems)}")

    extra_predict_args = [x for x in str(args.extra_predict_args).split(" ") if x.strip()]

    rows: List[Dict] = []
    for i, stem in enumerate(stems, start=1):
        tle_file = tle_dir / f"{stem}.txt"
        baseline_csv = baseline_dir / f"{stem}.csv"
        out_corr = raw_corr_dir / f"{stem}.csv"
        out_pred = raw_pred_dir / f"{stem}.csv"
        out_met = raw_met_dir / f"{stem}.csv"
        out_log = raw_log_dir / f"{stem}.log"

        status = "ok"
        err = ""
        if (not args.skip_predict) or (not out_pred.exists()) or (not out_met.exists()) or (not out_corr.exists()):
            cmd = build_predict_cmd(
                python_exe=str(args.python_exe),
                predict_script=predict_script,
                model=model,
                tle_file=tle_file,
                baseline_csv=baseline_csv,
                truth_csv=truth_csv,
                out_corrected_csv=out_corr,
                out_pred_error_csv=out_pred,
                out_metrics_csv=out_met,
                ood_conf_floor=float(args.ood_conf_floor),
                days_horizon=args.days_horizon,
                fit_days=args.fit_days,
                pre_days=args.pre_days,
                step_minutes=args.step_minutes,
                sample_every=args.sample_every,
                extra_args=extra_predict_args,
            )
            p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore")
            out_log.write_text((p.stdout or "") + "\n" + (p.stderr or ""), encoding="utf-8")
            if p.returncode != 0:
                status = "error"
                err = f"predict failed rc={p.returncode}"
                log(f"[WARN] {i}/{len(stems)} {stem} failed: rc={p.returncode}")
            elif i % 20 == 0 or i == len(stems):
                log(f"[INFO] predict progress {i}/{len(stems)}")
        else:
            if i % 20 == 0 or i == len(stems):
                log(f"[INFO] predict skipped progress {i}/{len(stems)}")

        rec: Dict = {
            "stem": stem,
            "status": status,
            "error": err,
            "ood_conf": np.nan,
            "ood_conf_raw": np.nan,
            "corr_scale": np.nan,
            "neighbor0_dist": np.nan,
            "neighbor_dist_w": np.nan,
            "unc_az_rms": np.nan,
            "unc_el_rms": np.nan,
            "corr_ratio": np.nan,
            "est_base_az_rmse": np.nan,
            "est_base_el_rmse": np.nan,
            "est_base_azel_rmse": np.nan,
            "gate_reason_raw": "",
            "alpha_az": np.nan,
            "alpha_el": np.nan,
            "k": np.nan,
            "tau": np.nan,
            "az_rmse_base_full": np.nan,
            "az_rmse_corr_full": np.nan,
            "el_rmse_base_full": np.nan,
            "el_rmse_corr_full": np.nan,
            "azel_rmse_base_full": np.nan,
            "azel_rmse_corr_full": np.nan,
            "improve_pct_full": np.nan,
            "az_rmse_base_fut": np.nan,
            "az_rmse_corr_fut": np.nan,
            "el_rmse_base_fut": np.nan,
            "el_rmse_corr_fut": np.nan,
            "azel_rmse_base_fut": np.nan,
            "azel_rmse_corr_fut": np.nan,
            "improve_pct_fut": np.nan,
        }

        if status == "ok":
            try:
                pdf = pd.read_csv(out_pred)
                p0 = pdf.iloc[0]
                for k in [
                    "ood_conf", "ood_conf_raw", "corr_scale", "neighbor0_dist", "neighbor_dist_w",
                    "unc_az_rms", "unc_el_rms", "corr_ratio",
                    "est_base_az_rmse", "est_base_el_rmse", "est_base_azel_rmse",
                    "alpha_AZ", "alpha_EL", "k", "tau", "gate_reason",
                ]:
                    if k not in p0.index:
                        continue
                    v = p0[k]
                    if k == "alpha_AZ":
                        rec["alpha_az"] = float(v)
                    elif k == "alpha_EL":
                        rec["alpha_el"] = float(v)
                    elif k == "gate_reason":
                        rec["gate_reason_raw"] = str(v)
                    else:
                        rec[k] = float(v) if pd.notna(v) else np.nan
            except Exception as e:
                rec["status"] = "error"
                rec["error"] = f"pred csv parse error: {e}"

        if rec["status"] == "ok":
            try:
                mdf = pd.read_csv(out_met)
                f = mdf[mdf["segment"] == "full_30d"].copy()
                fu = mdf[mdf["segment"] == "future_23d"].copy()
                if len(f) > 0:
                    b = f[f["kind"] == "baseline"].iloc[0]
                    c = f[f["kind"] == "corrected"].iloc[0]
                    rec["az_rmse_base_full"] = float(b["AZ_RMSE"])
                    rec["az_rmse_corr_full"] = float(c["AZ_RMSE"])
                    rec["el_rmse_base_full"] = float(b["EL_RMSE"])
                    rec["el_rmse_corr_full"] = float(c["EL_RMSE"])
                    rec["azel_rmse_base_full"] = 0.5 * (rec["az_rmse_base_full"] + rec["el_rmse_base_full"])
                    rec["azel_rmse_corr_full"] = 0.5 * (rec["az_rmse_corr_full"] + rec["el_rmse_corr_full"])
                    if abs(rec["azel_rmse_base_full"]) > 1e-12:
                        rec["improve_pct_full"] = (rec["azel_rmse_base_full"] - rec["azel_rmse_corr_full"]) / rec["azel_rmse_base_full"] * 100.0
                if len(fu) > 0:
                    b = fu[fu["kind"] == "baseline"].iloc[0]
                    c = fu[fu["kind"] == "corrected"].iloc[0]
                    rec["az_rmse_base_fut"] = float(b["AZ_RMSE"]) if pd.notna(b["AZ_RMSE"]) else np.nan
                    rec["az_rmse_corr_fut"] = float(c["AZ_RMSE"]) if pd.notna(c["AZ_RMSE"]) else np.nan
                    rec["el_rmse_base_fut"] = float(b["EL_RMSE"]) if pd.notna(b["EL_RMSE"]) else np.nan
                    rec["el_rmse_corr_fut"] = float(c["EL_RMSE"]) if pd.notna(c["EL_RMSE"]) else np.nan
                    if np.isfinite(rec["az_rmse_base_fut"]) and np.isfinite(rec["el_rmse_base_fut"]):
                        rec["azel_rmse_base_fut"] = 0.5 * (rec["az_rmse_base_fut"] + rec["el_rmse_base_fut"])
                    if np.isfinite(rec["az_rmse_corr_fut"]) and np.isfinite(rec["el_rmse_corr_fut"]):
                        rec["azel_rmse_corr_fut"] = 0.5 * (rec["az_rmse_corr_fut"] + rec["el_rmse_corr_fut"])
                    if np.isfinite(rec["azel_rmse_base_fut"]) and np.isfinite(rec["azel_rmse_corr_fut"]) and abs(rec["azel_rmse_base_fut"]) > 1e-12:
                        rec["improve_pct_fut"] = (rec["azel_rmse_base_fut"] - rec["azel_rmse_corr_fut"]) / rec["azel_rmse_base_fut"] * 100.0
            except Exception as e:
                rec["status"] = "error"
                rec["error"] = f"metric csv parse error: {e}"

        rows.append(rec)

    df = pd.DataFrame(rows)
    summary_raw_csv = out_dir / "summary_raw.csv"
    df.to_csv(summary_raw_csv, index=False)
    log(f"[SAVED] raw summary: {summary_raw_csv}")
    raw_agg = aggregate_raw(df[df["status"] == "ok"].copy())
    raw_agg_path = out_dir / "aggregate_raw.json"
    raw_agg_path.write_text(json.dumps(raw_agg, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[SAVED] raw aggregate: {raw_agg_path}")

    ok = df[(df["status"] == "ok") & np.isfinite(pd.to_numeric(df["azel_rmse_base_full"], errors="coerce"))].copy()
    if len(ok) == 0:
        raise RuntimeError("no successful rows for rule tuning")

    ok = attach_season_cluster(ok, mode=str(args.season_mode))

    lowerr_grid = parse_float_list(args.lowerr_grid)
    dist_grid = parse_float_list(args.dist_grid)
    unc_az_grid = parse_float_list(args.unc_az_grid)
    unc_el_grid = parse_float_list(args.unc_el_grid)
    corr_ratio_grid = parse_float_list(args.corr_ratio_grid)

    if str(args.seasonal_grid_profile) == "compact":
        q_low = [0.05, 0.10, 0.15, 0.20, 0.30, 0.40]
        q_dist = [0.40, 0.50, 0.60, 0.70, 0.80, 0.90]
        q_unc = [0.50, 0.60, 0.70, 0.80]
        q_corr = [0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80]
    else:
        q_low = [0.03, 0.05, 0.08, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50]
        q_dist = [0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95]
        q_unc = [0.50, 0.60, 0.70, 0.80, 0.90, 0.95]
        q_corr = [0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95]

    if len(lowerr_grid) == 0:
        lowerr_candidates = quantile_grid(ok["est_base_azel_rmse"], q_low)
    else:
        lowerr_candidates = [None] + lowerr_grid
    if len(dist_grid) == 0:
        dist_candidates = quantile_grid(ok["neighbor0_dist"], q_dist)
    else:
        dist_candidates = [None] + dist_grid
    if len(unc_az_grid) == 0:
        unc_az_candidates = quantile_grid(ok["unc_az_rms"], q_unc)
    else:
        unc_az_candidates = [None] + unc_az_grid
    if len(unc_el_grid) == 0:
        unc_el_candidates = quantile_grid(ok["unc_el_rms"], q_unc)
    else:
        unc_el_candidates = [None] + unc_el_grid
    if len(corr_ratio_grid) == 0:
        corr_ratio_candidates = quantile_grid(ok["corr_ratio"], q_corr)
    else:
        corr_ratio_candidates = [None] + corr_ratio_grid

    global_rule = None
    global_eval = None
    global_sel_ok = None
    if str(args.rule_mode) in ("global", "both"):
        global_rule, global_eval = pick_best_rule(
            df=ok,
            lowerr_grid=lowerr_candidates,
            dist_grid=dist_candidates,
            unc_az_grid=unc_az_candidates,
            unc_el_grid=unc_el_candidates,
            corr_ratio_grid=corr_ratio_candidates,
            target_losses=int(args.target_losses),
            objective_mode=str(args.objective_mode),
            min_mean_improve_pct=float(args.min_mean_improve_pct),
        )
        global_sel_ok = apply_rule_df(ok, global_rule)

    seasonal_rule = None
    seasonal_eval = None
    seasonal_sel_ok = None
    if str(args.rule_mode) in ("two-stage-seasonal", "both"):
        q_stage1 = parse_quantile_list(
            args.stage1_lowerr_quantiles,
            default=[0.0, 0.03, 0.05, 0.08, 0.10, 0.15, 0.20, 0.25, 0.30],
        )
        st1_candidates: List[Optional[float]] = []
        for q in q_stage1:
            if q <= 0.0:
                st1_candidates.append(None)
            else:
                vals = pd.to_numeric(ok["est_base_azel_rmse"], errors="coerce")
                vals = vals[np.isfinite(vals.to_numpy(dtype=np.float64))]
                if len(vals) == 0:
                    continue
                st1_candidates.append(float(np.quantile(vals.to_numpy(dtype=np.float64), q)))
        # dedup
        st1_u: List[Optional[float]] = []
        seen = set()
        for v in st1_candidates:
            key = "None" if v is None else f"{float(v):.12g}"
            if key in seen:
                continue
            seen.add(key)
            st1_u.append(v)
        cluster_labels = sorted([x for x in ok["season_cluster"].dropna().astype(str).unique().tolist() if x != "UNK"])
        seasonal_rule, seasonal_eval, seasonal_gate, seasonal_reason = pick_two_stage_seasonal_rule(
            df=ok,
            stage1_lowerr_grid=st1_u if len(st1_u) > 0 else [None],
            cluster_col="season_cluster",
            cluster_labels=cluster_labels,
            lowerr_grid=lowerr_candidates,
            dist_grid=dist_candidates,
            unc_az_grid=unc_az_candidates,
            unc_el_grid=unc_el_candidates,
            corr_ratio_grid=corr_ratio_candidates,
            target_losses=int(args.target_losses),
            min_mean_improve_pct=float(args.min_mean_improve_pct),
            min_cluster_size=int(args.season_min_cluster_size),
        )
        seasonal_sel_ok = apply_gate_df(
            df=ok,
            gate=seasonal_gate,
            gate_reason=seasonal_reason,
            rule_mode="two-stage-seasonal",
        )
    else:
        st1_u = []
        cluster_labels = []

    def candidate_score(ev: Optional[Dict]) -> Tuple:
        if ev is None:
            return (-1e9, -1e9, -1e9, -1e9)
        losses = int(ev["losses"])
        mean_imp = float(ev["mean_improve_pct"]) if np.isfinite(ev["mean_improve_pct"]) else -1e9
        if losses > int(args.target_losses):
            return (-1e9, -1e9, -1e9, -1e9)
        if mean_imp < float(args.min_mean_improve_pct):
            return (-1e9, -1e9, -1e9, -1e9)
        apply_rate = float(1.0 - float(ev["gate_rate"]))
        return (apply_rate, mean_imp, float(ev["wins"]), -float(ev["gate_rate"]))

    selected_mode = str(args.rule_mode)
    selected_rule_obj = None
    selected_eval = None
    df_sel_ok = None
    if str(args.rule_mode) == "global":
        selected_mode = "global"
        selected_rule_obj = global_rule
        selected_eval = global_eval
        df_sel_ok = global_sel_ok
    elif str(args.rule_mode) == "two-stage-seasonal":
        selected_mode = "two-stage-seasonal"
        selected_rule_obj = seasonal_rule
        selected_eval = seasonal_eval
        df_sel_ok = seasonal_sel_ok
    else:
        sg = candidate_score(global_eval)
        ss = candidate_score(seasonal_eval)
        if ss >= sg:
            selected_mode = "two-stage-seasonal"
            selected_rule_obj = seasonal_rule
            selected_eval = seasonal_eval
            df_sel_ok = seasonal_sel_ok
        else:
            selected_mode = "global"
            selected_rule_obj = global_rule
            selected_eval = global_eval
            df_sel_ok = global_sel_ok

    if df_sel_ok is None:
        # hard fallback (all baseline)
        df_sel_ok = apply_gate_df(
            df=ok,
            gate=np.ones((len(ok),), dtype=bool),
            gate_reason=np.full((len(ok),), "fallback_all_stop", dtype=object),
            rule_mode="fallback",
        )
        selected_mode = "fallback"
        selected_rule_obj = fallback_rule()
        selected_eval = evaluate_gate(df=ok, gate=np.ones((len(ok),), dtype=bool))

    rule_path = out_dir / "best_rule.json"
    rule_payload = {
        "selected_mode": selected_mode,
        "selected_rule": selected_rule_obj,
        "selected_eval": {
            "losses": int(selected_eval["losses"]) if selected_eval is not None else None,
            "wins": int(selected_eval["wins"]) if selected_eval is not None else None,
            "ties": int(selected_eval["ties"]) if selected_eval is not None else None,
            "n_valid": int(selected_eval["n_valid"]) if selected_eval is not None else None,
            "mean_improve_pct": float(selected_eval["mean_improve_pct"]) if selected_eval is not None else None,
            "median_improve_pct": float(selected_eval["median_improve_pct"]) if selected_eval is not None else None,
            "gate_rate": float(selected_eval["gate_rate"]) if selected_eval is not None else None,
        },
        "global_rule": global_rule,
        "global_eval": None if global_eval is None else {
            "losses": int(global_eval["losses"]),
            "wins": int(global_eval["wins"]),
            "ties": int(global_eval["ties"]),
            "n_valid": int(global_eval["n_valid"]),
            "mean_improve_pct": float(global_eval["mean_improve_pct"]),
            "median_improve_pct": float(global_eval["median_improve_pct"]),
            "gate_rate": float(global_eval["gate_rate"]),
        },
        "seasonal_rule": seasonal_rule,
        "seasonal_eval": None if seasonal_eval is None else {
            "losses": int(seasonal_eval["losses"]),
            "wins": int(seasonal_eval["wins"]),
            "ties": int(seasonal_eval["ties"]),
            "n_valid": int(seasonal_eval["n_valid"]),
            "mean_improve_pct": float(seasonal_eval["mean_improve_pct"]),
            "median_improve_pct": float(seasonal_eval["median_improve_pct"]),
            "gate_rate": float(seasonal_eval["gate_rate"]),
        },
        "grids": {
            "auto_lowerr_th": lowerr_candidates,
            "auto_max_neighbor_dist": dist_candidates,
            "auto_max_unc_az": unc_az_candidates,
            "auto_max_unc_el": unc_el_candidates,
            "auto_max_corr_ratio": corr_ratio_candidates,
        },
        "stage1_lowerr_candidates": st1_u,
        "cluster_labels": cluster_labels,
        "target_losses": int(args.target_losses),
        "min_mean_improve_pct": float(args.min_mean_improve_pct),
        "ood_conf_floor": float(args.ood_conf_floor),
    }
    rule_path.write_text(json.dumps(rule_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[SAVED] best rule: {rule_path}")

    df_sel = df.copy()
    df_sel = df_sel.merge(
        df_sel_ok[[
            "stem", "season_cluster", "rule_mode", "gate_reason_selected", "gate_stop",
            "azel_rmse_selected_full", "improve_pct_selected_full", "selected_kind_full",
            "azel_rmse_selected_fut", "improve_pct_selected_fut", "selected_kind_fut",
        ]],
        on="stem",
        how="left",
    )
    # For failed rows, keep NaN; for ok but missing values, fallback to baseline.
    m_ok = (df_sel["status"] == "ok") & (~df_sel["azel_rmse_base_full"].isna()) & (df_sel["azel_rmse_selected_full"].isna())
    df_sel.loc[m_ok, "azel_rmse_selected_full"] = df_sel.loc[m_ok, "azel_rmse_base_full"]
    df_sel.loc[m_ok, "improve_pct_selected_full"] = 0.0
    df_sel.loc[m_ok, "selected_kind_full"] = "baseline"
    df_sel.loc[m_ok, "gate_stop"] = True
    df_sel.loc[m_ok, "rule_mode"] = "fallback"
    df_sel.loc[m_ok, "gate_reason_selected"] = "fallback_missing"
    m_ok2 = (df_sel["status"] == "ok") & (~df_sel["azel_rmse_base_fut"].isna()) & (df_sel["azel_rmse_selected_fut"].isna())
    df_sel.loc[m_ok2, "azel_rmse_selected_fut"] = df_sel.loc[m_ok2, "azel_rmse_base_fut"]
    df_sel.loc[m_ok2, "improve_pct_selected_fut"] = 0.0
    df_sel.loc[m_ok2, "selected_kind_fut"] = "baseline"
    df_sel.loc[m_ok2, "gate_stop"] = True
    df_sel.loc[m_ok2, "rule_mode"] = "fallback"
    df_sel.loc[m_ok2, "gate_reason_selected"] = "fallback_missing"

    summary_sel_csv = out_dir / "summary_selected.csv"
    df_sel.to_csv(summary_sel_csv, index=False)
    log(f"[SAVED] selected summary: {summary_sel_csv}")

    agg = aggregate_selected(df_sel[df_sel["status"] == "ok"].copy())
    agg_path = out_dir / "aggregate_selected.json"
    agg_path.write_text(json.dumps(agg, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[SAVED] aggregate: {agg_path}")

    top_imp = df_sel[df_sel["status"] == "ok"].copy().sort_values("improve_pct_selected_full", ascending=False).head(20)
    top_wor = df_sel[df_sel["status"] == "ok"].copy().sort_values("improve_pct_selected_full", ascending=True).head(20)
    top_imp.to_csv(out_dir / "top_improved_selected.csv", index=False)
    top_wor.to_csv(out_dir / "top_worsened_selected.csv", index=False)

    month = df_sel[df_sel["status"] == "ok"].copy()
    month["month"] = month["stem"].astype(str).str.slice(0, 7)
    g = month.groupby("month", dropna=False)
    month_df = g["improve_pct_selected_full"].agg(["count", "mean", "median"]).reset_index()
    month_df["wins"] = g.apply(lambda z: int(np.sum(pd.to_numeric(z["improve_pct_selected_full"], errors="coerce") > 1e-12))).values
    month_df["losses"] = g.apply(lambda z: int(np.sum(pd.to_numeric(z["improve_pct_selected_full"], errors="coerce") < -1e-12))).values
    month_df.to_csv(out_dir / "monthly_trend_selected.csv", index=False)

    def rule_to_args(rule: Optional[Dict]) -> str:
        if rule is None:
            return ""
        args2: List[str] = []
        if rule.get("auto_lowerr_th") is not None:
            args2 += ["--auto-lowerr-th", str(rule["auto_lowerr_th"])]
        if rule.get("auto_max_neighbor_dist") is not None:
            args2 += ["--auto-max-neighbor-dist", str(rule["auto_max_neighbor_dist"])]
        if rule.get("auto_max_unc_az") is not None:
            args2 += ["--auto-max-unc-az", str(rule["auto_max_unc_az"])]
        if rule.get("auto_max_unc_el") is not None:
            args2 += ["--auto-max-unc-el", str(rule["auto_max_unc_el"])]
        if rule.get("auto_max_corr_ratio") is not None:
            args2 += ["--auto-max-corr-ratio", str(rule["auto_max_corr_ratio"])]
        return " ".join(args2)

    report = []
    report.append("# GEO 7d23d Re-evaluation (ood_conf_floor=0 + auto-stop)")
    report.append("")
    report.append("## Selected Rule")
    report.append(f"- selected_mode: {selected_mode}")
    report.append(f"- target_losses: {int(args.target_losses)}")
    report.append(f"- min_mean_improve_pct: {float(args.min_mean_improve_pct)}")
    if selected_mode == "global":
        report.append(f"- rule: {selected_rule_obj}")
    elif selected_mode == "two-stage-seasonal":
        st1 = (selected_rule_obj or {}).get("stage1", {})
        report.append(f"- stage1 auto_lowerr_th: {st1.get('auto_lowerr_th')}")
        cl_rules = (selected_rule_obj or {}).get("clusters", {})
        for cl in sorted(cl_rules.keys()):
            report.append(f"- cluster {cl}: {cl_rules[cl]}")
    else:
        report.append("- fallback baseline-only")
    report.append("")
    report.append("## Raw (before auto-stop)")
    for k, v in raw_agg.items():
        report.append(f"- {k}: {v}")
    report.append("")
    if global_eval is not None:
        report.append("## Global Eval")
        report.append(f"- losses: {int(global_eval['losses'])}")
        report.append(f"- wins: {int(global_eval['wins'])}")
        report.append(f"- mean_improve_pct: {float(global_eval['mean_improve_pct'])}")
        report.append(f"- gate_rate: {float(global_eval['gate_rate'])}")
        report.append("")
    if seasonal_eval is not None:
        report.append("## Two-Stage Seasonal Eval")
        report.append(f"- losses: {int(seasonal_eval['losses'])}")
        report.append(f"- wins: {int(seasonal_eval['wins'])}")
        report.append(f"- mean_improve_pct: {float(seasonal_eval['mean_improve_pct'])}")
        report.append(f"- gate_rate: {float(seasonal_eval['gate_rate'])}")
        report.append("")
    report.append("## Aggregate (selected)")
    for k, v in agg.items():
        report.append(f"- {k}: {v}")
    report.append("")
    report.append("## Recommended Predict Args")
    if selected_mode == "global":
        gargs = rule_to_args(selected_rule_obj)
        if not gargs:
            report.append("- baseline-only fallback selected.")
        else:
            report.append("- " + gargs)
    elif selected_mode == "two-stage-seasonal":
        st1 = (selected_rule_obj or {}).get("stage1", {})
        st1_part = ""
        if st1.get("auto_lowerr_th") is not None:
            st1_part = f"--auto-lowerr-th {st1.get('auto_lowerr_th')}"
        report.append("- For each target TLE, choose cluster by month and append its cluster args.")
        cl_rules = (selected_rule_obj or {}).get("clusters", {})
        for cl in sorted(cl_rules.keys()):
            carg = rule_to_args(cl_rules[cl])
            joined = " ".join([x for x in [st1_part, carg] if x]).strip()
            if not joined:
                joined = "(no correction; baseline)"
            report.append(f"- {cl}: {joined}")
    else:
        report.append("- baseline-only fallback selected (all corrections stopped).")
    report.append("")
    report.append("## Notes")
    report.append("- `target_losses=0` means the tuner prefers zero-degradation rules.")
    report.append("- Two-stage seasonal mode uses stage1 low-error stop + cluster-wise stage2 no-harm gating.")
    report.append("- If no feasible non-harm rule is found, baseline-only fallback is selected.")
    (out_dir / "analysis_selected.md").write_text("\n".join(report) + "\n", encoding="utf-8")

    if args.materialize_selected_csv:
        ok2 = df_sel[df_sel["status"] == "ok"]
        for _, r in ok2.iterrows():
            stem = str(r["stem"])
            src = (baseline_dir / f"{stem}.csv") if str(r.get("selected_kind_full", "baseline")) == "baseline" else (raw_corr_dir / f"{stem}.csv")
            dst = sel_csv_dir / f"{stem}.csv"
            if src.exists():
                if dst.exists() and args.overwrite:
                    dst.unlink()
                if (not dst.exists()) or args.overwrite:
                    shutil.copy2(src, dst)
        log(f"[SAVED] selected corrected csv dir: {sel_csv_dir}")

    log("[DONE]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
