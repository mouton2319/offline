#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Auto-tune orbit_error_ai_no_tle_tf.py hyperparameters (AZ/EL priority).

Workflow per candidate:
1) Train model in docker
2) Predict one target 2024 TLE baseline CSV in docker
3) Read metrics CSV, compute AZ/EL-priority score
4) Save ranking CSV + best params JSON
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd


@dataclasses.dataclass
class Candidate:
    name: str
    alpha_max_az: float
    alpha_max_el: float
    azel_cap_deg: float
    min_improve_pct: float
    azel_alpha_shrink: float
    clip_grid: str
    alpha_grid_step: float = 0.02


def run_cmd(cmd: str, cwd: Path, log_path: Path) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as fw:
        fw.write(f"$ {cmd}\n\n")
        fw.flush()
        p = subprocess.Popen(
            cmd,
            cwd=str(cwd),
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert p.stdout is not None
        for line in p.stdout:
            fw.write(line)
            fw.flush()
            sys.stdout.write(line)
            sys.stdout.flush()
        p.wait()
        fw.write(f"\n[exit_code] {p.returncode}\n")
        fw.flush()
        return int(p.returncode)


def read_metrics(metrics_csv: Path) -> Dict[str, float]:
    df = pd.read_csv(metrics_csv)
    b = df[df["kind"] == "baseline"].iloc[0]
    c = df[df["kind"] == "corrected"].iloc[0]

    out: Dict[str, float] = {}
    for k in ["Lat", "Lon", "Alt", "AZ", "EL"]:
        out[f"{k}_RMSE_base"] = float(b[f"{k}_RMSE"])
        out[f"{k}_RMSE_corr"] = float(c[f"{k}_RMSE"])
        out[f"{k}_MSE_base"] = float(b[f"{k}_MSE"])
        out[f"{k}_MSE_corr"] = float(c[f"{k}_MSE"])
    out["global_RMSE_base"] = float(b["global_RMSE"])
    out["global_RMSE_corr"] = float(c["global_RMSE"])
    out["global_MSE_base"] = float(b["global_MSE"])
    out["global_MSE_corr"] = float(c["global_MSE"])
    out["rows"] = float(b["rows"])
    return out


def score_azel_priority(m: Dict[str, float]) -> float:
    az_b = m["AZ_RMSE_base"]
    az_c = m["AZ_RMSE_corr"]
    el_b = m["EL_RMSE_base"]
    el_c = m["EL_RMSE_corr"]
    lon_b = m["Lon_RMSE_base"]
    lon_c = m["Lon_RMSE_corr"]

    # AZ/EL degradation gets strong penalty.
    pen_az = max(0.0, az_c - az_b)
    pen_el = max(0.0, el_c - el_b)
    pen_lon = max(0.0, lon_c - lon_b)

    # Primary objective: minimize corrected AZ/EL RMSE.
    score = (
        1.0 * az_c
        + 1.0 * el_c
        + 6.0 * pen_az
        + 6.0 * pen_el
        + 1.0 * pen_lon
        + 0.05 * m["global_RMSE_corr"]
    )
    return float(score)


def make_candidates() -> List[Candidate]:
    return [
        Candidate("c01_safe006", alpha_max_az=0.25, alpha_max_el=0.08, azel_cap_deg=0.006, min_improve_pct=0.5, azel_alpha_shrink=0.7, clip_grid="0,0.5,1"),
        Candidate("c02_safe008", alpha_max_az=0.30, alpha_max_el=0.10, azel_cap_deg=0.008, min_improve_pct=0.5, azel_alpha_shrink=0.7, clip_grid="0,0.5,1"),
        Candidate("c03_safe010", alpha_max_az=0.35, alpha_max_el=0.12, azel_cap_deg=0.010, min_improve_pct=0.5, azel_alpha_shrink=0.7, clip_grid="0,0.5,1,1.5"),
        Candidate("c04_bal010", alpha_max_az=0.40, alpha_max_el=0.15, azel_cap_deg=0.010, min_improve_pct=0.5, azel_alpha_shrink=0.7, clip_grid="0,0.5,1,1.5"),
        Candidate("c05_strict006", alpha_max_az=0.30, alpha_max_el=0.08, azel_cap_deg=0.006, min_improve_pct=1.0, azel_alpha_shrink=0.6, clip_grid="0,0.5,1"),
        Candidate("c06_strict008", alpha_max_az=0.35, alpha_max_el=0.10, azel_cap_deg=0.008, min_improve_pct=1.0, azel_alpha_shrink=0.6, clip_grid="0,0.5,1"),
        Candidate("c07_med010", alpha_max_az=0.45, alpha_max_el=0.15, azel_cap_deg=0.010, min_improve_pct=1.0, azel_alpha_shrink=0.6, clip_grid="0,0.5,1,1.5"),
        Candidate("c08_wide015", alpha_max_az=0.50, alpha_max_el=0.20, azel_cap_deg=0.015, min_improve_pct=0.5, azel_alpha_shrink=0.8, clip_grid="0,0.5,1,1.5,2"),
    ]


def main() -> int:
    ap = argparse.ArgumentParser(description="Auto tune orbit_error_ai_no_tle_tf.py parameters")
    ap.add_argument("--workdir", default=".")
    ap.add_argument("--image", default="orbit-tf-pip:cuda128")
    ap.add_argument(
        "--gpus",
        default="all",
        help="Value for docker --gpus (e.g. all, device=0). Use 'none' to disable GPU option.",
    )
    ap.add_argument(
        "--docker-run-extra",
        default="",
        help="Extra raw arguments inserted into docker run (e.g. '--shm-size 16g').",
    )
    ap.add_argument("--script", default="orbit_error_ai_no_tle_tf.py")
    ap.add_argument("--tle-dir", default="23467_2023")
    ap.add_argument("--err-dir", default="23467_2023_error")
    ap.add_argument("--truth-csv", default="2024_calc_az_el.csv")
    ap.add_argument("--tle-file", default="23467_2024/2024-03-01_15-44-37.txt")
    ap.add_argument("--baseline-csv", default="23467_2024_csv/2024-03-01_15-44-37.csv")
    ap.add_argument("--out-root", default="auto_tune_runs")
    ap.add_argument("--max-candidates", type=int, default=None)
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--batch-size", type=int, default=1024)
    ap.add_argument("--sample-every", type=int, default=2)
    ap.add_argument("--max-files", type=int, default=180)
    ap.add_argument("--early-stop-patience", type=int, default=8)
    ap.add_argument("--early-stop-warmup", type=int, default=4)
    ap.add_argument("--val-eval-max-files", type=int, default=16)
    ap.add_argument("--hidden", default="512,512,256,128")
    args = ap.parse_args()

    workdir = Path(args.workdir).resolve()
    out_root = workdir / args.out_root
    out_root.mkdir(parents=True, exist_ok=True)

    gpus_raw = str(args.gpus).strip()
    if gpus_raw and gpus_raw.lower() not in ("none", "off", "false", "cpu"):
        docker_gpus_opt = f"--gpus {shlex.quote(gpus_raw)} "
    else:
        docker_gpus_opt = ""
    docker_extra_opt = (str(args.docker_run_extra).strip() + " ") if str(args.docker_run_extra).strip() else ""

    candidates = make_candidates()
    if args.max_candidates is not None:
        candidates = candidates[: int(args.max_candidates)]

    results: List[Dict[str, object]] = []

    for i, c in enumerate(candidates, start=1):
        print(f"\n===== Candidate {i}/{len(candidates)}: {c.name} =====", flush=True)
        model_dir = out_root / f"model_{c.name}"
        pred_dir = out_root / f"pred_{c.name}"
        pred_dir.mkdir(parents=True, exist_ok=True)
        train_log = out_root / f"{c.name}_train.log"
        pred_log = out_root / f"{c.name}_predict.log"

        train_cmd = (
            f"docker run --rm {docker_gpus_opt}{docker_extra_opt}"
            f"-v {shlex.quote(str(workdir))}:/work -w /work {shlex.quote(args.image)} "
            f"bash -lc "
            f"\"python3.11 {shlex.quote(args.script)} train "
            f"--tle-dir {shlex.quote(args.tle_dir)} "
            f"--err-dir {shlex.quote(args.err_dir)} "
            f"--out-model {shlex.quote(str(model_dir.relative_to(workdir)))} "
            f"--days-horizon 30 --step-minutes 1 "
            f"--sample-every {int(args.sample_every)} "
            f"--max-files {int(args.max_files)} "
            f"--epochs {int(args.epochs)} --batch-size {int(args.batch_size)} "
            f"--time-weight-power 2.0 "
            f"--early-stop-objective azel "
            f"--early-stop-patience {int(args.early_stop_patience)} "
            f"--early-stop-warmup {int(args.early_stop_warmup)} "
            f"--val-eval-max-files {int(args.val_eval_max_files)} "
            f"--hidden {shlex.quote(args.hidden)} "
            f"--alpha-max 1.0 "
            f"--alpha-max-az {c.alpha_max_az} "
            f"--alpha-max-el {c.alpha_max_el} "
            f"--alpha-grid-step {c.alpha_grid_step} "
            f"--min-improve-pct {c.min_improve_pct} "
            f"--azel-alpha-shrink {c.azel_alpha_shrink} "
            f"--azel-cap-deg {c.azel_cap_deg} "
            f"--clip-grid {shlex.quote(c.clip_grid)} "
            f"--overwrite\""
        )

        t0 = time.time()
        rc_train = run_cmd(train_cmd, cwd=workdir, log_path=train_log)
        train_sec = time.time() - t0
        if rc_train != 0:
            results.append(
                {
                    "name": c.name,
                    "status": "train_fail",
                    "train_rc": rc_train,
                    "train_sec": train_sec,
                }
            )
            continue

        out_corr = pred_dir / "2024-03-01_15-44-37.csv"
        out_err = pred_dir / "2024-03-01_15-44-37_pred_error.csv"
        out_metrics = pred_dir / "2024-03-01_15-44-37_metrics.csv"

        pred_cmd = (
            f"docker run --rm {docker_gpus_opt}{docker_extra_opt}"
            f"-v {shlex.quote(str(workdir))}:/work -w /work {shlex.quote(args.image)} "
            f"bash -lc "
            f"\"python3.11 {shlex.quote(args.script)} predict "
            f"--model {shlex.quote(str(model_dir.relative_to(workdir)))} "
            f"--tle-file {shlex.quote(args.tle_file)} "
            f"--baseline-csv {shlex.quote(args.baseline_csv)} "
            f"--out-corrected-csv {shlex.quote(str(out_corr.relative_to(workdir)))} "
            f"--out-pred-error-csv {shlex.quote(str(out_err.relative_to(workdir)))} "
            f"--out-metrics-csv {shlex.quote(str(out_metrics.relative_to(workdir)))} "
            f"--truth-csv {shlex.quote(args.truth_csv)} "
            f"--plot-dir {shlex.quote(str((pred_dir / 'plots').relative_to(workdir)))} "
            f"--days 30 --step-minutes 1 "
            f"--azel-cap-deg {c.azel_cap_deg} "
            f"--overwrite\""
        )
        rc_pred = run_cmd(pred_cmd, cwd=workdir, log_path=pred_log)
        if rc_pred != 0 or not out_metrics.exists():
            results.append(
                {
                    "name": c.name,
                    "status": "predict_fail",
                    "train_rc": rc_train,
                    "predict_rc": rc_pred,
                    "train_sec": train_sec,
                }
            )
            continue

        m = read_metrics(out_metrics)
        score = score_azel_priority(m)
        result = {
            "name": c.name,
            "status": "ok",
            "score_azel_priority": score,
            "train_sec": train_sec,
            "alpha_max_az": c.alpha_max_az,
            "alpha_max_el": c.alpha_max_el,
            "azel_cap_deg": c.azel_cap_deg,
            "min_improve_pct": c.min_improve_pct,
            "azel_alpha_shrink": c.azel_alpha_shrink,
            "clip_grid": c.clip_grid,
        }
        result.update(m)
        results.append(result)

    if not results:
        print("[ERROR] no results", file=sys.stderr)
        return 2

    df = pd.DataFrame(results)
    ranking_csv = out_root / "tuning_ranking.csv"
    df.to_csv(ranking_csv, index=False)
    print(f"[SAVED] ranking: {ranking_csv}")

    ok = df[df["status"] == "ok"].copy()
    if len(ok) == 0:
        print("[ERROR] all candidates failed", file=sys.stderr)
        return 1

    ok = ok.sort_values("score_azel_priority", ascending=True).reset_index(drop=True)
    best = ok.iloc[0].to_dict()
    best_json = out_root / "best_result.json"
    best_json.write_text(json.dumps(best, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[SAVED] best result: {best_json}")

    print("\n=== BEST ===")
    print(json.dumps(best, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
