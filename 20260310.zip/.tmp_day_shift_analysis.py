import numpy as np, pandas as pd

prev=pd.read_csv('2023_calc_az_el.csv', usecols=['date','AZ','EL'])
cur=pd.read_csv('2024_calc_az_el.csv', usecols=['date','AZ','EL'])
prev['dt']=pd.to_datetime(prev['date'])
cur['dt']=pd.to_datetime(cur['date'])
prev['key']=prev['dt'].dt.strftime('%m-%d %H:%M')
cur['key']=cur['dt'].dt.strftime('%m-%d %H:%M')
prev=prev.set_index('key')
cur=cur.set_index('key')
common=cur.index.intersection(prev.index)
base=prev.loc[common,['AZ','EL']].copy()
truth=cur.loc[common,['AZ','EL']].copy()

# repeat baseline
for col in ['AZ','EL']:
    d=(base[col]-truth[col]).to_numpy()
    print('repeat', col, np.mean(np.abs(d)), np.max(np.abs(d)))

# build per-day arrays
cur2=cur.reset_index()
cur2['day']=cur2['dt'].dt.strftime('%m-%d')
prev2=prev.reset_index()
prev2['day']=pd.to_datetime('2023-'+prev2['key'].str[:5]+' '+prev2['key'].str[6:]).dt.strftime('%m-%d')

# easier via minute-of-day map per day
cur2['min']=cur2['dt'].dt.hour*60+cur2['dt'].dt.minute
prev2['min']=prev2['dt'].dt.hour*60+prev2['dt'].dt.minute

errs=[]
pred_rows=[]
for day, g in cur2.groupby('day', sort=True):
    p=prev2[prev2['day']==day].set_index('min')[['AZ','EL']].sort_index()
    c=g.set_index('min')[['AZ','EL']].sort_index()
    mins=c.index.intersection(p.index)
    p=p.loc[mins]
    c=c.loc[mins]
    if len(mins)==0:
        continue
    best=None
    p_full=p.reindex(range(1440))
    c_full=c.reindex(range(1440))
    for shift in range(-60,61):
        ps=p_full.shift(shift)
        m=ps.notna().all(axis=1) & c_full.notna().all(axis=1)
        if m.sum()<1000:
            continue
        delta=(c_full[m]-ps[m])
        az_off=delta['AZ'].median()
        el_off=delta['EL'].median()
        rem=np.maximum(np.abs((ps[m]['AZ']+az_off)-c_full[m]['AZ']), np.abs((ps[m]['EL']+el_off)-c_full[m]['EL']))
        score=np.quantile(rem, 0.99)
        if best is None or score<best[0]:
            best=(score, shift, az_off, el_off, rem.max(), rem.mean())
    errs.append((day,)+best)

errs=pd.DataFrame(errs, columns=['day','p99','shift','az_off','el_off','max','mean'])
print(errs.head(10).to_string(index=False))
print('shift range', errs['shift'].min(), errs['shift'].max(), 'mean abs', errs['shift'].abs().mean())
print('oracle day shift+offset max', errs['max'].max(), 'mean p99', errs['p99'].mean(), 'mean mean', errs['mean'].mean())
print('worst days')
print(errs.sort_values('max', ascending=False).head(15).to_string(index=False))
