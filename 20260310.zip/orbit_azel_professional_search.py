#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AZ/EL-focused correction model without TensorFlow.

Design goals:
- Improve AZ/EL over single-TLE SGP4 baseline when possible.
- Avoid degradation via conservative alpha/gamma calibration (no-harm guard).
- Try multiple strategies and parameter grids automatically:
  template / ridge / knn / blend.
- Optional auxiliary satellite bank (e.g., INMALSAT-F1) with tuned aux weight.
- Single-TLE inference only.

Training data:
- TLE files: <tle-dir>/*.txt
- Error files: <err-dir>/*.csv, where error = baseline - truth
  (columns include No, AZ, EL)

Inference data:
- One TLE file + one baseline csv, output corrected csv and predicted error csv.
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import json
import math
import os
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from orbit_error_ai_no_tle_tf import (
    TARGET_COLS,
    angle_diff_deg,
    compute_metrics,
    ensure_dir,
    list_stems_with_both,
    load_orbit_csv,
    log,
    now_jst_str,
    parse_tle_file,
    plot_baseline_vs_corrected,
    plot_metric_summary,
    plot_truth_baseline_corrected,
    tle_feature_vector,
    trim_horizon_and_stride,
    wrap180,
    wrap360,
)


MINUTES_PER_DAY = 1440.0


def parse_stem_datetime(stem: str) -> Optional[dt.datetime]:
    s = str(stem).strip()
    # Common patterns:
    # - YYYY-MM-DD_HH-MM-SS
    # - YYYY-MM-DD-HH-MM-SS
    # - with suffix like _1 / -copy etc.
    m = re.search(r"(\d{4}-\d{2}-\d{2})[-_](\d{2})-(\d{2})-(\d{2})", s)
    if m is None:
        return None
    ds = m.group(1)
    hh = int(m.group(2))
    mm = int(m.group(3))
    ss = int(m.group(4))
    try:
        d0 = dt.datetime.strptime(ds, "%Y-%m-%d")
    except Exception:
        return None
    return d0.replace(hour=hh, minute=mm, second=ss)


def list_tles_with_datetime(tle_dir: Path) -> List[Tuple[dt.datetime, Path]]:
    out: List[Tuple[dt.datetime, Path]] = []
    for p in sorted(tle_dir.glob("*.txt")):
        if not p.is_file():
            continue
        t = parse_stem_datetime(p.stem)
        if t is None:
            continue
        out.append((t, p))
    out.sort(key=lambda x: x[0])
    return out


def resolve_baseline_csv_for_anchor(
    baseline_csv_dir: Path,
    anchor_stem: str,
    anchor_dt: dt.datetime,
) -> Path:
    direct = baseline_csv_dir / f"{anchor_stem}.csv"
    if direct.exists():
        return direct
    cands: List[Tuple[float, Path]] = []
    for p in baseline_csv_dir.glob("*.csv"):
        if not p.is_file():
            continue
        t = parse_stem_datetime(p.stem)
        if t is None:
            continue
        dd = abs((t - anchor_dt).total_seconds())
        cands.append((float(dd), p))
    if len(cands) == 0:
        raise FileNotFoundError(
            f"baseline csv not found for anchor stem={anchor_stem} in {baseline_csv_dir}"
        )
    cands.sort(key=lambda x: x[0])
    return cands[0][1]


def parse_float_csv(text: str) -> List[float]:
    vals: List[float] = []
    for tok in str(text).split(","):
        t = tok.strip()
        if not t:
            continue
        vals.append(float(t))
    return vals


def parse_int_csv(text: str) -> List[int]:
    vals: List[int] = []
    for tok in str(text).split(","):
        t = tok.strip()
        if not t:
            continue
        vals.append(int(float(t)))
    return vals


def parse_aux_specs(specs: Optional[List[str]]) -> List[Tuple[str, Path, Path]]:
    out: List[Tuple[str, Path, Path]] = []
    if not specs:
        return out
    for raw in specs:
        parts = [p.strip() for p in str(raw).split(":")]
        if len(parts) != 3:
            raise ValueError(
                f"--aux-dataset format error: {raw}. Expected name:tle_dir:err_dir"
            )
        out.append((parts[0], Path(parts[1]), Path(parts[2])))
    return out


def deterministic_split(stem: str, val_split: float, seed: int) -> str:
    # Same behavior as other scripts to keep reproducibility.
    import hashlib

    h = hashlib.md5((stem + str(seed)).encode("utf-8")).hexdigest()
    r = int(h[:8], 16) / float(16**8)
    return "val" if r < val_split else "train"


def split_stems(
    stems: List[str],
    val_split: float,
    split_mode: str,
    seed: int,
) -> Tuple[List[str], List[str]]:
    if len(stems) == 0:
        return [], []
    v = float(np.clip(val_split, 0.0, 0.9))
    if v <= 0.0:
        return list(stems), []
    if split_mode == "hash":
        tr: List[str] = []
        va: List[str] = []
        for s in stems:
            if deterministic_split(s, v, seed) == "val":
                va.append(s)
            else:
                tr.append(s)
        if len(va) == 0 and len(tr) > 1:
            va = [tr.pop(-1)]
        return tr, va

    # time split (by stem sort)
    ss = sorted(stems)
    n_val = max(1, int(round(len(ss) * v)))
    n_val = min(n_val, max(1, len(ss) - 1))
    return ss[:-n_val], ss[-n_val:]


def day_bin_index(no: np.ndarray, edges: np.ndarray) -> np.ndarray:
    day = (np.asarray(no, dtype=np.float64).reshape(-1) - 1.0) / MINUTES_PER_DAY
    idx = np.searchsorted(edges, day, side="right") - 1
    idx = np.clip(idx, 0, len(edges) - 2)
    return idx.astype(np.int64)


def circular_mean_weighted_deg(vals_deg: np.ndarray, w: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    # vals_deg shape=(k,T), w shape=(k,)
    r = np.deg2rad(np.asarray(vals_deg, dtype=np.float64))
    ww = np.asarray(w, dtype=np.float64).reshape(-1, 1)
    s = np.sum(ww * np.sin(r), axis=0)
    c = np.sum(ww * np.cos(r), axis=0)
    ang = np.rad2deg(np.arctan2(s, c))
    conf = np.sqrt(s * s + c * c) / max(1e-12, float(np.sum(np.abs(w))))
    conf = np.clip(conf, 0.0, 1.0)
    return wrap180(ang), conf


def circular_blend_deg(
    a_deg: np.ndarray,
    b_deg: np.ndarray,
    w_b: float,
) -> np.ndarray:
    wa = float(1.0 - w_b)
    wb = float(w_b)
    ar = np.deg2rad(np.asarray(a_deg, dtype=np.float64))
    br = np.deg2rad(np.asarray(b_deg, dtype=np.float64))
    s = wa * np.sin(ar) + wb * np.sin(br)
    c = wa * np.cos(ar) + wb * np.cos(br)
    return wrap180(np.rad2deg(np.arctan2(s, c)))


def weighted_mean_and_conf(vals: np.ndarray, w: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    # vals shape=(k,T), w shape=(k,)
    ww = np.asarray(w, dtype=np.float64).reshape(-1, 1)
    sw = np.sum(ww, axis=0)
    sw = np.where(sw <= 0, 1.0, sw)
    mean = np.sum(ww * vals, axis=0) / sw
    var = np.sum(ww * (vals - mean.reshape(1, -1)) ** 2, axis=0) / sw
    std = np.sqrt(np.maximum(var, 0.0))
    ref = float(np.median(std[std > 1e-12])) if np.any(std > 1e-12) else 1.0
    conf = np.exp(-std / max(1e-8, ref))
    conf = np.clip(conf, 0.0, 1.0)
    return mean, conf


def fit_linear_fill(vals: np.ndarray, mask: np.ndarray) -> np.ndarray:
    out = np.asarray(vals, dtype=np.float64).copy()
    m = np.asarray(mask, dtype=bool)
    idx = np.where(m)[0]
    if len(idx) == 0:
        return np.zeros_like(out)
    if len(idx) == 1:
        out[:] = out[idx[0]]
        return out
    full = np.arange(len(out), dtype=np.float64)
    out[:] = np.interp(full, idx.astype(np.float64), out[idx])
    return out


def fit_angle_fill(vals: np.ndarray, mask: np.ndarray) -> np.ndarray:
    out = np.asarray(vals, dtype=np.float64).copy()
    m = np.asarray(mask, dtype=bool)
    idx = np.where(m)[0]
    if len(idx) == 0:
        return np.zeros_like(out)
    if len(idx) == 1:
        out[:] = out[idx[0]]
        return wrap180(out)
    full = np.arange(len(out), dtype=np.float64)
    rad = np.unwrap(np.deg2rad(out[idx]))
    out[:] = np.rad2deg(np.interp(full, idx.astype(np.float64), rad))
    return wrap180(out)


def ensure_len(arr: np.ndarray, n: int, is_angle: bool) -> np.ndarray:
    a = np.asarray(arr, dtype=np.float64).reshape(-1)
    if len(a) == n:
        return wrap180(a) if is_angle else a
    if len(a) == 0:
        z = np.zeros((n,), dtype=np.float64)
        return z
    if len(a) > n:
        b = a[:n].copy()
        return wrap180(b) if is_angle else b
    # extend with last value
    b = np.empty((n,), dtype=np.float64)
    b[: len(a)] = a
    b[len(a) :] = a[-1]
    return wrap180(b) if is_angle else b


@dataclasses.dataclass
class FileSeries:
    stem: str
    source: str
    is_aux: bool
    feat: np.ndarray
    err_az: np.ndarray
    err_el: np.ndarray
    mask: np.ndarray


@dataclasses.dataclass
class SearchResult:
    strategy: str
    params: Dict[str, float]
    rmse_az_base: float
    rmse_el_base: float
    rmse_az_corr: float
    rmse_el_corr: float
    rmse_azel_base: float
    rmse_azel_corr: float
    alpha_az: float
    alpha_el: float
    gamma_az: np.ndarray
    gamma_el: np.ndarray


def load_error_series(
    stem: str,
    source: str,
    is_aux: bool,
    tle_dir: Path,
    err_dir: Path,
    rows: int,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> FileSeries:
    tle = parse_tle_file(tle_dir / f"{stem}.txt")
    feat, _ = tle_feature_vector(tle)
    df = load_orbit_csv(err_dir / f"{stem}.csv", require_targets=True)
    df = trim_horizon_and_stride(
        df,
        days_horizon=days_horizon,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    no = pd.to_numeric(df["No"], errors="coerce").astype("Int64")
    valid_no = no.notna().to_numpy()
    no_i = no.fillna(-1).to_numpy(np.int64)

    az = np.full((rows,), np.nan, dtype=np.float64)
    el = np.full((rows,), np.nan, dtype=np.float64)
    mask = np.zeros((rows,), dtype=bool)

    az_raw = wrap180(pd.to_numeric(df["AZ"], errors="coerce").to_numpy(np.float64))
    el_raw = pd.to_numeric(df["EL"], errors="coerce").to_numpy(np.float64)
    for i in range(len(df)):
        if not valid_no[i]:
            continue
        idx = int(no_i[i]) - 1
        if idx < 0 or idx >= rows:
            continue
        if not np.isfinite(az_raw[i]) or not np.isfinite(el_raw[i]):
            continue
        az[idx] = float(az_raw[i])
        el[idx] = float(el_raw[i])
        mask[idx] = True

    return FileSeries(
        stem=stem,
        source=source,
        is_aux=bool(is_aux),
        feat=feat.astype(np.float64),
        err_az=az,
        err_el=el,
        mask=mask,
    )


def build_template(records: Sequence[FileSeries], rows: int) -> Tuple[np.ndarray, np.ndarray]:
    s = np.zeros((rows,), dtype=np.float64)
    c = np.zeros((rows,), dtype=np.float64)
    cnt_az = np.zeros((rows,), dtype=np.int64)
    sum_el = np.zeros((rows,), dtype=np.float64)
    cnt_el = np.zeros((rows,), dtype=np.int64)

    for r in records:
        m = np.asarray(r.mask, dtype=bool)
        if not np.any(m):
            continue
        az = r.err_az[m]
        el = r.err_el[m]
        rr = np.deg2rad(az)
        s[m] += np.sin(rr)
        c[m] += np.cos(rr)
        cnt_az[m] += 1
        sum_el[m] += el
        cnt_el[m] += 1

    tpl_az = np.zeros((rows,), dtype=np.float64)
    tpl_el = np.zeros((rows,), dtype=np.float64)
    ma = cnt_az > 0
    me = cnt_el > 0
    tpl_az[ma] = np.rad2deg(np.arctan2(s[ma], c[ma]))
    tpl_el[me] = sum_el[me] / cnt_el[me].astype(np.float64)

    tpl_az = fit_angle_fill(tpl_az, ma)
    tpl_el = fit_linear_fill(tpl_el, me)
    return wrap180(tpl_az), tpl_el


def finalize_records(records: Sequence[FileSeries], tpl_az: np.ndarray, tpl_el: np.ndarray) -> List[FileSeries]:
    out: List[FileSeries] = []
    for r in records:
        az = np.asarray(r.err_az, dtype=np.float64).copy()
        el = np.asarray(r.err_el, dtype=np.float64).copy()
        m = np.asarray(r.mask, dtype=bool)
        az[~m] = tpl_az[~m]
        el[~m] = tpl_el[~m]
        out.append(
            FileSeries(
                stem=r.stem,
                source=r.source,
                is_aux=r.is_aux,
                feat=np.asarray(r.feat, dtype=np.float64).copy(),
                err_az=wrap180(az),
                err_el=el.astype(np.float64),
                mask=m.copy(),
            )
        )
    return out


def standardize_features(x_train: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    m = np.mean(x_train, axis=0)
    s = np.std(x_train, axis=0)
    s = np.where(s < 1e-9, 1.0, s)
    return m.astype(np.float64), s.astype(np.float64)


def zscore(x: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    return (np.asarray(x, dtype=np.float64) - mean.reshape(1, -1)) / std.reshape(1, -1)


def fit_ridge(
    x_train: np.ndarray,
    y_az_deg: np.ndarray,
    y_el: np.ndarray,
    is_aux: np.ndarray,
    aux_weight: float,
    l2: float,
) -> Dict[str, np.ndarray]:
    n, d = x_train.shape
    if y_az_deg.shape != (n, y_az_deg.shape[1]):
        raise ValueError("shape mismatch for AZ train matrix")
    w_row = np.ones((n,), dtype=np.float64)
    if len(is_aux) == n:
        w_row[np.asarray(is_aux, dtype=bool)] = float(max(0.0, aux_weight))
    sw = np.sqrt(np.maximum(w_row, 1e-12)).reshape(-1, 1)

    xw = x_train * sw
    eye = np.eye(d, dtype=np.float64)
    a = xw.T @ xw + float(l2) * eye

    az_rad = np.deg2rad(np.asarray(y_az_deg, dtype=np.float64))
    y_sin = np.sin(az_rad) * sw
    y_cos = np.cos(az_rad) * sw
    y_elw = np.asarray(y_el, dtype=np.float64) * sw

    b_sin = xw.T @ y_sin
    b_cos = xw.T @ y_cos
    b_el = xw.T @ y_elw

    w_sin = np.linalg.solve(a, b_sin)
    w_cos = np.linalg.solve(a, b_cos)
    w_el = np.linalg.solve(a, b_el)

    pred_el = x_train @ w_el
    resid_el = y_el - pred_el
    std_el = np.std(resid_el, axis=0)
    ref = float(np.median(std_el[std_el > 1e-9])) if np.any(std_el > 1e-9) else 1.0
    conf_el = np.exp(-std_el / max(1e-8, ref))
    conf_el = np.clip(conf_el, 0.0, 1.0)

    return {
        "w_sin": w_sin.astype(np.float64),
        "w_cos": w_cos.astype(np.float64),
        "w_el": w_el.astype(np.float64),
        "conf_el": conf_el.astype(np.float64),
    }


def predict_ridge(
    x_query: np.ndarray,
    ridge: Dict[str, np.ndarray],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    q = np.asarray(x_query, dtype=np.float64).reshape(1, -1)
    sinp = (q @ ridge["w_sin"]).reshape(-1)
    cosp = (q @ ridge["w_cos"]).reshape(-1)
    pred_az = wrap180(np.rad2deg(np.arctan2(sinp, cosp)))
    conf_az = np.clip(np.sqrt(sinp * sinp + cosp * cosp), 0.0, 1.0)
    pred_el = (q @ ridge["w_el"]).reshape(-1)
    conf_el = np.asarray(ridge["conf_el"], dtype=np.float64).reshape(-1)
    conf_el = ensure_len(conf_el, len(pred_el), is_angle=False)
    return pred_az, pred_el, conf_az, conf_el


def predict_knn(
    x_query: np.ndarray,
    x_train: np.ndarray,
    train_az: np.ndarray,
    train_el: np.ndarray,
    train_is_aux: np.ndarray,
    template_az: np.ndarray,
    template_el: np.ndarray,
    k: int,
    tau: float,
    knn_weight: float,
    aux_weight: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    q = np.asarray(x_query, dtype=np.float64).reshape(1, -1)
    d = np.sqrt(np.sum((x_train - q) ** 2, axis=1))
    kk = int(max(1, min(int(k), len(d))))
    idx = np.argpartition(d, kk - 1)[:kk]
    dd = d[idx]
    if float(tau) > 0:
        w = np.exp(-((dd / float(tau)) ** 2))
    else:
        w = 1.0 / np.maximum(dd, 1e-6)
    if len(train_is_aux) == len(x_train):
        m_aux = np.asarray(train_is_aux[idx], dtype=bool)
        if np.any(m_aux):
            w[m_aux] *= float(max(0.0, aux_weight))
    if np.sum(np.abs(w)) <= 1e-12:
        w[:] = 1.0
    w = w / max(1e-12, np.sum(np.abs(w)))

    az_knn, conf_az_knn = circular_mean_weighted_deg(train_az[idx, :], w)
    el_knn, conf_el_knn = weighted_mean_and_conf(train_el[idx, :], w)

    kw = float(np.clip(knn_weight, 0.0, 1.0))
    pred_az = circular_blend_deg(template_az, az_knn, w_b=kw)
    pred_el = (1.0 - kw) * template_el + kw * el_knn
    conf_az = np.clip((1.0 - kw) * 1.0 + kw * conf_az_knn, 0.0, 1.0)
    conf_el = np.clip((1.0 - kw) * 1.0 + kw * conf_el_knn, 0.0, 1.0)
    return pred_az, pred_el, conf_az, conf_el


def apply_confidence_shrink(pred: np.ndarray, conf: np.ndarray, exp: float, is_angle: bool) -> np.ndarray:
    p = np.asarray(pred, dtype=np.float64).copy()
    c = np.asarray(conf, dtype=np.float64).reshape(-1)
    if len(c) != len(p):
        c = np.ones((len(p),), dtype=np.float64)
    q = float(max(0.0, exp))
    if q > 0:
        p *= np.power(np.clip(c, 0.0, 1.0), q)
    return wrap180(p) if is_angle else p


def rmse_angle(true_err: np.ndarray, pred_err: np.ndarray, mask: np.ndarray) -> float:
    m = np.asarray(mask, dtype=bool)
    if not np.any(m):
        return float("nan")
    d = angle_diff_deg(true_err[m], pred_err[m])
    return float(np.sqrt(np.mean(d * d)))


def rmse_linear(true_err: np.ndarray, pred_err: np.ndarray, mask: np.ndarray) -> float:
    m = np.asarray(mask, dtype=bool)
    if not np.any(m):
        return float("nan")
    d = np.asarray(true_err[m], dtype=np.float64) - np.asarray(pred_err[m], dtype=np.float64)
    return float(np.sqrt(np.mean(d * d)))


def _target_rmse(
    true_err: np.ndarray,
    pred_err: np.ndarray,
    mask: np.ndarray,
    is_angle: bool,
) -> float:
    if is_angle:
        return rmse_angle(true_err=true_err, pred_err=pred_err, mask=mask)
    return rmse_linear(true_err=true_err, pred_err=pred_err, mask=mask)


def calibrate_alpha(
    true_list: Sequence[np.ndarray],
    pred_list: Sequence[np.ndarray],
    mask_list: Sequence[np.ndarray],
    alpha_grid: Sequence[float],
    is_angle: bool,
    objective_quantile: float,
) -> float:
    if len(alpha_grid) == 0:
        return 0.0
    q = float(objective_quantile)
    use_quantile = (q > 0.0) and (q < 1.0)
    best_alpha = 0.0
    best_obj = float("inf")
    for a in alpha_grid:
        file_rmses: List[float] = []
        for yt, yp, m in zip(true_list, pred_list, mask_list):
            mm = np.asarray(m, dtype=bool)
            if not np.any(mm):
                continue
            if is_angle:
                d = angle_diff_deg(yt[mm], float(a) * yp[mm])
            else:
                d = yt[mm] - float(a) * yp[mm]
            file_rmses.append(float(np.sqrt(np.mean(d * d))))
        if len(file_rmses) == 0:
            continue
        if use_quantile:
            obj = float(np.quantile(np.asarray(file_rmses, dtype=np.float64), q))
        else:
            obj = float(np.mean(file_rmses))
        if obj < best_obj:
            best_obj = obj
            best_alpha = float(a)
    return float(best_alpha)


def calibrate_gamma_schedule(
    true_list: Sequence[np.ndarray],
    pred_list: Sequence[np.ndarray],
    no_list: Sequence[np.ndarray],
    mask_list: Sequence[np.ndarray],
    alpha: float,
    day_edges: np.ndarray,
    gamma_grid: Sequence[float],
    is_angle: bool,
    min_improve_pct: float,
    min_file_improve_ratio: float,
) -> np.ndarray:
    nb = len(day_edges) - 1
    g = np.zeros((nb,), dtype=np.float64)
    if nb <= 0:
        return g
    gg = [float(np.clip(x, 0.0, 1.5)) for x in gamma_grid]
    if len(gg) == 0:
        gg = [0.0, 1.0]

    for bi in range(nb):
        ss_base = 0.0
        ss_best = 0.0
        cc = 0
        best_rmse = float("inf")
        best_gamma = 0.0
        lo = float(day_edges[bi])
        hi = float(day_edges[bi + 1])
        for gm in gg:
            ss = 0.0
            c = 0
            for yt, yp, no, m in zip(true_list, pred_list, no_list, mask_list):
                mm = np.asarray(m, dtype=bool).copy()
                day = (np.asarray(no, dtype=np.float64) - 1.0) / MINUTES_PER_DAY
                mm &= (day >= lo) & (day < hi)
                if not np.any(mm):
                    continue
                pred = float(alpha) * float(gm) * yp[mm]
                if is_angle:
                    d = angle_diff_deg(yt[mm], pred)
                else:
                    d = yt[mm] - pred
                ss += float(np.sum(d * d))
                c += int(np.sum(mm))
            if c <= 0:
                continue
            rm = math.sqrt(ss / c)
            if rm < best_rmse:
                best_rmse = rm
                best_gamma = float(gm)
                ss_best = ss
                cc = c

        if cc <= 0:
            g[bi] = 0.0
            continue

        # baseline in this bin (gamma=0)
        for yt, yp, no, m in zip(true_list, pred_list, no_list, mask_list):
            mm = np.asarray(m, dtype=bool).copy()
            day = (np.asarray(no, dtype=np.float64) - 1.0) / MINUTES_PER_DAY
            mm &= (day >= lo) & (day < hi)
            if not np.any(mm):
                continue
            if is_angle:
                d0 = angle_diff_deg(yt[mm], np.zeros(np.sum(mm), dtype=np.float64))
            else:
                d0 = yt[mm]
            ss_base += float(np.sum(d0 * d0))
        rm_base = math.sqrt(ss_base / cc)
        rm_best = math.sqrt(ss_best / cc)
        improve = 0.0 if rm_base <= 0 else 100.0 * (rm_base - rm_best) / rm_base
        # Per-file guard in this bin: require enough files to improve.
        improved_files = 0
        total_files = 0
        for yt, yp, no, m in zip(true_list, pred_list, no_list, mask_list):
            mm = np.asarray(m, dtype=bool).copy()
            day = (np.asarray(no, dtype=np.float64) - 1.0) / MINUTES_PER_DAY
            mm &= (day >= lo) & (day < hi)
            if not np.any(mm):
                continue
            total_files += 1
            pred0 = np.zeros(np.sum(mm), dtype=np.float64)
            pred1 = float(alpha) * float(best_gamma) * yp[mm]
            if is_angle:
                d0 = angle_diff_deg(yt[mm], pred0)
                d1 = angle_diff_deg(yt[mm], pred1)
            else:
                d0 = yt[mm] - pred0
                d1 = yt[mm] - pred1
            r0 = float(np.sqrt(np.mean(d0 * d0)))
            r1 = float(np.sqrt(np.mean(d1 * d1)))
            if r1 < r0:
                improved_files += 1

        ratio = 0.0 if total_files <= 0 else float(improved_files) / float(total_files)
        if improve < float(min_improve_pct) or ratio < float(min_file_improve_ratio):
            g[bi] = 0.0
        else:
            g[bi] = best_gamma

    return g


def apply_alpha_gamma(
    pred: np.ndarray,
    no: np.ndarray,
    alpha: float,
    gamma_vec: np.ndarray,
    day_edges: np.ndarray,
    is_angle: bool,
) -> np.ndarray:
    p = np.asarray(pred, dtype=np.float64).reshape(-1)
    idx = day_bin_index(no=no, edges=day_edges)
    g = np.asarray(gamma_vec, dtype=np.float64).reshape(-1)
    if len(g) == 0:
        out = float(alpha) * p
    else:
        out = float(alpha) * g[idx] * p
    return wrap180(out) if is_angle else out


def evaluate_fixed_calibration(
    true_az_list: Sequence[np.ndarray],
    true_el_list: Sequence[np.ndarray],
    pred_az_list: Sequence[np.ndarray],
    pred_el_list: Sequence[np.ndarray],
    no_list: Sequence[np.ndarray],
    mask_list: Sequence[np.ndarray],
    alpha_az: float,
    alpha_el: float,
    gamma_az: np.ndarray,
    gamma_el: np.ndarray,
    day_edges: np.ndarray,
) -> Tuple[float, float, float]:
    ss_az = 0.0
    ss_el = 0.0
    c_az = 0
    c_el = 0
    for taz, tel, paz, pel, no, m in zip(
        true_az_list,
        true_el_list,
        pred_az_list,
        pred_el_list,
        no_list,
        mask_list,
    ):
        mm = np.asarray(m, dtype=bool)
        if not np.any(mm):
            continue
        p_az = apply_alpha_gamma(
            pred=paz,
            no=no,
            alpha=alpha_az,
            gamma_vec=gamma_az,
            day_edges=day_edges,
            is_angle=True,
        )
        p_el = apply_alpha_gamma(
            pred=pel,
            no=no,
            alpha=alpha_el,
            gamma_vec=gamma_el,
            day_edges=day_edges,
            is_angle=False,
        )
        d_az = angle_diff_deg(taz[mm], p_az[mm])
        d_el = tel[mm] - p_el[mm]
        ss_az += float(np.sum(d_az * d_az))
        ss_el += float(np.sum(d_el * d_el))
        c_az += int(np.sum(mm))
        c_el += int(np.sum(mm))
    rmse_az = math.sqrt(ss_az / max(1, c_az))
    rmse_el = math.sqrt(ss_el / max(1, c_el))
    rmse_azel = 0.5 * (rmse_az + rmse_el)
    return float(rmse_az), float(rmse_el), float(rmse_azel)


def eval_candidate(
    true_az_list: Sequence[np.ndarray],
    true_el_list: Sequence[np.ndarray],
    pred_az_raw_list: Sequence[np.ndarray],
    pred_el_raw_list: Sequence[np.ndarray],
    conf_az_list: Sequence[np.ndarray],
    conf_el_list: Sequence[np.ndarray],
    no_list: Sequence[np.ndarray],
    mask_list: Sequence[np.ndarray],
    conf_exp: float,
    alpha_grid: Sequence[float],
    day_edges: np.ndarray,
    gamma_grid: Sequence[float],
    min_bin_improve_pct: float,
    alpha_objective_quantile: float,
    min_file_improve_ratio: float,
) -> SearchResult:
    pred_az_list: List[np.ndarray] = []
    pred_el_list: List[np.ndarray] = []
    for paz, pel, caz, cel in zip(pred_az_raw_list, pred_el_raw_list, conf_az_list, conf_el_list):
        pred_az_list.append(
            apply_confidence_shrink(pred=paz, conf=caz, exp=conf_exp, is_angle=True)
        )
        pred_el_list.append(
            apply_confidence_shrink(pred=pel, conf=cel, exp=conf_exp, is_angle=False)
        )

    a_az = calibrate_alpha(
        true_list=true_az_list,
        pred_list=pred_az_list,
        mask_list=mask_list,
        alpha_grid=alpha_grid,
        is_angle=True,
        objective_quantile=float(alpha_objective_quantile),
    )
    a_el = calibrate_alpha(
        true_list=true_el_list,
        pred_list=pred_el_list,
        mask_list=mask_list,
        alpha_grid=alpha_grid,
        is_angle=False,
        objective_quantile=float(alpha_objective_quantile),
    )

    g_az = calibrate_gamma_schedule(
        true_list=true_az_list,
        pred_list=pred_az_list,
        no_list=no_list,
        mask_list=mask_list,
        alpha=a_az,
        day_edges=day_edges,
        gamma_grid=gamma_grid,
        is_angle=True,
        min_improve_pct=min_bin_improve_pct,
        min_file_improve_ratio=float(min_file_improve_ratio),
    )
    g_el = calibrate_gamma_schedule(
        true_list=true_el_list,
        pred_list=pred_el_list,
        no_list=no_list,
        mask_list=mask_list,
        alpha=a_el,
        day_edges=day_edges,
        gamma_grid=gamma_grid,
        is_angle=False,
        min_improve_pct=min_bin_improve_pct,
        min_file_improve_ratio=float(min_file_improve_ratio),
    )

    ss_az_b = 0.0
    ss_el_b = 0.0
    ss_az_c = 0.0
    ss_el_c = 0.0
    c_az = 0
    c_el = 0
    for taz, tel, paz, pel, no, m in zip(
        true_az_list,
        true_el_list,
        pred_az_list,
        pred_el_list,
        no_list,
        mask_list,
    ):
        mm = np.asarray(m, dtype=bool)
        if not np.any(mm):
            continue
        pred_az = apply_alpha_gamma(
            pred=paz,
            no=no,
            alpha=a_az,
            gamma_vec=g_az,
            day_edges=day_edges,
            is_angle=True,
        )
        pred_el = apply_alpha_gamma(
            pred=pel,
            no=no,
            alpha=a_el,
            gamma_vec=g_el,
            day_edges=day_edges,
            is_angle=False,
        )

        d_az_b = taz[mm]
        d_az_c = angle_diff_deg(taz[mm], pred_az[mm])
        d_el_b = tel[mm]
        d_el_c = tel[mm] - pred_el[mm]
        ss_az_b += float(np.sum(d_az_b * d_az_b))
        ss_az_c += float(np.sum(d_az_c * d_az_c))
        ss_el_b += float(np.sum(d_el_b * d_el_b))
        ss_el_c += float(np.sum(d_el_c * d_el_c))
        c_az += int(np.sum(mm))
        c_el += int(np.sum(mm))

    rmse_az_b = math.sqrt(ss_az_b / max(1, c_az))
    rmse_az_c = math.sqrt(ss_az_c / max(1, c_az))
    rmse_el_b = math.sqrt(ss_el_b / max(1, c_el))
    rmse_el_c = math.sqrt(ss_el_c / max(1, c_el))
    rmse_azel_b = 0.5 * (rmse_az_b + rmse_el_b)
    rmse_azel_c = 0.5 * (rmse_az_c + rmse_el_c)

    return SearchResult(
        strategy="",
        params={},
        rmse_az_base=float(rmse_az_b),
        rmse_el_base=float(rmse_el_b),
        rmse_az_corr=float(rmse_az_c),
        rmse_el_corr=float(rmse_el_c),
        rmse_azel_base=float(rmse_azel_b),
        rmse_azel_corr=float(rmse_azel_c),
        alpha_az=float(a_az),
        alpha_el=float(a_el),
        gamma_az=g_az,
        gamma_el=g_el,
    )


def pack_records(records: Sequence[FileSeries]) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str]]:
    if len(records) == 0:
        return (
            np.zeros((0, 1), dtype=np.float64),
            np.zeros((0, 1), dtype=np.float64),
            np.zeros((0, 1), dtype=np.float64),
            np.zeros((0,), dtype=bool),
            [],
        )
    x = np.stack([r.feat for r in records], axis=0).astype(np.float64)
    az = np.stack([r.err_az for r in records], axis=0).astype(np.float64)
    el = np.stack([r.err_el for r in records], axis=0).astype(np.float64)
    is_aux = np.array([bool(r.is_aux) for r in records], dtype=bool)
    stems = [r.stem for r in records]
    return x, az, el, is_aux, stems


def build_no_array(rows: int) -> np.ndarray:
    return np.arange(1, rows + 1, dtype=np.int64)


def load_truth_error_for_target_val(records: Sequence[FileSeries]) -> Tuple[List[np.ndarray], List[np.ndarray], List[np.ndarray], List[np.ndarray]]:
    true_az: List[np.ndarray] = []
    true_el: List[np.ndarray] = []
    no_list: List[np.ndarray] = []
    masks: List[np.ndarray] = []
    for r in records:
        true_az.append(np.asarray(r.err_az, dtype=np.float64))
        true_el.append(np.asarray(r.err_el, dtype=np.float64))
        no_list.append(build_no_array(len(r.err_az)))
        masks.append(np.asarray(r.mask, dtype=bool))
    return true_az, true_el, no_list, masks


def merge_corrected_with_baseline(
    baseline_df: pd.DataFrame,
    pred_err_az: np.ndarray,
    pred_err_el: np.ndarray,
) -> pd.DataFrame:
    out = baseline_df.copy()
    az = out["AZ"].to_numpy(np.float64)
    el = out["EL"].to_numpy(np.float64)
    n = len(out)
    paz = ensure_len(pred_err_az, n=n, is_angle=True)
    pel = ensure_len(pred_err_el, n=n, is_angle=False)
    out["AZ"] = wrap360(az - paz)
    out["EL"] = np.clip(el - pel, -90.0, 90.0)
    return out


def circular_weighted_mean_and_std_deg(vals_deg: np.ndarray, weights: np.ndarray) -> Tuple[float, float]:
    v = np.asarray(vals_deg, dtype=np.float64).reshape(-1)
    w = np.asarray(weights, dtype=np.float64).reshape(-1)
    if len(v) == 0:
        return 0.0, 180.0
    if len(w) != len(v):
        w = np.ones((len(v),), dtype=np.float64)
    sw = float(np.sum(np.abs(w)))
    if sw <= 1e-12:
        w = np.ones((len(v),), dtype=np.float64)
        sw = float(len(v))
    r = np.deg2rad(v)
    s = float(np.sum(w * np.sin(r)))
    c = float(np.sum(w * np.cos(r)))
    mean = float(np.rad2deg(np.arctan2(s, c)))
    mean = float(wrap180(np.asarray([mean], dtype=np.float64))[0])
    R = float(np.sqrt(s * s + c * c) / max(sw, 1e-12))
    R = float(np.clip(R, 1e-12, 1.0))
    # Circular standard deviation in degrees.
    std = float(np.rad2deg(np.sqrt(max(0.0, -2.0 * np.log(R)))))
    return mean, std


def weighted_mean_std(vals: np.ndarray, weights: np.ndarray) -> Tuple[float, float]:
    v = np.asarray(vals, dtype=np.float64).reshape(-1)
    w = np.asarray(weights, dtype=np.float64).reshape(-1)
    if len(v) == 0:
        return 0.0, 0.0
    if len(w) != len(v):
        w = np.ones((len(v),), dtype=np.float64)
    sw = float(np.sum(np.abs(w)))
    if sw <= 1e-12:
        w = np.ones((len(v),), dtype=np.float64)
        sw = float(len(v))
    m = float(np.sum(w * v) / sw)
    var = float(np.sum(w * (v - m) ** 2) / sw)
    return m, float(np.sqrt(max(0.0, var)))


def save_model(
    out_model: Path,
    overwrite: bool,
    meta: Dict,
    arrays: Dict[str, np.ndarray],
) -> Tuple[Path, Path]:
    ensure_dir(out_model)
    meta_path = out_model / "meta.json"
    bank_path = out_model / "bank.npz"
    if (meta_path.exists() or bank_path.exists()) and not overwrite:
        raise FileExistsError(f"model exists: {out_model} (use --overwrite)")
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    np.savez_compressed(bank_path, **arrays)
    return meta_path, bank_path


def load_model(model_dir: Path) -> Tuple[Dict, Dict[str, np.ndarray]]:
    meta_path = model_dir / "meta.json"
    bank_path = model_dir / "bank.npz"
    if not meta_path.exists():
        raise FileNotFoundError(f"meta not found: {meta_path}")
    if not bank_path.exists():
        raise FileNotFoundError(f"bank not found: {bank_path}")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    with np.load(bank_path, allow_pickle=False) as z:
        arrays = {k: z[k] for k in z.files}
    return meta, arrays


def infer_pred_error_from_tle(
    tle_file: Path,
    n_rows: int,
    meta: Dict,
    arrays: Dict[str, np.ndarray],
    cap_deg: float,
    global_scale_override: Optional[float],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    strategy = str(meta["strategy"])
    strategy_params = dict(meta.get("strategy_params", {}))
    conf_exp = float(meta.get("conf_exp", 0.0))
    alpha_az = float(meta.get("alpha_az", 0.0))
    alpha_el = float(meta.get("alpha_el", 0.0))
    day_edges = np.asarray(meta.get("day_edges", [0.0, 30.0]), dtype=np.float64)
    gamma_az = np.asarray(meta.get("gamma_az", [0.0]), dtype=np.float64)
    gamma_el = np.asarray(meta.get("gamma_el", [0.0]), dtype=np.float64)
    global_scale = float(meta.get("global_scale_selected", 1.0))
    if global_scale_override is not None:
        global_scale = float(global_scale_override)

    tle = parse_tle_file(Path(tle_file))
    feat_raw, _ = tle_feature_vector(tle)
    x_mean = arrays["feature_mean"].astype(np.float64)
    x_std = arrays["feature_std"].astype(np.float64)
    feat_z = ((feat_raw.reshape(1, -1) - x_mean.reshape(1, -1)) / x_std.reshape(1, -1)).reshape(-1)

    template_az = ensure_len(arrays["template_az"], n=n_rows, is_angle=True)
    template_el = ensure_len(arrays["template_el"], n=n_rows, is_angle=False)
    x_train = arrays["train_feats"].astype(np.float64)
    train_az = arrays["train_err_az"].astype(np.float64)
    train_el = arrays["train_err_el"].astype(np.float64)
    train_is_aux = arrays["train_is_aux"].astype(np.int8).astype(bool)

    if train_az.shape[1] != n_rows:
        train_az = np.stack([ensure_len(r, n=n_rows, is_angle=True) for r in train_az], axis=0)
        train_el = np.stack([ensure_len(r, n=n_rows, is_angle=False) for r in train_el], axis=0)

    ridge = {
        "w_sin": arrays["ridge_w_sin"].astype(np.float64),
        "w_cos": arrays["ridge_w_cos"].astype(np.float64),
        "w_el": arrays["ridge_w_el"].astype(np.float64),
        "conf_el": ensure_len(arrays["ridge_conf_el"], n=n_rows, is_angle=False),
    }
    if ridge["w_sin"].shape[1] != n_rows:
        ridge["w_sin"] = np.stack([ensure_len(r, n=n_rows, is_angle=False) for r in ridge["w_sin"]], axis=0)
        ridge["w_cos"] = np.stack([ensure_len(r, n=n_rows, is_angle=False) for r in ridge["w_cos"]], axis=0)
        ridge["w_el"] = np.stack([ensure_len(r, n=n_rows, is_angle=False) for r in ridge["w_el"]], axis=0)

    pred_az_raw, pred_el_raw, conf_az, conf_el = make_strategy_predictions(
        strategy=strategy,
        params={k: float(v) for k, v in strategy_params.items()},
        x_query=feat_z,
        template_az=template_az,
        template_el=template_el,
        x_train=x_train,
        train_az=train_az,
        train_el=train_el,
        train_is_aux=train_is_aux,
        ridge=ridge,
    )

    pred_az_conf = apply_confidence_shrink(pred=pred_az_raw, conf=conf_az, exp=conf_exp, is_angle=True)
    pred_el_conf = apply_confidence_shrink(pred=pred_el_raw, conf=conf_el, exp=conf_exp, is_angle=False)

    no = np.arange(1, n_rows + 1, dtype=np.int64)
    pred_az = apply_alpha_gamma(
        pred=pred_az_conf,
        no=no,
        alpha=alpha_az,
        gamma_vec=gamma_az,
        day_edges=day_edges,
        is_angle=True,
    )
    pred_el = apply_alpha_gamma(
        pred=pred_el_conf,
        no=no,
        alpha=alpha_el,
        gamma_vec=gamma_el,
        day_edges=day_edges,
        is_angle=False,
    )
    pred_az = wrap180(global_scale * pred_az)
    pred_el = global_scale * pred_el
    if cap_deg > 0:
        pred_az = np.clip(pred_az, -float(cap_deg), float(cap_deg))
        pred_el = np.clip(pred_el, -float(cap_deg), float(cap_deg))

    return pred_az_raw, pred_el_raw, conf_az, conf_el, pred_az, pred_el


def make_strategy_predictions(
    strategy: str,
    params: Dict[str, float],
    x_query: np.ndarray,
    template_az: np.ndarray,
    template_el: np.ndarray,
    x_train: np.ndarray,
    train_az: np.ndarray,
    train_el: np.ndarray,
    train_is_aux: np.ndarray,
    ridge: Optional[Dict[str, np.ndarray]],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    strategy = str(strategy).strip().lower()
    n = len(template_az)
    ones = np.ones((n,), dtype=np.float64)
    if strategy == "template":
        return template_az.copy(), template_el.copy(), ones.copy(), ones.copy()

    if strategy == "ridge":
        if ridge is None:
            raise RuntimeError("ridge params are missing")
        return predict_ridge(x_query=x_query, ridge=ridge)

    if strategy == "knn":
        return predict_knn(
            x_query=x_query,
            x_train=x_train,
            train_az=train_az,
            train_el=train_el,
            train_is_aux=train_is_aux,
            template_az=template_az,
            template_el=template_el,
            k=int(params["knn_k"]),
            tau=float(params["knn_tau"]),
            knn_weight=float(params["knn_weight"]),
            aux_weight=float(params["aux_weight"]),
        )

    if strategy == "blend":
        if ridge is None:
            raise RuntimeError("ridge params are missing for blend")
        p_az_r, p_el_r, c_az_r, c_el_r = predict_ridge(x_query=x_query, ridge=ridge)
        p_az_k, p_el_k, c_az_k, c_el_k = predict_knn(
            x_query=x_query,
            x_train=x_train,
            train_az=train_az,
            train_el=train_el,
            train_is_aux=train_is_aux,
            template_az=template_az,
            template_el=template_el,
            k=int(params["knn_k"]),
            tau=float(params["knn_tau"]),
            knn_weight=float(params["knn_weight"]),
            aux_weight=float(params["aux_weight"]),
        )
        wr = float(params["blend_ridge"])
        wk = float(params["blend_knn"])
        wt = float(max(0.0, 1.0 - wr - wk))
        pred_az = wrap180(
            np.rad2deg(
                np.arctan2(
                    wr * np.sin(np.deg2rad(p_az_r))
                    + wk * np.sin(np.deg2rad(p_az_k))
                    + wt * np.sin(np.deg2rad(template_az)),
                    wr * np.cos(np.deg2rad(p_az_r))
                    + wk * np.cos(np.deg2rad(p_az_k))
                    + wt * np.cos(np.deg2rad(template_az)),
                )
            )
        )
        pred_el = wr * p_el_r + wk * p_el_k + wt * template_el
        conf_az = np.clip(wr * c_az_r + wk * c_az_k + wt * 1.0, 0.0, 1.0)
        conf_el = np.clip(wr * c_el_r + wk * c_el_k + wt * 1.0, 0.0, 1.0)
        return pred_az, pred_el, conf_az, conf_el

    raise ValueError(f"unknown strategy: {strategy}")


def train_cmd(args: argparse.Namespace) -> int:
    rows = int(args.days_horizon * 24 * 60 // max(1, int(args.step_minutes)) // max(1, int(args.sample_every)))
    if rows <= 0:
        raise ValueError("rows <= 0. check --days-horizon/--step-minutes/--sample-every")

    target_tle = Path(args.tle_dir)
    target_err = Path(args.err_dir)
    if not target_tle.exists():
        raise FileNotFoundError(f"tle-dir not found: {target_tle}")
    if not target_err.exists():
        raise FileNotFoundError(f"err-dir not found: {target_err}")

    stems = list_stems_with_both(tle_dir=target_tle, csv_dir=target_err)
    if len(stems) == 0:
        raise RuntimeError("no matching target TLE/error pairs")
    if args.max_target_files is not None:
        stems = stems[: int(args.max_target_files)]
    tr_stems, va_stems = split_stems(
        stems=stems,
        val_split=float(args.val_split),
        split_mode=str(args.split_mode),
        seed=int(args.seed),
    )
    if len(va_stems) == 0:
        raise RuntimeError("validation split is empty; increase --val-split")

    log(
        f"[INFO] target stems total/train/val = {len(stems)}/{len(tr_stems)}/{len(va_stems)}"
    )

    # load target data
    target_train_raw: List[FileSeries] = []
    target_val_raw: List[FileSeries] = []
    for i, s in enumerate(tr_stems, start=1):
        try:
            target_train_raw.append(
                load_error_series(
                    stem=s,
                    source="target",
                    is_aux=False,
                    tle_dir=target_tle,
                    err_dir=target_err,
                    rows=rows,
                    days_horizon=int(args.days_horizon),
                    step_minutes=int(args.step_minutes),
                    sample_every=int(args.sample_every),
                )
            )
        except Exception as e:
            log(f"[WARN] skip target train {s}: {e}")
        if i % 50 == 0:
            log(f"[LOAD] target train {i}/{len(tr_stems)}")

    for i, s in enumerate(va_stems, start=1):
        try:
            target_val_raw.append(
                load_error_series(
                    stem=s,
                    source="target",
                    is_aux=False,
                    tle_dir=target_tle,
                    err_dir=target_err,
                    rows=rows,
                    days_horizon=int(args.days_horizon),
                    step_minutes=int(args.step_minutes),
                    sample_every=int(args.sample_every),
                )
            )
        except Exception as e:
            log(f"[WARN] skip target val {s}: {e}")
        if i % 50 == 0:
            log(f"[LOAD] target val {i}/{len(va_stems)}")

    if len(target_train_raw) == 0 or len(target_val_raw) == 0:
        raise RuntimeError("insufficient target train/val files after loading")

    aux_specs = parse_aux_specs(args.aux_dataset)
    aux_train_raw: List[FileSeries] = []
    for name, tle_dir, err_dir in aux_specs:
        if not tle_dir.exists() or not err_dir.exists():
            log(f"[WARN] aux dataset missing path; skip: {name}")
            continue
        aux_stems = list_stems_with_both(tle_dir=tle_dir, csv_dir=err_dir)
        if len(aux_stems) == 0:
            log(f"[WARN] aux dataset has no matched pairs; skip: {name}")
            continue
        if args.max_aux_files is not None:
            aux_stems = aux_stems[: int(args.max_aux_files)]
        for i, s in enumerate(aux_stems, start=1):
            try:
                aux_train_raw.append(
                    load_error_series(
                        stem=s,
                        source=name,
                        is_aux=True,
                        tle_dir=tle_dir,
                        err_dir=err_dir,
                        rows=rows,
                        days_horizon=int(args.days_horizon),
                        step_minutes=int(args.step_minutes),
                        sample_every=int(args.sample_every),
                    )
                )
            except Exception as e:
                log(f"[WARN] skip aux {name}:{s}: {e}")
            if i % 100 == 0:
                log(f"[LOAD] aux {name} {i}/{len(aux_stems)}")

    template_az, template_el = build_template(records=target_train_raw, rows=rows)
    target_train = finalize_records(target_train_raw, tpl_az=template_az, tpl_el=template_el)
    target_val = finalize_records(target_val_raw, tpl_az=template_az, tpl_el=template_el)
    aux_train = finalize_records(aux_train_raw, tpl_az=template_az, tpl_el=template_el)

    all_train = list(target_train) + list(aux_train)
    x_train_raw, az_train_raw, el_train_raw, is_aux_train, train_stems = pack_records(all_train)
    if len(x_train_raw) == 0:
        raise RuntimeError("no train rows after loading")

    x_mean, x_std = standardize_features(x_train_raw)
    x_train = zscore(x_train_raw, mean=x_mean, std=x_std)

    x_val_raw = np.stack([r.feat for r in target_val], axis=0).astype(np.float64)
    x_val = zscore(x_val_raw, mean=x_mean, std=x_std)

    true_az_val, true_el_val, no_val, mask_val = load_truth_error_for_target_val(target_val)

    # coarse search arrays
    stride = max(1, int(args.search_stride))
    idx_sub = np.arange(0, rows, stride, dtype=np.int64)
    template_az_sub = template_az[idx_sub]
    template_el_sub = template_el[idx_sub]
    az_train_sub = az_train_raw[:, idx_sub]
    el_train_sub = el_train_raw[:, idx_sub]
    true_az_sub = [a[idx_sub] for a in true_az_val]
    true_el_sub = [a[idx_sub] for a in true_el_val]
    no_sub = [n[idx_sub] for n in no_val]
    mask_sub = [m[idx_sub] for m in mask_val]

    max_val_search = int(args.max_val_files_search) if args.max_val_files_search else len(x_val)
    max_val_search = max(1, min(max_val_search, len(x_val)))
    x_val_sub = x_val[:max_val_search, :]
    true_az_sub = true_az_sub[:max_val_search]
    true_el_sub = true_el_sub[:max_val_search]
    no_sub = no_sub[:max_val_search]
    mask_sub = mask_sub[:max_val_search]

    day_edges = np.asarray(parse_float_csv(str(args.day_edges)), dtype=np.float64)
    if len(day_edges) < 2:
        day_edges = np.array([0.0, float(args.days_horizon)], dtype=np.float64)
    if day_edges[0] > 0.0:
        day_edges = np.concatenate([np.array([0.0], dtype=np.float64), day_edges])
    if day_edges[-1] < float(args.days_horizon):
        day_edges = np.concatenate([day_edges, np.array([float(args.days_horizon)], dtype=np.float64)])
    day_edges = np.unique(day_edges)

    alpha_grid = parse_float_csv(str(args.alpha_grid))
    gamma_grid = parse_float_csv(str(args.gamma_grid))
    conf_exp_grid = parse_float_csv(str(args.conf_exp_grid))
    ridge_l2_grid = parse_float_csv(str(args.ridge_l2_grid))
    aux_weight_grid = parse_float_csv(str(args.aux_weight_grid))
    knn_k_grid = parse_int_csv(str(args.knn_k_grid))
    knn_tau_grid = parse_float_csv(str(args.knn_tau_grid))
    knn_weight_grid = parse_float_csv(str(args.knn_weight_grid))
    blend_grid = parse_float_csv(str(args.blend_grid))

    candidates: List[SearchResult] = []
    tested = 0

    def append_result(res: SearchResult, strategy: str, params: Dict[str, float]) -> None:
        nonlocal tested
        tested += 1
        res.strategy = str(strategy)
        res.params = {k: float(v) for k, v in params.items()}
        candidates.append(res)
        if tested % 20 == 0:
            log(
                f"[SEARCH] tested={tested} best_AZEL_RMSE={min(c.rmse_azel_corr for c in candidates):.6g}"
            )

    # 1) template baseline candidate
    pred_az_tpl = [template_az_sub.copy() for _ in range(len(x_val_sub))]
    pred_el_tpl = [template_el_sub.copy() for _ in range(len(x_val_sub))]
    conf_ones = [np.ones_like(template_az_sub) for _ in range(len(x_val_sub))]
    for q in conf_exp_grid:
        res = eval_candidate(
            true_az_list=true_az_sub,
            true_el_list=true_el_sub,
            pred_az_raw_list=pred_az_tpl,
            pred_el_raw_list=pred_el_tpl,
            conf_az_list=conf_ones,
            conf_el_list=conf_ones,
            no_list=no_sub,
            mask_list=mask_sub,
            conf_exp=float(q),
            alpha_grid=alpha_grid,
            day_edges=day_edges,
            gamma_grid=gamma_grid,
            min_bin_improve_pct=float(args.min_bin_improve_pct),
            alpha_objective_quantile=float(args.alpha_objective_quantile),
            min_file_improve_ratio=float(args.min_file_improve_ratio),
        )
        append_result(res, strategy="template", params={"conf_exp": float(q)})

    # 2) ridge candidates
    ridge_cache: Dict[Tuple[float, float], Dict[str, np.ndarray]] = {}
    best_ridge_preds = None
    best_ridge = None
    best_ridge_key = None
    best_ridge_score = float("inf")
    for l2 in ridge_l2_grid:
        for aw in aux_weight_grid:
            key = (float(l2), float(aw))
            ridge = fit_ridge(
                x_train=x_train,
                y_az_deg=az_train_sub,
                y_el=el_train_sub,
                is_aux=is_aux_train,
                aux_weight=float(aw),
                l2=float(l2),
            )
            ridge_cache[key] = ridge
            p_az_list: List[np.ndarray] = []
            p_el_list: List[np.ndarray] = []
            c_az_list: List[np.ndarray] = []
            c_el_list: List[np.ndarray] = []
            for xv in x_val_sub:
                paz, pel, caz, cel = predict_ridge(x_query=xv, ridge=ridge)
                p_az_list.append(paz)
                p_el_list.append(pel)
                c_az_list.append(caz)
                c_el_list.append(cel)
            for q in conf_exp_grid:
                res = eval_candidate(
                    true_az_list=true_az_sub,
                    true_el_list=true_el_sub,
                    pred_az_raw_list=p_az_list,
                    pred_el_raw_list=p_el_list,
                    conf_az_list=c_az_list,
                    conf_el_list=c_el_list,
                    no_list=no_sub,
                    mask_list=mask_sub,
                    conf_exp=float(q),
                    alpha_grid=alpha_grid,
                    day_edges=day_edges,
                    gamma_grid=gamma_grid,
                    min_bin_improve_pct=float(args.min_bin_improve_pct),
                    alpha_objective_quantile=float(args.alpha_objective_quantile),
                    min_file_improve_ratio=float(args.min_file_improve_ratio),
                )
                append_result(
                    res,
                    strategy="ridge",
                    params={"ridge_l2": float(l2), "aux_weight": float(aw), "conf_exp": float(q)},
                )
                if res.rmse_azel_corr < best_ridge_score:
                    best_ridge_score = res.rmse_azel_corr
                    best_ridge_preds = (p_az_list, p_el_list, c_az_list, c_el_list, float(q))
                    best_ridge = ridge
                    best_ridge_key = key

    # 3) knn candidates
    best_knn_preds = None
    best_knn_score = float("inf")
    best_knn_params = None
    for k in knn_k_grid:
        for tau in knn_tau_grid:
            for kw in knn_weight_grid:
                for aw in aux_weight_grid:
                    p_az_list = []
                    p_el_list = []
                    c_az_list = []
                    c_el_list = []
                    for xv in x_val_sub:
                        paz, pel, caz, cel = predict_knn(
                            x_query=xv,
                            x_train=x_train,
                            train_az=az_train_sub,
                            train_el=el_train_sub,
                            train_is_aux=is_aux_train,
                            template_az=template_az_sub,
                            template_el=template_el_sub,
                            k=int(k),
                            tau=float(tau),
                            knn_weight=float(kw),
                            aux_weight=float(aw),
                        )
                        p_az_list.append(paz)
                        p_el_list.append(pel)
                        c_az_list.append(caz)
                        c_el_list.append(cel)
                    for q in conf_exp_grid:
                        res = eval_candidate(
                            true_az_list=true_az_sub,
                            true_el_list=true_el_sub,
                            pred_az_raw_list=p_az_list,
                            pred_el_raw_list=p_el_list,
                            conf_az_list=c_az_list,
                            conf_el_list=c_el_list,
                            no_list=no_sub,
                            mask_list=mask_sub,
                            conf_exp=float(q),
                            alpha_grid=alpha_grid,
                            day_edges=day_edges,
                            gamma_grid=gamma_grid,
                            min_bin_improve_pct=float(args.min_bin_improve_pct),
                            alpha_objective_quantile=float(args.alpha_objective_quantile),
                            min_file_improve_ratio=float(args.min_file_improve_ratio),
                        )
                        append_result(
                            res,
                            strategy="knn",
                            params={
                                "knn_k": float(k),
                                "knn_tau": float(tau),
                                "knn_weight": float(kw),
                                "aux_weight": float(aw),
                                "conf_exp": float(q),
                            },
                        )
                        if res.rmse_azel_corr < best_knn_score:
                            best_knn_score = res.rmse_azel_corr
                            best_knn_preds = (p_az_list, p_el_list, c_az_list, c_el_list, float(q))
                            best_knn_params = (int(k), float(tau), float(kw), float(aw))

    # 4) blend candidates from best ridge + best knn
    if best_ridge_preds is not None and best_knn_preds is not None:
        pr_az, pr_el, cr_az, cr_el, _ = best_ridge_preds
        pk_az, pk_el, ck_az, ck_el, _ = best_knn_preds
        for wr in blend_grid:
            for wk in blend_grid:
                wrf = float(np.clip(wr, 0.0, 1.0))
                wkf = float(np.clip(wk, 0.0, 1.0))
                if wrf + wkf > 1.000001:
                    continue
                wtf = max(0.0, 1.0 - wrf - wkf)
                p_az_list = []
                p_el_list = []
                c_az_list = []
                c_el_list = []
                for i in range(len(x_val_sub)):
                    paz = wrap180(
                        np.rad2deg(
                            np.arctan2(
                                wrf * np.sin(np.deg2rad(pr_az[i]))
                                + wkf * np.sin(np.deg2rad(pk_az[i]))
                                + wtf * np.sin(np.deg2rad(template_az_sub)),
                                wrf * np.cos(np.deg2rad(pr_az[i]))
                                + wkf * np.cos(np.deg2rad(pk_az[i]))
                                + wtf * np.cos(np.deg2rad(template_az_sub)),
                            )
                        )
                    )
                    pel = wrf * pr_el[i] + wkf * pk_el[i] + wtf * template_el_sub
                    caz = np.clip(wrf * cr_az[i] + wkf * ck_az[i] + wtf, 0.0, 1.0)
                    cel = np.clip(wrf * cr_el[i] + wkf * ck_el[i] + wtf, 0.0, 1.0)
                    p_az_list.append(paz)
                    p_el_list.append(pel)
                    c_az_list.append(caz)
                    c_el_list.append(cel)
                for q in conf_exp_grid:
                    res = eval_candidate(
                        true_az_list=true_az_sub,
                        true_el_list=true_el_sub,
                        pred_az_raw_list=p_az_list,
                        pred_el_raw_list=p_el_list,
                        conf_az_list=c_az_list,
                        conf_el_list=c_el_list,
                        no_list=no_sub,
                        mask_list=mask_sub,
                        conf_exp=float(q),
                        alpha_grid=alpha_grid,
                        day_edges=day_edges,
                        gamma_grid=gamma_grid,
                        min_bin_improve_pct=float(args.min_bin_improve_pct),
                        alpha_objective_quantile=float(args.alpha_objective_quantile),
                        min_file_improve_ratio=float(args.min_file_improve_ratio),
                    )
                    p = {
                        "blend_ridge": float(wrf),
                        "blend_knn": float(wkf),
                        "knn_k": float(best_knn_params[0]),
                        "knn_tau": float(best_knn_params[1]),
                        "knn_weight": float(best_knn_params[2]),
                        "aux_weight": float(best_knn_params[3]),
                        "ridge_l2": float(best_ridge_key[0]),
                        "conf_exp": float(q),
                    }
                    append_result(res, strategy="blend", params=p)

    if len(candidates) == 0:
        raise RuntimeError("no candidate was evaluated")

    candidates_sorted = sorted(candidates, key=lambda x: x.rmse_azel_corr)
    best_coarse = candidates_sorted[0]
    log(
        f"[SEARCH] tested={tested} best strategy={best_coarse.strategy} "
        f"AZEL_RMSE {best_coarse.rmse_azel_base:.6g} -> {best_coarse.rmse_azel_corr:.6g}"
    )
    log(
        f"[SEARCH] best coarse AZ {best_coarse.rmse_az_base:.6g}->{best_coarse.rmse_az_corr:.6g} | "
        f"EL {best_coarse.rmse_el_base:.6g}->{best_coarse.rmse_el_corr:.6g}"
    )

    # Rebuild best strategy on full rows / full val
    # Prepare full train/val arrays
    az_train_full = az_train_raw
    el_train_full = el_train_raw
    template_az_full = template_az
    template_el_full = template_el
    true_az_full, true_el_full, no_full, mask_full = load_truth_error_for_target_val(target_val)
    x_val_full = x_val

    use_strategy = best_coarse.strategy
    use_params = dict(best_coarse.params)
    conf_exp_best = float(use_params.get("conf_exp", 0.0))

    ridge_full: Optional[Dict[str, np.ndarray]] = None
    if use_strategy in {"ridge", "blend"}:
        ridge_l2 = float(use_params.get("ridge_l2", 1.0))
        aux_w = float(use_params.get("aux_weight", 0.0))
        ridge_full = fit_ridge(
            x_train=x_train,
            y_az_deg=az_train_full,
            y_el=el_train_full,
            is_aux=is_aux_train,
            aux_weight=aux_w,
            l2=ridge_l2,
        )

    pred_az_raw_full: List[np.ndarray] = []
    pred_el_raw_full: List[np.ndarray] = []
    conf_az_full: List[np.ndarray] = []
    conf_el_full: List[np.ndarray] = []
    for xv in x_val_full:
        paz, pel, caz, cel = make_strategy_predictions(
            strategy=use_strategy,
            params=use_params,
            x_query=xv,
            template_az=template_az_full,
            template_el=template_el_full,
            x_train=x_train,
            train_az=az_train_full,
            train_el=el_train_full,
            train_is_aux=is_aux_train,
            ridge=ridge_full,
        )
        pred_az_raw_full.append(paz)
        pred_el_raw_full.append(pel)
        conf_az_full.append(caz)
        conf_el_full.append(cel)

    best_full = eval_candidate(
        true_az_list=true_az_full,
        true_el_list=true_el_full,
        pred_az_raw_list=pred_az_raw_full,
        pred_el_raw_list=pred_el_raw_full,
        conf_az_list=conf_az_full,
        conf_el_list=conf_el_full,
        no_list=no_full,
        mask_list=mask_full,
        conf_exp=conf_exp_best,
        alpha_grid=alpha_grid,
        day_edges=day_edges,
        gamma_grid=gamma_grid,
        min_bin_improve_pct=float(args.min_bin_improve_pct),
        alpha_objective_quantile=float(args.alpha_objective_quantile),
        min_file_improve_ratio=float(args.min_file_improve_ratio),
    )
    best_full.strategy = use_strategy
    best_full.params = dict(use_params)

    # strict no-harm guard
    if bool(args.strict_no_harm_azel):
        az_bad = best_full.rmse_az_corr > best_full.rmse_az_base
        el_bad = best_full.rmse_el_corr > best_full.rmse_el_base
        if az_bad:
            best_full.alpha_az = 0.0
            best_full.gamma_az = np.zeros_like(best_full.gamma_az)
        if el_bad:
            best_full.alpha_el = 0.0
            best_full.gamma_el = np.zeros_like(best_full.gamma_el)
        if az_bad or el_bad:
            best_full = eval_candidate(
                true_az_list=true_az_full,
                true_el_list=true_el_full,
                pred_az_raw_list=pred_az_raw_full,
                pred_el_raw_list=pred_el_raw_full,
                conf_az_list=conf_az_full,
                conf_el_list=conf_el_full,
                no_list=no_full,
                mask_list=mask_full,
                conf_exp=conf_exp_best,
                alpha_grid=[best_full.alpha_az, best_full.alpha_az],
                day_edges=day_edges,
                gamma_grid=[0.0],  # all-zero fallback if bad
                min_bin_improve_pct=1e9,
                alpha_objective_quantile=float(args.alpha_objective_quantile),
                min_file_improve_ratio=1.0,
            )
            # restore intended zero/no-harm values
            if az_bad:
                best_full.alpha_az = 0.0
                best_full.gamma_az = np.zeros((len(day_edges) - 1,), dtype=np.float64)
            if el_bad:
                best_full.alpha_el = 0.0
                best_full.gamma_el = np.zeros((len(day_edges) - 1,), dtype=np.float64)
            best_full.strategy = use_strategy
            best_full.params = dict(use_params)
            log("[GUARD] strict no-harm applied for AZ/EL on validation.")

    # Conservative global scale: choose the smallest scale within slack of best val RMSE.
    pred_az_conf_full = [
        apply_confidence_shrink(pred=p, conf=c, exp=conf_exp_best, is_angle=True)
        for p, c in zip(pred_az_raw_full, conf_az_full)
    ]
    pred_el_conf_full = [
        apply_confidence_shrink(pred=p, conf=c, exp=conf_exp_best, is_angle=False)
        for p, c in zip(pred_el_raw_full, conf_el_full)
    ]
    scale_grid = sorted(set(float(x) for x in parse_float_csv(str(args.global_scale_grid))))
    if len(scale_grid) == 0:
        scale_grid = [1.0]
    if 1.0 not in scale_grid:
        scale_grid.append(1.0)
    scale_grid = sorted(set(scale_grid))

    scale_rmse: List[Tuple[float, float, float, float]] = []
    for s in scale_grid:
        az_rmse_s, el_rmse_s, azel_rmse_s = evaluate_fixed_calibration(
            true_az_list=true_az_full,
            true_el_list=true_el_full,
            pred_az_list=pred_az_conf_full,
            pred_el_list=pred_el_conf_full,
            no_list=no_full,
            mask_list=mask_full,
            alpha_az=float(best_full.alpha_az) * float(s),
            alpha_el=float(best_full.alpha_el) * float(s),
            gamma_az=best_full.gamma_az,
            gamma_el=best_full.gamma_el,
            day_edges=day_edges,
        )
        scale_rmse.append((float(s), float(az_rmse_s), float(el_rmse_s), float(azel_rmse_s)))

    min_rmse = min(x[3] for x in scale_rmse)
    slack = max(0.0, float(args.global_scale_slack_pct)) / 100.0
    allow = min_rmse * (1.0 + slack)
    chosen_scale = 1.0
    chosen = None
    for rec in sorted(scale_rmse, key=lambda x: x[0]):
        if rec[3] <= allow:
            chosen = rec
            break
    if chosen is None:
        chosen = min(scale_rmse, key=lambda x: x[3])
    chosen_scale = float(chosen[0])
    best_full.alpha_az *= chosen_scale
    best_full.alpha_el *= chosen_scale
    best_full.rmse_az_corr = float(chosen[1])
    best_full.rmse_el_corr = float(chosen[2])
    best_full.rmse_azel_corr = float(chosen[3])
    log(
        f"[VAL] global scale selected={chosen_scale:.6g} "
        f"(min_AZEL_RMSE={min_rmse:.6g}, slack={float(args.global_scale_slack_pct):.3g}%)"
    )

    log(
        f"[VAL] AZEL RMSE {best_full.rmse_azel_base:.6g} -> {best_full.rmse_azel_corr:.6g} "
        f"({(0.0 if best_full.rmse_azel_base<=0 else 100.0*(best_full.rmse_azel_base-best_full.rmse_azel_corr)/best_full.rmse_azel_base):.3f}%)"
    )
    log(f"[VAL] AZ RMSE {best_full.rmse_az_base:.6g} -> {best_full.rmse_az_corr:.6g}")
    log(f"[VAL] EL RMSE {best_full.rmse_el_base:.6g} -> {best_full.rmse_el_corr:.6g}")
    log(
        "[VAL] alpha/gamma: "
        f"alpha_AZ={best_full.alpha_az:.6g}, alpha_EL={best_full.alpha_el:.6g}, "
        f"gamma_AZ={','.join(f'{x:.3g}' for x in best_full.gamma_az.tolist())}, "
        f"gamma_EL={','.join(f'{x:.3g}' for x in best_full.gamma_el.tolist())}"
    )

    out_model = Path(args.out_model)
    ensure_dir(out_model)
    # Save full assets needed for prediction.
    arrays: Dict[str, np.ndarray] = {
        "feature_mean": x_mean.astype(np.float64),
        "feature_std": x_std.astype(np.float64),
        "template_az": template_az_full.astype(np.float32),
        "template_el": template_el_full.astype(np.float32),
        "train_feats": x_train.astype(np.float32),
        "train_err_az": az_train_full.astype(np.float32),
        "train_err_el": el_train_full.astype(np.float32),
        "train_is_aux": is_aux_train.astype(np.int8),
        "ridge_w_sin": np.zeros((x_train.shape[1], rows), dtype=np.float32),
        "ridge_w_cos": np.zeros((x_train.shape[1], rows), dtype=np.float32),
        "ridge_w_el": np.zeros((x_train.shape[1], rows), dtype=np.float32),
        "ridge_conf_el": np.zeros((rows,), dtype=np.float32),
    }
    if ridge_full is not None:
        arrays["ridge_w_sin"] = ridge_full["w_sin"].astype(np.float32)
        arrays["ridge_w_cos"] = ridge_full["w_cos"].astype(np.float32)
        arrays["ridge_w_el"] = ridge_full["w_el"].astype(np.float32)
        arrays["ridge_conf_el"] = ridge_full["conf_el"].astype(np.float32)

    meta = {
        "created_at_jst": now_jst_str(),
        "model_type": "azel_professional_search_v1",
        "target_tle_dir": str(target_tle),
        "target_err_dir": str(target_err),
        "days_horizon": int(args.days_horizon),
        "step_minutes": int(args.step_minutes),
        "sample_every": int(args.sample_every),
        "rows": int(rows),
        "strategy": str(best_full.strategy),
        "strategy_params": {k: float(v) for k, v in best_full.params.items()},
        "conf_exp": float(conf_exp_best),
        "alpha_az": float(best_full.alpha_az),
        "alpha_el": float(best_full.alpha_el),
        "global_scale_selected": float(chosen_scale),
        "day_edges": [float(x) for x in day_edges.tolist()],
        "gamma_az": [float(x) for x in best_full.gamma_az.tolist()],
        "gamma_el": [float(x) for x in best_full.gamma_el.tolist()],
        "cap_deg": float(args.cap_deg),
        "strict_no_harm_azel": bool(args.strict_no_harm_azel),
        "val_rmse": {
            "AZ_base": float(best_full.rmse_az_base),
            "AZ_corr": float(best_full.rmse_az_corr),
            "EL_base": float(best_full.rmse_el_base),
            "EL_corr": float(best_full.rmse_el_corr),
            "AZEL_base": float(best_full.rmse_azel_base),
            "AZEL_corr": float(best_full.rmse_azel_corr),
        },
        "search": {
            "tested": int(tested),
            "search_stride": int(stride),
            "max_val_files_search": int(max_val_search),
            "ridge_l2_grid": [float(x) for x in ridge_l2_grid],
            "aux_weight_grid": [float(x) for x in aux_weight_grid],
            "knn_k_grid": [int(x) for x in knn_k_grid],
            "knn_tau_grid": [float(x) for x in knn_tau_grid],
            "knn_weight_grid": [float(x) for x in knn_weight_grid],
            "blend_grid": [float(x) for x in blend_grid],
            "conf_exp_grid": [float(x) for x in conf_exp_grid],
            "alpha_grid": [float(x) for x in alpha_grid],
            "gamma_grid": [float(x) for x in gamma_grid],
            "alpha_objective_quantile": float(args.alpha_objective_quantile),
            "min_file_improve_ratio": float(args.min_file_improve_ratio),
            "global_scale_grid": [float(x) for x in scale_grid],
            "global_scale_slack_pct": float(args.global_scale_slack_pct),
        },
        "train_files_target": int(len(target_train)),
        "val_files_target": int(len(target_val)),
        "train_files_aux": int(len(aux_train)),
        "train_stems": train_stems,
    }
    meta_path, bank_path = save_model(
        out_model=out_model,
        overwrite=bool(args.overwrite),
        meta=meta,
        arrays=arrays,
    )

    topn = min(10, len(candidates_sorted))
    top_rows = []
    for i in range(topn):
        c = candidates_sorted[i]
        top_rows.append(
            {
                "rank": i + 1,
                "strategy": c.strategy,
                "params": json.dumps(c.params, ensure_ascii=False),
                "AZ_base_RMSE": c.rmse_az_base,
                "AZ_corr_RMSE": c.rmse_az_corr,
                "EL_base_RMSE": c.rmse_el_base,
                "EL_corr_RMSE": c.rmse_el_corr,
                "AZEL_base_RMSE": c.rmse_azel_base,
                "AZEL_corr_RMSE": c.rmse_azel_corr,
            }
        )
    top_df = pd.DataFrame(top_rows)
    top_path = out_model / "search_top10.csv"
    top_df.to_csv(top_path, index=False)

    log(f"[SAVED] model meta: {meta_path}")
    log(f"[SAVED] model bank: {bank_path}")
    log(f"[SAVED] search top: {top_path}")
    return 0


def predict_cmd(args: argparse.Namespace) -> int:
    model_dir = Path(args.model)
    meta, arrays = load_model(model_dir)
    cap_deg = float(meta.get("cap_deg", 0.0))
    if args.cap_deg is not None:
        cap_deg = float(args.cap_deg)

    base_df = load_orbit_csv(Path(args.baseline_csv), require_targets=True)
    base_df = trim_horizon_and_stride(
        base_df,
        days_horizon=int(args.days),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
    )
    n = len(base_df)
    if n <= 0:
        raise RuntimeError(f"no rows in baseline after trim: {args.baseline_csv}")

    pred_az_raw, pred_el_raw, conf_az, conf_el, pred_az, pred_el = infer_pred_error_from_tle(
        tle_file=Path(args.tle_file),
        n_rows=n,
        meta=meta,
        arrays=arrays,
        cap_deg=cap_deg,
        global_scale_override=args.global_scale_override,
    )
    alpha_az = float(meta.get("alpha_az", 0.0))
    alpha_el = float(meta.get("alpha_el", 0.0))
    global_scale = float(meta.get("global_scale_selected", 1.0))
    if args.global_scale_override is not None:
        global_scale = float(args.global_scale_override)

    corrected_df = merge_corrected_with_baseline(base_df, pred_err_az=pred_az, pred_err_el=pred_el)

    out_corr = Path(args.out_corrected_csv)
    out_pred = Path(args.out_pred_error_csv)
    if out_corr.exists() and not args.overwrite:
        raise FileExistsError(f"exists: {out_corr} (use --overwrite)")
    if out_pred.exists() and not args.overwrite:
        raise FileExistsError(f"exists: {out_pred} (use --overwrite)")
    ensure_dir(out_corr.parent)
    ensure_dir(out_pred.parent)
    corrected_df.to_csv(out_corr, index=False)

    pred_df = base_df[["No", "date", "UNIX"]].copy()
    pred_df["pred_error_AZ_raw"] = pred_az_raw
    pred_df["pred_error_EL_raw"] = pred_el_raw
    pred_df["conf_AZ"] = conf_az
    pred_df["conf_EL"] = conf_el
    pred_df["pred_error_AZ"] = pred_az
    pred_df["pred_error_EL"] = pred_el
    pred_df["alpha_AZ"] = float(alpha_az)
    pred_df["alpha_EL"] = float(alpha_el)
    pred_df["global_scale"] = float(global_scale)
    pred_df.to_csv(out_pred, index=False)

    log(f"[SAVED] corrected: {out_corr}")
    log(f"[SAVED] predicted error: {out_pred}")

    if args.plot_dir:
        plot_dir = Path(args.plot_dir)
    else:
        plot_dir = out_corr.parent / "plots"
    if not args.no_plot:
        plot_baseline_vs_corrected(
            stem=out_corr.stem,
            baseline_df=base_df,
            corrected_df=corrected_df,
            out_dir=plot_dir,
            sample_every=int(args.plot_sample_every),
        )
        log(f"[SAVED] baseline-vs-corrected plots: {plot_dir}")

    if args.truth_csv:
        truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True)
        metrics_df, merged_df = compute_metrics(
            truth_df=truth_df,
            baseline_df=base_df,
            corrected_df=corrected_df,
        )
        mpath = Path(args.out_metrics_csv) if args.out_metrics_csv else (out_corr.parent / f"{out_corr.stem}_metrics.csv")
        if mpath.exists() and not args.overwrite:
            raise FileExistsError(f"exists: {mpath} (use --overwrite)")
        ensure_dir(mpath.parent)
        metrics_df.to_csv(mpath, index=False)
        b = metrics_df[metrics_df["kind"] == "baseline"].iloc[0]
        c = metrics_df[metrics_df["kind"] == "corrected"].iloc[0]
        log("[METRIC] MSE/RMSE (baseline -> corrected)")
        for col in TARGET_COLS:
            log(
                f"  {col}: MSE {float(b[f'{col}_MSE']):.6g} -> {float(c[f'{col}_MSE']):.6g} | "
                f"RMSE {float(b[f'{col}_RMSE']):.6g} -> {float(c[f'{col}_RMSE']):.6g}"
            )
        log(
            f"  GLOBAL: MSE {float(b['global_MSE']):.6g} -> {float(c['global_MSE']):.6g} | "
            f"RMSE {float(b['global_RMSE']):.6g} -> {float(c['global_RMSE']):.6g}"
        )
        log(f"[SAVED] metrics: {mpath}")
        if not args.no_plot:
            plot_truth_baseline_corrected(
                stem=out_corr.stem,
                merged_df=merged_df,
                out_dir=plot_dir,
                sample_every=int(args.plot_sample_every),
            )
            plot_metric_summary(stem=out_corr.stem, metrics_df=metrics_df, out_dir=plot_dir)
            log(f"[SAVED] truth comparison plots: {plot_dir}")

    return 0


def predict_multi_cmd(args: argparse.Namespace) -> int:
    model_dir = Path(args.model)
    meta, arrays = load_model(model_dir)

    tle_dir = Path(args.tle_dir)
    if not tle_dir.exists():
        raise FileNotFoundError(f"tle-dir not found: {tle_dir}")
    tles = list_tles_with_datetime(tle_dir)
    if len(tles) == 0:
        raise RuntimeError(f"no parseable TLE files in {tle_dir}")

    anchor_dt, anchor_tle = tles[-1]
    lookback_hours = float(max(0.0, float(args.lookback_days) * 24.0))
    max_tles = int(max(1, int(args.max_tles)))
    selected: List[Tuple[dt.datetime, Path, float]] = []
    for t, p in reversed(tles):
        age_h = float((anchor_dt - t).total_seconds() / 3600.0)
        if age_h < -1e-9:
            continue
        if age_h <= lookback_hours + 1e-9:
            selected.append((t, p, age_h))
        if len(selected) >= max_tles:
            break
    if len(selected) == 0:
        selected = [(anchor_dt, anchor_tle, 0.0)]
    selected = sorted(selected, key=lambda x: x[0], reverse=False)

    baseline_csv_dir = Path(args.baseline_csv_dir)
    if not baseline_csv_dir.exists():
        raise FileNotFoundError(f"baseline-csv-dir not found: {baseline_csv_dir}")
    baseline_csv = resolve_baseline_csv_for_anchor(
        baseline_csv_dir=baseline_csv_dir,
        anchor_stem=anchor_tle.stem,
        anchor_dt=anchor_dt,
    )

    base_df = load_orbit_csv(baseline_csv, require_targets=True)
    base_df = trim_horizon_and_stride(
        base_df,
        days_horizon=int(args.days),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
    )
    n = len(base_df)
    if n <= 0:
        raise RuntimeError(f"no rows in baseline after trim: {baseline_csv}")

    cap_deg = float(meta.get("cap_deg", 0.0))
    if args.cap_deg is not None:
        cap_deg = float(args.cap_deg)

    half_life_h = float(args.half_life_hours)
    min_conf = float(np.clip(args.min_conf, 0.0, 1.0))
    disagree_az_sigma = float(max(0.0, args.disagreement_sigma_az))
    disagree_el_sigma = float(max(0.0, args.disagreement_sigma_el))
    fusion_scale = float(args.fusion_scale)

    members: List[Dict] = []
    for t, p, age_h in selected:
        _paz_raw, _pel_raw, conf_az, conf_el, pred_az, pred_el = infer_pred_error_from_tle(
            tle_file=p,
            n_rows=n,
            meta=meta,
            arrays=arrays,
            cap_deg=cap_deg,
            global_scale_override=args.global_scale_override,
        )
        if half_life_h > 0:
            recency = float(np.exp(-np.log(2.0) * age_h / half_life_h))
        else:
            recency = 1.0
        members.append(
            {
                "stem": p.stem,
                "path": str(p),
                "timestamp": t.isoformat(sep=" "),
                "age_hours": float(age_h),
                "recency_weight": float(recency),
                "pred_az": np.asarray(pred_az, dtype=np.float64),
                "pred_el": np.asarray(pred_el, dtype=np.float64),
                "conf_az": np.asarray(conf_az, dtype=np.float64),
                "conf_el": np.asarray(conf_el, dtype=np.float64),
            }
        )

    mnum = len(members)
    fused_az = np.zeros((n,), dtype=np.float64)
    fused_el = np.zeros((n,), dtype=np.float64)
    gate_az = np.ones((n,), dtype=np.float64)
    gate_el = np.ones((n,), dtype=np.float64)
    std_az = np.zeros((n,), dtype=np.float64)
    std_el = np.zeros((n,), dtype=np.float64)

    for i in range(n):
        az_vals = np.array([m["pred_az"][i] for m in members], dtype=np.float64)
        el_vals = np.array([m["pred_el"][i] for m in members], dtype=np.float64)
        waz = np.array(
            [m["recency_weight"] * max(min_conf, float(np.clip(m["conf_az"][i], 0.0, 1.0))) for m in members],
            dtype=np.float64,
        )
        wel = np.array(
            [m["recency_weight"] * max(min_conf, float(np.clip(m["conf_el"][i], 0.0, 1.0))) for m in members],
            dtype=np.float64,
        )

        az_m, az_s = circular_weighted_mean_and_std_deg(az_vals, waz)
        el_m, el_s = weighted_mean_std(el_vals, wel)
        std_az[i] = az_s
        std_el[i] = el_s

        if disagree_az_sigma > 0:
            gz = float(np.exp(-((az_s / disagree_az_sigma) ** 2)))
        else:
            gz = 1.0
        if disagree_el_sigma > 0:
            ge = float(np.exp(-((el_s / disagree_el_sigma) ** 2)))
        else:
            ge = 1.0
        gate_az[i] = float(np.clip(gz, 0.0, 1.0))
        gate_el[i] = float(np.clip(ge, 0.0, 1.0))

        fused_az[i] = float(az_m) * gate_az[i]
        fused_el[i] = float(el_m) * gate_el[i]

    fused_az = wrap180(fusion_scale * fused_az)
    fused_el = fusion_scale * fused_el
    if cap_deg > 0:
        fused_az = np.clip(fused_az, -float(cap_deg), float(cap_deg))
        fused_el = np.clip(fused_el, -float(cap_deg), float(cap_deg))

    corrected_df = merge_corrected_with_baseline(base_df, pred_err_az=fused_az, pred_err_el=fused_el)

    out_corr = Path(args.out_corrected_csv)
    out_pred = Path(args.out_pred_error_csv)
    if out_corr.exists() and not args.overwrite:
        raise FileExistsError(f"exists: {out_corr} (use --overwrite)")
    if out_pred.exists() and not args.overwrite:
        raise FileExistsError(f"exists: {out_pred} (use --overwrite)")
    ensure_dir(out_corr.parent)
    ensure_dir(out_pred.parent)
    corrected_df.to_csv(out_corr, index=False)

    pred_df = base_df[["No", "date", "UNIX"]].copy()
    pred_df["pred_error_AZ"] = fused_az
    pred_df["pred_error_EL"] = fused_el
    pred_df["gate_AZ"] = gate_az
    pred_df["gate_EL"] = gate_el
    pred_df["std_AZ_members"] = std_az
    pred_df["std_EL_members"] = std_el
    pred_df["members_used"] = int(mnum)
    pred_df.to_csv(out_pred, index=False)

    members_path = out_pred.parent / f"{out_pred.stem}_members.json"
    mpayload = {
        "anchor_tle": {
            "stem": anchor_tle.stem,
            "path": str(anchor_tle),
            "timestamp": anchor_dt.isoformat(sep=" "),
            "baseline_csv": str(baseline_csv),
        },
        "selected_count": int(mnum),
        "lookback_days": float(args.lookback_days),
        "max_tles": int(max_tles),
        "half_life_hours": float(half_life_h),
        "min_conf": float(min_conf),
        "disagreement_sigma_az": float(disagree_az_sigma),
        "disagreement_sigma_el": float(disagree_el_sigma),
        "fusion_scale": float(fusion_scale),
        "global_scale_override": (None if args.global_scale_override is None else float(args.global_scale_override)),
        "members": [
            {
                "stem": m["stem"],
                "path": m["path"],
                "timestamp": m["timestamp"],
                "age_hours": float(m["age_hours"]),
                "recency_weight": float(m["recency_weight"]),
            }
            for m in members
        ],
    }
    members_path.write_text(json.dumps(mpayload, ensure_ascii=False, indent=2), encoding="utf-8")

    log(f"[INFO] anchor TLE: {anchor_tle.stem}")
    log("[INFO] selected members: " + ", ".join(m["stem"] for m in members))
    log(f"[SAVED] corrected: {out_corr}")
    log(f"[SAVED] predicted error: {out_pred}")
    log(f"[SAVED] member summary: {members_path}")

    if args.plot_dir:
        plot_dir = Path(args.plot_dir)
    else:
        plot_dir = out_corr.parent / "plots"
    if not args.no_plot:
        plot_baseline_vs_corrected(
            stem=out_corr.stem,
            baseline_df=base_df,
            corrected_df=corrected_df,
            out_dir=plot_dir,
            sample_every=int(args.plot_sample_every),
        )
        log(f"[SAVED] baseline-vs-corrected plots: {plot_dir}")

    if args.truth_csv:
        truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True)
        metrics_df, merged_df = compute_metrics(
            truth_df=truth_df,
            baseline_df=base_df,
            corrected_df=corrected_df,
        )
        mpath = Path(args.out_metrics_csv) if args.out_metrics_csv else (out_corr.parent / f"{out_corr.stem}_metrics.csv")
        if mpath.exists() and not args.overwrite:
            raise FileExistsError(f"exists: {mpath} (use --overwrite)")
        ensure_dir(mpath.parent)
        metrics_df.to_csv(mpath, index=False)
        b = metrics_df[metrics_df["kind"] == "baseline"].iloc[0]
        c = metrics_df[metrics_df["kind"] == "corrected"].iloc[0]
        log("[METRIC] MSE/RMSE (baseline -> corrected)")
        for col in TARGET_COLS:
            log(
                f"  {col}: MSE {float(b[f'{col}_MSE']):.6g} -> {float(c[f'{col}_MSE']):.6g} | "
                f"RMSE {float(b[f'{col}_RMSE']):.6g} -> {float(c[f'{col}_RMSE']):.6g}"
            )
        log(
            f"  GLOBAL: MSE {float(b['global_MSE']):.6g} -> {float(c['global_MSE']):.6g} | "
            f"RMSE {float(b['global_RMSE']):.6g} -> {float(c['global_RMSE']):.6g}"
        )
        log(f"[SAVED] metrics: {mpath}")
        if not args.no_plot:
            plot_truth_baseline_corrected(
                stem=out_corr.stem,
                merged_df=merged_df,
                out_dir=plot_dir,
                sample_every=int(args.plot_sample_every),
            )
            plot_metric_summary(stem=out_corr.stem, metrics_df=metrics_df, out_dir=plot_dir)
            log(f"[SAVED] truth comparison plots: {plot_dir}")

    return 0


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="orbit_azel_professional_search.py",
        description="AZ/EL-focused non-TF model search (template/ridge/knn/blend) with no-harm guard",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train", help="Search best strategy and train model")
    t.add_argument("--tle-dir", default="23467_2023")
    t.add_argument("--err-dir", default="23467_2023_error")
    t.add_argument("--aux-dataset", action="append", default=None,
                   help="Optional aux dataset spec: name:tle_dir:err_dir (repeatable)")
    t.add_argument("--out-model", default="orbit_azel_professional_model")
    t.add_argument("--days-horizon", type=int, default=30)
    t.add_argument("--step-minutes", type=int, default=1)
    t.add_argument("--sample-every", type=int, default=1)
    t.add_argument("--val-split", type=float, default=0.2)
    t.add_argument("--split-mode", choices=["time", "hash"], default="time")
    t.add_argument("--seed", type=int, default=42)
    t.add_argument("--max-target-files", type=int, default=None)
    t.add_argument("--max-aux-files", type=int, default=None)
    t.add_argument("--max-val-files-search", type=int, default=30)
    t.add_argument("--search-stride", type=int, default=10,
                   help="Temporal stride for coarse search (final calibration uses full stride)")

    t.add_argument("--ridge-l2-grid", type=str, default="0.001,0.01,0.1,1,10")
    t.add_argument("--aux-weight-grid", type=str, default="0,0.1,0.3,0.5,1.0")
    t.add_argument("--knn-k-grid", type=str, default="2,3,5,8,13")
    t.add_argument("--knn-tau-grid", type=str, default="0.2,0.5,1,2,5")
    t.add_argument("--knn-weight-grid", type=str, default="0.2,0.4,0.6,0.8,1.0")
    t.add_argument("--blend-grid", type=str, default="0,0.25,0.5,0.75,1.0")
    t.add_argument("--conf-exp-grid", type=str, default="0,0.5,1.0,2.0")
    t.add_argument("--alpha-grid", type=str, default="0,0.1,0.2,0.3,0.4,0.5,0.7,1.0,1.2")
    t.add_argument("--day-edges", type=str, default="0,1,3,7,14,30")
    t.add_argument("--gamma-grid", type=str, default="0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1")
    t.add_argument("--min-bin-improve-pct", type=float, default=0.2)
    t.add_argument("--alpha-objective-quantile", type=float, default=0.8,
                   help="Alpha calibration objective quantile across files (0<q<1). <=0 or >=1 uses mean.")
    t.add_argument("--min-file-improve-ratio", type=float, default=0.6,
                   help="Per-bin minimum improved-file ratio to keep gamma > 0")
    t.add_argument("--global-scale-grid", type=str, default="0,0.1,0.2,0.3,0.5,0.7,1.0",
                   help="Conservative global scale grid applied after alpha/gamma")
    t.add_argument("--global-scale-slack-pct", type=float, default=1.0,
                   help="Pick smallest scale within this percent of best val AZEL RMSE")
    t.add_argument("--cap-deg", type=float, default=0.05,
                   help="Optional absolute cap (deg) applied to predicted AZ/EL error at inference")
    t.add_argument("--strict-no-harm-azel", action=argparse.BooleanOptionalAction, default=True)
    t.add_argument("--overwrite", action="store_true")

    pr = sub.add_parser("predict", help="Predict one TLE and output corrected csv")
    pr.add_argument("--model", required=True)
    pr.add_argument("--tle-file", required=True)
    pr.add_argument("--baseline-csv", required=True)
    pr.add_argument("--out-corrected-csv", required=True)
    pr.add_argument("--out-pred-error-csv", required=True)
    pr.add_argument("--truth-csv", default=None)
    pr.add_argument("--out-metrics-csv", default=None)
    pr.add_argument("--plot-dir", default=None)
    pr.add_argument("--plot-sample-every", type=int, default=5)
    pr.add_argument("--no-plot", action="store_true")
    pr.add_argument("--days", type=int, default=30)
    pr.add_argument("--step-minutes", type=int, default=1)
    pr.add_argument("--sample-every", type=int, default=1)
    pr.add_argument("--cap-deg", type=float, default=None)
    pr.add_argument("--global-scale-override", type=float, default=None,
                    help="Override global scale selected in model")
    pr.add_argument("--overwrite", action="store_true")

    pm = sub.add_parser("predict-multi", help="Predict using multiple recent TLEs in a directory")
    pm.add_argument("--model", required=True)
    pm.add_argument("--tle-dir", required=True,
                    help="Directory containing multiple TLE txt files for inference")
    pm.add_argument("--baseline-csv-dir", required=True,
                    help="Directory containing baseline CSV files (same stem as TLE)")
    pm.add_argument("--out-corrected-csv", required=True)
    pm.add_argument("--out-pred-error-csv", required=True)
    pm.add_argument("--truth-csv", default=None)
    pm.add_argument("--out-metrics-csv", default=None)
    pm.add_argument("--plot-dir", default=None)
    pm.add_argument("--plot-sample-every", type=int, default=5)
    pm.add_argument("--no-plot", action="store_true")
    pm.add_argument("--days", type=int, default=30)
    pm.add_argument("--step-minutes", type=int, default=1)
    pm.add_argument("--sample-every", type=int, default=1)
    pm.add_argument("--lookback-days", type=float, default=3.0,
                    help="Use TLEs within this lookback window from latest TLE datetime")
    pm.add_argument("--max-tles", type=int, default=6,
                    help="Maximum number of recent TLEs to fuse")
    pm.add_argument("--half-life-hours", type=float, default=24.0,
                    help="Recency weight half-life in hours (<=0 disables recency decay)")
    pm.add_argument("--min-conf", type=float, default=0.05,
                    help="Minimum confidence floor per member")
    pm.add_argument("--disagreement-sigma-az", type=float, default=0.25,
                    help="Disagreement sigma [deg] for AZ uncertainty gate (<=0 disables)")
    pm.add_argument("--disagreement-sigma-el", type=float, default=0.15,
                    help="Disagreement sigma [deg] for EL uncertainty gate (<=0 disables)")
    pm.add_argument("--fusion-scale", type=float, default=0.5,
                    help="Additional scale after member fusion (conservative default)")
    pm.add_argument("--cap-deg", type=float, default=None)
    pm.add_argument("--global-scale-override", type=float, default=None,
                    help="Override global scale selected in model")
    pm.add_argument("--overwrite", action="store_true")

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    os.environ.setdefault("PYTHONHASHSEED", "0")
    args = make_parser().parse_args(argv)
    if args.cmd == "train":
        return train_cmd(args)
    if args.cmd == "predict":
        return predict_cmd(args)
    if args.cmd == "predict-multi":
        return predict_multi_cmd(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
