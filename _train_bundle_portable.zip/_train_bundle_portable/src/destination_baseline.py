#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
目的地推論ベースライン（統計/検索ベース、学習なし）。

長期予測で「最終的にどこへ行くか」を推論するための、モデル非依存の統計ベースライン。
1ファイルに3サブコマンドを集約する:

  build    : 学習航跡（trajectories_full + trajectories_2017 のみ）から
             目的地語彙(zone)・MMSI索引・通過グリッド索引を構築する（重い/バックグラウンド推奨）。
  predict  : 1航跡を先頭から読み、--every 点ごとの各時点で目的地Top-kを推論して表に出す
             （観測が増えるたびに推論が更新される様子をそのまま表示する運用インターフェース）。
  evaluate : holdout2017 を進捗20/50/80%で切って推論し、Top-1/Top-3的中率と距離誤差を
             「既知船/初見船」で層別評価する。

=== 設計判断（NEXT_SESSION_PROMPT 優先1 の正式仕様に準拠） ===
- 終点抽出: CSVの行は unix_time 昇順に並んでいる（1000ファイル検証で100%一致）ため、
  末尾のデータ行を終点とする「末尾行読み」を採用（全行ソートを回避して高速）。
- 目的地語彙(zone): 終点を 0.02°セル(≈2km)に集約 → 終点数>=10のコアセルのみ8近傍連結
  （疎セルの橋渡しで海岸線全体が1zoneになるパーコレーションを防止）→ 隣接成分が一意な
  疎セルを付与（カバレッジ回復）→ bbox対角>30kmの成分は重み付きk-meansで約20km粒度に分割
  → 終点数>=閾値(既定30)を「目的地帯(zone)」とする。DBSCAN不使用（グリッド連結で十分・高速）。
- MMSI索引: mmsi -> {zone_id: 回数}（zoneに入った終点のみ）。
- 通過グリッド索引: 各航跡を5点間引きで走査し (0.05°セル, 方位8ビン) -> {目的地zone_id: 回数}。
  目的地が zone 無しの航跡はスキップ。
- 推論混合: P = 0.7*P_mmsi + 0.3*P_grid（MMSIが索引に無ければ P_grid のみ）。
  現在地に最も近い zone へ引っ張る自明解を避けるため、距離重み付けはしない（純粋に履歴統計）。

リーク規則: build の入力は trajectories_full / trajectories_2017 のみ。holdout2017 / val500 は
語彙・索引に絶対に混ぜない。MMSI_0_* は無効MMSIなので索引から除外する。
"""

from __future__ import annotations

import argparse
import glob
import math
import os
import pickle
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# 定数（グリッド解像度・閾値・混合重み）
# ---------------------------------------------------------------------------
KM_PER_DEG_LAT = 110.574
KM_PER_DEG_LON_AT_EQUATOR = 111.320

ZONE_CELL_DEG = 0.02          # 終点集約グリッド（≈2km）
ZONE_MIN_COUNT = 30           # 連結成分をzoneとみなす最小終点数
ZONE_CORE_MIN = 10            # 連結対象コアセルの最小終点数（疎セルの橋渡し=パーコレーション防止）
ZONE_MAX_DIAG_KM = 30.0       # 連結成分のbbox対角がこれを超えたらk-meansで分割
ZONE_SPLIT_TARGET_KM = 20.0   # 分割時の k = ceil(対角km / この値)
GRID_CELL_DEG = 0.05          # 通過グリッド索引のセル（緯度経度セル）
N_BEARING_BINS = 8            # 方位ビン数
TRAJ_STRIDE = 5               # 通過グリッド走査の間引き（5点ごと）
W_MMSI = 0.7                  # 混合: MMSI履歴の重み
W_GRID = 0.3                  # 混合: 通過グリッドの重み
GRID_SMOOTH_CELLS = 3         # predict時に直近何セル分の通過索引を平均するか


def km_per_deg_lon(lat: float) -> float:
    return max(KM_PER_DEG_LON_AT_EQUATOR * math.cos(math.radians(float(lat))), 1e-6)


def haversine_km(lon1, lat1, lon2, lat2) -> float:
    R = 6371.0088
    lon1, lat1, lon2, lat2 = map(math.radians, (lon1, lat1, lon2, lat2))
    dlon, dlat = lon2 - lon1, lat2 - lat1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 2.0 * R * math.asin(math.sqrt(min(1.0, a)))


def mmsi_from_name(name: str):
    """ファイル名 MMSI_<番号>_traj_*.csv から MMSI 文字列を得る。取れなければ None。"""
    base = os.path.basename(name)
    if not base.startswith("MMSI_"):
        return None
    rest = base[len("MMSI_"):]
    idx = rest.find("_")
    if idx <= 0:
        return None
    return rest[:idx]


def bearing_bin(dlon: float, dlat_km_east: float, dlat: float) -> int:
    """東(km)・北(km)成分の移動から方位を8ビンに離散化する。0=北, 時計回り。移動0なら-1。"""
    # 引数は (東km, 北km) を想定。ここでは呼び出し側で km 換算済みを渡す。
    east = dlon
    north = dlat
    if abs(east) < 1e-9 and abs(north) < 1e-9:
        return -1
    ang = math.degrees(math.atan2(east, north))  # 北=0, 東=90
    if ang < 0:
        ang += 360.0
    return int((ang + 22.5) % 360.0 // 45.0)


# ---------------------------------------------------------------------------
# 高速な終点読み（末尾行のみ）／航跡の間引き列挙
# ---------------------------------------------------------------------------
def read_endpoint(path: str):
    """CSVの最終データ行から (lon, lat, n_points) を返す。ファイルは時刻昇順前提（検証済み）。

    末尾から数KBだけ読んで最終行の lon/lat を取る。ヘッダから列位置を特定する。
    失敗時は None。n_points は概算不要のため -1 を許容するが、ここでは全行数を軽く数える。
    """
    try:
        with open(path, "rb") as fh:
            first = fh.readline().decode("utf-8", "replace").rstrip("\n\r")
            header = first.split(",")
            try:
                i_lon = header.index("lon")
                i_lat = header.index("lat")
            except ValueError:
                return None
            fh.seek(0, os.SEEK_END)
            filesize = fh.tell()
            # 末尾から少しずつ遡って最後の非空行を得る
            block = 4096
            data = b""
            pos = filesize
            last_line = None
            while pos > 0:
                step = min(block, pos)
                pos -= step
                fh.seek(pos)
                data = fh.read(step) + data
                lines = data.split(b"\n")
                # 末尾の空要素を除いた最後の行を探す
                for ln in reversed(lines):
                    s = ln.strip()
                    if s:
                        last_line = s
                        break
                if last_line is not None and len(lines) > 2:
                    break
            if last_line is None:
                return None
            parts = last_line.decode("utf-8", "replace").split(",")
            if len(parts) <= max(i_lon, i_lat):
                return None
            lon = float(parts[i_lon]); lat = float(parts[i_lat])
        return (lon, lat)
    except Exception:
        return None


def read_traj_lonlat(path: str):
    """1航跡の (lon, lat) 系列を numpy で返す。時刻昇順前提のためソートしない。失敗時 None。"""
    try:
        df = pd.read_csv(path, usecols=lambda c: c in ("lon", "lat"))
        if "lon" not in df.columns or "lat" not in df.columns:
            return None
        lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
        lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
        m = np.isfinite(lon) & np.isfinite(lat)
        lon, lat = lon[m], lat[m]
        if len(lon) < 2:
            return None
        return lon, lat
    except Exception:
        return None


# ---------------------------------------------------------------------------
# build: worker（終点抽出＋航跡の通過グリッド寄与を1パスで返す）
# ---------------------------------------------------------------------------
def _endpoint_worker(paths):
    """複数ファイルの終点を末尾行読みで抽出。 [(mmsi, lon, lat), ...] を返す。"""
    out = []
    for p in paths:
        mmsi = mmsi_from_name(p)
        if mmsi is None or mmsi == "0":
            continue
        ep = read_endpoint(p)
        if ep is None:
            continue
        out.append((mmsi, ep[0], ep[1]))
    return out


def _cell_of(lon, lat, cell):
    return (int(math.floor(lon / cell)), int(math.floor(lat / cell)))


def _comp_diag_km(comp, cell_stat):
    """連結成分（セル集合）のバウンディングボックス対角長(km)。セルは終点重心で代表する。"""
    lons = [cell_stat[c][1] / cell_stat[c][0] for c in comp]
    lats = [cell_stat[c][2] / cell_stat[c][0] for c in comp]
    lon_min, lon_max = min(lons), max(lons)
    lat_min, lat_max = min(lats), max(lats)
    mid_lat = 0.5 * (lat_min + lat_max)
    dx = (lon_max - lon_min) * km_per_deg_lon(mid_lat)
    dy = (lat_max - lat_min) * KM_PER_DEG_LAT
    return math.hypot(dx, dy)


def _kmeans_cells(comp, cell_stat, k, seed=42, n_iter=25):
    """セル（終点重心・終点数重み）に対する重み付きk-means。ラベル配列を返す。

    セル数は終点数より桁違いに少ないため、終点ではなくセルをクラスタリングする
    （cell2zone のセル→zone割当がそのまま得られる利点もある）。
    km空間（経度は中央緯度でスケール）で距離を測る。k-means++風の重み付き初期化。
    """
    pts_lon = np.array([cell_stat[c][1] / cell_stat[c][0] for c in comp])
    pts_lat = np.array([cell_stat[c][2] / cell_stat[c][0] for c in comp])
    w = np.array([float(cell_stat[c][0]) for c in comp])
    mid_lat = float(pts_lat.mean())
    X = np.stack([pts_lon * km_per_deg_lon(mid_lat), pts_lat * KM_PER_DEG_LAT], axis=1)
    n = len(X)
    k = min(k, n)
    rng = np.random.default_rng(seed)
    # k-means++ 初期化（重み付き）
    centers = np.empty((k, 2))
    i0 = rng.choice(n, p=w / w.sum())
    centers[0] = X[i0]
    d2 = ((X - centers[0]) ** 2).sum(axis=1)
    for j in range(1, k):
        p = w * d2
        s = p.sum()
        if s <= 0:
            centers[j:] = X[rng.choice(n, size=k - j)]
            break
        centers[j] = X[rng.choice(n, p=p / s)]
        d2 = np.minimum(d2, ((X - centers[j]) ** 2).sum(axis=1))
    # Lloyd 反復
    labels = np.zeros(n, dtype=np.int64)
    for _ in range(n_iter):
        dist = ((X[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)  # [n,k]
        new_labels = dist.argmin(axis=1)
        if np.array_equal(new_labels, labels) and _ > 0:
            break
        labels = new_labels
        for j in range(k):
            m = labels == j
            if m.any():
                wm = w[m]
                centers[j] = (X[m] * wm[:, None]).sum(axis=0) / wm.sum()
    return labels


def build_zones(endpoints, cell=ZONE_CELL_DEG, min_count=ZONE_MIN_COUNT,
                core_min=ZONE_CORE_MIN, max_diag_km=ZONE_MAX_DIAG_KM,
                split_target_km=ZONE_SPLIT_TARGET_KM):
    """終点リスト [(mmsi,lon,lat),...] から zone を構築する。

    手順（沿岸パーコレーション対策込み・2026-07-08改訂）:
      1. 0.02°セルに集約。
      2. 終点数 >= core_min のセルだけを「コアセル」とし、8近傍連結成分を作る
         （疎セルが密集地帯同士を数珠つなぎに連結するのを防ぐ）。
      3. コア成分に8近傍で隣接する疎セルは「隣接成分が一意な場合のみ」その成分へ付与
         （カバレッジ回復。2成分以上に接する疎セルは橋になるので付与しない）。
      4. bbox対角 > max_diag_km の成分は重み付きk-means（k=ceil(対角/split_target_km)）で
         分割し、分割後の各部分も再検査（キュー方式）。
      5. 終点数 >= min_count の成分を zone とする。
    戻り値: (zones, cell2zone)
      zones: list of dict(zone_id, center_lon, center_lat, count)
      cell2zone: dict[(cx,cy)] -> zone_id （zoneに属するセルのみ）
    """
    from collections import deque

    # 1) セルごとに (件数, sum_lon, sum_lat) を集計
    cell_stat = defaultdict(lambda: [0, 0.0, 0.0])
    for mmsi, lon, lat in endpoints:
        c = _cell_of(lon, lat, cell)
        st = cell_stat[c]
        st[0] += 1; st[1] += lon; st[2] += lat

    # 2) コアセルのみで8近傍連結成分（BFS）
    core = {c for c, st in cell_stat.items() if st[0] >= core_min}
    neigh = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    visited = set()
    comps = []
    for c0 in core:
        if c0 in visited:
            continue
        stack = [c0]; visited.add(c0); comp = []
        while stack:
            c = stack.pop(); comp.append(c)
            for dx, dy in neigh:
                nb = (c[0] + dx, c[1] + dy)
                if nb in core and nb not in visited:
                    visited.add(nb); stack.append(nb)
        comps.append(comp)

    # 3) 疎セルの付与: 隣接するコア成分が一意な疎セルのみ、その成分に加える
    comp_of_core = {}
    for ci, comp in enumerate(comps):
        for c in comp:
            comp_of_core[c] = ci
    for c, st in cell_stat.items():
        if c in core:
            continue
        adj = set()
        for dx, dy in neigh:
            nb = (c[0] + dx, c[1] + dy)
            if nb in comp_of_core:
                adj.add(comp_of_core[nb])
        if len(adj) == 1:
            comps[adj.pop()].append(c)

    # 4) 直径制限つき分割（キュー方式・分割後も再検査）
    queue = deque(comps)
    final_comps = []
    guard = 0
    while queue:
        guard += 1
        if guard > 100000:  # 想定外の無限ループ防止
            final_comps.extend(queue)
            break
        comp = queue.popleft()
        if len(comp) < 2:
            final_comps.append(comp)
            continue
        diag = _comp_diag_km(comp, cell_stat)
        if diag <= max_diag_km:
            final_comps.append(comp)
            continue
        k = max(2, int(math.ceil(diag / split_target_km)))
        labels = _kmeans_cells(comp, cell_stat, k)
        parts = defaultdict(list)
        for c, lb in zip(comp, labels):
            parts[int(lb)].append(c)
        parts = [p for p in parts.values() if p]
        if len(parts) <= 1:
            final_comps.append(comp)  # 分割できなければ受理（安全弁）
            continue
        queue.extend(parts)

    # 5) zone化（min_count足切り・終点数の重み付き平均中心）
    zones = []
    cell2zone = {}
    zid = 0
    for comp in final_comps:
        tot = sum(cell_stat[c][0] for c in comp)
        if tot < min_count:
            continue
        slon = sum(cell_stat[c][1] for c in comp)
        slat = sum(cell_stat[c][2] for c in comp)
        zones.append({
            "zone_id": zid,
            "center_lon": slon / tot,
            "center_lat": slat / tot,
            "count": tot,
        })
        for c in comp:
            cell2zone[c] = zid
        zid += 1
    return zones, cell2zone


def endpoint_zone(lon, lat, cell2zone, cell=ZONE_CELL_DEG):
    """終点座標が属する zone_id を返す（どのzoneにも入らなければ None）。"""
    return cell2zone.get(_cell_of(lon, lat, cell))


def _grid_worker(args):
    """通過グリッド索引の部分集計を1プロセスで行う。

    args = (paths, cell2zone_bytes) の形で cell2zone は pickle 済み dict を渡す。
    各航跡: 終点zoneを求め（無ければスキップ）、5点間引きで走査し
      (grid_cell, bearing_bin) -> {dest_zone: 回数} を集計。
    戻り値: dict[(gx,gy,b)] -> dict[zone_id -> count]  と、mmsi->{zone:count} の部分。
    """
    paths, cell2zone = args
    grid_index = defaultdict(lambda: defaultdict(int))
    mmsi_index = defaultdict(lambda: defaultdict(int))
    for p in paths:
        mmsi = mmsi_from_name(p)
        if mmsi is None or mmsi == "0":
            continue
        seq = read_traj_lonlat(p)
        if seq is None:
            continue
        lon, lat = seq
        dz = endpoint_zone(lon[-1], lat[-1], cell2zone)
        if dz is None:
            continue
        # MMSI索引（終点zoneのみ）
        mmsi_index[mmsi][dz] += 1
        # 通過グリッド: 5点間引き
        n = len(lon)
        idxs = range(1, n, TRAJ_STRIDE)
        for i in idxs:
            # 方位: 前点→現点の変位（km換算）
            de = (lon[i] - lon[i - 1]) * km_per_deg_lon(lat[i])
            dn = (lat[i] - lat[i - 1]) * KM_PER_DEG_LAT
            b = bearing_bin(de, 0.0, dn)
            if b < 0:
                continue
            gx = int(math.floor(lon[i] / GRID_CELL_DEG))
            gy = int(math.floor(lat[i] / GRID_CELL_DEG))
            grid_index[(gx, gy, b)][dz] += 1
    # defaultdict -> 通常dictへ
    gi = {k: dict(v) for k, v in grid_index.items()}
    mi = {k: dict(v) for k, v in mmsi_index.items()}
    return gi, mi


def cmd_build(args):
    t0 = time.time()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1) ファイル列挙（MMSI_0除外）
    files = []
    for d in args.data_dir:
        fs = glob.glob(os.path.join(d, "*.csv"))
        fs = [f for f in fs if not os.path.basename(f).startswith("MMSI_0_")]
        files.extend(fs)
    if args.limit and args.limit > 0:
        files = files[: args.limit]
    n_files = len(files)
    print(f"[build] files (MMSI_0除外後): {n_files}", flush=True)
    if n_files == 0:
        raise SystemExit("[build] 対象ファイルが0件です。--data-dir を確認してください。")

    import multiprocessing as mp
    nw = max(1, int(args.num_workers))

    # 2) 終点抽出（末尾行読み・並列）
    print(f"[build] 終点抽出を開始（workers={nw}）...", flush=True)
    chunks = [files[i::nw * 4] for i in range(nw * 4)]  # 細かめに分割して負荷分散
    chunks = [c for c in chunks if c]
    endpoints = []
    with mp.Pool(nw) as pool:
        done = 0
        for res in pool.imap_unordered(_endpoint_worker, chunks):
            endpoints.extend(res)
            done += 1
            if done % max(1, len(chunks) // 10) == 0:
                print(f"[build]   終点抽出 {done}/{len(chunks)} chunk 完了、累積 {len(endpoints)} 終点、"
                      f"{time.time()-t0:.0f}s", flush=True)
    n_endpoints = len(endpoints)
    print(f"[build] 終点抽出完了: {n_endpoints} 終点、{time.time()-t0:.0f}s", flush=True)

    # 3) zone構築
    print("[build] zone構築（0.02°集約→コアセル連結→疎セル付与→直径分割→閾値）...", flush=True)
    zones, cell2zone = build_zones(endpoints, cell=ZONE_CELL_DEG, min_count=args.min_count)
    n_zones = len(zones)
    # カバレッジ: 全終点のうち zone に入る割合
    covered = 0
    for mmsi, lon, lat in endpoints:
        if endpoint_zone(lon, lat, cell2zone) is not None:
            covered += 1
    coverage = 100.0 * covered / max(1, n_endpoints)
    max_share = (100.0 * max(z["count"] for z in zones) / max(1, covered)) if zones else 0.0
    print(f"[build] zone数: {n_zones}, カバレッジ: {coverage:.2f}% "
          f"({covered}/{n_endpoints}), 最大zoneシェア: {max_share:.2f}%（zone入り終点比）", flush=True)

    # zones.csv 保存
    zdf = pd.DataFrame(zones).sort_values("count", ascending=False).reset_index(drop=True)
    zdf.to_csv(out_dir / "zones.csv", index=False, encoding="utf-8")

    # 上位10 zone をログ
    print("[build] 上位10 zone（終点数順）:", flush=True)
    for _, r in zdf.head(10).iterrows():
        print(f"  zone {int(r['zone_id']):5d}  count={int(r['count']):7d}  "
              f"lon={r['center_lon']:.4f} lat={r['center_lat']:.4f}", flush=True)

    # 4) 通過グリッド索引 + MMSI索引（並列・1パス）
    print(f"[build] 通過グリッド索引 + MMSI索引を構築（workers={nw}）...", flush=True)
    gchunks = [files[i::nw * 4] for i in range(nw * 4)]
    gchunks = [(c, cell2zone) for c in gchunks if c]
    grid_index = defaultdict(lambda: defaultdict(int))
    mmsi_index = defaultdict(lambda: defaultdict(int))
    with mp.Pool(nw) as pool:
        done = 0
        for gi, mi in pool.imap_unordered(_grid_worker, gchunks):
            for k, d in gi.items():
                dst = grid_index[k]
                for z, c in d.items():
                    dst[z] += c
            for m, d in mi.items():
                dst = mmsi_index[m]
                for z, c in d.items():
                    dst[z] += c
            done += 1
            if done % max(1, len(gchunks) // 10) == 0:
                print(f"[build]   索引 {done}/{len(gchunks)} chunk 完了、grid keys={len(grid_index)}、"
                      f"mmsi={len(mmsi_index)}、{time.time()-t0:.0f}s", flush=True)

    grid_index = {k: dict(v) for k, v in grid_index.items()}
    mmsi_index = {k: dict(v) for k, v in mmsi_index.items()}
    print(f"[build] grid索引キー数: {len(grid_index)}, MMSI索引船数: {len(mmsi_index)}", flush=True)

    # 5) 保存（pickle）
    meta = {
        "zone_cell_deg": ZONE_CELL_DEG,
        "grid_cell_deg": GRID_CELL_DEG,
        "n_bearing_bins": N_BEARING_BINS,
        "traj_stride": TRAJ_STRIDE,
        "min_count": int(args.min_count),
        "core_min": ZONE_CORE_MIN,
        "max_diag_km": ZONE_MAX_DIAG_KM,
        "split_target_km": ZONE_SPLIT_TARGET_KM,
        "n_files": n_files,
        "n_endpoints": n_endpoints,
        "n_zones": n_zones,
        "coverage_pct": coverage,
        "max_zone_share_pct": max_share,
        "w_mmsi": W_MMSI,
        "w_grid": W_GRID,
    }
    with open(out_dir / "index.pkl", "wb") as fh:
        pickle.dump({
            "meta": meta,
            "zones": zones,          # list of dict
            "cell2zone": cell2zone,  # dict[(cx,cy)] -> zone_id
            "grid_index": grid_index,
            "mmsi_index": mmsi_index,
        }, fh, protocol=pickle.HIGHEST_PROTOCOL)

    # 索引サイズ
    idx_bytes = os.path.getsize(out_dir / "index.pkl")
    print(f"[build] index.pkl サイズ: {idx_bytes/1e6:.1f} MB", flush=True)
    print(f"[build] 完了。総所要 {time.time()-t0:.0f}s", flush=True)

    # メタをテキストでも残す
    with open(out_dir / "build_meta.txt", "w", encoding="utf-8") as fh:
        for k, v in meta.items():
            fh.write(f"{k}\t{v}\n")
        fh.write(f"index_pkl_bytes\t{idx_bytes}\n")
        fh.write(f"build_seconds\t{time.time()-t0:.0f}\n")


# ---------------------------------------------------------------------------
# 索引の読み込みと推論ロジック（predict / evaluate 共通）
# ---------------------------------------------------------------------------
class DestinationIndex:
    def __init__(self, index_dir):
        with open(Path(index_dir) / "index.pkl", "rb") as fh:
            d = pickle.load(fh)
        self.meta = d["meta"]
        self.zones = d["zones"]
        self.cell2zone = d["cell2zone"]
        self.grid_index = d["grid_index"]
        self.mmsi_index = d["mmsi_index"]
        self.zone_by_id = {z["zone_id"]: z for z in self.zones}
        self.zone_cell = self.meta["zone_cell_deg"]
        self.grid_cell = self.meta["grid_cell_deg"]
        # 参考ベースライン用: 最頻zone（全終点数=zone count が最大のもの）
        self.most_common_zone = max(self.zones, key=lambda z: z["count"])["zone_id"] if self.zones else None

    def endpoint_zone(self, lon, lat):
        return self.cell2zone.get((int(math.floor(lon / self.zone_cell)),
                                   int(math.floor(lat / self.zone_cell))))

    def _p_grid(self, lon, lat):
        """直近数点の位置×方位ビンから通過グリッド索引を参照して {zone:score} を返す。

        lon,lat は「観測済み系列」。直近 GRID_SMOOTH_CELLS 個の走査点の索引を合算して平滑化する。
        """
        n = len(lon)
        acc = defaultdict(float)
        used = 0
        # 末尾から遡り、方位が取れる点を最大 GRID_SMOOTH_CELLS 個使う
        for i in range(n - 1, 0, -1):
            de = (lon[i] - lon[i - 1]) * km_per_deg_lon(lat[i])
            dn = (lat[i] - lat[i - 1]) * KM_PER_DEG_LAT
            b = bearing_bin(de, 0.0, dn)
            if b < 0:
                continue
            gx = int(math.floor(lon[i] / self.grid_cell))
            gy = int(math.floor(lat[i] / self.grid_cell))
            d = self.grid_index.get((gx, gy, b))
            if d:
                tot = float(sum(d.values()))
                for z, c in d.items():
                    acc[z] += c / tot   # 各セルは自己正規化してから平均（大票セルの支配を緩和）
                used += 1
            if used >= GRID_SMOOTH_CELLS:
                break
        if used > 0:
            for z in acc:
                acc[z] /= used
        return dict(acc)

    def _p_mmsi(self, mmsi):
        """そのMMSIのzoneヒストグラムを正規化して {zone:prob} を返す（索引に無ければ空）。"""
        d = self.mmsi_index.get(str(mmsi))
        if not d:
            return {}
        tot = float(sum(d.values()))
        return {z: c / tot for z, c in d.items()}

    def predict_dist(self, lon, lat, mmsi, top_k=3):
        """観測系列(lon,lat)とmmsiから目的地Top-kを推論する。

        戻り値: [(zone_id, prob), ...] を prob 降順で top_k 件。
        混合: P = 0.7*P_mmsi + 0.3*P_grid（MMSIが索引に無ければ P_grid のみ）。正規化。
        """
        p_mmsi = self._p_mmsi(mmsi)
        p_grid = self._p_grid(lon, lat)
        combined = defaultdict(float)
        if p_mmsi:
            for z, p in p_mmsi.items():
                combined[z] += W_MMSI * p
            for z, p in p_grid.items():
                combined[z] += W_GRID * p
        else:
            # MMSI未知: グリッドのみ
            for z, p in p_grid.items():
                combined[z] += p
        if not combined:
            return []
        tot = float(sum(combined.values()))
        items = sorted(((z, p / tot) for z, p in combined.items()),
                       key=lambda x: -x[1])
        return items[:top_k]

    def zone_center(self, zone_id):
        z = self.zone_by_id.get(zone_id)
        if z is None:
            return None
        return z["center_lon"], z["center_lat"]


# ---------------------------------------------------------------------------
# predict サブコマンド
# ---------------------------------------------------------------------------
def cmd_predict(args):
    idx = DestinationIndex(args.index_dir)
    seq = read_traj_lonlat(args.traj_csv)
    if seq is None:
        raise SystemExit(f"[predict] 航跡が読めません: {args.traj_csv}")
    lon, lat = seq
    n = len(lon)
    mmsi = mmsi_from_name(args.traj_csv)
    known = str(mmsi) in idx.mmsi_index
    # 正解zone（終点）
    true_zone = idx.endpoint_zone(lon[-1], lat[-1])

    rows = []
    every = max(1, int(args.every))
    # 各時点: step点まで観測 → 推論
    steps = list(range(every, n + 1, every))
    if steps and steps[-1] != n:
        steps.append(n)  # 最終時点（全観測）も入れる
    for step in steps:
        sub_lon = lon[:step]; sub_lat = lat[:step]
        preds = idx.predict_dist(sub_lon, sub_lat, mmsi, top_k=args.top_k)
        cur_lon, cur_lat = sub_lon[-1], sub_lat[-1]
        if not preds:
            rows.append({
                "step": step, "lon": cur_lon, "lat": cur_lat, "rank": 0,
                "zone_id": -1, "prob": 0.0, "zone_lon": float("nan"),
                "zone_lat": float("nan"), "dist_to_zone_km": float("nan"),
            })
            continue
        for rank, (z, p) in enumerate(preds, start=1):
            zc = idx.zone_center(z)
            zlon, zlat = (zc if zc else (float("nan"), float("nan")))
            dist = (haversine_km(cur_lon, cur_lat, zlon, zlat)
                    if zc else float("nan"))
            rows.append({
                "step": step, "lon": cur_lon, "lat": cur_lat, "rank": rank,
                "zone_id": z, "prob": round(p, 4), "zone_lon": zlon,
                "zone_lat": zlat, "dist_to_zone_km": round(dist, 3),
            })

    out = pd.DataFrame(rows)
    if args.out_csv:
        Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
        out.to_csv(args.out_csv, index=False, encoding="utf-8")
        print(f"[predict] 出力: {args.out_csv}", flush=True)
    # サマリ表示
    print(f"[predict] file={os.path.basename(args.traj_csv)} mmsi={mmsi} "
          f"known={known} n_points={n} true_zone={true_zone}", flush=True)
    print(out.to_string(index=False), flush=True)


# ---------------------------------------------------------------------------
# evaluate サブコマンド
# ---------------------------------------------------------------------------
def _eval_one(args_tuple):
    """1航跡を進捗20/50/80%で推論して結果行を返す（worker）。索引はグローバル参照。"""
    path = args_tuple
    seq = read_traj_lonlat(path)
    if seq is None:
        return None
    lon, lat = seq
    n = len(lon)
    if n < 5:
        return None
    mmsi = mmsi_from_name(path)
    idx = _EVAL_IDX
    true_zone = idx.endpoint_zone(lon[-1], lat[-1])
    if true_zone is None:
        return {"filename": os.path.basename(path), "excluded": True}
    known = str(mmsi) in idx.mmsi_index
    rows = []
    for prog in (0.2, 0.5, 0.8):
        cut = max(2, int(round(n * prog)))
        sub_lon = lon[:cut]; sub_lat = lat[:cut]
        preds = idx.predict_dist(sub_lon, sub_lat, mmsi, top_k=3)
        if preds:
            top1 = preds[0][0]
            top_ids = [z for z, _ in preds]
            hit1 = int(top1 == true_zone)
            hit3 = int(true_zone in top_ids)
            zc = idx.zone_center(top1)
            if zc:
                dist = haversine_km(zc[0], zc[1], lon[-1], lat[-1])
            else:
                dist = float("nan")
        else:
            top1 = -1; hit1 = 0; hit3 = 0; dist = float("nan")
        rows.append({
            "filename": os.path.basename(path),
            "mmsi": mmsi,
            "mmsi_known": int(known),
            "true_zone": true_zone,
            "progress": prog,
            "top1_zone": top1,
            "hit1": hit1,
            "hit3": hit3,
            "dist_km": dist,
            "excluded": False,
        })
    return rows


_EVAL_IDX = None


def _eval_init(index_dir):
    global _EVAL_IDX
    _EVAL_IDX = DestinationIndex(index_dir)


def cmd_evaluate(args):
    t0 = time.time()
    idx = DestinationIndex(args.index_dir)
    files = glob.glob(os.path.join(args.data_dir, "*.csv"))
    files = [f for f in files if not os.path.basename(f).startswith("MMSI_0_")]
    if args.limit and args.limit > 0:
        files = files[: args.limit]
    print(f"[evaluate] 評価対象: {len(files)} 航跡", flush=True)

    import multiprocessing as mp
    nw = max(1, int(args.num_workers))
    all_rows = []
    excluded = 0
    with mp.Pool(nw, initializer=_eval_init, initargs=(args.index_dir,)) as pool:
        for res in pool.imap_unordered(_eval_one, files, chunksize=8):
            if res is None:
                continue
            if isinstance(res, dict) and res.get("excluded"):
                excluded += 1
                continue
            all_rows.extend(res)

    df = pd.DataFrame(all_rows)
    n_traj = df["filename"].nunique() if len(df) else 0
    total_seen = n_traj + excluded
    print(f"[evaluate] zone有り航跡: {n_traj}, zone無し除外: {excluded} "
          f"(除外率 {100.0*excluded/max(1,total_seen):.1f}%)", flush=True)

    # per-trajectory CSV 保存
    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
    save_cols = ["filename", "mmsi_known", "progress", "top1_zone", "hit1", "hit3", "dist_km"]
    df[save_cols].to_csv(args.out_csv, index=False, encoding="utf-8")
    print(f"[evaluate] per-trajectory 出力: {args.out_csv}", flush=True)

    # 参考ベースライン: 最頻zoneを常に予測したときの的中率（zone有り航跡・各航跡1回）
    mc = idx.most_common_zone
    per_traj = df.drop_duplicates("filename")[["filename", "true_zone"]]
    mc_hit = (per_traj["true_zone"] == mc).mean() if len(per_traj) else float("nan")

    # 集計表: 進捗 × (全体/既知/初見) × (Top1/Top3/dist median/mean)
    def agg(sub):
        if len(sub) == 0:
            return (0, float("nan"), float("nan"), float("nan"), float("nan"))
        return (len(sub), sub["hit1"].mean() * 100, sub["hit3"].mean() * 100,
                sub["dist_km"].median(), sub["dist_km"].mean())

    print("\n[evaluate] ===== 結果表 =====", flush=True)
    print(f"参考ベースライン（最頻zone {mc} を常に予測）Top-1的中率: {mc_hit*100:.1f}%", flush=True)
    header = f"{'progress':>8} {'group':>8} {'N':>7} {'Top1%':>7} {'Top3%':>7} {'dist_med':>9} {'dist_mean':>9}"
    print(header, flush=True)
    for prog in (0.2, 0.5, 0.8):
        p = df[df["progress"] == prog]
        for gname, gsub in (("全体", p), ("既知船", p[p["mmsi_known"] == 1]),
                            ("初見船", p[p["mmsi_known"] == 0])):
            n_, t1, t3, dmed, dmean = agg(gsub)
            print(f"{prog:>8.1f} {gname:>8} {n_:>7d} {t1:>7.1f} {t3:>7.1f} "
                  f"{dmed:>9.2f} {dmean:>9.2f}", flush=True)

    print(f"\n[evaluate] 完了。所要 {time.time()-t0:.0f}s", flush=True)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="目的地推論ベースライン（build/predict/evaluate）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build", help="語彙と索引の構築（重い）")
    b.add_argument("--data-dir", nargs="+", required=True)
    b.add_argument("--out-dir", required=True)
    b.add_argument("--num-workers", type=int, default=16)
    b.add_argument("--min-count", type=int, default=ZONE_MIN_COUNT)
    b.add_argument("--limit", type=int, default=0, help="デバッグ用: 先頭N件のみ")
    b.set_defaults(func=cmd_build)

    p = sub.add_parser("predict", help="逐次更新型の推論")
    p.add_argument("--index-dir", required=True)
    p.add_argument("--traj-csv", required=True)
    p.add_argument("--every", type=int, default=10)
    p.add_argument("--top-k", type=int, default=3)
    p.add_argument("--out-csv", default="")
    p.set_defaults(func=cmd_predict)

    e = sub.add_parser("evaluate", help="holdout2017 での層別評価")
    e.add_argument("--index-dir", required=True)
    e.add_argument("--data-dir", required=True)
    e.add_argument("--out-csv", required=True)
    e.add_argument("--num-workers", type=int, default=16)
    e.add_argument("--limit", type=int, default=0)
    e.set_defaults(func=cmd_evaluate)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
