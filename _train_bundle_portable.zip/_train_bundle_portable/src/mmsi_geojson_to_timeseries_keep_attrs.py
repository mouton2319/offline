# mmsi_geojson_to_timeseries_keep_attrs.py
#
# MMSI別GeoJSONから以下を作成する:
#   1) assigned_points/*.csv
#      元coordinatesに TrackStartTime〜TrackEndTime を等分割してtimestampを付与したCSV
#
#   2) resampled_5min/*.csv など
#      fixed intervalに線形補間したCSV
#      位置だけでなく vessel_type / length / width / draft / vessel_group 等も保持する
#
# 入力:
#   by_mmsi/MMSI_*.geojson
#
# 例:
#   python mmsi_geojson_to_timeseries_keep_attrs.py ^
#     --input-dir by_mmsi ^
#     --output-dir timeseries_by_mmsi ^
#     --resample-minutes 5 ^
#     --max-gap-minutes 60 ^
#     --overwrite

import argparse
import csv
import math
import re
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

try:
    import ijson
except ImportError:
    print("[ERROR] ijson がインストールされていません。", file=sys.stderr)
    print("        python -m pip install ijson", file=sys.stderr)
    sys.exit(1)


def parse_dt_utc(text: str) -> datetime:
    """ISO datetime文字列をUTC datetimeへ変換する。

    Args:
        text: `2016-01-01T00:01:18Z` や
            `2016-01-01T00:01:18+00:00` 形式の日時文字列。

    Returns:
        timezone-awareなUTC datetime。

    Raises:
        ValueError: textがNoneまたは空文字の場合。
    """
    if text is None:
        raise ValueError("datetime is None")

    s = str(text).strip()
    if not s:
        raise ValueError("datetime is empty")

    if s.endswith("Z"):
        s = s[:-1] + "+00:00"

    dt = datetime.fromisoformat(s)

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    return dt.astimezone(timezone.utc)


def format_dt_z(dt: datetime) -> str:
    """UTC datetimeを `2016-01-01T00:00:00.000Z` 形式にする。

    Args:
        dt: 変換したいdatetime。

    Returns:
        UTCのISO文字列。ミリ秒付きで末尾は`Z`。
    """
    return dt.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def safe_filename(value) -> str:
    """MMSIなどをWindowsファイル名として安全な文字列にする。

    Args:
        value: ファイル名の一部にしたい値。

    Returns:
        英数字、`_`、`.`、`-`だけを含む文字列。空なら`UNKNOWN`。
    """
    if value is None or value == "":
        value = "UNKNOWN"

    text = str(value)
    text = re.sub(r"[^0-9A-Za-z_.-]+", "_", text)
    return text or "UNKNOWN"


def empty_if_none(value):
    """NoneをCSV出力向けの空文字へ変換する。

    Args:
        value: 任意の値。

    Returns:
        valueがNoneなら空文字、それ以外はvalueそのもの。
    """
    return "" if value is None else value


def flatten_coordinates(geometry: dict):
    """GeoJSON geometryから`(lon, lat)`のリストを順序維持で取り出す。

    Args:
        geometry: GeoJSON Feature内のgeometry dict。

    Returns:
        `(lon, lat)` tupleのリスト。LineString/MultiLineString以外は空リスト。

    Notes:
        対応するgeometry typeはLineStringとMultiLineStringのみ。
        AIS航跡の順番を保つため、GeoJSON内の座標順をそのまま使う。
    """
    if not geometry:
        return []

    gtype = geometry.get("type")
    coords = geometry.get("coordinates")

    points = []

    if gtype == "LineString":
        lines = [coords]
    elif gtype == "MultiLineString":
        lines = coords
    else:
        return []

    if not lines:
        return []

    for line in lines:
        if not line:
            continue

        for p in line:
            if not p or len(p) < 2:
                continue

            lon = float(p[0])
            lat = float(p[1])

            if math.isfinite(lon) and math.isfinite(lat):
                points.append((lon, lat))

    return points


def infer_mmsi_from_filename(path: Path) -> str:
    """ファイル名からMMSIを推定する。

    Args:
        path: `MMSI_123456789.geojson`のようなパス。

    Returns:
        `MMSI_`接頭辞を除いた文字列。形式が違う場合はstem。
    """
    name = path.stem
    if name.startswith("MMSI_"):
        return name[5:]
    return name


def iter_assigned_points(feature: dict, feature_index: int, fallback_mmsi: str, source_geojson: str):
    """1つのGeoJSON Featureから時刻付き点列CSV行を生成する。

    Args:
        feature: GeoJSON Feature dict。
        feature_index: 元GeoJSON内でのFeature番号。
        fallback_mmsi: properties.MMSIがない場合に使うMMSI。
        source_geojson: 由来ファイル名。

    Yields:
        assigned_points CSVへ書き込むdict。

    Notes:
        元GeoJSONのLineStringは、各座標点に個別timestampを持っていない。
        そのため、TrackStartTimeからTrackEndTimeまでの時間を
        `座標数 - 1` 個の区間に等分し、各座標へtimestampを割り当てる。
        船種・船長・幅・喫水・VesselGroupなどの属性は各点に引き継ぐ。
    """
    props = feature.get("properties") or {}

    mmsi = props.get("MMSI")
    if mmsi is None or mmsi == "":
        mmsi = fallback_mmsi

    start_raw = props.get("TrackStartTime")
    end_raw = props.get("TrackEndTime")

    if not start_raw or not end_raw:
        return

    start_dt = parse_dt_utc(start_raw)
    end_dt = parse_dt_utc(end_raw)

    coords = flatten_coordinates(feature.get("geometry") or {})
    n = len(coords)

    if n == 0:
        return

    duration_sec = (end_dt - start_dt).total_seconds()

    # 異常データ対策
    if duration_sec < 0:
        return

    sequence_id = f"{safe_filename(mmsi)}__feature_{feature_index:07d}"

    vessel_type = props.get("VesselType")
    length = props.get("Length")
    width = props.get("Width")
    draft = props.get("Draft")
    duration_minutes = props.get("DurationMinutes")
    vessel_group = props.get("VesselGroup")
    shape_length = props.get("Shape_Length")
    source_file = props.get("SourceFile") or source_geojson

    for point_index, (lon, lat) in enumerate(coords):
        if n == 1 or duration_sec == 0:
            dt = start_dt
        else:
            # GeoJSONには各座標点の時刻がないため、Feature全体の開始/終了時刻を
            # 座標indexの比率で線形に割り当てる。
            offset_sec = duration_sec * point_index / (n - 1)
            dt = start_dt + timedelta(seconds=offset_sec)

        yield {
            "mmsi": str(mmsi),
            "sequence_id": sequence_id,
            "source_geojson": source_geojson,
            "source_file": source_file,
            "feature_index": feature_index,
            "point_index": point_index,
            "timestamp": format_dt_z(dt),
            "unix_time": f"{dt.timestamp():.3f}",
            "lon": f"{lon:.6f}",
            "lat": f"{lat:.6f}",
            "track_start_time": format_dt_z(start_dt),
            "track_end_time": format_dt_z(end_dt),
            "track_duration_sec": f"{duration_sec:.3f}",
            "coord_count_in_feature": n,
            "vessel_type": empty_if_none(vessel_type),
            "length": empty_if_none(length),
            "width": empty_if_none(width),
            "draft": empty_if_none(draft),
            "duration_minutes": empty_if_none(duration_minutes),
            "vessel_group": empty_if_none(vessel_group),
            "shape_length": empty_if_none(shape_length),
        }


ASSIGNED_FIELDS = [
    "mmsi",
    "sequence_id",
    "source_geojson",
    "source_file",
    "feature_index",
    "point_index",
    "timestamp",
    "unix_time",
    "lon",
    "lat",
    "track_start_time",
    "track_end_time",
    "track_duration_sec",
    "coord_count_in_feature",
    "vessel_type",
    "length",
    "width",
    "draft",
    "duration_minutes",
    "vessel_group",
    "shape_length",
]


# 修正版:
# resampled側にも船舶属性と由来情報を残す
MOTION_FIELDS = [
    "dlon",
    "dlat",
    "speed_deg_per_min",
    "course_deg",
    "heading_sin",
    "heading_cos",
    "turn_rate_deg_per_min",
    "abs_turn_rate_deg_per_min",
]

RESAMPLED_FIELDS = [
    "mmsi",
    "block_id",
    "step_index",
    "timestamp",
    "unix_time",
    "lon",
    "lat",
] + MOTION_FIELDS + [
    "vessel_type",
    "length",
    "width",
    "draft",
    "duration_minutes",
    "vessel_group",
    "shape_length",
    "source_geojson",
    "source_file",
    "sequence_id",
    "source_feature_index",
    "source_point_index_left",
    "source_point_index_right",
    "interpolation_ratio",
]


def ceil_to_interval(dt: datetime, interval_sec: int) -> datetime:
    """dt以降の固定間隔境界へ切り上げる。

    Args:
        dt: 元のdatetime。
        interval_sec: 固定間隔秒。5分なら300。

    Returns:
        dt以降で最初に来る固定間隔境界のdatetime。

    Example:
        5分間隔なら `00:03:10 -> 00:05:00`。
    """
    ts = dt.timestamp()
    ceiled = math.ceil(ts / interval_sec) * interval_sec
    return datetime.fromtimestamp(ceiled, tz=timezone.utc)


def assigned_row_to_resample_point(row: dict) -> dict:
    """assigned.csvの1行を、リサンプル用内部形式へ変換する。

    Args:
        row: assigned_points CSVから読んだ1行dict。

    Returns:
        timestampをdatetime、lon/latをfloatにしたdict。
        船舶属性と由来情報も保持する。
    """
    dt = parse_dt_utc(row["timestamp"])
    lon = float(row["lon"])
    lat = float(row["lat"])

    return {
        "dt": dt,
        "lon": lon,
        "lat": lat,
        "mmsi": row.get("mmsi", ""),
        "vessel_type": row.get("vessel_type", ""),
        "length": row.get("length", ""),
        "width": row.get("width", ""),
        "draft": row.get("draft", ""),
        "duration_minutes": row.get("duration_minutes", ""),
        "vessel_group": row.get("vessel_group", ""),
        "shape_length": row.get("shape_length", ""),
        "source_geojson": row.get("source_geojson", ""),
        "source_file": row.get("source_file", ""),
        "sequence_id": row.get("sequence_id", ""),
        "feature_index": row.get("feature_index", ""),
        "point_index": row.get("point_index", ""),
    }


def deduplicate_points(points):
    """同一timestampが複数ある場合、最後の点だけを残す。

    Args:
        points: `assigned_row_to_resample_point()`で作ったdictのリスト。

    Returns:
        timestamp順に並んだ重複除去済みリスト。

    Notes:
        同じMMSI内でFeature境界が接している場合など、同一timestampが重なることがある。
        ここでは後から読まれた点を優先する。
    """
    merged = {}
    for p in points:
        merged[p["dt"]] = p
    return [merged[k] for k in sorted(merged.keys())]


def enrich_resampled_motion_features(rows, interval_minutes: float):
    """resampled行へ速度・方位・旋回率の特徴量を追加する。

    Args:
        rows: `resample_points()`で作った固定間隔行のリスト。
        interval_minutes: resample間隔。通常は3分または5分。

    Returns:
        `dlon`, `dlat`, `speed_deg_per_min`, `course_deg`,
        `heading_sin`, `heading_cos`, `turn_rate_deg_per_min`,
        `abs_turn_rate_deg_per_min`を追加したrows。

    Notes:
        方位は北向きを0度として、東向き成分をsin、北向き成分をcosに対応させる。
        旋回率は「前ステップの方位から現在方位への角度変化 / 分」で計算する。
    """
    interval = max(float(interval_minutes), 1e-6)

    prev_block = None
    prev_lon = None
    prev_lat = None
    prev_heading = None
    last_heading = 0.0

    for row in rows:
        block_id = row.get("block_id", "")
        lon = float(row["lon"])
        lat = float(row["lat"])

        if block_id != prev_block:
            prev_lon = None
            prev_lat = None
            prev_heading = None
            last_heading = 0.0
            prev_block = block_id

        if prev_lon is None or prev_lat is None:
            dlon = 0.0
            dlat = 0.0
        else:
            dlon = lon - prev_lon
            dlat = lat - prev_lat

        speed = math.hypot(dlon, dlat) / interval
        # 経度方向の1度あたり距離は緯度で変わるため、方位計算では
        # dlonにcos(lat)を掛け、東西成分をざっくり距離相当に補正する。
        # ここではCSV列の互換性を保つため、速度自体は従来の度/分も残している。
        east = dlon * math.cos(math.radians(lat))
        north = dlat

        if math.hypot(east, north) > 1e-12:
            # atan2(east, north)にすると、北=0、東=+90度の航海方位に近い角度になる。
            # 一般的な数学のatan2(y, x)とは引数順が逆なので注意。
            heading = math.atan2(east, north)
            last_heading = heading
        else:
            # 停止またはほぼ停止している点では方位が不安定になる。
            # その場合は直前に有効だった方位を引き継ぎ、急なノイズを避ける。
            heading = last_heading

        if prev_heading is None:
            turn_rate = 0.0
        else:
            delta = heading - prev_heading
            # 角度は360度で一周するため、単純な引き算だと
            # 359度 -> 1度の変化が -358度に見えてしまう。
            # atan2(sin(delta), cos(delta))で [-pi, pi] に折り返し、
            # 最短方向の旋回角として扱う。
            delta = math.atan2(math.sin(delta), math.cos(delta))
            turn_rate = math.degrees(delta) / interval

        row["dlon"] = f"{dlon:.8f}"
        row["dlat"] = f"{dlat:.8f}"
        row["speed_deg_per_min"] = f"{speed:.8f}"
        row["course_deg"] = f"{(math.degrees(heading) + 360.0) % 360.0:.6f}"
        row["heading_sin"] = f"{math.sin(heading):.8f}"
        row["heading_cos"] = f"{math.cos(heading):.8f}"
        row["turn_rate_deg_per_min"] = f"{turn_rate:.8f}"
        row["abs_turn_rate_deg_per_min"] = f"{abs(turn_rate):.8f}"

        prev_lon = lon
        prev_lat = lat
        prev_heading = heading

    return rows


def resample_points(points, mmsi: str, interval_minutes: float, max_gap_minutes: float):
    """等分割済み点列を固定時間間隔に再サンプリングする。

    Args:
        points: assigned pointの内部dictリスト。
        mmsi: 出力CSVに入れるMMSI。
        interval_minutes: 出力間隔。3なら3分ごと。
        max_gap_minutes: この分数を超える隣接点間は補間しない。

    Returns:
        resampled CSVへ書き込むdictリスト。最後に旋回特徴も追加済み。

    Notes:
        lon/latは時刻比率で線形補間する。
        vessel_type/length/width/draft/vessel_group等は補間区間の左側点p0から引き継ぐ。
        長い欠損の後は別航跡として扱うため、block_idを進めstep_indexを0に戻す。
    """
    if not points:
        return []

    interval_sec = int(round(interval_minutes * 60))
    max_gap_sec = max_gap_minutes * 60

    if interval_sec <= 0:
        raise ValueError("interval_minutes must be positive")

    points = deduplicate_points(points)

    if len(points) < 2:
        return []

    rows = []
    block_index = 0
    step_index = 0
    last_written_ts = None

    for i in range(len(points) - 1):
        p0 = points[i]
        p1 = points[i + 1]

        t0 = p0["dt"]
        t1 = p1["dt"]

        lon0 = p0["lon"]
        lat0 = p0["lat"]
        lon1 = p1["lon"]
        lat1 = p1["lat"]

        gap_sec = (t1 - t0).total_seconds()

        if gap_sec <= 0:
            continue

        if gap_sec > max_gap_sec:
            # 長すぎる空白は別航跡ブロックとして扱い、間を補間しない
            block_index += 1
            step_index = 0
            last_written_ts = None
            continue

        target = ceil_to_interval(t0, interval_sec)

        while target <= t1:
            if target < t0:
                target += timedelta(seconds=interval_sec)
                continue

            if last_written_ts is not None and target <= last_written_ts:
                target += timedelta(seconds=interval_sec)
                continue

            ratio = (target - t0).total_seconds() / gap_sec

            # target時刻がp0とp1の間のどの割合にいるかをratioで表し、
            # lon/latを直線補間する。例: ratio=0.25ならp0からp1へ25%進んだ位置。
            lon = lon0 + (lon1 - lon0) * ratio
            lat = lat0 + (lat1 - lat0) * ratio

            rows.append({
                "mmsi": str(mmsi),
                "block_id": f"{safe_filename(mmsi)}__block_{block_index:07d}",
                "step_index": step_index,
                "timestamp": format_dt_z(target),
                "unix_time": f"{target.timestamp():.3f}",
                "lon": f"{lon:.6f}",
                "lat": f"{lat:.6f}",

                # 船舶属性は左側点から引き継ぐ
                "vessel_type": p0.get("vessel_type", ""),
                "length": p0.get("length", ""),
                "width": p0.get("width", ""),
                "draft": p0.get("draft", ""),
                "duration_minutes": p0.get("duration_minutes", ""),
                "vessel_group": p0.get("vessel_group", ""),
                "shape_length": p0.get("shape_length", ""),

                # 由来情報
                "source_geojson": p0.get("source_geojson", ""),
                "source_file": p0.get("source_file", ""),
                "sequence_id": p0.get("sequence_id", ""),
                "source_feature_index": p0.get("feature_index", ""),
                "source_point_index_left": p0.get("point_index", ""),
                "source_point_index_right": p1.get("point_index", ""),
                "interpolation_ratio": f"{ratio:.6f}",
            })

            last_written_ts = target
            step_index += 1
            target += timedelta(seconds=interval_sec)

    return enrich_resampled_motion_features(rows, interval_minutes=interval_minutes)


def process_mmsi_file(
    input_path: Path,
    assigned_dir: Path,
    resampled_dir: Path | None,
    overwrite: bool,
    resample_minutes: float | None,
    max_gap_minutes: float,
    progress_every: int,
):
    """MMSI別GeoJSON 1ファイルをassigned/resampled CSVへ変換する。

    Args:
        input_path: 入力MMSI別GeoJSON。
        assigned_dir: assigned_points CSV出力先フォルダ。
        resampled_dir: resampled CSV出力先フォルダ。Noneならresampleしない。
        overwrite: 既存出力を上書きするか。
        resample_minutes: resample間隔。Noneならresampleしない。
        max_gap_minutes: これを超える点間は補間しない。
        progress_every: 何Featureごとに進捗表示するか。0なら非表示。

    Returns:
        manifest.csvへ書く処理結果dict。
    """
    fallback_mmsi = infer_mmsi_from_filename(input_path)

    assigned_path = assigned_dir / f"{input_path.stem}_assigned.csv"

    if assigned_path.exists() and not overwrite:
        print(f"[SKIP] exists: {assigned_path}")
        return {
            "input_file": input_path.name,
            "mmsi": fallback_mmsi,
            "assigned_points": "SKIPPED",
            "resampled_points": "SKIPPED",
            "first_time": "",
            "last_time": "",
            "assigned_csv": str(assigned_path),
            "resampled_csv": "",
        }

    if assigned_path.exists() and overwrite:
        assigned_path.unlink()

    resampled_path = None
    if resampled_dir is not None:
        resampled_path = resampled_dir / f"{input_path.stem}_resampled_{resample_minutes:g}min.csv"
        if resampled_path.exists() and overwrite:
            resampled_path.unlink()

    print("=" * 80)
    print(f"[INPUT]     {input_path}")
    print(f"[ASSIGNED]  {assigned_path}")
    if resampled_path:
        print(f"[RESAMPLED] {resampled_path}")
    print("=" * 80)

    points_for_resample = []
    assigned_count = 0
    feature_count = 0
    first_dt = None
    last_dt = None
    actual_mmsi = fallback_mmsi

    with input_path.open("rb") as fp, assigned_path.open("w", encoding="utf-8-sig", newline="") as out_fp:
        writer = csv.DictWriter(out_fp, fieldnames=ASSIGNED_FIELDS)
        writer.writeheader()

        for feature in ijson.items(fp, "features.item", use_float=True):
            feature_count += 1

            props = feature.get("properties") or {}
            if props.get("MMSI") not in [None, ""]:
                actual_mmsi = str(props.get("MMSI"))

            for row in iter_assigned_points(
                feature=feature,
                feature_index=feature_count - 1,
                fallback_mmsi=fallback_mmsi,
                source_geojson=input_path.name,
            ):
                writer.writerow(row)
                assigned_count += 1

                p = assigned_row_to_resample_point(row)
                points_for_resample.append(p)

                dt = p["dt"]

                if first_dt is None or dt < first_dt:
                    first_dt = dt
                if last_dt is None or dt > last_dt:
                    last_dt = dt

            if progress_every > 0 and feature_count % progress_every == 0:
                print(
                    f"[PROGRESS] {input_path.name}: "
                    f"features={feature_count:,}, points={assigned_count:,}"
                )

    resampled_count = 0

    if resampled_path is not None and resample_minutes is not None:
        points_for_resample.sort(key=lambda x: x["dt"])

        resampled_rows = resample_points(
            points=points_for_resample,
            mmsi=actual_mmsi,
            interval_minutes=resample_minutes,
            max_gap_minutes=max_gap_minutes,
        )

        with resampled_path.open("w", encoding="utf-8-sig", newline="") as fp:
            writer = csv.DictWriter(fp, fieldnames=RESAMPLED_FIELDS)
            writer.writeheader()
            writer.writerows(resampled_rows)

        resampled_count = len(resampled_rows)

    print(
        f"[DONE] {input_path.name}: "
        f"features={feature_count:,}, assigned_points={assigned_count:,}, "
        f"resampled_points={resampled_count:,}"
    )

    return {
        "input_file": input_path.name,
        "mmsi": actual_mmsi,
        "assigned_points": assigned_count,
        "resampled_points": resampled_count,
        "first_time": "" if first_dt is None else format_dt_z(first_dt),
        "last_time": "" if last_dt is None else format_dt_z(last_dt),
        "assigned_csv": str(assigned_path),
        "resampled_csv": "" if resampled_path is None else str(resampled_path),
    }


def main():
    """コマンドライン引数を読み、全MMSI別GeoJSONを前処理する入口。

    Args:
        なし。argparseが`sys.argv`から読む。

    Returns:
        None。assigned/resampled CSVとmanifest.csvを書き出す。
    """
    parser = argparse.ArgumentParser(
        description=(
            "MMSI別GeoJSONから、日時と[lon, lat]が一対一対応する時系列CSVを作成する。"
            "resampled CSVにも船種・船長・幅・喫水・VesselGroupを保持する。"
        )
    )

    parser.add_argument(
        "--input-dir",
        default="by_mmsi",
        help="MMSI_*.geojson があるフォルダ",
    )
    parser.add_argument(
        "--output-dir",
        default="timeseries_by_mmsi",
        help="出力先フォルダ",
    )
    parser.add_argument(
        "--pattern",
        default="MMSI_*.geojson",
        help="入力ファイルのglobパターン",
    )
    parser.add_argument(
        "--only-mmsi",
        nargs="*",
        default=None,
        help="指定MMSIだけ処理する。例: --only-mmsi 1056261 121251121",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="既存出力を上書きする",
    )
    parser.add_argument(
        "--resample-minutes",
        type=float,
        default=5.0,
        help="固定時間間隔に再サンプリングする間隔。0以下で無効。例: 1, 5, 10",
    )
    parser.add_argument(
        "--max-gap-minutes",
        type=float,
        default=60.0,
        help="この分数を超える点間は補間しない。例: 60",
    )
    parser.add_argument(
        "--progress-every",
        type=int,
        default=1000,
        help="何Featureごとに進捗表示するか。0で非表示",
    )

    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)

    if not input_dir.exists():
        raise FileNotFoundError(f"input-dir が見つかりません: {input_dir}")

    assigned_dir = output_dir / "assigned_points"
    assigned_dir.mkdir(parents=True, exist_ok=True)

    if args.resample_minutes is not None and args.resample_minutes > 0:
        resampled_dir = output_dir / f"resampled_{args.resample_minutes:g}min"
        resampled_dir.mkdir(parents=True, exist_ok=True)
        resample_minutes = args.resample_minutes
    else:
        resampled_dir = None
        resample_minutes = None

    files = sorted(input_dir.glob(args.pattern))

    if args.only_mmsi:
        targets = {safe_filename(x) for x in args.only_mmsi}
        files = [
            p for p in files
            if safe_filename(infer_mmsi_from_filename(p)) in targets
        ]

    if not files:
        raise FileNotFoundError(f"対象ファイルがありません: {input_dir / args.pattern}")

    manifest_rows = []

    for path in files:
        row = process_mmsi_file(
            input_path=path,
            assigned_dir=assigned_dir,
            resampled_dir=resampled_dir,
            overwrite=args.overwrite,
            resample_minutes=resample_minutes,
            max_gap_minutes=args.max_gap_minutes,
            progress_every=args.progress_every,
        )
        manifest_rows.append(row)

    manifest_path = output_dir / "manifest.csv"

    with manifest_path.open("w", encoding="utf-8-sig", newline="") as fp:
        fieldnames = [
            "input_file",
            "mmsi",
            "assigned_points",
            "resampled_points",
            "first_time",
            "last_time",
            "assigned_csv",
            "resampled_csv",
        ]
        writer = csv.DictWriter(fp, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(manifest_rows)

    print("=" * 80)
    print("[ALL DONE]")
    print(f"input files : {len(files):,}")
    print(f"output dir  : {output_dir}")
    print(f"manifest    : {manifest_path}")


if __name__ == "__main__":
    main()
