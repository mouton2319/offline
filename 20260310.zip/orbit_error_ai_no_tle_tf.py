#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""No+TLE error learning for GEO satellites (UFO4 workflow).

Training data (2023):
- TLE files: <tle-dir>/*.txt
- Error files: <err-dir>/*.csv (columns: No,date,UNIX,Lat,Lon,Alt,AZ,EL)

Inference data (2024):
- One TLE file + one baseline CSV (30 days, 1-min step)
- Predict error, correct baseline, output corrected CSV
- Optional: evaluate against truth CSV and plot comparison

Model strategy for accuracy/stability:
1) Build per-No error template from 2023 error files (circular mean for angle cols)
2) Train MLP to predict residual error around template from
   (No features + TLE features + baseline-orbit features from SGP4 CSV)
3) Use AZ/EL-weighted loss for antenna-focused learning
4) Calibrate per-target alpha and clip-k-sigma on validation set
5) In inference, predicted_error = clip(alpha * (template + residual_pred))
   corrected = baseline - predicted_error  (because error = pred - true)
6) Optional abs-representation branch: evaluate baseline +/- correction and pick best branch
7) Optional confidence controls for AZ/EL:
   - No(day)-dependent alpha schedule
   - Prediction-magnitude gate (shrink to zero in low-confidence bins)
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import tensorflow as tf
except Exception:
    tf = None


TARGET_COLS = ["Lat", "Lon", "Alt", "AZ", "EL"]
ANGLE_COLS = {"Lon", "AZ"}
ANTENNA_COLS = {"AZ", "EL"}
ERROR_DEF_PRED_MINUS_TRUE = "pred_minus_true"
ERROR_DEF_TRUE_MINUS_PRED = "true_minus_pred"
ERROR_REPR_SIGNED = "signed"
ERROR_REPR_ABS = "abs"
ERROR_REPR_AUTO = "auto"
MINUTES_PER_DAY = 1440.0
SIDEREAL_PERIOD_MIN = 1436.07


def log(msg: str) -> None:
    print(msg, flush=True)


def require_tensorflow() -> None:
    if tf is None:
        raise RuntimeError(
            "TensorFlow is required for this script. "
            "Use your docker image with TF installed, e.g. orbit-tf-pip:cuda128."
        )


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def now_jst_str() -> str:
    jst = dt.timezone(dt.timedelta(hours=9))
    return dt.datetime.now(tz=jst).strftime("%Y-%m-%d %H:%M:%S%z")


def wrap360(deg: np.ndarray) -> np.ndarray:
    return np.mod(deg, 360.0)


def wrap180(deg: np.ndarray) -> np.ndarray:
    return (np.asarray(deg, dtype=np.float64) + 180.0) % 360.0 - 180.0


def angle_diff_deg(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return wrap180(np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64))


def deterministic_split(stem: str, val_split: float, seed: int) -> str:
    h = hashlib.md5((stem + str(seed)).encode("utf-8")).hexdigest()
    r = int(h[:8], 16) / float(16**8)
    return "val" if r < val_split else "train"


def _normalize_repr_list(error_repr_by_col: Sequence[str]) -> List[str]:
    out: List[str] = []
    if len(error_repr_by_col) != len(TARGET_COLS):
        raise ValueError(f"error_repr_by_col length mismatch: {len(error_repr_by_col)}")
    for i, col in enumerate(TARGET_COLS):
        v = str(error_repr_by_col[i]).strip().lower()
        if v not in (ERROR_REPR_SIGNED, ERROR_REPR_ABS):
            raise ValueError(f"invalid error repr for {col}: {error_repr_by_col[i]}")
        out.append(v)
    return out


def has_abs_repr(error_repr_by_col: Sequence[str]) -> bool:
    rr = _normalize_repr_list(error_repr_by_col)
    return any(v == ERROR_REPR_ABS for v in rr)


def canonicalize_signed_error(y_signed: np.ndarray) -> np.ndarray:
    y = np.asarray(y_signed, dtype=np.float64).copy()
    if y.ndim != 2 or y.shape[1] != len(TARGET_COLS):
        raise ValueError(f"y_signed shape mismatch: {y.shape}")
    for i, col in enumerate(TARGET_COLS):
        if col in ANGLE_COLS:
            y[:, i] = wrap180(y[:, i])
    return y


def to_model_error_repr(y_signed: np.ndarray, error_repr_by_col: Sequence[str]) -> np.ndarray:
    rr = _normalize_repr_list(error_repr_by_col)
    y = canonicalize_signed_error(y_signed)
    out = y.copy()
    for i in range(len(TARGET_COLS)):
        if rr[i] == ERROR_REPR_ABS:
            out[:, i] = np.abs(out[:, i])
    return out


def resolve_error_repr_by_col(
    mode: str,
    sign_consistency_ratio: np.ndarray,
    auto_threshold: float,
) -> List[str]:
    m = str(mode).strip().lower()
    if m == ERROR_REPR_SIGNED:
        return [ERROR_REPR_SIGNED] * len(TARGET_COLS)
    if m == ERROR_REPR_ABS:
        return [ERROR_REPR_ABS] * len(TARGET_COLS)
    if m != ERROR_REPR_AUTO:
        raise ValueError(f"unsupported --error-repr: {mode}")

    out: List[str] = []
    ratio = np.asarray(sign_consistency_ratio, dtype=np.float64).reshape(-1)
    if ratio.shape[0] != len(TARGET_COLS):
        ratio = np.full((len(TARGET_COLS),), np.nan, dtype=np.float64)

    thr = float(auto_threshold)
    for i, col in enumerate(TARGET_COLS):
        r = ratio[i]
        if np.isfinite(r) and r < thr:
            out.append(ERROR_REPR_ABS)
        else:
            out.append(ERROR_REPR_SIGNED)
        if col in ANTENNA_COLS and out[-1] == ERROR_REPR_ABS and np.isfinite(r):
            # AZ/EL are primary objective; keep signed unless sign cancellation is very strong.
            if r >= max(0.05, thr * 0.7):
                out[-1] = ERROR_REPR_SIGNED
    return out


# =========================
# TLE parser
# =========================


@dataclasses.dataclass
class TLEInfo:
    inc_deg: float
    raan_deg: float
    ecc: float
    argp_deg: float
    mean_anom_deg: float
    mean_motion_rev_per_day: float
    bstar: float
    ndot: float
    nddot: float
    epoch_year_2digit: int
    epoch_day: float


def _parse_tle_exponent_field(s: str) -> float:
    s = s.strip()
    if not s:
        return 0.0

    sign = 1.0
    if s[0] == "-":
        sign = -1.0
        s = s[1:]
    elif s[0] == "+":
        s = s[1:]

    plus_pos = s[1:].find("+")
    minus_pos = s[1:].find("-")
    if plus_pos >= 0:
        i = plus_pos + 1
    elif minus_pos >= 0:
        i = minus_pos + 1
    else:
        return sign * float(s)

    mant = s[:i]
    exp = s[i:]
    return sign * float("0." + mant) * (10.0 ** int(exp))


def parse_tle_file(path: Path) -> TLEInfo:
    lines = [
        ln.strip("\n")
        for ln in path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if ln.strip()
    ]
    if len(lines) < 2:
        raise ValueError(f"TLE line count < 2: {path}")

    if lines[0].startswith("1 ") and lines[1].startswith("2 "):
        line1, line2 = lines[0], lines[1]
    else:
        line1, line2 = lines[-2], lines[-1]
        if not (line1.startswith("1 ") and line2.startswith("2 ")):
            raise ValueError(f"Unrecognized TLE format: {path}")

    epoch_year = int(line1[18:20])
    epoch_day = float(line1[20:32])
    ndot = float(line1[33:43].strip() or 0.0)
    nddot = _parse_tle_exponent_field(line1[44:52])
    bstar = _parse_tle_exponent_field(line1[53:61])

    return TLEInfo(
        inc_deg=float(line2[8:16]),
        raan_deg=float(line2[17:25]),
        ecc=float("0." + line2[26:33].strip()),
        argp_deg=float(line2[34:42]),
        mean_anom_deg=float(line2[43:51]),
        mean_motion_rev_per_day=float(line2[52:63]),
        bstar=bstar,
        ndot=ndot,
        nddot=nddot,
        epoch_year_2digit=epoch_year,
        epoch_day=epoch_day,
    )


# =========================
# Data loading
# =========================


def _coerce_unix_int64(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "UNIX" not in out.columns:
        raise ValueError("UNIX column is missing")
    out["UNIX"] = pd.to_numeric(out["UNIX"], errors="coerce").round().astype("Int64")
    out = out.dropna(subset=["UNIX"]).copy()
    out["UNIX"] = out["UNIX"].astype(np.int64)
    return out


def _coerce_no_int64(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "No" not in out.columns:
        out.insert(0, "No", np.arange(1, len(out) + 1, dtype=np.int64))
        return out
    out["No"] = pd.to_numeric(out["No"], errors="coerce").astype("Int64")
    out = out.dropna(subset=["No"]).copy()
    out["No"] = out["No"].astype(np.int64)
    return out


def load_orbit_csv(path: Path, require_targets: bool = True) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "date" not in df.columns:
        df.insert(0, "date", "")

    df = _coerce_unix_int64(df)
    df = _coerce_no_int64(df)

    missing_basic = [c for c in ("date", "UNIX", "No") if c not in df.columns]
    if missing_basic:
        raise ValueError(f"{path}: missing basic columns {missing_basic}")

    if require_targets:
        missing = [c for c in TARGET_COLS if c not in df.columns]
        if missing:
            raise ValueError(f"{path}: missing target columns {missing}")
        for c in TARGET_COLS:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        df = df.dropna(subset=TARGET_COLS).copy()

    df = df.drop_duplicates(subset=["No"], keep="last").sort_values("No").reset_index(drop=True)
    return df


def trim_horizon_and_stride(
    df: pd.DataFrame,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> pd.DataFrame:
    if days_horizon <= 0:
        raise ValueError(f"days_horizon must be > 0, got {days_horizon}")
    if step_minutes <= 0:
        raise ValueError(f"step_minutes must be > 0, got {step_minutes}")
    if sample_every <= 0:
        raise ValueError(f"sample_every must be > 0, got {sample_every}")

    out = df.copy()
    max_rows = int(days_horizon * 24 * 60)
    out = out.iloc[:max_rows].copy()

    stride = int(step_minutes) * int(sample_every)
    if stride > 1:
        out = out.iloc[::stride].copy()

    out = out.reset_index(drop=True)
    return out


def list_stems_with_both(tle_dir: Path, csv_dir: Path) -> List[str]:
    tle_stems = {p.stem for p in tle_dir.glob("*.txt") if p.is_file()}
    csv_stems = {p.stem for p in csv_dir.glob("*.csv") if p.is_file()}
    return sorted(tle_stems & csv_stems)


# =========================
# Online stats
# =========================


class OnlineMeanVar:
    def __init__(self, dim: int):
        self.dim = int(dim)
        self.n = 0
        self.mean = np.zeros(self.dim, dtype=np.float64)
        self.m2 = np.zeros(self.dim, dtype=np.float64)

    def update(self, x: np.ndarray) -> None:
        arr = np.asarray(x, dtype=np.float64)
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        if arr.ndim != 2 or arr.shape[1] != self.dim:
            raise ValueError(f"shape mismatch: expected (*,{self.dim}), got {arr.shape}")
        m = int(arr.shape[0])
        if m <= 0:
            return

        b_mean = np.mean(arr, axis=0)
        b_m2 = np.sum((arr - b_mean.reshape(1, -1)) ** 2, axis=0)

        if self.n == 0:
            self.n = m
            self.mean = b_mean
            self.m2 = b_m2
            return

        total = self.n + m
        delta = b_mean - self.mean
        self.mean = self.mean + delta * (m / total)
        self.m2 = self.m2 + b_m2 + (delta ** 2) * (self.n * m / total)
        self.n = total

    def finalize(self, eps: float = 1e-12) -> Tuple[np.ndarray, np.ndarray]:
        if self.n < 2:
            std = np.ones(self.dim, dtype=np.float64)
            return self.mean.astype(np.float64), std
        var = self.m2 / (self.n - 1)
        std = np.sqrt(np.maximum(var, eps))
        return self.mean.astype(np.float64), std.astype(np.float64)


# =========================
# Template by No
# =========================


def _fill_missing_1d(vals: np.ndarray, mask: np.ndarray, is_angle: bool) -> np.ndarray:
    out = np.asarray(vals, dtype=np.float64).copy()
    m = np.asarray(mask, dtype=bool)
    idx = np.where(m)[0]
    if len(idx) == 0:
        return out
    if len(idx) == 1:
        out[:] = out[idx[0]]
        return out

    full = np.arange(len(out), dtype=np.float64)
    if is_angle:
        rad = np.deg2rad(out[idx])
        rad_unwrap = np.unwrap(rad)
        interp = np.interp(full, idx.astype(np.float64), rad_unwrap)
        out = wrap180(np.rad2deg(interp))
        return out

    interp = np.interp(full, idx.astype(np.float64), out[idx])
    return interp.astype(np.float64)


@dataclasses.dataclass
class TemplateStats:
    template_by_no: np.ndarray
    count_by_no: np.ndarray
    y_total_mean: np.ndarray
    y_total_std: np.ndarray
    rows: int


@dataclasses.dataclass
class SignConsistencyStats:
    ratio_by_col: np.ndarray
    valid_no_by_col: np.ndarray
    rows: int


def compute_sign_consistency_stats(
    stems: List[str],
    err_dir: Path,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> SignConsistencyStats:
    max_no = int(days_horizon * 24 * 60)
    ncol = len(TARGET_COLS)

    sum_val = np.zeros((max_no, ncol), dtype=np.float64)
    sum_abs = np.zeros((max_no, ncol), dtype=np.float64)
    cnt = np.zeros((max_no, ncol), dtype=np.int64)

    rows = 0
    for i, stem in enumerate(stems, start=1):
        err_path = err_dir / f"{stem}.csv"
        try:
            df = load_orbit_csv(err_path, require_targets=True)
            df = trim_horizon_and_stride(
                df,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] sign-consistency skip {stem}: {e}")
            continue

        if len(df) == 0:
            continue

        no = df["No"].to_numpy(np.int64)
        y = canonicalize_signed_error(df[TARGET_COLS].to_numpy(np.float64))
        valid = (no >= 1) & (no <= max_no)
        if not np.any(valid):
            continue

        no = no[valid]
        y = y[valid]
        idx = no - 1
        for j in range(ncol):
            np.add.at(sum_val[:, j], idx, y[:, j])
            np.add.at(sum_abs[:, j], idx, np.abs(y[:, j]))
            np.add.at(cnt[:, j], idx, 1)
        rows += len(no)

        if i % 25 == 0:
            log(f"[SIGN] {i}/{len(stems)} files, rows={rows}")

    ratio = np.full((ncol,), np.nan, dtype=np.float64)
    valid_no = np.zeros((ncol,), dtype=np.int64)
    for j in range(ncol):
        m = cnt[:, j] > 0
        if not np.any(m):
            continue
        mean = np.zeros(np.sum(m), dtype=np.float64)
        mean_abs = np.zeros(np.sum(m), dtype=np.float64)
        c = cnt[m, j].astype(np.float64)
        mean[:] = sum_val[m, j] / c
        mean_abs[:] = sum_abs[m, j] / c
        vv = mean_abs > 1e-12
        if not np.any(vv):
            continue
        ratio[j] = float(np.mean(np.abs(mean[vv]) / mean_abs[vv]))
        valid_no[j] = int(np.sum(vv))

    return SignConsistencyStats(
        ratio_by_col=ratio,
        valid_no_by_col=valid_no,
        rows=int(rows),
    )


def compute_template(
    stems: List[str],
    err_dir: Path,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    error_repr_by_col: Sequence[str],
) -> TemplateStats:
    max_no = int(days_horizon * 24 * 60)
    rr = _normalize_repr_list(error_repr_by_col)

    angle_idx = [i for i, c in enumerate(TARGET_COLS) if c in ANGLE_COLS and rr[i] == ERROR_REPR_SIGNED]
    non_angle_idx = [i for i in range(len(TARGET_COLS)) if i not in angle_idx]

    lin_sum = np.zeros((max_no, len(non_angle_idx)), dtype=np.float64)
    lin_cnt = np.zeros((max_no, len(non_angle_idx)), dtype=np.int64)

    ang_sin_sum = np.zeros((max_no, len(angle_idx)), dtype=np.float64)
    ang_cos_sum = np.zeros((max_no, len(angle_idx)), dtype=np.float64)
    ang_cnt = np.zeros((max_no, len(angle_idx)), dtype=np.int64)

    y_stat = OnlineMeanVar(dim=len(TARGET_COLS))
    rows = 0

    for i, stem in enumerate(stems, start=1):
        err_path = err_dir / f"{stem}.csv"
        try:
            df = load_orbit_csv(err_path, require_targets=True)
            df = trim_horizon_and_stride(
                df,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] template skip {stem}: {e}")
            continue

        if len(df) == 0:
            continue

        no = df["No"].to_numpy(np.int64)
        y_signed = df[TARGET_COLS].to_numpy(np.float64)
        y = to_model_error_repr(y_signed, rr)
        valid = (no >= 1) & (no <= max_no)
        if not np.any(valid):
            continue

        no = no[valid]
        y = y[valid]
        idx = no - 1

        if non_angle_idx:
            y_lin = y[:, non_angle_idx]
            lin_sum[idx, :] += y_lin
            lin_cnt[idx, :] += 1

        if angle_idx:
            y_ang_rad = np.deg2rad(y[:, angle_idx])
            ang_sin_sum[idx, :] += np.sin(y_ang_rad)
            ang_cos_sum[idx, :] += np.cos(y_ang_rad)
            ang_cnt[idx, :] += 1

        y_stat.update(y)
        rows += len(y)

        if i % 25 == 0:
            log(f"[TEMPLATE] {i}/{len(stems)} files, rows={rows}")

    template = np.zeros((max_no, len(TARGET_COLS)), dtype=np.float64)
    count = np.zeros((max_no,), dtype=np.int64)

    for pos, col_idx in enumerate(non_angle_idx):
        c = lin_cnt[:, pos]
        m = c > 0
        template[m, col_idx] = lin_sum[m, pos] / c[m]
        count[m] = np.maximum(count[m], c[m])

    for pos, col_idx in enumerate(angle_idx):
        c = ang_cnt[:, pos]
        m = c > 0
        template[m, col_idx] = np.rad2deg(np.arctan2(ang_sin_sum[m, pos], ang_cos_sum[m, pos]))
        count[m] = np.maximum(count[m], c[m])

    # Fill missing No slots by interpolation to avoid discontinuities.
    for j, col in enumerate(TARGET_COLS):
        if j in angle_idx:
            mask = ang_cnt[:, angle_idx.index(j)] > 0 if j in angle_idx else (count > 0)
            template[:, j] = _fill_missing_1d(template[:, j], mask, is_angle=True)
        else:
            mask = lin_cnt[:, non_angle_idx.index(j)] > 0 if j in non_angle_idx else (count > 0)
            template[:, j] = _fill_missing_1d(template[:, j], mask, is_angle=False)

    y_mean, y_std = y_stat.finalize()
    y_std = np.where(y_std < 1e-9, 1.0, y_std)

    return TemplateStats(
        template_by_no=template,
        count_by_no=count,
        y_total_mean=y_mean,
        y_total_std=y_std,
        rows=rows,
    )


def lookup_template(template_by_no: np.ndarray, no: np.ndarray) -> np.ndarray:
    if len(template_by_no) == 0:
        return np.zeros((len(no), len(TARGET_COLS)), dtype=np.float64)
    idx = np.asarray(no, dtype=np.int64) - 1
    idx = np.clip(idx, 0, len(template_by_no) - 1)
    return template_by_no[idx]


# =========================
# Features (No + TLE only; template is No-derived prior)
# =========================


@dataclasses.dataclass
class FeatureConfig:
    day_harmonics: int = 6
    span_harmonics: int = 4
    include_sidereal: bool = True
    include_interactions: bool = True
    include_template_feature: bool = True
    include_baseline_feature: bool = False


def _sincos_deg_scalar(deg: float) -> Tuple[float, float]:
    r = math.radians(float(deg))
    return math.sin(r), math.cos(r)


def tle_feature_vector(tle: TLEInfo) -> Tuple[np.ndarray, List[str]]:
    inc_s, inc_c = _sincos_deg_scalar(tle.inc_deg)
    raan_s, raan_c = _sincos_deg_scalar(tle.raan_deg)
    argp_s, argp_c = _sincos_deg_scalar(tle.argp_deg)
    ma_s, ma_c = _sincos_deg_scalar(tle.mean_anom_deg)

    epoch_day_norm = float(tle.epoch_day) / 366.0
    epoch_day_frac = float(tle.epoch_day) - math.floor(float(tle.epoch_day))

    vals = np.array(
        [
            tle.inc_deg,
            inc_s,
            inc_c,
            tle.raan_deg,
            raan_s,
            raan_c,
            tle.ecc,
            tle.argp_deg,
            argp_s,
            argp_c,
            tle.mean_anom_deg,
            ma_s,
            ma_c,
            tle.mean_motion_rev_per_day,
            tle.bstar,
            tle.ndot,
            tle.nddot,
            epoch_day_norm,
            epoch_day_frac,
        ],
        dtype=np.float64,
    )
    names = [
        "tle_inc_deg",
        "tle_inc_sin",
        "tle_inc_cos",
        "tle_raan_deg",
        "tle_raan_sin",
        "tle_raan_cos",
        "tle_ecc",
        "tle_argp_deg",
        "tle_argp_sin",
        "tle_argp_cos",
        "tle_mean_anom_deg",
        "tle_mean_anom_sin",
        "tle_mean_anom_cos",
        "tle_mean_motion_rev_per_day",
        "tle_bstar",
        "tle_ndot",
        "tle_nddot",
        "tle_epoch_day_norm",
        "tle_epoch_day_frac",
    ]
    return vals, names


def build_no_features(
    no: np.ndarray,
    total_rows: int,
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, List[str], Dict[str, np.ndarray]]:
    no_f = np.asarray(no, dtype=np.float64)
    if no_f.ndim != 1:
        raise ValueError("No must be 1-D")
    if len(no_f) == 0:
        empty = np.zeros((0,), dtype=np.float64)
        return np.zeros((0, 1), dtype=np.float64), ["no_norm"], {
            "no_norm": empty,
            "span_sin_1": empty,
            "span_cos_1": empty,
        }

    denom = float(max(1, total_rows - 1))
    minute_index = no_f - 1.0
    no_norm = np.clip(minute_index / denom, 0.0, 1.0)
    no_norm2 = no_norm * no_norm
    no_norm3 = no_norm2 * no_norm

    feats: List[np.ndarray] = [no_norm, no_norm2, no_norm3]
    names: List[str] = ["no_norm", "no_norm2", "no_norm3"]

    for k in range(1, int(cfg.day_harmonics) + 1):
        phase = 2.0 * math.pi * k * (minute_index / MINUTES_PER_DAY)
        feats.append(np.sin(phase))
        feats.append(np.cos(phase))
        names.append(f"day_sin_{k}")
        names.append(f"day_cos_{k}")

    if cfg.include_sidereal:
        phase = 2.0 * math.pi * (minute_index / SIDEREAL_PERIOD_MIN)
        feats.append(np.sin(phase))
        feats.append(np.cos(phase))
        names.append("sidereal_sin_1")
        names.append("sidereal_cos_1")

    span_sin_1 = np.zeros_like(no_norm)
    span_cos_1 = np.zeros_like(no_norm)
    for k in range(1, int(cfg.span_harmonics) + 1):
        phase = 2.0 * math.pi * k * no_norm
        s = np.sin(phase)
        c = np.cos(phase)
        feats.append(s)
        feats.append(c)
        names.append(f"span_sin_{k}")
        names.append(f"span_cos_{k}")
        if k == 1:
            span_sin_1 = s
            span_cos_1 = c

    x = np.stack(feats, axis=1).astype(np.float64)
    aux = {
        "no_norm": no_norm,
        "span_sin_1": span_sin_1,
        "span_cos_1": span_cos_1,
    }
    return x, names, aux


def build_baseline_features(
    baseline_at_no: np.ndarray,
) -> Tuple[np.ndarray, List[str]]:
    b = np.asarray(baseline_at_no, dtype=np.float64)
    if b.ndim != 2 or b.shape[1] != len(TARGET_COLS):
        raise ValueError(f"baseline_at_no shape mismatch: {b.shape}")
    n = b.shape[0]

    feats: List[np.ndarray] = []
    names: List[str] = []

    for i, col in enumerate(TARGET_COLS):
        v = b[:, i]
        if col in ANGLE_COLS:
            r = np.deg2rad(v)
            feats.append(np.sin(r))
            feats.append(np.cos(r))
            names.append(f"base_{col}_sin")
            names.append(f"base_{col}_cos")
        else:
            feats.append(v)
            names.append(f"base_{col}")

    az = np.deg2rad(b[:, TARGET_COLS.index("AZ")])
    el = np.deg2rad(np.clip(b[:, TARGET_COLS.index("EL")], -90.0, 90.0))
    ce = np.cos(el)
    feats.append(ce * np.cos(az))
    feats.append(ce * np.sin(az))
    feats.append(np.sin(el))
    names.extend(["base_los_x", "base_los_y", "base_los_z"])

    def lag_diff(v: np.ndarray, lag: int, is_angle: bool) -> np.ndarray:
        out = np.zeros((n,), dtype=np.float64)
        if n <= lag:
            return out
        if is_angle:
            out[lag:] = angle_diff_deg(v[lag:], v[:-lag])
        else:
            out[lag:] = v[lag:] - v[:-lag]
        return out

    for lag in (1, 5, 30):
        for i, col in enumerate(TARGET_COLS):
            d = lag_diff(b[:, i], lag=lag, is_angle=(col in ANGLE_COLS))
            feats.append(d)
            names.append(f"base_d{lag}_{col}")

    x = np.stack(feats, axis=1).astype(np.float64)
    return x, names


def build_design_matrix(
    no: np.ndarray,
    total_rows: int,
    tle: TLEInfo,
    template_at_no: np.ndarray,
    baseline_at_no: Optional[np.ndarray],
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, List[str]]:
    x_no, no_names, aux = build_no_features(no=no, total_rows=total_rows, cfg=cfg)
    tle_vec, tle_names = tle_feature_vector(tle)

    n = len(no)
    x_tle = np.repeat(tle_vec.reshape(1, -1), n, axis=0)

    feats: List[np.ndarray] = [x_no, x_tle]
    names: List[str] = list(no_names) + list(tle_names)

    if cfg.include_template_feature:
        tmp = np.asarray(template_at_no, dtype=np.float64)
        if tmp.shape != (n, len(TARGET_COLS)):
            raise ValueError(f"template_at_no shape mismatch: {tmp.shape}")
        feats.append(tmp)
        names.extend([f"template_{c}" for c in TARGET_COLS])

    if cfg.include_baseline_feature:
        if baseline_at_no is None:
            raise ValueError("baseline features enabled but baseline_at_no is None")
        bfeat, bnames = build_baseline_features(baseline_at_no=baseline_at_no)
        feats.append(bfeat)
        names.extend(bnames)

    if cfg.include_interactions:
        basis = [
            ("no_norm", aux["no_norm"]),
            ("span_sin_1", aux["span_sin_1"]),
            ("span_cos_1", aux["span_cos_1"]),
        ]
        interact_keys = {
            "tle_inc_deg",
            "tle_raan_sin",
            "tle_raan_cos",
            "tle_ecc",
            "tle_argp_sin",
            "tle_argp_cos",
            "tle_mean_anom_sin",
            "tle_mean_anom_cos",
            "tle_mean_motion_rev_per_day",
            "tle_bstar",
            "tle_ndot",
            "tle_nddot",
        }
        idx = [i for i, name in enumerate(tle_names) if name in interact_keys]
        if idx:
            x_tle_sel = x_tle[:, idx]
            tle_sel_names = [tle_names[i] for i in idx]
            for b_name, b in basis:
                z = b.reshape(-1, 1) * x_tle_sel
                feats.append(z)
                names.extend([f"{b_name}*{tn}" for tn in tle_sel_names])

    x = np.concatenate(feats, axis=1).astype(np.float64)
    return x, names


# =========================
# Pair loading for train/eval/infer
# =========================


def build_residual_target(
    y_total: np.ndarray,
    template_at_no: np.ndarray,
    error_repr_by_col: Sequence[str],
) -> np.ndarray:
    y = np.asarray(y_total, dtype=np.float64)
    t = np.asarray(template_at_no, dtype=np.float64)
    rr = _normalize_repr_list(error_repr_by_col)
    if y.shape != t.shape:
        raise ValueError(f"shape mismatch y={y.shape}, template={t.shape}")

    r = np.zeros_like(y)
    for i, col in enumerate(TARGET_COLS):
        if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
            r[:, i] = angle_diff_deg(y[:, i], t[:, i])
        else:
            r[:, i] = y[:, i] - t[:, i]
    return r


def reconstruct_total_error(
    template_at_no: np.ndarray,
    y_resid_pred: np.ndarray,
    error_repr_by_col: Sequence[str],
) -> np.ndarray:
    t = np.asarray(template_at_no, dtype=np.float64)
    r = np.asarray(y_resid_pred, dtype=np.float64)
    rr = _normalize_repr_list(error_repr_by_col)
    if t.shape != r.shape:
        raise ValueError(f"shape mismatch template={t.shape}, resid={r.shape}")

    y = np.zeros_like(t)
    for i, col in enumerate(TARGET_COLS):
        if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
            y[:, i] = wrap180(t[:, i] + r[:, i])
        else:
            y[:, i] = t[:, i] + r[:, i]
        if rr[i] == ERROR_REPR_ABS:
            y[:, i] = np.maximum(0.0, y[:, i])
    return y


def load_train_pair(
    stem: str,
    tle_dir: Path,
    err_dir: Path,
    pred_dir: Optional[Path],
    template_by_no: np.ndarray,
    cfg: FeatureConfig,
    error_repr_by_col: Sequence[str],
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str]]:
    tle = parse_tle_file(tle_dir / f"{stem}.txt")
    df = load_orbit_csv(err_dir / f"{stem}.csv", require_targets=True)
    df = trim_horizon_and_stride(
        df,
        days_horizon=days_horizon,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    if len(df) == 0:
        return (
            np.zeros((0, 1), dtype=np.float64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0,), dtype=np.int64),
            ["dummy"],
        )

    no = df["No"].to_numpy(np.int64)
    total_rows = int(max(1, int(df["No"].max())))
    y_total_signed = df[TARGET_COLS].to_numpy(np.float64)
    baseline_at_no: Optional[np.ndarray] = None

    if cfg.include_baseline_feature:
        if pred_dir is None:
            raise ValueError("include_baseline_feature=True requires pred_dir")
        bpath = pred_dir / f"{stem}.csv"
        bdf = load_orbit_csv(bpath, require_targets=True)
        bdf = trim_horizon_and_stride(
            bdf,
            days_horizon=days_horizon,
            step_minutes=step_minutes,
            sample_every=sample_every,
        )
        merged = (
            df[["No"] + TARGET_COLS]
            .merge(
                bdf[["No"] + TARGET_COLS],
                on="No",
                how="inner",
                suffixes=("_err", "_base"),
            )
            .sort_values("No")
            .reset_index(drop=True)
        )
        if len(merged) == 0:
            raise ValueError(f"no matching No rows between error and baseline for {stem}")
        no = merged["No"].to_numpy(np.int64)
        total_rows = int(max(1, int(merged["No"].max())))
        y_total_signed = merged[[f"{c}_err" for c in TARGET_COLS]].to_numpy(np.float64)
        baseline_at_no = merged[[f"{c}_base" for c in TARGET_COLS]].to_numpy(np.float64)

    y_total = to_model_error_repr(y_total_signed, error_repr_by_col)

    template_at_no = lookup_template(template_by_no, no)
    y_resid = build_residual_target(
        y_total=y_total,
        template_at_no=template_at_no,
        error_repr_by_col=error_repr_by_col,
    )

    x, names = build_design_matrix(
        no=no,
        total_rows=total_rows,
        tle=tle,
        template_at_no=template_at_no,
        baseline_at_no=baseline_at_no,
        cfg=cfg,
    )
    return x, y_resid, y_total, no, names


def load_infer_pair(
    tle_file: Path,
    baseline_csv: Path,
    template_by_no: np.ndarray,
    cfg: FeatureConfig,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray, List[str]]:
    tle = parse_tle_file(tle_file)
    df = load_orbit_csv(baseline_csv, require_targets=True)
    df = trim_horizon_and_stride(
        df,
        days_horizon=days_horizon,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    if len(df) == 0:
        return df, np.zeros((0, 1), dtype=np.float64), np.zeros((0,), dtype=np.int64), ["dummy"]

    no = df["No"].to_numpy(np.int64)
    total_rows = int(max(1, int(df["No"].max())))
    template_at_no = lookup_template(template_by_no, no)
    baseline_at_no = df[TARGET_COLS].to_numpy(np.float64)

    x, names = build_design_matrix(
        no=no,
        total_rows=total_rows,
        tle=tle,
        template_at_no=template_at_no,
        baseline_at_no=(baseline_at_no if cfg.include_baseline_feature else None),
        cfg=cfg,
    )
    return df, x, no, names


# =========================
# Scaling / model bundle
# =========================


@dataclasses.dataclass
class ModelBundle:
    feature_cfg: FeatureConfig
    feature_names: List[str]
    x_mean: np.ndarray
    x_std: np.ndarray
    y_mean: np.ndarray
    y_std: np.ndarray
    y_total_std: np.ndarray
    template_by_no: np.ndarray
    template_count_by_no: np.ndarray
    alpha_vec: np.ndarray
    clip_k_sigma: Optional[float]
    clip_k_sigma_vec: np.ndarray
    alpha_schedule_edges_days: np.ndarray
    alpha_schedule_matrix: np.ndarray
    gate_targets: List[str]
    gate_edges_by_col: Dict[str, List[float]]
    gate_beta_by_col: Dict[str, List[float]]
    error_definition: str
    error_repr_mode: str
    error_repr_by_col: List[str]
    sign_consistency_ratio: np.ndarray
    train_rows: int
    train_files: int
    val_files: int


def scale_x(x: np.ndarray, x_mean: np.ndarray, x_std: np.ndarray) -> np.ndarray:
    return ((x - x_mean.reshape(1, -1)) / x_std.reshape(1, -1)).astype(np.float32)


def scale_y(y: np.ndarray, y_mean: np.ndarray, y_std: np.ndarray) -> np.ndarray:
    return ((y - y_mean.reshape(1, -1)) / y_std.reshape(1, -1)).astype(np.float32)


def unscale_y(y_scaled: np.ndarray, y_mean: np.ndarray, y_std: np.ndarray) -> np.ndarray:
    return (y_scaled * y_std.reshape(1, -1) + y_mean.reshape(1, -1)).astype(np.float64)


def compute_scalers(
    stems: List[str],
    tle_dir: Path,
    err_dir: Path,
    pred_dir: Optional[Path],
    template_by_no: np.ndarray,
    cfg: FeatureConfig,
    error_repr_by_col: Sequence[str],
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str], int]:
    x_stat: Optional[OnlineMeanVar] = None
    y_stat = OnlineMeanVar(dim=len(TARGET_COLS))
    feature_names: Optional[List[str]] = None
    rows = 0

    for i, stem in enumerate(stems, start=1):
        try:
            x, y_resid, _, _, names = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                err_dir=err_dir,
                pred_dir=pred_dir,
                template_by_no=template_by_no,
                cfg=cfg,
                error_repr_by_col=error_repr_by_col,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] scaler skip {stem}: {e}")
            continue

        if len(x) == 0:
            continue

        if x_stat is None:
            x_stat = OnlineMeanVar(dim=x.shape[1])
            feature_names = names
        elif x.shape[1] != x_stat.dim:
            raise ValueError(f"feature dim mismatch for {stem}: {x.shape[1]} vs {x_stat.dim}")

        x_stat.update(x)
        y_stat.update(y_resid)
        rows += len(x)

        if i % 25 == 0:
            log(f"[SCALER] {i}/{len(stems)} files, rows={rows}")

    if x_stat is None or feature_names is None or rows == 0:
        raise RuntimeError("no usable rows for scaler computation")

    x_mean, x_std = x_stat.finalize()
    y_mean, y_std = y_stat.finalize()

    x_std = np.where(x_std < 1e-9, 1.0, x_std)
    y_std = np.where(y_std < 1e-9, 1.0, y_std)
    return x_mean, x_std, y_mean, y_std, feature_names, rows


# =========================
# TensorFlow model
# =========================


def build_mlp_model(
    input_dim: int,
    hidden: Sequence[int],
    dropout: float,
    l2: float,
) -> "tf.keras.Model":
    require_tensorflow()

    x_in = tf.keras.Input(shape=(input_dim,), name="x")
    h = x_in
    l2_reg = tf.keras.regularizers.l2(l2) if l2 > 0 else None

    for i, units in enumerate(hidden):
        h = tf.keras.layers.Dense(units, activation=None, kernel_regularizer=l2_reg, name=f"dense_{i}")(h)
        h = tf.keras.layers.LayerNormalization(name=f"ln_{i}")(h)
        h = tf.keras.layers.Activation("swish", name=f"act_{i}")(h)
        if dropout > 0:
            h = tf.keras.layers.Dropout(dropout, name=f"drop_{i}")(h)

    out = tf.keras.layers.Dense(len(TARGET_COLS), activation=None, name="residual_out")(h)
    model = tf.keras.Model(inputs=x_in, outputs=out, name="no_tle_residual_mlp")
    return model


def build_weighted_huber_loss(
    delta: float,
    target_weights: np.ndarray,
):
    require_tensorflow()
    w = tf.constant(np.asarray(target_weights, dtype=np.float32).reshape(1, -1), dtype=tf.float32)
    d = tf.constant(float(delta), dtype=tf.float32)

    def _loss(y_true, y_pred):
        e = y_pred - y_true
        ae = tf.abs(e)
        q = tf.minimum(ae, d)
        lin = ae - q
        huber = 0.5 * tf.square(q) + d * lin
        weighted = huber * w
        return tf.reduce_mean(tf.reduce_sum(weighted, axis=-1))

    return _loss


def _model_predict_residual(
    model: "tf.keras.Model",
    x: np.ndarray,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    batch_size: int,
) -> np.ndarray:
    x_s = scale_x(x, x_mean=x_mean, x_std=x_std)
    y_resid_s = model.predict(x_s, batch_size=int(batch_size), verbose=0)
    return unscale_y(y_resid_s, y_mean=y_mean, y_std=y_std)


def _apply_alpha_and_clip(
    y_pred_total: np.ndarray,
    no: Optional[np.ndarray],
    alpha_vec: np.ndarray,
    alpha_schedule_edges_days: Optional[np.ndarray],
    alpha_schedule_matrix: Optional[np.ndarray],
    clip_k_sigma: Optional[float],
    clip_k_sigma_vec: Optional[np.ndarray],
    y_total_std: np.ndarray,
    error_repr_by_col: Sequence[str],
    azel_abs_cap_deg: Optional[float] = None,
) -> np.ndarray:
    y = np.asarray(y_pred_total, dtype=np.float64).copy()
    rr = _normalize_repr_list(error_repr_by_col)

    alpha_row = np.repeat(np.asarray(alpha_vec, dtype=np.float64).reshape(1, -1), y.shape[0], axis=0)
    if (
        no is not None
        and alpha_schedule_edges_days is not None
        and alpha_schedule_matrix is not None
        and len(alpha_schedule_edges_days) >= 2
    ):
        edges = np.asarray(alpha_schedule_edges_days, dtype=np.float64).reshape(-1)
        sch = np.asarray(alpha_schedule_matrix, dtype=np.float64)
        if sch.ndim == 2 and sch.shape[1] == len(TARGET_COLS) and sch.shape[0] == (len(edges) - 1):
            day = (np.asarray(no, dtype=np.float64).reshape(-1) - 1.0) / MINUTES_PER_DAY
            bin_idx = np.searchsorted(edges, day, side="right") - 1
            bin_idx = np.clip(bin_idx, 0, sch.shape[0] - 1)
            alpha_row = sch[bin_idx, :]

    y = y * alpha_row

    if clip_k_sigma_vec is not None:
        ck = np.asarray(clip_k_sigma_vec, dtype=np.float64).reshape(-1)
        if ck.shape[0] != len(TARGET_COLS):
            raise ValueError(f"clip_k_sigma_vec length mismatch: {ck.shape}")
        for i in range(len(TARGET_COLS)):
            if np.isfinite(ck[i]) and ck[i] > 0:
                lim = float(ck[i]) * float(y_total_std[i])
                if rr[i] == ERROR_REPR_ABS:
                    y[:, i] = np.clip(y[:, i], 0.0, lim)
                else:
                    y[:, i] = np.clip(y[:, i], -lim, lim)
    elif clip_k_sigma is not None and clip_k_sigma > 0:
        for i in range(len(TARGET_COLS)):
            lim = float(clip_k_sigma) * float(y_total_std[i])
            if rr[i] == ERROR_REPR_ABS:
                y[:, i] = np.clip(y[:, i], 0.0, lim)
            else:
                y[:, i] = np.clip(y[:, i], -lim, lim)

    if azel_abs_cap_deg is not None and azel_abs_cap_deg > 0:
        cap = float(azel_abs_cap_deg)
        az_idx = TARGET_COLS.index("AZ")
        el_idx = TARGET_COLS.index("EL")
        if rr[az_idx] == ERROR_REPR_ABS:
            y[:, az_idx] = np.clip(y[:, az_idx], 0.0, cap)
        else:
            y[:, az_idx] = np.clip(y[:, az_idx], -cap, cap)
        if rr[el_idx] == ERROR_REPR_ABS:
            y[:, el_idx] = np.clip(y[:, el_idx], 0.0, cap)
        else:
            y[:, el_idx] = np.clip(y[:, el_idx], -cap, cap)

    # keep angle range stable
    for i, col in enumerate(TARGET_COLS):
        if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
            y[:, i] = wrap180(y[:, i])
        if rr[i] == ERROR_REPR_ABS:
            y[:, i] = np.maximum(0.0, y[:, i])
    return y


# =========================
# Eval / calibration (on error files)
# =========================


def _error_residual(
    y_true_error: np.ndarray,
    y_pred_error: np.ndarray,
    col: str,
    repr_kind: str,
) -> np.ndarray:
    if repr_kind == ERROR_REPR_SIGNED and col in ANGLE_COLS:
        return angle_diff_deg(y_true_error, y_pred_error)
    return y_true_error - y_pred_error


def evaluate_on_error_files(
    stems: List[str],
    tle_dir: Path,
    err_dir: Path,
    pred_dir: Optional[Path],
    cfg: FeatureConfig,
    template_by_no: np.ndarray,
    error_repr_by_col: Sequence[str],
    model: "tf.keras.Model",
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    y_total_std: np.ndarray,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    alpha_vec: Optional[np.ndarray],
    alpha_schedule_edges_days: Optional[np.ndarray],
    alpha_schedule_matrix: Optional[np.ndarray],
    gate_targets: Optional[Sequence[str]],
    gate_edges_by_col: Optional[Dict[str, List[float]]],
    gate_beta_by_col: Optional[Dict[str, List[float]]],
    clip_k_sigma: Optional[float],
    clip_k_sigma_vec: Optional[np.ndarray] = None,
    azel_abs_cap_deg: Optional[float] = None,
) -> Dict[str, float]:
    if not stems:
        return {}
    rr = _normalize_repr_list(error_repr_by_col)

    if alpha_vec is None:
        alpha_use = np.ones((len(TARGET_COLS),), dtype=np.float64)
    else:
        alpha_use = np.asarray(alpha_vec, dtype=np.float64).reshape(-1)
        if alpha_use.shape[0] != len(TARGET_COLS):
            raise ValueError(f"alpha length mismatch: {alpha_use.shape}")

    sum_base = np.zeros(len(TARGET_COLS), dtype=np.float64)
    sum_corr = np.zeros(len(TARGET_COLS), dtype=np.float64)
    rows = 0

    for stem in stems:
        try:
            x, _, y_total, no, _ = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                err_dir=err_dir,
                pred_dir=pred_dir,
                template_by_no=template_by_no,
                cfg=cfg,
                error_repr_by_col=rr,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] eval skip {stem}: {e}")
            continue

        if len(x) == 0:
            continue

        template_at_no = lookup_template(template_by_no, no)
        y_resid_pred = _model_predict_residual(
            model=model,
            x=x,
            x_mean=x_mean,
            x_std=x_std,
            y_mean=y_mean,
            y_std=y_std,
            batch_size=batch_size,
        )
        y_pred_total = reconstruct_total_error(
            template_at_no=template_at_no,
            y_resid_pred=y_resid_pred,
            error_repr_by_col=rr,
        )
        y_pred_total = _apply_alpha_and_clip(
            y_pred_total=y_pred_total,
            no=no,
            alpha_vec=alpha_use,
            alpha_schedule_edges_days=alpha_schedule_edges_days,
            alpha_schedule_matrix=alpha_schedule_matrix,
            clip_k_sigma=clip_k_sigma,
            clip_k_sigma_vec=clip_k_sigma_vec,
            y_total_std=y_total_std,
            error_repr_by_col=rr,
            azel_abs_cap_deg=azel_abs_cap_deg,
        )
        if gate_targets and gate_edges_by_col is not None and gate_beta_by_col is not None:
            y_pred_total = apply_magnitude_gate(
                y_pred_total=y_pred_total,
                gate_targets=gate_targets,
                gate_edges_by_col=gate_edges_by_col,
                gate_beta_by_col=gate_beta_by_col,
            )

        for i, col in enumerate(TARGET_COLS):
            yb = y_total[:, i]
            if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
                yb = wrap180(yb)
            rc = _error_residual(
                y_true_error=y_total[:, i],
                y_pred_error=y_pred_total[:, i],
                col=col,
                repr_kind=rr[i],
            )

            sum_base[i] += np.sum(yb * yb)
            sum_corr[i] += np.sum(rc * rc)

        rows += len(x)

    if rows == 0:
        return {}

    mse_base = sum_base / rows
    mse_corr = sum_corr / rows
    rmse_base = np.sqrt(mse_base)
    rmse_corr = np.sqrt(mse_corr)

    out: Dict[str, float] = {"rows": float(rows)}
    for i, col in enumerate(TARGET_COLS):
        out[f"{col}_MSE_base"] = float(mse_base[i])
        out[f"{col}_MSE_corr"] = float(mse_corr[i])
        out[f"{col}_RMSE_base"] = float(rmse_base[i])
        out[f"{col}_RMSE_corr"] = float(rmse_corr[i])

    out["global_MSE_base"] = float(np.mean(mse_base))
    out["global_MSE_corr"] = float(np.mean(mse_corr))
    out["global_RMSE_base"] = float(np.sqrt(out["global_MSE_base"]))
    out["global_RMSE_corr"] = float(np.sqrt(out["global_MSE_corr"]))
    if out["global_RMSE_base"] > 0:
        out["global_RMSE_improve_pct"] = float(
            100.0 * (out["global_RMSE_base"] - out["global_RMSE_corr"]) / out["global_RMSE_base"]
        )
    else:
        out["global_RMSE_improve_pct"] = float("nan")
    return out


def fit_alpha_vector(
    stems: List[str],
    tle_dir: Path,
    err_dir: Path,
    pred_dir: Optional[Path],
    cfg: FeatureConfig,
    template_by_no: np.ndarray,
    error_repr_by_col: Sequence[str],
    model: "tf.keras.Model",
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    alpha_min: float,
    alpha_max: float,
) -> np.ndarray:
    rr = _normalize_repr_list(error_repr_by_col)
    sum_yp = np.zeros(len(TARGET_COLS), dtype=np.float64)
    sum_pp = np.zeros(len(TARGET_COLS), dtype=np.float64)

    for stem in stems:
        try:
            x, _, y_total, no, _ = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                err_dir=err_dir,
                pred_dir=pred_dir,
                template_by_no=template_by_no,
                cfg=cfg,
                error_repr_by_col=rr,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception:
            continue
        if len(x) == 0:
            continue

        template_at_no = lookup_template(template_by_no, no)
        y_resid_pred = _model_predict_residual(
            model=model,
            x=x,
            x_mean=x_mean,
            x_std=x_std,
            y_mean=y_mean,
            y_std=y_std,
            batch_size=batch_size,
        )
        y_pred_total = reconstruct_total_error(
            template_at_no=template_at_no,
            y_resid_pred=y_resid_pred,
            error_repr_by_col=rr,
        )

        for i, col in enumerate(TARGET_COLS):
            yv = y_total[:, i]
            pv = y_pred_total[:, i]
            if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
                yv = wrap180(yv)
                pv = wrap180(pv)
            sum_yp[i] += np.sum(yv * pv)
            sum_pp[i] += np.sum(pv * pv)

    alpha = np.zeros(len(TARGET_COLS), dtype=np.float64)
    m = sum_pp > 1e-12
    alpha[m] = sum_yp[m] / sum_pp[m]
    alpha = np.clip(alpha, float(alpha_min), float(alpha_max))
    return alpha


def _rmse_error_col(
    y_true_error: np.ndarray,
    y_pred_error: np.ndarray,
    col: str,
    repr_kind: str,
    trim_quantile: Optional[float] = None,
) -> float:
    r = _error_residual(
        y_true_error=y_true_error,
        y_pred_error=y_pred_error,
        col=col,
        repr_kind=repr_kind,
    )
    if trim_quantile is not None and 0.0 < float(trim_quantile) < 1.0 and len(r) > 10:
        a = np.abs(r)
        lim = float(np.quantile(a, float(trim_quantile)))
        m = a <= lim
        if np.any(m):
            r = r[m]
    return float(np.sqrt(np.mean(r**2)))


def collect_calibration_arrays(
    stems: List[str],
    tle_dir: Path,
    err_dir: Path,
    pred_dir: Optional[Path],
    cfg: FeatureConfig,
    template_by_no: np.ndarray,
    error_repr_by_col: Sequence[str],
    model: "tf.keras.Model",
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    rr = _normalize_repr_list(error_repr_by_col)
    y_true_list: List[np.ndarray] = []
    y_pred_raw_list: List[np.ndarray] = []
    no_list: List[np.ndarray] = []

    for stem in stems:
        try:
            x, _, y_total, no, _ = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                err_dir=err_dir,
                pred_dir=pred_dir,
                template_by_no=template_by_no,
                cfg=cfg,
                error_repr_by_col=rr,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception:
            continue
        if len(x) == 0:
            continue

        template_at_no = lookup_template(template_by_no, no)
        y_resid_pred = _model_predict_residual(
            model=model,
            x=x,
            x_mean=x_mean,
            x_std=x_std,
            y_mean=y_mean,
            y_std=y_std,
            batch_size=batch_size,
        )
        y_pred_total_raw = reconstruct_total_error(
            template_at_no=template_at_no,
            y_resid_pred=y_resid_pred,
            error_repr_by_col=rr,
        )

        y_true_list.append(y_total.astype(np.float64))
        y_pred_raw_list.append(y_pred_total_raw.astype(np.float64))
        no_list.append(no.astype(np.int64))

    if not y_true_list:
        return (
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0,), dtype=np.int64),
        )

    y_true = np.concatenate(y_true_list, axis=0)
    y_pred_raw = np.concatenate(y_pred_raw_list, axis=0)
    no_all = np.concatenate(no_list, axis=0)
    return y_true, y_pred_raw, no_all


def calibrate_alpha_clip_per_target(
    y_true_total: np.ndarray,
    y_pred_total_raw: np.ndarray,
    y_total_std: np.ndarray,
    error_repr_by_col: Sequence[str],
    alpha_min: float,
    alpha_max: float,
    alpha_max_azel: float,
    alpha_max_az: Optional[float],
    alpha_max_el: Optional[float],
    alpha_grid_step: float,
    clip_candidates: List[Optional[float]],
    min_improve_pct: float,
    azel_alpha_shrink: float,
    azel_abs_cap_deg: Optional[float],
    calib_trim_quantile_azel: float,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Dict[str, float]]]:
    if len(y_true_total) == 0:
        alpha_vec = np.zeros((len(TARGET_COLS),), dtype=np.float64)
        clip_vec = np.full((len(TARGET_COLS),), np.nan, dtype=np.float64)
        return alpha_vec, clip_vec, {}
    rr = _normalize_repr_list(error_repr_by_col)

    if alpha_grid_step <= 0:
        raise ValueError(f"alpha_grid_step must be > 0, got {alpha_grid_step}")

    alpha_vec = np.zeros((len(TARGET_COLS),), dtype=np.float64)
    clip_vec = np.full((len(TARGET_COLS),), np.nan, dtype=np.float64)
    details: Dict[str, Dict[str, float]] = {}

    for i, col in enumerate(TARGET_COLS):
        y_true = y_true_total[:, i].astype(np.float64)
        y_raw = y_pred_total_raw[:, i].astype(np.float64)
        if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
            y_true = wrap180(y_true)
            y_raw = wrap180(y_raw)
        if rr[i] == ERROR_REPR_ABS:
            y_true = np.maximum(0.0, y_true)
            y_raw = np.maximum(0.0, y_raw)

        base_pred = np.zeros_like(y_true)
        tq = float(calib_trim_quantile_azel) if (col in ANTENNA_COLS and float(calib_trim_quantile_azel) > 0) else None
        base_rmse = _rmse_error_col(
            y_true_error=y_true,
            y_pred_error=base_pred,
            col=col,
            repr_kind=rr[i],
            trim_quantile=tq,
        )

        if col == "AZ" and alpha_max_az is not None:
            amax = float(alpha_max_az)
        elif col == "EL" and alpha_max_el is not None:
            amax = float(alpha_max_el)
        else:
            amax = float(alpha_max_azel if col in ANTENNA_COLS else alpha_max)
        amax = max(float(alpha_min), amax)
        alphas = np.arange(float(alpha_min), amax + 1e-12, float(alpha_grid_step), dtype=np.float64)
        if len(alphas) == 0:
            alphas = np.array([float(alpha_min)], dtype=np.float64)

        best_rmse = base_rmse
        best_alpha = 0.0
        best_ck: Optional[float] = None

        for a in alphas:
            pred_scaled = y_raw * float(a)
            for ck in clip_candidates:
                pred = pred_scaled.copy()
                if ck is not None and ck > 0:
                    lim = float(ck) * float(y_total_std[i])
                    if rr[i] == ERROR_REPR_ABS:
                        pred = np.clip(pred, 0.0, lim)
                    else:
                        pred = np.clip(pred, -lim, lim)
                if col in ANTENNA_COLS and azel_abs_cap_deg is not None and azel_abs_cap_deg > 0:
                    if rr[i] == ERROR_REPR_ABS:
                        pred = np.clip(pred, 0.0, float(azel_abs_cap_deg))
                    else:
                        pred = np.clip(pred, -float(azel_abs_cap_deg), float(azel_abs_cap_deg))
                if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
                    pred = wrap180(pred)
                if rr[i] == ERROR_REPR_ABS:
                    pred = np.maximum(0.0, pred)
                rmse = _rmse_error_col(
                    y_true_error=y_true,
                    y_pred_error=pred,
                    col=col,
                    repr_kind=rr[i],
                    trim_quantile=tq,
                )
                if rmse < best_rmse:
                    best_rmse = rmse
                    best_alpha = float(a)
                    best_ck = ck

        if base_rmse > 0:
            improve_pct = 100.0 * (base_rmse - best_rmse) / base_rmse
        else:
            improve_pct = 0.0

        if improve_pct < float(min_improve_pct):
            best_alpha = 0.0
            best_ck = None
            best_rmse = base_rmse

        if col in ANTENNA_COLS and best_alpha > 0:
            best_alpha = best_alpha * float(azel_alpha_shrink)
            pred = y_raw * best_alpha
            if best_ck is not None and best_ck > 0:
                lim = float(best_ck) * float(y_total_std[i])
                if rr[i] == ERROR_REPR_ABS:
                    pred = np.clip(pred, 0.0, lim)
                else:
                    pred = np.clip(pred, -lim, lim)
            if azel_abs_cap_deg is not None and azel_abs_cap_deg > 0:
                if rr[i] == ERROR_REPR_ABS:
                    pred = np.clip(pred, 0.0, float(azel_abs_cap_deg))
                else:
                    pred = np.clip(pred, -float(azel_abs_cap_deg), float(azel_abs_cap_deg))
            if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
                pred = wrap180(pred)
            if rr[i] == ERROR_REPR_ABS:
                pred = np.maximum(0.0, pred)
            shrunk_rmse = _rmse_error_col(
                y_true_error=y_true,
                y_pred_error=pred,
                col=col,
                repr_kind=rr[i],
                trim_quantile=tq,
            )
            if shrunk_rmse > base_rmse:
                best_alpha = 0.0
                best_ck = None
                best_rmse = base_rmse
            else:
                best_rmse = shrunk_rmse

        alpha_vec[i] = best_alpha
        clip_vec[i] = np.nan if best_ck is None else float(best_ck)
        details[col] = {
            "rmse_base": float(base_rmse),
            "rmse_calib": float(best_rmse),
            "alpha": float(best_alpha),
            "clip_k_sigma": float(best_ck) if best_ck is not None else float("nan"),
            "improve_pct": float(0.0 if base_rmse <= 0 else 100.0 * (base_rmse - best_rmse) / base_rmse),
        }

    return alpha_vec, clip_vec, details


def parse_clip_candidates(s: str) -> List[Optional[float]]:
    out: List[Optional[float]] = []
    for p in str(s).split(","):
        t = p.strip()
        if not t:
            continue
        v = float(t)
        if v <= 0:
            out.append(None)
        else:
            out.append(v)
    if not out:
        out = [None, 3.0, 5.0]
    return out


def parse_float_list_csv(s: str) -> List[float]:
    out: List[float] = []
    for p in str(s).split(","):
        t = p.strip()
        if not t:
            continue
        out.append(float(t))
    return out


def parse_target_list_csv(s: str) -> List[str]:
    tset = {c.upper(): c for c in TARGET_COLS}
    out: List[str] = []
    for p in str(s).split(","):
        t = p.strip().upper()
        if not t:
            continue
        if t not in tset:
            raise ValueError(f"unknown target in --alpha-schedule-targets: {p}")
        col = tset[t]
        if col not in out:
            out.append(col)
    return out


def parse_quantiles_csv(s: str) -> List[float]:
    vals = parse_float_list_csv(s)
    if not vals:
        vals = [0.0, 0.5, 0.8, 0.95, 1.0]
    vals = [float(v) for v in vals if np.isfinite(v)]
    vals = [min(1.0, max(0.0, v)) for v in vals]
    vals = sorted(set(vals))
    if vals[0] > 0.0:
        vals = [0.0] + vals
    if vals[-1] < 1.0:
        vals = vals + [1.0]
    if len(vals) < 2:
        vals = [0.0, 1.0]
    return vals


def fit_magnitude_gate(
    y_true_total: np.ndarray,
    y_pred_total: np.ndarray,
    error_repr_by_col: Sequence[str],
    target_cols: List[str],
    quantiles: List[float],
    beta_step: float,
    min_rows_per_bin: int,
    min_improve_pct: float,
    trim_quantile_azel: float,
) -> Tuple[Dict[str, List[float]], Dict[str, List[float]], Dict[str, Dict[str, float]]]:
    rr = _normalize_repr_list(error_repr_by_col)
    q = parse_quantiles_csv(",".join(str(v) for v in quantiles))
    if float(beta_step) <= 0:
        raise ValueError(f"beta_step must be >0, got {beta_step}")
    betas = np.arange(0.0, 1.0 + 1e-12, float(beta_step), dtype=np.float64)
    if len(betas) == 0:
        betas = np.array([0.0, 1.0], dtype=np.float64)

    edges_by_col: Dict[str, List[float]] = {}
    beta_by_col: Dict[str, List[float]] = {}
    details: Dict[str, Dict[str, float]] = {}

    for col in target_cols:
        if col not in TARGET_COLS:
            continue
        i = TARGET_COLS.index(col)
        y_true = y_true_total[:, i].astype(np.float64)
        y_pred = y_pred_total[:, i].astype(np.float64)
        if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
            y_true = wrap180(y_true)
            y_pred = wrap180(y_pred)
        if rr[i] == ERROR_REPR_ABS:
            y_true = np.maximum(0.0, y_true)
            y_pred = np.maximum(0.0, y_pred)

        mag = np.abs(y_pred)
        if len(mag) == 0:
            continue
        qv = np.quantile(mag, q).astype(np.float64)
        qv = np.maximum.accumulate(qv)
        qv[0] = 0.0
        if qv[-1] <= 0:
            qv[-1] = 1e-12
        edges = qv.tolist()
        nb = max(1, len(edges) - 1)
        bin_beta: List[float] = []
        col_detail: Dict[str, float] = {}

        tq = float(trim_quantile_azel) if (col in ANTENNA_COLS and float(trim_quantile_azel) > 0) else None
        for b in range(nb):
            lo = edges[b]
            hi = edges[b + 1]
            if b < nb - 1:
                m = (mag >= lo) & (mag < hi)
            else:
                m = (mag >= lo) & (mag <= hi)
            n = int(np.sum(m))
            key = f"{lo:.6g}-{hi:.6g}"
            if n < int(min_rows_per_bin):
                bin_beta.append(0.0)
                col_detail[key] = 0.0
                continue

            yt = y_true[m]
            yp = y_pred[m]
            base_rmse = _rmse_error_col(
                y_true_error=yt,
                y_pred_error=np.zeros_like(yt),
                col=col,
                repr_kind=rr[i],
                trim_quantile=tq,
            )

            best_beta = 0.0
            best_rmse = base_rmse
            for be in betas:
                pr = yp * float(be)
                if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
                    pr = wrap180(pr)
                if rr[i] == ERROR_REPR_ABS:
                    pr = np.maximum(0.0, pr)
                rmse = _rmse_error_col(
                    y_true_error=yt,
                    y_pred_error=pr,
                    col=col,
                    repr_kind=rr[i],
                    trim_quantile=tq,
                )
                if rmse < best_rmse:
                    best_rmse = rmse
                    best_beta = float(be)

            improve_pct = float(0.0 if base_rmse <= 0 else 100.0 * (base_rmse - best_rmse) / base_rmse)
            if improve_pct < float(min_improve_pct):
                best_beta = 0.0
            bin_beta.append(float(best_beta))
            col_detail[key] = float(best_beta)

        edges_by_col[col] = [float(x) for x in edges]
        beta_by_col[col] = [float(x) for x in bin_beta]
        details[col] = col_detail

    return edges_by_col, beta_by_col, details


def apply_magnitude_gate(
    y_pred_total: np.ndarray,
    gate_targets: Sequence[str],
    gate_edges_by_col: Dict[str, List[float]],
    gate_beta_by_col: Dict[str, List[float]],
) -> np.ndarray:
    y = np.asarray(y_pred_total, dtype=np.float64).copy()
    for col in gate_targets:
        if col not in TARGET_COLS:
            continue
        edges = np.asarray(gate_edges_by_col.get(col, []), dtype=np.float64).reshape(-1)
        beta = np.asarray(gate_beta_by_col.get(col, []), dtype=np.float64).reshape(-1)
        if len(edges) < 2 or len(beta) != (len(edges) - 1):
            continue
        i = TARGET_COLS.index(col)
        mag = np.abs(y[:, i])
        idx = np.searchsorted(edges, mag, side="right") - 1
        idx = np.clip(idx, 0, len(beta) - 1)
        y[:, i] = y[:, i] * beta[idx]
    return y


def calibrate_alpha_schedule_per_target(
    y_true_total: np.ndarray,
    y_pred_total_raw: np.ndarray,
    no_all: np.ndarray,
    y_total_std: np.ndarray,
    error_repr_by_col: Sequence[str],
    base_alpha_vec: np.ndarray,
    target_cols: List[str],
    day_edges: List[float],
    alpha_min: float,
    alpha_max: float,
    alpha_max_azel: float,
    alpha_max_az: Optional[float],
    alpha_max_el: Optional[float],
    alpha_grid_step: float,
    clip_vec: Optional[np.ndarray],
    azel_abs_cap_deg: Optional[float],
    min_rows_per_bin: int,
    min_improve_pct: float,
    calib_trim_quantile_azel: float,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Dict[str, float]]]:
    rr = _normalize_repr_list(error_repr_by_col)
    alpha_base = np.asarray(base_alpha_vec, dtype=np.float64).reshape(-1)
    if alpha_base.shape[0] != len(TARGET_COLS):
        raise ValueError(f"base_alpha_vec length mismatch: {alpha_base.shape}")

    edges = np.asarray(day_edges, dtype=np.float64).reshape(-1)
    if len(edges) < 2:
        raise ValueError("--alpha-schedule-days must contain at least 2 values")
    if not np.all(np.diff(edges) > 0):
        raise ValueError("--alpha-schedule-days must be strictly increasing")

    nb = len(edges) - 1
    mat = np.repeat(alpha_base.reshape(1, -1), nb, axis=0)
    details: Dict[str, Dict[str, float]] = {}

    day = (np.asarray(no_all, dtype=np.float64).reshape(-1) - 1.0) / MINUTES_PER_DAY
    if len(day) != len(y_true_total):
        raise ValueError(f"no_all length mismatch: {len(day)} vs {len(y_true_total)}")

    for col in target_cols:
        if col not in TARGET_COLS:
            continue
        i = TARGET_COLS.index(col)
        col_info: Dict[str, float] = {}
        for b in range(nb):
            lo = float(edges[b])
            hi = float(edges[b + 1])
            m = (day >= lo) & (day < hi)
            n = int(np.sum(m))
            key = f"{lo:g}-{hi:g}"
            if n < int(min_rows_per_bin):
                col_info[key] = float(alpha_base[i])
                mat[b, i] = float(alpha_base[i])
                continue

            y_true = y_true_total[m, i].astype(np.float64)
            y_raw = y_pred_total_raw[m, i].astype(np.float64)
            if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
                y_true = wrap180(y_true)
                y_raw = wrap180(y_raw)
            if rr[i] == ERROR_REPR_ABS:
                y_true = np.maximum(0.0, y_true)
                y_raw = np.maximum(0.0, y_raw)

            tq = float(calib_trim_quantile_azel) if (col in ANTENNA_COLS and float(calib_trim_quantile_azel) > 0) else None
            base_rmse = _rmse_error_col(
                y_true,
                np.zeros_like(y_true),
                col=col,
                repr_kind=rr[i],
                trim_quantile=tq,
            )

            if col == "AZ" and alpha_max_az is not None:
                amax = float(alpha_max_az)
            elif col == "EL" and alpha_max_el is not None:
                amax = float(alpha_max_el)
            else:
                amax = float(alpha_max_azel if col in ANTENNA_COLS else alpha_max)
            amax = max(float(alpha_min), amax)
            alphas = np.arange(float(alpha_min), amax + 1e-12, float(alpha_grid_step), dtype=np.float64)
            if len(alphas) == 0:
                alphas = np.array([float(alpha_min)], dtype=np.float64)

            best_a = float(alpha_base[i])
            best_rmse = float("inf")
            for a in alphas:
                pred = y_raw * float(a)
                ck = None
                if clip_vec is not None and i < len(clip_vec):
                    ck = float(clip_vec[i]) if (np.isfinite(clip_vec[i]) and clip_vec[i] > 0) else None
                if ck is not None:
                    lim = ck * float(y_total_std[i])
                    if rr[i] == ERROR_REPR_ABS:
                        pred = np.clip(pred, 0.0, lim)
                    else:
                        pred = np.clip(pred, -lim, lim)
                if col in ANTENNA_COLS and azel_abs_cap_deg is not None and azel_abs_cap_deg > 0:
                    if rr[i] == ERROR_REPR_ABS:
                        pred = np.clip(pred, 0.0, float(azel_abs_cap_deg))
                    else:
                        pred = np.clip(pred, -float(azel_abs_cap_deg), float(azel_abs_cap_deg))
                if rr[i] == ERROR_REPR_SIGNED and col in ANGLE_COLS:
                    pred = wrap180(pred)
                if rr[i] == ERROR_REPR_ABS:
                    pred = np.maximum(0.0, pred)
                rmse = _rmse_error_col(
                    y_true,
                    pred,
                    col=col,
                    repr_kind=rr[i],
                    trim_quantile=tq,
                )
                if rmse < best_rmse:
                    best_rmse = rmse
                    best_a = float(a)

            improve_pct = float(0.0 if base_rmse <= 0 else 100.0 * (base_rmse - best_rmse) / base_rmse)
            if improve_pct < float(min_improve_pct):
                best_a = 0.0

            mat[b, i] = float(best_a)
            col_info[key] = float(best_a)
        details[col] = col_info

    return edges, mat, details


# =========================
# Save/load model
# =========================


def is_model_file(path: Path) -> bool:
    return path.suffix.lower() in (".keras", ".h5")


def resolve_model_and_meta(model_arg: Path) -> Tuple[Path, Path]:
    if model_arg.is_dir():
        return model_arg / "model.keras", model_arg / "meta.json"
    model_path = model_arg
    meta_path = model_arg.parent / "meta.json"
    return model_path, meta_path


def save_model_and_meta(
    model: "tf.keras.Model",
    bundle: ModelBundle,
    out_model: Path,
    overwrite: bool,
    extra: Optional[Dict] = None,
) -> Tuple[Path, Path]:
    require_tensorflow()

    if is_model_file(out_model):
        model_path = out_model
        meta_path = out_model.parent / "meta.json"
        if (model_path.exists() or meta_path.exists()) and not overwrite:
            raise FileExistsError(f"exists: {out_model} (use --overwrite)")
        ensure_dir(out_model.parent)
    else:
        ensure_dir(out_model)
        model_path = out_model / "model.keras"
        meta_path = out_model / "meta.json"
        if (model_path.exists() or meta_path.exists()) and not overwrite:
            raise FileExistsError(f"exists: {out_model} (use --overwrite)")

    model.save(str(model_path))

    clip_vec_json: List[Optional[float]] = []
    for v in np.asarray(bundle.clip_k_sigma_vec, dtype=np.float64).reshape(-1):
        if np.isfinite(v) and v > 0:
            clip_vec_json.append(float(v))
        else:
            clip_vec_json.append(None)

    payload = {
        "created_at_jst": now_jst_str(),
        "model_type": "no_tle_template_mlp",
        "feature_cfg": dataclasses.asdict(bundle.feature_cfg),
        "feature_names": bundle.feature_names,
        "target_cols": list(TARGET_COLS),
        "angle_cols": sorted(list(ANGLE_COLS)),
        "x_mean": bundle.x_mean.tolist(),
        "x_std": bundle.x_std.tolist(),
        "y_mean": bundle.y_mean.tolist(),
        "y_std": bundle.y_std.tolist(),
        "y_total_std": bundle.y_total_std.tolist(),
        "template_by_no": bundle.template_by_no.tolist(),
        "template_count_by_no": bundle.template_count_by_no.tolist(),
        "alpha_vec": bundle.alpha_vec.tolist(),
        "clip_k_sigma": None if bundle.clip_k_sigma is None else float(bundle.clip_k_sigma),
        "clip_k_sigma_vec": clip_vec_json,
        "alpha_schedule_edges_days": np.asarray(bundle.alpha_schedule_edges_days, dtype=np.float64).reshape(-1).tolist(),
        "alpha_schedule_matrix": np.asarray(bundle.alpha_schedule_matrix, dtype=np.float64).tolist(),
        "gate_targets": [str(c) for c in bundle.gate_targets],
        "gate_edges_by_col": {str(k): [float(x) for x in v] for k, v in bundle.gate_edges_by_col.items()},
        "gate_beta_by_col": {str(k): [float(x) for x in v] for k, v in bundle.gate_beta_by_col.items()},
        "error_definition": bundle.error_definition,
        "error_repr_mode": str(bundle.error_repr_mode),
        "error_repr_by_col": [str(v) for v in bundle.error_repr_by_col],
        "sign_consistency_ratio": np.asarray(bundle.sign_consistency_ratio, dtype=np.float64).reshape(-1).tolist(),
        "train_rows": int(bundle.train_rows),
        "train_files": int(bundle.train_files),
        "val_files": int(bundle.val_files),
    }
    if extra:
        payload["extra"] = extra

    meta_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return model_path, meta_path


def load_model_and_meta(model_arg: Path) -> Tuple["tf.keras.Model", ModelBundle, Dict]:
    require_tensorflow()

    model_path, meta_path = resolve_model_and_meta(model_arg)
    if not model_path.exists():
        raise FileNotFoundError(f"model not found: {model_path}")
    if not meta_path.exists():
        raise FileNotFoundError(f"meta not found: {meta_path}")

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    feature_cfg = FeatureConfig(**meta["feature_cfg"])

    clip_vec_raw = meta.get("clip_k_sigma_vec", [None] * len(TARGET_COLS))
    clip_vec_arr = np.full((len(TARGET_COLS),), np.nan, dtype=np.float64)
    for i in range(min(len(clip_vec_raw), len(TARGET_COLS))):
        v = clip_vec_raw[i]
        if v is not None:
            clip_vec_arr[i] = float(v)

    repr_by_col_raw = meta.get("error_repr_by_col", [ERROR_REPR_SIGNED] * len(TARGET_COLS))
    try:
        repr_by_col = _normalize_repr_list(repr_by_col_raw)
    except Exception:
        repr_by_col = [ERROR_REPR_SIGNED] * len(TARGET_COLS)
    sc_ratio = np.asarray(meta.get("sign_consistency_ratio", [np.nan] * len(TARGET_COLS)), dtype=np.float64)
    if sc_ratio.shape[0] != len(TARGET_COLS):
        sc_ratio = np.full((len(TARGET_COLS),), np.nan, dtype=np.float64)

    alpha_edges = np.asarray(meta.get("alpha_schedule_edges_days", []), dtype=np.float64).reshape(-1)
    alpha_mat = np.asarray(meta.get("alpha_schedule_matrix", []), dtype=np.float64)
    if alpha_mat.ndim == 1 and alpha_mat.size == 0:
        alpha_mat = np.zeros((0, len(TARGET_COLS)), dtype=np.float64)
    if alpha_mat.ndim != 2 or alpha_mat.shape[1] != len(TARGET_COLS):
        alpha_edges = np.zeros((0,), dtype=np.float64)
        alpha_mat = np.zeros((0, len(TARGET_COLS)), dtype=np.float64)
    if len(alpha_edges) != (alpha_mat.shape[0] + 1):
        alpha_edges = np.zeros((0,), dtype=np.float64)
        alpha_mat = np.zeros((0, len(TARGET_COLS)), dtype=np.float64)

    gate_targets_raw = meta.get("gate_targets", [])
    gate_targets: List[str] = []
    for c in gate_targets_raw:
        cs = str(c)
        if cs in TARGET_COLS and cs not in gate_targets:
            gate_targets.append(cs)
    gate_edges_by_col: Dict[str, List[float]] = {}
    gate_beta_by_col: Dict[str, List[float]] = {}
    gedge_raw = meta.get("gate_edges_by_col", {}) or {}
    gbeta_raw = meta.get("gate_beta_by_col", {}) or {}
    for col in gate_targets:
        ev = [float(x) for x in gedge_raw.get(col, [])]
        bv = [float(x) for x in gbeta_raw.get(col, [])]
        if len(ev) >= 2 and len(bv) == (len(ev) - 1):
            gate_edges_by_col[col] = ev
            gate_beta_by_col[col] = bv

    bundle = ModelBundle(
        feature_cfg=feature_cfg,
        feature_names=list(meta["feature_names"]),
        x_mean=np.asarray(meta["x_mean"], dtype=np.float64),
        x_std=np.asarray(meta["x_std"], dtype=np.float64),
        y_mean=np.asarray(meta["y_mean"], dtype=np.float64),
        y_std=np.asarray(meta["y_std"], dtype=np.float64),
        y_total_std=np.asarray(meta.get("y_total_std", [1.0] * len(TARGET_COLS)), dtype=np.float64),
        template_by_no=np.asarray(meta["template_by_no"], dtype=np.float64),
        template_count_by_no=np.asarray(meta.get("template_count_by_no", []), dtype=np.int64),
        alpha_vec=np.asarray(meta.get("alpha_vec", [1.0] * len(TARGET_COLS)), dtype=np.float64),
        clip_k_sigma=float(meta["clip_k_sigma"]) if meta.get("clip_k_sigma") is not None else None,
        clip_k_sigma_vec=clip_vec_arr,
        alpha_schedule_edges_days=alpha_edges,
        alpha_schedule_matrix=alpha_mat,
        gate_targets=gate_targets,
        gate_edges_by_col=gate_edges_by_col,
        gate_beta_by_col=gate_beta_by_col,
        error_definition=str(meta.get("error_definition", ERROR_DEF_PRED_MINUS_TRUE)),
        error_repr_mode=str(meta.get("error_repr_mode", ERROR_REPR_SIGNED)),
        error_repr_by_col=repr_by_col,
        sign_consistency_ratio=sc_ratio,
        train_rows=int(meta.get("train_rows", 0)),
        train_files=int(meta.get("train_files", 0)),
        val_files=int(meta.get("val_files", 0)),
    )

    model = tf.keras.models.load_model(str(model_path), compile=False)
    return model, bundle, meta


# =========================
# Metrics / correction / plots
# =========================


def _with_stem_suffix(path: Path, suffix: str) -> Path:
    return path.with_name(f"{path.stem}{suffix}{path.suffix}")


def build_signed_error_branches(
    y_pred_model_repr: np.ndarray,
    error_repr_by_col: Sequence[str],
) -> Tuple[np.ndarray, np.ndarray, bool]:
    rr = _normalize_repr_list(error_repr_by_col)
    y = np.asarray(y_pred_model_repr, dtype=np.float64)
    if y.ndim != 2 or y.shape[1] != len(TARGET_COLS):
        raise ValueError(f"y_pred_model_repr shape mismatch: {y.shape}")

    minus = np.zeros_like(y)
    plus = np.zeros_like(y)
    has_abs = False
    for i, col in enumerate(TARGET_COLS):
        if rr[i] == ERROR_REPR_ABS:
            mag = np.maximum(0.0, y[:, i])
            minus[:, i] = mag
            plus[:, i] = -mag
            has_abs = True
        else:
            v = y[:, i]
            if col in ANGLE_COLS:
                v = wrap180(v)
            minus[:, i] = v
            plus[:, i] = v
    return minus, plus, has_abs


def _select_branch_by_metrics(
    metrics_minus: pd.DataFrame,
    metrics_plus: pd.DataFrame,
    branch_select: str,
) -> str:
    mode = str(branch_select).strip().lower()
    if mode in ("minus", "plus"):
        return mode
    row_m = metrics_minus[metrics_minus["kind"] == "corrected"].iloc[0]
    row_p = metrics_plus[metrics_plus["kind"] == "corrected"].iloc[0]
    if mode == "best_global":
        return "minus" if float(row_m["global_RMSE"]) <= float(row_p["global_RMSE"]) else "plus"

    # auto / best_azel
    azel_m = 0.5 * (float(row_m["AZ_RMSE"]) + float(row_m["EL_RMSE"]))
    azel_p = 0.5 * (float(row_p["AZ_RMSE"]) + float(row_p["EL_RMSE"]))
    return "minus" if azel_m <= azel_p else "plus"


def _make_pred_df(
    base_df: pd.DataFrame,
    pred_error: np.ndarray,
    alpha_vec: np.ndarray,
    clip_k: Optional[float],
    clip_vec: Optional[np.ndarray],
    azel_cap_deg: Optional[float],
    err_def: str,
    error_repr_by_col: Sequence[str],
    branch_name: str,
) -> pd.DataFrame:
    rr = _normalize_repr_list(error_repr_by_col)
    return pd.DataFrame(
        {
            "No": base_df["No"].to_numpy(np.int64),
            "date": base_df["date"].astype(str),
            "UNIX": base_df["UNIX"].to_numpy(np.int64),
            "Lat": pred_error[:, 0],
            "Lon": pred_error[:, 1],
            "Alt": pred_error[:, 2],
            "AZ": pred_error[:, 3],
            "EL": pred_error[:, 4],
            "alpha_Lat": float(alpha_vec[0]),
            "alpha_Lon": float(alpha_vec[1]),
            "alpha_Alt": float(alpha_vec[2]),
            "alpha_AZ": float(alpha_vec[3]),
            "alpha_EL": float(alpha_vec[4]),
            "clip_k_sigma_Lat": "none" if (clip_vec is None or (not np.isfinite(clip_vec[0]) or clip_vec[0] <= 0)) else float(clip_vec[0]),
            "clip_k_sigma_Lon": "none" if (clip_vec is None or (not np.isfinite(clip_vec[1]) or clip_vec[1] <= 0)) else float(clip_vec[1]),
            "clip_k_sigma_Alt": "none" if (clip_vec is None or (not np.isfinite(clip_vec[2]) or clip_vec[2] <= 0)) else float(clip_vec[2]),
            "clip_k_sigma_AZ": "none" if (clip_vec is None or (not np.isfinite(clip_vec[3]) or clip_vec[3] <= 0)) else float(clip_vec[3]),
            "clip_k_sigma_EL": "none" if (clip_vec is None or (not np.isfinite(clip_vec[4]) or clip_vec[4] <= 0)) else float(clip_vec[4]),
            "clip_k_sigma_global": "none" if (clip_k is None or clip_k <= 0) else float(clip_k),
            "azel_cap_deg": "none" if (azel_cap_deg is None or azel_cap_deg <= 0) else float(azel_cap_deg),
            "error_definition": err_def,
            "error_repr_Lat": rr[0],
            "error_repr_Lon": rr[1],
            "error_repr_Alt": rr[2],
            "error_repr_AZ": rr[3],
            "error_repr_EL": rr[4],
            "branch": str(branch_name),
        }
    )


def apply_correction(
    baseline_df: pd.DataFrame,
    pred_error: np.ndarray,
    error_definition: str,
) -> pd.DataFrame:
    out = baseline_df.copy()
    if pred_error.shape != (len(out), len(TARGET_COLS)):
        raise ValueError(f"pred_error shape mismatch: {pred_error.shape} vs {(len(out), len(TARGET_COLS))}")

    if error_definition == ERROR_DEF_PRED_MINUS_TRUE:
        sign = -1.0
    elif error_definition == ERROR_DEF_TRUE_MINUS_PRED:
        sign = 1.0
    else:
        raise ValueError(f"unsupported error_definition: {error_definition}")

    for i, col in enumerate(TARGET_COLS):
        out[col] = out[col].to_numpy(np.float64) + sign * pred_error[:, i]

    out["Lon"] = wrap180(out["Lon"].to_numpy(np.float64))
    out["AZ"] = wrap360(out["AZ"].to_numpy(np.float64))
    out["EL"] = np.clip(out["EL"].to_numpy(np.float64), -90.0, 90.0)
    return out


def _prep_metric_df(df: pd.DataFrame, suffix: str) -> pd.DataFrame:
    d = _coerce_unix_int64(df)
    miss = [c for c in TARGET_COLS if c not in d.columns]
    if miss:
        raise ValueError(f"missing columns {miss}")
    d = d[["UNIX"] + TARGET_COLS].copy()
    d = d.drop_duplicates("UNIX", keep="last").sort_values("UNIX").reset_index(drop=True)
    return d.rename(columns={c: f"{c}{suffix}" for c in TARGET_COLS})


def compute_metrics(
    truth_df: pd.DataFrame,
    baseline_df: pd.DataFrame,
    corrected_df: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    t = _prep_metric_df(truth_df, "_true")
    b = _prep_metric_df(baseline_df, "_base")
    c = _prep_metric_df(corrected_df, "_corr")
    m = t.merge(b, on="UNIX", how="inner").merge(c, on="UNIX", how="inner")

    rows = int(len(m))
    if rows == 0:
        nan = float("nan")
        df = pd.DataFrame(
            [
                {"kind": "baseline", "rows": 0, **{f"{k}_MSE": nan for k in TARGET_COLS}, **{f"{k}_RMSE": nan for k in TARGET_COLS}, "global_MSE": nan, "global_RMSE": nan},
                {"kind": "corrected", "rows": 0, **{f"{k}_MSE": nan for k in TARGET_COLS}, **{f"{k}_RMSE": nan for k in TARGET_COLS}, "global_MSE": nan, "global_RMSE": nan},
            ]
        )
        return df, m

    def _mse_rmse(a: np.ndarray, b_: np.ndarray, is_angle: bool) -> Tuple[float, float]:
        if is_angle:
            d = angle_diff_deg(a, b_)
        else:
            d = a - b_
        mse = float(np.mean(d**2))
        return mse, float(np.sqrt(mse))

    base_row: Dict[str, float] = {"kind": "baseline", "rows": float(rows)}
    corr_row: Dict[str, float] = {"kind": "corrected", "rows": float(rows)}
    base_mse: List[float] = []
    corr_mse: List[float] = []

    for col in TARGET_COLS:
        is_angle = col in ANGLE_COLS
        mse_b, rmse_b = _mse_rmse(m[f"{col}_base"].to_numpy(np.float64), m[f"{col}_true"].to_numpy(np.float64), is_angle)
        mse_c, rmse_c = _mse_rmse(m[f"{col}_corr"].to_numpy(np.float64), m[f"{col}_true"].to_numpy(np.float64), is_angle)
        base_row[f"{col}_MSE"] = mse_b
        base_row[f"{col}_RMSE"] = rmse_b
        corr_row[f"{col}_MSE"] = mse_c
        corr_row[f"{col}_RMSE"] = rmse_c
        base_mse.append(mse_b)
        corr_mse.append(mse_c)

    base_row["global_MSE"] = float(np.mean(base_mse))
    corr_row["global_MSE"] = float(np.mean(corr_mse))
    base_row["global_RMSE"] = float(np.sqrt(base_row["global_MSE"]))
    corr_row["global_RMSE"] = float(np.sqrt(corr_row["global_MSE"]))

    metrics_df = pd.DataFrame([base_row, corr_row])
    return metrics_df, m


def plot_truth_baseline_corrected(
    stem: str,
    merged_df: pd.DataFrame,
    out_dir: Path,
    sample_every: int,
) -> None:
    ensure_dir(out_dir)
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if len(merged_df) == 0:
        log("[WARN] truth plot skipped: no matching UNIX")
        return

    mp = merged_df.iloc[:: max(1, int(sample_every))].copy()
    unix0 = float(mp["UNIX"].iloc[0])
    t_day = (mp["UNIX"].to_numpy(np.float64) - unix0) / 86400.0

    for col in TARGET_COLS:
        y_true = mp[f"{col}_true"].to_numpy(np.float64)
        y_base = mp[f"{col}_base"].to_numpy(np.float64)
        y_corr = mp[f"{col}_corr"].to_numpy(np.float64)

        if col in ANGLE_COLS:
            e_base = np.abs(angle_diff_deg(y_base, y_true))
            e_corr = np.abs(angle_diff_deg(y_corr, y_true))
        else:
            e_base = np.abs(y_base - y_true)
            e_corr = np.abs(y_corr - y_true)

        fig = plt.figure(figsize=(12, 7))
        ax1 = fig.add_subplot(2, 1, 1)
        ax1.plot(t_day, y_true, label="Truth")
        ax1.plot(t_day, y_base, label="Baseline")
        ax1.plot(t_day, y_corr, label="Corrected")
        ax1.set_title(f"{stem} : {col} value")
        ax1.set_xlabel("Elapsed day")
        ax1.set_ylabel(col)
        ax1.grid(True)
        ax1.legend()

        ax2 = fig.add_subplot(2, 1, 2)
        ax2.plot(t_day, e_base, label="|Baseline-Truth|")
        ax2.plot(t_day, e_corr, label="|Corrected-Truth|")
        ax2.set_title(f"{stem} : {col} absolute error")
        ax2.set_xlabel("Elapsed day")
        ax2.set_ylabel("|error|")
        ax2.grid(True)
        ax2.legend()

        out_path = out_dir / f"{stem}_{col}.png"
        fig.tight_layout()
        fig.savefig(out_path, dpi=150)
        plt.close(fig)


def plot_baseline_vs_corrected(
    stem: str,
    baseline_df: pd.DataFrame,
    corrected_df: pd.DataFrame,
    out_dir: Path,
    sample_every: int,
) -> None:
    ensure_dir(out_dir)
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    b = _prep_metric_df(baseline_df, "_base")
    c = _prep_metric_df(corrected_df, "_corr")
    m = b.merge(c, on="UNIX", how="inner")
    if len(m) == 0:
        log("[WARN] baseline-vs-corrected plot skipped: no matching UNIX")
        return

    mp = m.iloc[:: max(1, int(sample_every))].copy()
    unix0 = float(mp["UNIX"].iloc[0])
    t_day = (mp["UNIX"].to_numpy(np.float64) - unix0) / 86400.0

    for col in TARGET_COLS:
        y_base = mp[f"{col}_base"].to_numpy(np.float64)
        y_corr = mp[f"{col}_corr"].to_numpy(np.float64)
        if col in ANGLE_COLS:
            diff = angle_diff_deg(y_corr, y_base)
        else:
            diff = y_corr - y_base

        fig = plt.figure(figsize=(12, 7))
        ax1 = fig.add_subplot(2, 1, 1)
        ax1.plot(t_day, y_base, label="Baseline")
        ax1.plot(t_day, y_corr, label="Corrected")
        ax1.set_title(f"{stem} : {col} baseline vs corrected")
        ax1.set_xlabel("Elapsed day")
        ax1.set_ylabel(col)
        ax1.grid(True)
        ax1.legend()

        ax2 = fig.add_subplot(2, 1, 2)
        ax2.plot(t_day, np.abs(diff), label="|Corrected-Baseline|")
        ax2.set_title(f"{stem} : {col} correction magnitude")
        ax2.set_xlabel("Elapsed day")
        ax2.set_ylabel("|diff|")
        ax2.grid(True)
        ax2.legend()

        out_path = out_dir / f"{stem}_{col}_baseline_vs_corrected.png"
        fig.tight_layout()
        fig.savefig(out_path, dpi=150)
        plt.close(fig)


def plot_metric_summary(stem: str, metrics_df: pd.DataFrame, out_dir: Path) -> None:
    ensure_dir(out_dir)
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if len(metrics_df) < 2:
        return

    b = metrics_df[metrics_df["kind"] == "baseline"]
    c = metrics_df[metrics_df["kind"] == "corrected"]
    if len(b) == 0 or len(c) == 0:
        return
    b = b.iloc[0]
    c = c.iloc[0]

    rmse_b = [float(b[f"{k}_RMSE"]) for k in TARGET_COLS]
    rmse_c = [float(c[f"{k}_RMSE"]) for k in TARGET_COLS]

    x = np.arange(len(TARGET_COLS))
    w = 0.38

    fig = plt.figure(figsize=(10, 5))
    ax = fig.add_subplot(1, 1, 1)
    ax.bar(x - w / 2, rmse_b, width=w, label="Baseline RMSE")
    ax.bar(x + w / 2, rmse_c, width=w, label="Corrected RMSE")
    ax.set_xticks(x)
    ax.set_xticklabels(TARGET_COLS)
    ax.set_ylabel("RMSE")
    ax.set_title(
        f"{stem} RMSE summary\n"
        f"Global RMSE: {float(b['global_RMSE']):.6g} -> {float(c['global_RMSE']):.6g}"
    )
    ax.grid(True, axis="y")
    ax.legend()

    out_path = out_dir / f"{stem}_metric_summary.png"
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# =========================
# Training
# =========================


def train_cmd(args: argparse.Namespace) -> int:
    require_tensorflow()

    use_baseline_feature = not bool(args.no_baseline_feature)
    tle_dir = Path(args.tle_dir)
    err_dir = Path(args.err_dir)
    pred_dir: Optional[Path] = Path(args.pred_dir) if args.pred_dir else None
    out_model = Path(args.out_model)

    if use_baseline_feature:
        if pred_dir is None:
            pred_dir = Path(f"{tle_dir}_csv")
        if not pred_dir.exists():
            raise FileNotFoundError(
                f"baseline pred dir not found: {pred_dir}. "
                f"Set --pred-dir explicitly or disable with --no-baseline-feature."
            )
        log(f"[INFO] baseline feature source: {pred_dir}")
    else:
        pred_dir = None

    all_stems = list_stems_with_both(tle_dir=tle_dir, csv_dir=err_dir)
    if not all_stems:
        log("[ERROR] no matching TLE/error pairs found")
        return 2

    if args.max_files is not None:
        all_stems = all_stems[: int(args.max_files)]

    split_mode = str(args.split_mode).strip().lower()
    if split_mode == "time":
        n_all = len(all_stems)
        n_val = int(round(float(args.val_split) * n_all))
        if n_val <= 0:
            n_val = 1
        if n_val >= n_all:
            n_val = max(1, n_all - 1)
        val_stems = all_stems[-n_val:]
        train_stems = all_stems[:-n_val]
    else:
        train_stems = [s for s in all_stems if deterministic_split(s, args.val_split, args.seed) == "train"]
        val_stems = [s for s in all_stems if deterministic_split(s, args.val_split, args.seed) == "val"]
    if not train_stems:
        train_stems = all_stems
    if not val_stems:
        n = max(1, int(0.1 * len(train_stems)))
        val_stems = train_stems[:n]

    if int(args.batch_size) <= 0:
        raise ValueError(f"--batch-size must be > 0, got {args.batch_size}")
    if int(args.epochs) <= 0:
        raise ValueError(f"--epochs must be > 0, got {args.epochs}")

    feature_cfg = FeatureConfig(
        day_harmonics=int(args.day_harmonics),
        span_harmonics=int(args.span_harmonics),
        include_sidereal=(not args.no_sidereal),
        include_interactions=(not args.no_interactions),
        include_template_feature=(not args.no_template_feature),
        include_baseline_feature=use_baseline_feature,
    )

    log(
        f"[INFO] files total/train/val={len(all_stems)}/{len(train_stems)}/{len(val_stems)}, "
        f"days={args.days_horizon}, step={args.step_minutes}, sample_every={args.sample_every}"
    )

    sign_stats = compute_sign_consistency_stats(
        stems=train_stems,
        err_dir=err_dir,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
    )
    for i, col in enumerate(TARGET_COLS):
        r = float(sign_stats.ratio_by_col[i]) if np.isfinite(sign_stats.ratio_by_col[i]) else float("nan")
        log(
            f"[SIGN] {col}: ratio(|E[e_no]|/E|e_no|)={r:.6g}, valid_no={int(sign_stats.valid_no_by_col[i])}"
        )

    error_repr_by_col = resolve_error_repr_by_col(
        mode=str(args.error_repr),
        sign_consistency_ratio=sign_stats.ratio_by_col,
        auto_threshold=float(args.repr_auto_threshold),
    )
    log(
        "[INFO] error repr by target (Lat,Lon,Alt,AZ,EL): "
        + ", ".join(error_repr_by_col)
    )

    template_stats = compute_template(
        stems=train_stems,
        err_dir=err_dir,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        error_repr_by_col=error_repr_by_col,
    )
    log(f"[INFO] template rows={template_stats.rows}")

    x_mean, x_std, y_mean, y_std, feature_names, scaler_rows = compute_scalers(
        stems=train_stems,
        tle_dir=tle_dir,
        err_dir=err_dir,
        pred_dir=pred_dir,
        template_by_no=template_stats.template_by_no,
        cfg=feature_cfg,
        error_repr_by_col=error_repr_by_col,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
    )
    log(f"[INFO] scaler rows={scaler_rows}, input_dim={len(feature_names)}")

    hidden = [int(x) for x in str(args.hidden).split(",") if x.strip()]
    model = build_mlp_model(
        input_dim=len(feature_names),
        hidden=hidden,
        dropout=float(args.dropout),
        l2=float(args.l2),
    )

    target_loss_weights = np.array(
        [
            float(args.loss_weight_lat),
            float(args.loss_weight_lon),
            float(args.loss_weight_alt),
            float(args.loss_weight_az),
            float(args.loss_weight_el),
        ],
        dtype=np.float64,
    )
    target_loss_weights = np.where(target_loss_weights > 0, target_loss_weights, 1.0)

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=float(args.lr)),
        loss=build_weighted_huber_loss(
            delta=float(args.huber_delta),
            target_weights=target_loss_weights,
        ),
    )

    rng = np.random.default_rng(int(args.seed))
    best_score = float("inf")
    best_epoch = -1
    no_improve = 0

    tmp_dir = out_model if out_model.suffix == "" else out_model.parent
    ensure_dir(tmp_dir)
    best_model_path = tmp_dir / "_best_model.keras"

    def load_train_arrays(stem: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        x, y_resid, _, no, _ = load_train_pair(
            stem=stem,
            tle_dir=tle_dir,
            err_dir=err_dir,
            pred_dir=pred_dir,
            template_by_no=template_stats.template_by_no,
            cfg=feature_cfg,
            error_repr_by_col=error_repr_by_col,
            days_horizon=int(args.days_horizon),
            step_minutes=int(args.step_minutes),
            sample_every=int(args.sample_every),
        )
        if len(x) == 0:
            return np.zeros((0, 1), dtype=np.float32), np.zeros((0, len(TARGET_COLS)), dtype=np.float32), np.zeros((0,), dtype=np.float64)
        x_s = scale_x(x, x_mean=x_mean, x_std=x_std)
        y_s = scale_y(y_resid, y_mean=y_mean, y_std=y_std)

        no_norm = (no.astype(np.float64) - 1.0) / max(1.0, float(np.max(no) - 1.0))
        return x_s, y_s, no_norm

    val_eval_stems = val_stems
    if args.val_eval_max_files is not None and int(args.val_eval_max_files) > 0:
        val_eval_stems = val_eval_stems[: int(args.val_eval_max_files)]

    for epoch in range(1, int(args.epochs) + 1):
        stems = list(train_stems)
        rng.shuffle(stems)

        total_loss = 0.0
        total_rows = 0

        for stem in stems:
            try:
                x_s, y_s, no_norm = load_train_arrays(stem)
            except Exception as e:
                log(f"[WARN] train skip {stem}: {e}")
                continue

            n = len(x_s)
            if n == 0:
                continue

            idx = np.arange(n)
            rng.shuffle(idx)
            x_s = x_s[idx]
            y_s = y_s[idx]
            no_norm = no_norm[idx]

            bs = int(args.batch_size)
            for s in range(0, n, bs):
                e = min(n, s + bs)
                xb = x_s[s:e]
                yb = y_s[s:e]

                if float(args.time_weight_power) > 0:
                    w = np.power(np.clip(no_norm[s:e], 0.0, 1.0), float(args.time_weight_power)) + 1e-3
                else:
                    w = None

                loss = model.train_on_batch(xb, yb, sample_weight=w, return_dict=False)
                total_loss += float(loss) * len(xb)
                total_rows += len(xb)

        train_loss = total_loss / max(1, total_rows)

        val_metrics = evaluate_on_error_files(
            stems=val_eval_stems,
            tle_dir=tle_dir,
            err_dir=err_dir,
            pred_dir=pred_dir,
            cfg=feature_cfg,
            template_by_no=template_stats.template_by_no,
            error_repr_by_col=error_repr_by_col,
            model=model,
            x_mean=x_mean,
            x_std=x_std,
            y_mean=y_mean,
            y_std=y_std,
            y_total_std=template_stats.y_total_std,
            days_horizon=int(args.days_horizon),
            step_minutes=int(args.step_minutes),
            sample_every=int(args.sample_every),
            batch_size=int(args.batch_size),
            alpha_vec=np.ones((len(TARGET_COLS),), dtype=np.float64),
            alpha_schedule_edges_days=None,
            alpha_schedule_matrix=None,
            gate_targets=None,
            gate_edges_by_col=None,
            gate_beta_by_col=None,
            clip_k_sigma=None,
        )

        if str(args.early_stop_objective).lower() == "azel":
            score = float(
                0.5 * (
                    val_metrics.get("AZ_RMSE_corr", float("inf"))
                    + val_metrics.get("EL_RMSE_corr", float("inf"))
                )
            )
            base_rmse = float(
                0.5 * (
                    val_metrics.get("AZ_RMSE_base", float("nan"))
                    + val_metrics.get("EL_RMSE_base", float("nan"))
                )
            )
            score_name = "AZEL_RMSE_mean"
        else:
            score = float(val_metrics.get("global_RMSE_corr", float("inf")))
            base_rmse = float(val_metrics.get("global_RMSE_base", float("nan")))
            score_name = "global_RMSE"
        log(f"[EPOCH {epoch}/{args.epochs}] train_loss={train_loss:.6g} rows={total_rows}")
        log(f"  [VAL raw] {score_name} {base_rmse:.6g} -> {score:.6g}")

        improved = (best_score - score) > float(args.early_stop_min_delta)
        if improved:
            best_score = score
            best_epoch = epoch
            no_improve = 0
            model.save(str(best_model_path))
        else:
            no_improve += 1

        if int(args.early_stop_patience) > 0 and epoch >= int(args.early_stop_warmup):
            if no_improve >= int(args.early_stop_patience):
                log(f"[EARLY STOP] no improve for {no_improve} epochs. best_epoch={best_epoch} best_score={best_score:.6g}")
                break

    if best_model_path.exists():
        model = tf.keras.models.load_model(str(best_model_path), compile=False)

    calib_stems = val_stems if val_stems else train_stems

    clip_candidates = parse_clip_candidates(str(args.clip_grid))
    y_calib_true, y_calib_pred_raw, no_calib = collect_calibration_arrays(
        stems=calib_stems,
        tle_dir=tle_dir,
        err_dir=err_dir,
        pred_dir=pred_dir,
        cfg=feature_cfg,
        template_by_no=template_stats.template_by_no,
        error_repr_by_col=error_repr_by_col,
        model=model,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
    )

    alpha_vec, clip_vec, calib_details = calibrate_alpha_clip_per_target(
        y_true_total=y_calib_true,
        y_pred_total_raw=y_calib_pred_raw,
        y_total_std=template_stats.y_total_std,
        error_repr_by_col=error_repr_by_col,
        alpha_min=float(args.alpha_min),
        alpha_max=float(args.alpha_max),
        alpha_max_azel=float(args.alpha_max_azel),
        alpha_max_az=(float(args.alpha_max_az) if args.alpha_max_az is not None else None),
        alpha_max_el=(float(args.alpha_max_el) if args.alpha_max_el is not None else None),
        alpha_grid_step=float(args.alpha_grid_step),
        clip_candidates=clip_candidates,
        min_improve_pct=float(args.min_improve_pct),
        azel_alpha_shrink=float(args.azel_alpha_shrink),
        azel_abs_cap_deg=float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None,
        calib_trim_quantile_azel=float(args.calib_trim_quantile_azel),
    )
    log("[INFO] calibrated alpha vec (Lat,Lon,Alt,AZ,EL): " + ", ".join(f"{v:.6g}" for v in alpha_vec.tolist()))
    log(
        "[INFO] calibrated clip vec (Lat,Lon,Alt,AZ,EL): "
        + ", ".join("none" if (not np.isfinite(v) or v <= 0) else f"{v:.6g}" for v in clip_vec.tolist())
    )
    for col in TARGET_COLS:
        d = calib_details.get(col, {})
        if d:
            ck = d.get("clip_k_sigma", float("nan"))
            ck_s = "none" if (not np.isfinite(ck) or ck <= 0) else f"{ck:.6g}"
            log(
                f"[CALIB:{col}] RMSE {d.get('rmse_base', float('nan')):.6g} -> {d.get('rmse_calib', float('nan')):.6g} "
                f"(improve {d.get('improve_pct', float('nan')):.3f}%), alpha={d.get('alpha', float('nan')):.6g}, clip={ck_s}"
            )

    alpha_schedule_edges_days = np.zeros((0,), dtype=np.float64)
    alpha_schedule_matrix = np.zeros((0, len(TARGET_COLS)), dtype=np.float64)
    alpha_schedule_details: Dict[str, Dict[str, float]] = {}
    if not bool(args.disable_alpha_schedule):
        try:
            day_edges = parse_float_list_csv(str(args.alpha_schedule_days))
            if len(day_edges) < 2:
                day_edges = [0.0, float(args.days_horizon)]
            if day_edges[0] > 0:
                day_edges = [0.0] + day_edges
            horizon_d = float(args.days_horizon)
            if day_edges[-1] < horizon_d:
                day_edges = day_edges + [horizon_d]
            day_edges = sorted(set(float(x) for x in day_edges))
            if len(day_edges) >= 2:
                sch_targets = parse_target_list_csv(str(args.alpha_schedule_targets))
                alpha_schedule_edges_days, alpha_schedule_matrix, alpha_schedule_details = calibrate_alpha_schedule_per_target(
                    y_true_total=y_calib_true,
                    y_pred_total_raw=y_calib_pred_raw,
                    no_all=no_calib,
                    y_total_std=template_stats.y_total_std,
                    error_repr_by_col=error_repr_by_col,
                    base_alpha_vec=alpha_vec,
                    target_cols=sch_targets,
                    day_edges=day_edges,
                    alpha_min=float(args.alpha_min),
                    alpha_max=float(args.alpha_max),
                    alpha_max_azel=float(args.alpha_max_azel),
                    alpha_max_az=(float(args.alpha_max_az) if args.alpha_max_az is not None else None),
                    alpha_max_el=(float(args.alpha_max_el) if args.alpha_max_el is not None else None),
                    alpha_grid_step=float(args.alpha_grid_step),
                    clip_vec=clip_vec,
                    azel_abs_cap_deg=float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None,
                    min_rows_per_bin=int(args.alpha_schedule_min_rows),
                    min_improve_pct=float(args.min_improve_pct),
                    calib_trim_quantile_azel=float(args.calib_trim_quantile_azel),
                )
                log(
                    "[INFO] alpha schedule days: "
                    + ",".join(f"{x:g}" for x in alpha_schedule_edges_days.tolist())
                )
                for col in sch_targets:
                    idx = TARGET_COLS.index(col)
                    vals = alpha_schedule_matrix[:, idx].tolist()
                    log(f"[SCHED:{col}] " + ", ".join(f"{v:.4g}" for v in vals))
        except Exception as e:
            log(f"[WARN] alpha schedule disabled due to error: {e}")
            alpha_schedule_edges_days = np.zeros((0,), dtype=np.float64)
            alpha_schedule_matrix = np.zeros((0, len(TARGET_COLS)), dtype=np.float64)
            alpha_schedule_details = {}

    y_calib_pred_post = _apply_alpha_and_clip(
        y_pred_total=y_calib_pred_raw,
        no=no_calib,
        alpha_vec=alpha_vec,
        alpha_schedule_edges_days=alpha_schedule_edges_days,
        alpha_schedule_matrix=alpha_schedule_matrix,
        clip_k_sigma=None,
        clip_k_sigma_vec=clip_vec,
        y_total_std=template_stats.y_total_std,
        error_repr_by_col=error_repr_by_col,
        azel_abs_cap_deg=float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None,
    )

    gate_targets: List[str] = []
    gate_edges_by_col: Dict[str, List[float]] = {}
    gate_beta_by_col: Dict[str, List[float]] = {}
    gate_details: Dict[str, Dict[str, float]] = {}
    if not bool(args.disable_magnitude_gate):
        try:
            gate_targets = parse_target_list_csv(str(args.gate_targets))
            q_gate = parse_quantiles_csv(str(args.gate_quantiles))
            gate_edges_by_col, gate_beta_by_col, gate_details = fit_magnitude_gate(
                y_true_total=y_calib_true,
                y_pred_total=y_calib_pred_post,
                error_repr_by_col=error_repr_by_col,
                target_cols=gate_targets,
                quantiles=q_gate,
                beta_step=float(args.gate_beta_step),
                min_rows_per_bin=int(args.gate_min_rows),
                min_improve_pct=float(args.gate_min_improve_pct),
                trim_quantile_azel=float(args.calib_trim_quantile_azel),
            )
            for col in gate_targets:
                if col in gate_beta_by_col:
                    log(
                        f"[GATE:{col}] "
                        + ", ".join(f"{v:.4g}" for v in gate_beta_by_col[col])
                    )
        except Exception as e:
            log(f"[WARN] magnitude gate disabled due to error: {e}")
            gate_targets = []
            gate_edges_by_col = {}
            gate_beta_by_col = {}
            gate_details = {}

    azel_guard_details: Dict[str, Dict[str, float]] = {}
    if not bool(args.disable_final_azel_guard):
        guard_stems = val_stems if val_stems else calib_stems
        guard_eval = evaluate_on_error_files(
            stems=guard_stems,
            tle_dir=tle_dir,
            err_dir=err_dir,
            pred_dir=pred_dir,
            cfg=feature_cfg,
            template_by_no=template_stats.template_by_no,
            error_repr_by_col=error_repr_by_col,
            model=model,
            x_mean=x_mean,
            x_std=x_std,
            y_mean=y_mean,
            y_std=y_std,
            y_total_std=template_stats.y_total_std,
            days_horizon=int(args.days_horizon),
            step_minutes=int(args.step_minutes),
            sample_every=int(args.sample_every),
            batch_size=int(args.batch_size),
            alpha_vec=alpha_vec,
            alpha_schedule_edges_days=alpha_schedule_edges_days,
            alpha_schedule_matrix=alpha_schedule_matrix,
            gate_targets=gate_targets,
            gate_edges_by_col=gate_edges_by_col,
            gate_beta_by_col=gate_beta_by_col,
            clip_k_sigma=None,
            clip_k_sigma_vec=clip_vec,
            azel_abs_cap_deg=float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None,
        )
        min_imp = float(args.final_azel_guard_min_improve_pct)
        for col in ("AZ", "EL"):
            rb = float(guard_eval.get(f"{col}_RMSE_base", float("nan")))
            rc = float(guard_eval.get(f"{col}_RMSE_corr", float("nan")))
            imp = float("nan")
            keep = False
            if np.isfinite(rb) and rb > 0 and np.isfinite(rc):
                imp = 100.0 * (rb - rc) / rb
                keep = imp >= min_imp
            azel_guard_details[col] = {
                "rmse_base": rb,
                "rmse_corr_pre_guard": rc,
                "improve_pct_pre_guard": imp,
                "min_improve_pct": min_imp,
                "keep": float(1.0 if keep else 0.0),
            }
            if keep:
                log(
                    f"[GUARD:{col}] keep correction (RMSE {rb:.6g} -> {rc:.6g}, improve {imp:.3f}%)"
                )
                continue

            i = TARGET_COLS.index(col)
            alpha_vec[i] = 0.0
            clip_vec[i] = np.nan
            if alpha_schedule_matrix.ndim == 2 and alpha_schedule_matrix.shape[1] == len(TARGET_COLS):
                alpha_schedule_matrix[:, i] = 0.0
            if col in gate_targets:
                gate_targets = [c for c in gate_targets if c != col]
            gate_edges_by_col.pop(col, None)
            gate_beta_by_col.pop(col, None)
            log(
                f"[GUARD:{col}] disable correction (RMSE {rb:.6g} -> {rc:.6g}, improve {imp:.3f}%)"
            )

    bundle = ModelBundle(
        feature_cfg=feature_cfg,
        feature_names=feature_names,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        y_total_std=template_stats.y_total_std,
        template_by_no=template_stats.template_by_no,
        template_count_by_no=template_stats.count_by_no,
        alpha_vec=alpha_vec,
        clip_k_sigma=None,
        clip_k_sigma_vec=clip_vec,
        alpha_schedule_edges_days=alpha_schedule_edges_days,
        alpha_schedule_matrix=alpha_schedule_matrix,
        gate_targets=gate_targets,
        gate_edges_by_col=gate_edges_by_col,
        gate_beta_by_col=gate_beta_by_col,
        error_definition=ERROR_DEF_PRED_MINUS_TRUE,
        error_repr_mode=str(args.error_repr),
        error_repr_by_col=list(error_repr_by_col),
        sign_consistency_ratio=sign_stats.ratio_by_col.copy(),
        train_rows=int(scaler_rows),
        train_files=int(len(train_stems)),
        val_files=int(len(val_stems)),
    )

    train_eval = evaluate_on_error_files(
        stems=train_stems,
        tle_dir=tle_dir,
        err_dir=err_dir,
        pred_dir=pred_dir,
        cfg=feature_cfg,
        template_by_no=template_stats.template_by_no,
        error_repr_by_col=error_repr_by_col,
        model=model,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        y_total_std=template_stats.y_total_std,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        alpha_vec=alpha_vec,
        alpha_schedule_edges_days=alpha_schedule_edges_days,
        alpha_schedule_matrix=alpha_schedule_matrix,
        gate_targets=gate_targets,
        gate_edges_by_col=gate_edges_by_col,
        gate_beta_by_col=gate_beta_by_col,
        clip_k_sigma=None,
        clip_k_sigma_vec=clip_vec,
        azel_abs_cap_deg=float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None,
    )
    val_eval = evaluate_on_error_files(
        stems=val_stems,
        tle_dir=tle_dir,
        err_dir=err_dir,
        pred_dir=pred_dir,
        cfg=feature_cfg,
        template_by_no=template_stats.template_by_no,
        error_repr_by_col=error_repr_by_col,
        model=model,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        y_total_std=template_stats.y_total_std,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        alpha_vec=alpha_vec,
        alpha_schedule_edges_days=alpha_schedule_edges_days,
        alpha_schedule_matrix=alpha_schedule_matrix,
        gate_targets=gate_targets,
        gate_edges_by_col=gate_edges_by_col,
        gate_beta_by_col=gate_beta_by_col,
        clip_k_sigma=None,
        clip_k_sigma_vec=clip_vec,
        azel_abs_cap_deg=float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None,
    )

    if train_eval:
        log(
            f"[TRAIN] global RMSE {train_eval['global_RMSE_base']:.6g} -> {train_eval['global_RMSE_corr']:.6g} "
            f"({train_eval['global_RMSE_improve_pct']:.3f}%)"
        )
    if val_eval:
        log(
            f"[VAL] global RMSE {val_eval['global_RMSE_base']:.6g} -> {val_eval['global_RMSE_corr']:.6g} "
            f"({val_eval['global_RMSE_improve_pct']:.3f}%)"
        )
        for col in TARGET_COLS:
            log(f"  {col}: RMSE {val_eval[f'{col}_RMSE_base']:.6g} -> {val_eval[f'{col}_RMSE_corr']:.6g}")

    extra = {
        "best_epoch": int(best_epoch),
        "best_score_raw_val_global_rmse": float(best_score),
        "train_eval": train_eval,
        "val_eval": val_eval,
        "calibration": {
            "alpha_vec": alpha_vec.tolist(),
            "clip_k_sigma_vec": clip_vec.tolist(),
            "alpha_schedule_edges_days": alpha_schedule_edges_days.tolist(),
            "alpha_schedule_matrix": alpha_schedule_matrix.tolist(),
            "alpha_schedule_targets": parse_target_list_csv(str(args.alpha_schedule_targets)),
            "alpha_schedule_min_rows": int(args.alpha_schedule_min_rows),
            "alpha_schedule_details": alpha_schedule_details,
            "gate_targets": gate_targets,
            "disable_magnitude_gate": bool(args.disable_magnitude_gate),
            "gate_quantiles": parse_quantiles_csv(str(args.gate_quantiles)),
            "gate_beta_step": float(args.gate_beta_step),
            "gate_min_rows": int(args.gate_min_rows),
            "gate_min_improve_pct": float(args.gate_min_improve_pct),
            "gate_edges_by_col": gate_edges_by_col,
            "gate_beta_by_col": gate_beta_by_col,
            "gate_details": gate_details,
            "disable_final_azel_guard": bool(args.disable_final_azel_guard),
            "final_azel_guard_min_improve_pct": float(args.final_azel_guard_min_improve_pct),
            "final_azel_guard_details": azel_guard_details,
            "min_improve_pct": float(args.min_improve_pct),
            "calib_trim_quantile_azel": float(args.calib_trim_quantile_azel),
            "alpha_grid_step": float(args.alpha_grid_step),
            "alpha_max_azel": float(args.alpha_max_azel),
            "alpha_max_az": (float(args.alpha_max_az) if args.alpha_max_az is not None else None),
            "alpha_max_el": (float(args.alpha_max_el) if args.alpha_max_el is not None else None),
            "azel_alpha_shrink": float(args.azel_alpha_shrink),
            "azel_cap_deg": float(args.azel_cap_deg),
            "details": calib_details,
        },
        "model": {
            "hidden": hidden,
            "dropout": float(args.dropout),
            "l2": float(args.l2),
            "lr": float(args.lr),
            "huber_delta": float(args.huber_delta),
            "loss_weight_lat": float(target_loss_weights[0]),
            "loss_weight_lon": float(target_loss_weights[1]),
            "loss_weight_alt": float(target_loss_weights[2]),
            "loss_weight_az": float(target_loss_weights[3]),
            "loss_weight_el": float(target_loss_weights[4]),
            "early_stop_objective": str(args.early_stop_objective),
        },
        "error_repr": {
            "mode": str(args.error_repr),
            "auto_threshold": float(args.repr_auto_threshold),
            "repr_by_col": list(error_repr_by_col),
            "sign_consistency_ratio": sign_stats.ratio_by_col.tolist(),
            "sign_consistency_valid_no": sign_stats.valid_no_by_col.tolist(),
        },
        "baseline_feature": {
            "enabled": bool(feature_cfg.include_baseline_feature),
            "pred_dir": (str(pred_dir) if pred_dir is not None else None),
        },
        "split": {
            "mode": split_mode,
            "val_split": float(args.val_split),
        },
    }

    model_path, meta_path = save_model_and_meta(
        model=model,
        bundle=bundle,
        out_model=out_model,
        overwrite=args.overwrite,
        extra=extra,
    )
    summary_path = meta_path.parent / "train_summary.json"
    summary_path.write_text(json.dumps(extra, ensure_ascii=False, indent=2), encoding="utf-8")

    log(f"[SAVED] model: {model_path}")
    log(f"[SAVED] meta: {meta_path}")
    log(f"[SAVED] train summary: {summary_path}")
    return 0


# =========================
# Predict (single / directory)
# =========================


def run_predict_one(
    model: "tf.keras.Model",
    bundle: ModelBundle,
    tle_file: Path,
    baseline_csv: Path,
    out_corrected_csv: Path,
    out_pred_error_csv: Path,
    truth_df: Optional[pd.DataFrame],
    out_metrics_csv: Optional[Path],
    plot_dir: Optional[Path],
    days: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    plot_sample_every: int,
    overwrite: bool,
    error_definition_override: Optional[str],
    alpha_override: Optional[float],
    clip_k_sigma_override: Optional[float],
    azel_cap_deg: Optional[float],
    branch_select: str,
    disable_magnitude_gate: bool,
    no_plot: bool,
) -> Dict[str, object]:
    base_df, x, no, names = load_infer_pair(
        tle_file=tle_file,
        baseline_csv=baseline_csv,
        template_by_no=bundle.template_by_no,
        cfg=bundle.feature_cfg,
        days_horizon=days,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    if len(base_df) == 0:
        raise RuntimeError(f"no rows in baseline after trim: {baseline_csv}")

    if names != bundle.feature_names:
        raise ValueError("feature names mismatch between trained model and inference")
    rr = _normalize_repr_list(bundle.error_repr_by_col)

    template_at_no = lookup_template(bundle.template_by_no, no)
    y_resid_pred = _model_predict_residual(
        model=model,
        x=x,
        x_mean=bundle.x_mean,
        x_std=bundle.x_std,
        y_mean=bundle.y_mean,
        y_std=bundle.y_std,
        batch_size=batch_size,
    )
    y_pred_model_repr = reconstruct_total_error(
        template_at_no=template_at_no,
        y_resid_pred=y_resid_pred,
        error_repr_by_col=rr,
    )

    alpha_vec = bundle.alpha_vec.copy()
    if alpha_override is not None:
        alpha_vec = np.full_like(alpha_vec, float(alpha_override), dtype=np.float64)

    clip_k = bundle.clip_k_sigma
    clip_vec_raw = (
        bundle.clip_k_sigma_vec.copy()
        if bundle.clip_k_sigma_vec is not None
        else np.full((len(TARGET_COLS),), np.nan, dtype=np.float64)
    )
    has_clip_vec = bool(np.any(np.isfinite(clip_vec_raw) & (clip_vec_raw > 0)))
    clip_vec: Optional[np.ndarray] = clip_vec_raw if has_clip_vec else None

    if clip_k_sigma_override is not None:
        if float(clip_k_sigma_override) <= 0:
            clip_k = None
            clip_vec = None
        else:
            clip_k = float(clip_k_sigma_override)
            clip_vec = np.full((len(TARGET_COLS),), float(clip_k_sigma_override), dtype=np.float64)

    alpha_schedule_edges_days = bundle.alpha_schedule_edges_days
    alpha_schedule_matrix = bundle.alpha_schedule_matrix
    if alpha_override is not None:
        alpha_schedule_edges_days = np.zeros((0,), dtype=np.float64)
        alpha_schedule_matrix = np.zeros((0, len(TARGET_COLS)), dtype=np.float64)

    y_pred_model_repr = _apply_alpha_and_clip(
        y_pred_total=y_pred_model_repr,
        no=no,
        alpha_vec=alpha_vec,
        alpha_schedule_edges_days=alpha_schedule_edges_days,
        alpha_schedule_matrix=alpha_schedule_matrix,
        clip_k_sigma=clip_k,
        clip_k_sigma_vec=clip_vec,
        y_total_std=bundle.y_total_std,
        error_repr_by_col=rr,
        azel_abs_cap_deg=azel_cap_deg,
    )
    if (not disable_magnitude_gate) and bundle.gate_targets:
        y_pred_model_repr = apply_magnitude_gate(
            y_pred_total=y_pred_model_repr,
            gate_targets=bundle.gate_targets,
            gate_edges_by_col=bundle.gate_edges_by_col,
            gate_beta_by_col=bundle.gate_beta_by_col,
        )
        log("[INFO] applied magnitude gate: " + ",".join(bundle.gate_targets))

    err_def = error_definition_override or bundle.error_definition
    pred_error_minus, pred_error_plus, has_abs = build_signed_error_branches(
        y_pred_model_repr=y_pred_model_repr,
        error_repr_by_col=rr,
    )
    corrected_minus = apply_correction(
        baseline_df=base_df,
        pred_error=pred_error_minus,
        error_definition=err_def,
    )
    corrected_plus = apply_correction(
        baseline_df=base_df,
        pred_error=pred_error_plus,
        error_definition=err_def,
    )

    metrics_minus: Optional[pd.DataFrame] = None
    metrics_plus: Optional[pd.DataFrame] = None
    merged_minus: Optional[pd.DataFrame] = None
    merged_plus: Optional[pd.DataFrame] = None
    chosen_branch = "minus"
    branch_mode = str(branch_select).strip().lower()
    if has_abs:
        if branch_mode in ("minus", "plus"):
            chosen_branch = branch_mode
        elif truth_df is not None:
            metrics_minus, merged_minus = compute_metrics(
                truth_df=truth_df,
                baseline_df=base_df,
                corrected_df=corrected_minus,
            )
            metrics_plus, merged_plus = compute_metrics(
                truth_df=truth_df,
                baseline_df=base_df,
                corrected_df=corrected_plus,
            )
            chosen_branch = _select_branch_by_metrics(
                metrics_minus=metrics_minus,
                metrics_plus=metrics_plus,
                branch_select=branch_mode if branch_mode else "auto",
            )
        else:
            chosen_branch = "minus"

    pred_error_selected = pred_error_minus if chosen_branch == "minus" else pred_error_plus
    corrected_df = corrected_minus if chosen_branch == "minus" else corrected_plus

    out_corr_minus = _with_stem_suffix(out_corrected_csv, "_branch_minus")
    out_corr_plus = _with_stem_suffix(out_corrected_csv, "_branch_plus")
    out_err_minus = _with_stem_suffix(out_pred_error_csv, "_branch_minus")
    out_err_plus = _with_stem_suffix(out_pred_error_csv, "_branch_plus")
    mpath = out_metrics_csv or (out_corrected_csv.parent / f"{out_corrected_csv.stem}_metrics.csv")

    out_checks: List[Path] = [out_corrected_csv, out_pred_error_csv]
    if has_abs:
        out_checks.extend([out_corr_minus, out_corr_plus, out_err_minus, out_err_plus])
    if truth_df is not None:
        out_checks.append(mpath)
    uniq_checks: Dict[str, Path] = {}
    for pth in out_checks:
        uniq_checks[str(pth)] = pth
    for pth in uniq_checks.values():
        if pth.exists() and not overwrite:
            raise FileExistsError(f"exists: {pth} (use --overwrite)")

    ensure_dir(out_corrected_csv.parent)
    ensure_dir(out_pred_error_csv.parent)
    if has_abs:
        ensure_dir(out_corr_minus.parent)
        ensure_dir(out_err_minus.parent)
    if truth_df is not None:
        ensure_dir(mpath.parent)

    corrected_df.to_csv(out_corrected_csv, index=False)
    pred_df = _make_pred_df(
        base_df=base_df,
        pred_error=pred_error_selected,
        alpha_vec=alpha_vec,
        clip_k=clip_k,
        clip_vec=clip_vec,
        azel_cap_deg=azel_cap_deg,
        err_def=err_def,
        error_repr_by_col=rr,
        branch_name=chosen_branch,
    )
    pred_df.to_csv(out_pred_error_csv, index=False)

    if has_abs:
        corrected_minus.to_csv(out_corr_minus, index=False)
        corrected_plus.to_csv(out_corr_plus, index=False)
        _make_pred_df(
            base_df=base_df,
            pred_error=pred_error_minus,
            alpha_vec=alpha_vec,
            clip_k=clip_k,
            clip_vec=clip_vec,
            azel_cap_deg=azel_cap_deg,
            err_def=err_def,
            error_repr_by_col=rr,
            branch_name="minus",
        ).to_csv(out_err_minus, index=False)
        _make_pred_df(
            base_df=base_df,
            pred_error=pred_error_plus,
            alpha_vec=alpha_vec,
            clip_k=clip_k,
            clip_vec=clip_vec,
            azel_cap_deg=azel_cap_deg,
            err_def=err_def,
            error_repr_by_col=rr,
            branch_name="plus",
        ).to_csv(out_err_plus, index=False)

    log(f"[SAVED] corrected: {out_corrected_csv}")
    log(f"[SAVED] predicted error: {out_pred_error_csv}")
    if has_abs:
        log(f"[SAVED] corrected branch minus: {out_corr_minus}")
        log(f"[SAVED] corrected branch plus : {out_corr_plus}")
        log(f"[SAVED] predicted error branch minus: {out_err_minus}")
        log(f"[SAVED] predicted error branch plus : {out_err_plus}")

    summary: Dict[str, object] = {"rows_pred": float(len(base_df))}
    summary["has_abs_branch"] = float(1.0 if has_abs else 0.0)
    summary["selected_branch"] = chosen_branch
    summary["magnitude_gate_enabled"] = float(
        1.0 if ((not disable_magnitude_gate) and len(bundle.gate_targets) > 0) else 0.0
    )

    if (not no_plot) and plot_dir is not None:
        plot_baseline_vs_corrected(
            stem=out_corrected_csv.stem,
            baseline_df=base_df,
            corrected_df=corrected_df,
            out_dir=plot_dir,
            sample_every=plot_sample_every,
        )
        if has_abs:
            plot_baseline_vs_corrected(
                stem=f"{out_corrected_csv.stem}_branch_minus",
                baseline_df=base_df,
                corrected_df=corrected_minus,
                out_dir=plot_dir,
                sample_every=plot_sample_every,
            )
            plot_baseline_vs_corrected(
                stem=f"{out_corrected_csv.stem}_branch_plus",
                baseline_df=base_df,
                corrected_df=corrected_plus,
                out_dir=plot_dir,
                sample_every=plot_sample_every,
            )
        log(f"[SAVED] baseline-vs-corrected plots: {plot_dir}")

    if truth_df is not None:
        if metrics_minus is None or merged_minus is None:
            metrics_minus, merged_minus = compute_metrics(
                truth_df=truth_df,
                baseline_df=base_df,
                corrected_df=corrected_minus,
            )
        if has_abs and (metrics_plus is None or merged_plus is None):
            metrics_plus, merged_plus = compute_metrics(
                truth_df=truth_df,
                baseline_df=base_df,
                corrected_df=corrected_plus,
            )

        if chosen_branch == "minus":
            metrics_sel = metrics_minus
            merged_sel = merged_minus
        else:
            if metrics_plus is None or merged_plus is None:
                metrics_plus, merged_plus = compute_metrics(
                    truth_df=truth_df,
                    baseline_df=base_df,
                    corrected_df=corrected_plus,
                )
            metrics_sel = metrics_plus
            merged_sel = merged_plus

        b = metrics_sel[metrics_sel["kind"] == "baseline"].iloc[0].copy()
        s = metrics_sel[metrics_sel["kind"] == "corrected"].iloc[0].copy()
        s["kind"] = "corrected"
        metrics_rows: List[Dict[str, float]] = [dict(b), dict(s)]

        if has_abs and metrics_plus is not None:
            mrow = metrics_minus[metrics_minus["kind"] == "corrected"].iloc[0].copy()
            prow = metrics_plus[metrics_plus["kind"] == "corrected"].iloc[0].copy()
            mrow["kind"] = "corrected_minus"
            prow["kind"] = "corrected_plus"
            metrics_rows.append(dict(mrow))
            metrics_rows.append(dict(prow))

        metrics_df = pd.DataFrame(metrics_rows)
        metrics_df.to_csv(mpath, index=False)
        log(f"[SAVED] metrics: {mpath}")

        summary["rows_eval"] = float(b["rows"])
        summary["global_RMSE_base"] = float(b["global_RMSE"])
        summary["global_RMSE_corr"] = float(s["global_RMSE"])
        if float(b["global_RMSE"]) > 0:
            summary["global_RMSE_improve_pct"] = float(
                100.0 * (float(b["global_RMSE"]) - float(s["global_RMSE"])) / float(b["global_RMSE"])
            )
        else:
            summary["global_RMSE_improve_pct"] = float("nan")
        summary["AZEL_RMSE_base"] = float(0.5 * (float(b["AZ_RMSE"]) + float(b["EL_RMSE"])))
        summary["AZEL_RMSE_corr"] = float(0.5 * (float(s["AZ_RMSE"]) + float(s["EL_RMSE"])))

        if has_abs and metrics_plus is not None:
            mrow = metrics_df[metrics_df["kind"] == "corrected_minus"].iloc[0]
            prow = metrics_df[metrics_df["kind"] == "corrected_plus"].iloc[0]
            summary["global_RMSE_minus"] = float(mrow["global_RMSE"])
            summary["global_RMSE_plus"] = float(prow["global_RMSE"])
            summary["AZEL_RMSE_minus"] = float(0.5 * (float(mrow["AZ_RMSE"]) + float(mrow["EL_RMSE"])))
            summary["AZEL_RMSE_plus"] = float(0.5 * (float(prow["AZ_RMSE"]) + float(prow["EL_RMSE"])))

            log("[METRIC] branch compare (baseline -> corrected_minus / corrected_plus / corrected[selected])")
            log(
                f"  GLOBAL RMSE: {float(b['global_RMSE']):.6g} -> "
                f"{float(mrow['global_RMSE']):.6g} / {float(prow['global_RMSE']):.6g} / {float(s['global_RMSE']):.6g}"
            )
            log(
                f"  AZEL  RMSE: {0.5*(float(b['AZ_RMSE'])+float(b['EL_RMSE'])):.6g} -> "
                f"{0.5*(float(mrow['AZ_RMSE'])+float(mrow['EL_RMSE'])):.6g} / "
                f"{0.5*(float(prow['AZ_RMSE'])+float(prow['EL_RMSE'])):.6g} / "
                f"{0.5*(float(s['AZ_RMSE'])+float(s['EL_RMSE'])):.6g}"
            )

        log("[METRIC] MSE/RMSE (baseline -> corrected[selected])")
        for col in TARGET_COLS:
            log(
                f"  {col}: MSE {float(b[f'{col}_MSE']):.6g} -> {float(s[f'{col}_MSE']):.6g} | "
                f"RMSE {float(b[f'{col}_RMSE']):.6g} -> {float(s[f'{col}_RMSE']):.6g}"
            )
        log(
            f"  GLOBAL: MSE {float(b['global_MSE']):.6g} -> {float(s['global_MSE']):.6g} | "
            f"RMSE {float(b['global_RMSE']):.6g} -> {float(s['global_RMSE']):.6g}"
        )

        if (not no_plot) and plot_dir is not None:
            plot_truth_baseline_corrected(
                stem=out_corrected_csv.stem,
                merged_df=merged_sel,
                out_dir=plot_dir,
                sample_every=plot_sample_every,
            )
            if has_abs and merged_minus is not None and merged_plus is not None:
                plot_truth_baseline_corrected(
                    stem=f"{out_corrected_csv.stem}_branch_minus",
                    merged_df=merged_minus,
                    out_dir=plot_dir,
                    sample_every=plot_sample_every,
                )
                plot_truth_baseline_corrected(
                    stem=f"{out_corrected_csv.stem}_branch_plus",
                    merged_df=merged_plus,
                    out_dir=plot_dir,
                    sample_every=plot_sample_every,
                )
            plot_metric_summary(
                stem=out_corrected_csv.stem,
                metrics_df=metrics_df,
                out_dir=plot_dir,
            )
            log(f"[SAVED] truth comparison plots: {plot_dir}")

    return summary


def predict_cmd(args: argparse.Namespace) -> int:
    model, bundle, _ = load_model_and_meta(Path(args.model))

    truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True) if args.truth_csv else None

    out_corr = Path(args.out_corrected_csv)
    out_err = Path(args.out_pred_error_csv)
    out_metrics = Path(args.out_metrics_csv) if args.out_metrics_csv else None

    if args.plot_dir:
        plot_dir = Path(args.plot_dir)
    elif args.truth_csv:
        plot_dir = out_corr.parent / "plots"
    else:
        plot_dir = out_corr.parent / "plots"

    run_predict_one(
        model=model,
        bundle=bundle,
        tle_file=Path(args.tle_file),
        baseline_csv=Path(args.baseline_csv),
        out_corrected_csv=out_corr,
        out_pred_error_csv=out_err,
        truth_df=truth_df,
        out_metrics_csv=out_metrics,
        plot_dir=plot_dir,
        days=int(args.days),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        plot_sample_every=int(args.plot_sample_every),
        overwrite=args.overwrite,
        error_definition_override=args.error_definition,
        alpha_override=args.alpha_override,
        clip_k_sigma_override=args.clip_k_sigma,
        azel_cap_deg=(float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None),
        branch_select=str(args.branch_select),
        disable_magnitude_gate=bool(args.disable_magnitude_gate),
        no_plot=args.no_plot,
    )
    return 0


def predict_dir_cmd(args: argparse.Namespace) -> int:
    model, bundle, _ = load_model_and_meta(Path(args.model))

    tle_dir = Path(args.tle_dir)
    baseline_dir = Path(args.baseline_dir)
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)

    truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True) if args.truth_csv else None
    plot_dir = out_dir / "plots"

    files = sorted([p for p in baseline_dir.glob(args.glob) if p.is_file()])
    if not files:
        log(f"[ERROR] no baseline CSV found: dir={baseline_dir}, glob={args.glob}")
        return 2

    summary_rows: List[Dict[str, object]] = []
    total = len(files)

    for i, base_path in enumerate(files, start=1):
        stem = base_path.stem
        tle_file = tle_dir / f"{stem}.txt"
        if not tle_file.exists():
            log(f"[SKIP] ({i}/{total}) missing TLE: {tle_file.name}")
            continue

        out_corr = out_dir / f"{stem}.csv"
        out_err = out_dir / f"{stem}_pred_error.csv"
        out_metrics = out_dir / f"{stem}_metrics.csv"

        try:
            s = run_predict_one(
                model=model,
                bundle=bundle,
                tle_file=tle_file,
                baseline_csv=base_path,
                out_corrected_csv=out_corr,
                out_pred_error_csv=out_err,
                truth_df=truth_df,
                out_metrics_csv=out_metrics,
                plot_dir=plot_dir,
                days=int(args.days),
                step_minutes=int(args.step_minutes),
                sample_every=int(args.sample_every),
                batch_size=int(args.batch_size),
                plot_sample_every=int(args.plot_sample_every),
                overwrite=args.overwrite,
                error_definition_override=args.error_definition,
                alpha_override=args.alpha_override,
                clip_k_sigma_override=args.clip_k_sigma,
                azel_cap_deg=(float(args.azel_cap_deg) if float(args.azel_cap_deg) > 0 else None),
                branch_select=str(args.branch_select),
                disable_magnitude_gate=bool(args.disable_magnitude_gate),
                no_plot=args.no_plot,
            )
            row = {"stem": stem}
            row.update(s)
            summary_rows.append(row)
            log(f"[OK] ({i}/{total}) {stem}")
        except Exception as e:
            log(f"[FAIL] ({i}/{total}) {stem}: {e}")

    summary_path = out_dir / "summary_metrics.csv"
    if summary_rows:
        pd.DataFrame(summary_rows).to_csv(summary_path, index=False)
        log(f"[SAVED] summary: {summary_path}")
    else:
        log("[WARN] no successful predictions")
    return 0


# =========================
# CLI
# =========================


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="orbit_error_ai_no_tle_tf.py",
        description="No+TLE based 30-day error learning/correction for GEO satellites",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train", help="Train model from 2023 TLE + error files")
    t.add_argument("--tle-dir", default="23467_2023")
    t.add_argument("--err-dir", default="23467_2023_error")
    t.add_argument("--pred-dir", default=None,
                   help="Directory of 30-day baseline CSVs for training features (default: <tle-dir>_csv)")
    t.add_argument("--out-model", default="orbit_error_model_no_tle_tf")
    t.add_argument("--days-horizon", type=int, default=30)
    t.add_argument("--step-minutes", type=int, default=1)
    t.add_argument("--sample-every", type=int, default=1)
    t.add_argument("--val-split", type=float, default=0.1)
    t.add_argument("--split-mode", choices=["time", "hash"], default="time",
                   help="Validation split mode: time(last segment) or hash")
    t.add_argument("--seed", type=int, default=42)
    t.add_argument("--max-files", type=int, default=None)

    t.add_argument("--day-harmonics", type=int, default=6)
    t.add_argument("--span-harmonics", type=int, default=4)
    t.add_argument("--no-sidereal", action="store_true")
    t.add_argument("--no-interactions", action="store_true")
    t.add_argument("--no-template-feature", action="store_true")
    t.add_argument("--no-baseline-feature", action="store_true",
                   help="Disable baseline-orbit features (not recommended for AZ/EL)")

    t.add_argument("--hidden", type=str, default="512,512,256,128")
    t.add_argument("--dropout", type=float, default=0.05)
    t.add_argument("--l2", type=float, default=1e-6)
    t.add_argument("--lr", type=float, default=1e-3)
    t.add_argument("--huber-delta", type=float, default=1.0)
    t.add_argument("--loss-weight-lat", type=float, default=1.0)
    t.add_argument("--loss-weight-lon", type=float, default=1.0)
    t.add_argument("--loss-weight-alt", type=float, default=1.0)
    t.add_argument("--loss-weight-az", type=float, default=2.0)
    t.add_argument("--loss-weight-el", type=float, default=2.0)
    t.add_argument("--epochs", type=int, default=120)
    t.add_argument("--batch-size", type=int, default=4096)
    t.add_argument("--time-weight-power", type=float, default=0.0)

    t.add_argument("--early-stop-patience", type=int, default=15)
    t.add_argument("--early-stop-warmup", type=int, default=8)
    t.add_argument("--early-stop-min-delta", type=float, default=0.0)
    t.add_argument("--early-stop-objective", choices=["global", "azel"], default="azel",
                   help="Validation objective used for early stopping")
    t.add_argument("--val-eval-max-files", type=int, default=None,
                   help="Use only first N val files for epoch-wise eval speedup")
    t.add_argument("--error-repr", choices=[ERROR_REPR_SIGNED, ERROR_REPR_ABS, ERROR_REPR_AUTO], default=ERROR_REPR_AUTO,
                   help="Error representation for training target: signed/abs/auto")
    t.add_argument("--repr-auto-threshold", type=float, default=0.35,
                   help="Auto mode threshold for sign consistency ratio. Lower ratio -> abs")

    t.add_argument("--alpha-min", type=float, default=0.0)
    t.add_argument("--alpha-max", type=float, default=1.0, help="Max alpha for Lat/Lon/Alt")
    t.add_argument("--alpha-max-azel", type=float, default=0.6, help="Max alpha for AZ/EL (conservative by default)")
    t.add_argument("--alpha-max-az", type=float, default=None, help="Optional override max alpha for AZ")
    t.add_argument("--alpha-max-el", type=float, default=None, help="Optional override max alpha for EL")
    t.add_argument("--alpha-grid-step", type=float, default=0.02, help="Grid step for per-target alpha calibration")
    t.add_argument("--min-improve-pct", type=float, default=0.5,
                   help="If calibration improvement is below this percent, disable correction for that target")
    t.add_argument("--calib-trim-quantile-azel", type=float, default=0.8,
                   help="Use trimmed RMSE quantile for AZ/EL calibration (0<q<1, <=0 disables)")
    t.add_argument("--disable-alpha-schedule", action="store_true",
                   help="Disable No(day)-dependent alpha schedule")
    t.add_argument("--alpha-schedule-days", type=str, default="0,1,3,7,14,30",
                   help="Day edges for alpha schedule bins")
    t.add_argument("--alpha-schedule-targets", type=str, default="AZ,EL",
                   help="Targets to schedule, CSV from Lat,Lon,Alt,AZ,EL")
    t.add_argument("--alpha-schedule-min-rows", type=int, default=2000,
                   help="Minimum calibration rows per bin to fit scheduled alpha")
    t.add_argument("--disable-magnitude-gate", action="store_true",
                   help="Disable prediction-magnitude gate calibration")
    t.add_argument("--gate-targets", type=str, default="AZ,EL",
                   help="Targets to apply magnitude gate, CSV from Lat,Lon,Alt,AZ,EL")
    t.add_argument("--gate-quantiles", type=str, default="0,0.5,0.8,0.95,1.0",
                   help="Quantile edges for prediction-magnitude bins")
    t.add_argument("--gate-beta-step", type=float, default=0.05,
                   help="Grid step for gate beta in [0,1]")
    t.add_argument("--gate-min-rows", type=int, default=2000,
                   help="Minimum rows per gate bin")
    t.add_argument("--gate-min-improve-pct", type=float, default=0.5,
                   help="Minimum improvement percent per gate bin; otherwise beta=0")
    t.add_argument("--disable-final-azel-guard", action="store_true",
                   help="Disable final AZ/EL non-degradation guard on validation split")
    t.add_argument("--final-azel-guard-min-improve-pct", type=float, default=0.2,
                   help="Minimum AZ/EL improvement percent required to keep correction")
    t.add_argument("--azel-alpha-shrink", type=float, default=0.9,
                   help="Post-calibration shrink factor for AZ/EL alpha (safety)")
    t.add_argument("--azel-cap-deg", type=float, default=0.03,
                   help="Absolute cap [deg] for AZ/EL correction in calibration/inference (<=0 disables)")
    t.add_argument("--clip-grid", type=str, default="0,0.5,1,1.5,2,3",
                   help="Per-target clip candidates in k*sigma. <=0 means no clip")

    t.add_argument("--overwrite", action="store_true")

    pr = sub.add_parser("predict", help="Predict/correct one 2024 TLE baseline CSV")
    pr.add_argument("--model", required=True)
    pr.add_argument("--tle-file", required=True)
    pr.add_argument("--baseline-csv", required=True)
    pr.add_argument("--out-corrected-csv", required=True)
    pr.add_argument("--out-pred-error-csv", required=True)
    pr.add_argument("--truth-csv", default=None)
    pr.add_argument("--out-metrics-csv", default=None)
    pr.add_argument("--plot-dir", default=None)
    pr.add_argument("--plot-sample-every", type=int, default=5)
    pr.add_argument("--no-plot", action="store_true")

    pr.add_argument("--days", type=int, default=30)
    pr.add_argument("--step-minutes", type=int, default=1)
    pr.add_argument("--sample-every", type=int, default=1)
    pr.add_argument("--batch-size", type=int, default=4096)

    pr.add_argument("--alpha-override", type=float, default=None,
                    help="Override learned alpha with scalar")
    pr.add_argument("--clip-k-sigma", type=float, default=None,
                    help="Override learned clip_k_sigma (applied to all targets). <=0 disables clip")
    pr.add_argument("--azel-cap-deg", type=float, default=0.03,
                    help="Absolute cap [deg] for AZ/EL correction. <=0 disables cap")
    pr.add_argument("--error-definition", choices=[ERROR_DEF_PRED_MINUS_TRUE, ERROR_DEF_TRUE_MINUS_PRED], default=None)
    pr.add_argument("--branch-select", choices=["auto", "minus", "plus", "best_azel", "best_global"], default="auto",
                    help="For abs representation: how to choose baseline +/- correction output")
    pr.add_argument("--disable-magnitude-gate", action="store_true",
                    help="Disable learned magnitude gate at inference")
    pr.add_argument("--overwrite", action="store_true")

    pdm = sub.add_parser("predict-dir", help="Predict/correct all baseline CSVs in directory")
    pdm.add_argument("--model", required=True)
    pdm.add_argument("--tle-dir", default="23467_2024")
    pdm.add_argument("--baseline-dir", default="23467_2024_csv")
    pdm.add_argument("--out-dir", default="23467_2024_corrected")
    pdm.add_argument("--truth-csv", default="2024_calc_az_el.csv")
    pdm.add_argument("--glob", default="*.csv")
    pdm.add_argument("--plot-sample-every", type=int, default=5)
    pdm.add_argument("--no-plot", action="store_true")

    pdm.add_argument("--days", type=int, default=30)
    pdm.add_argument("--step-minutes", type=int, default=1)
    pdm.add_argument("--sample-every", type=int, default=1)
    pdm.add_argument("--batch-size", type=int, default=4096)

    pdm.add_argument("--alpha-override", type=float, default=None)
    pdm.add_argument("--clip-k-sigma", type=float, default=None)
    pdm.add_argument("--azel-cap-deg", type=float, default=0.03)
    pdm.add_argument("--error-definition", choices=[ERROR_DEF_PRED_MINUS_TRUE, ERROR_DEF_TRUE_MINUS_PRED], default=None)
    pdm.add_argument("--branch-select", choices=["auto", "minus", "plus", "best_azel", "best_global"], default="auto")
    pdm.add_argument("--disable-magnitude-gate", action="store_true")
    pdm.add_argument("--overwrite", action="store_true")

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
    args = make_parser().parse_args(argv)

    if args.cmd == "train":
        return train_cmd(args)
    if args.cmd == "predict":
        return predict_cmd(args)
    if args.cmd == "predict-dir":
        return predict_dir_cmd(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
