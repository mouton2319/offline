#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Train-only script for UFO4 AZ/EL model.

Outputs:
- model (.keras)
- template (.npz)
- meta (.json)
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np

import ufo4_orbit_predict_tf as core


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train UFO4 AZ/EL model (train only).")
    p.add_argument(
        "--train-files",
        nargs="+",
        default=[f"{y}_calc_az_el.csv" for y in range(2017, 2024)],
        help="Training CSVs (default: 2017..2023_calc_az_el.csv).",
    )
    p.add_argument("--output-dir", default="ufo4_azel_model_artifacts")

    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--fine-tune-epochs", type=int, default=0)
    p.add_argument("--batch-size", type=int, default=4096)
    p.add_argument("--learning-rate", type=float, default=1e-3)
    p.add_argument("--weight-decay", type=float, default=5e-7)
    p.add_argument("--dropout", type=float, default=0.10)
    p.add_argument("--l2-reg", type=float, default=5e-7)
    p.add_argument("--hidden-units", default="512,384,256,128")
    p.add_argument("--huber-delta", type=float, default=0.4)
    p.add_argument("--val-days", type=int, default=120)
    p.add_argument("--recent-weight-gamma", type=float, default=3.0)
    p.add_argument("--fine-tune-lr-ratio", type=float, default=0.25)
    p.add_argument("--seed", type=int, default=42)

    p.add_argument("--daily-harmonics", type=int, default=16)
    p.add_argument("--sidereal-harmonics", type=int, default=14)
    p.add_argument("--yearly-harmonics", type=int, default=8)
    p.add_argument("--weekly-harmonics", type=int, default=6)
    p.add_argument("--monthly-harmonics", type=int, default=4)

    # Saved as defaults for prediction stage
    p.add_argument("--observer-lat", type=float, default=36.3022)
    p.add_argument("--observer-lon", type=float, default=137.9031)
    p.add_argument("--observer-alt-m", type=float, default=0.0)
    p.add_argument("--geo-radius-km", type=float, default=42164.0)
    p.add_argument("--sat-name", default="23467")

    p.add_argument("--use-latest-tle-correction", dest="use_latest_tle_correction", action="store_true")
    p.add_argument("--no-latest-tle-correction", dest="use_latest_tle_correction", action="store_false")
    p.add_argument("--latest-tle-dir", default="pred_tle")
    p.add_argument("--tle-correction-start", default="")
    p.add_argument("--tle-priority-days", type=float, default=7.0)
    p.add_argument("--tle-max-weight", type=float, default=1.0)
    p.add_argument("--tle-decay-hours", type=float, default=336.0)
    p.add_argument("--tle-max-hours", type=float, default=0.0)

    p.set_defaults(use_latest_tle_correction=True)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    core.require_tensorflow()

    # tensorflow is imported in core (if available)
    tf = core.tf
    np.random.seed(int(args.seed))
    tf.random.set_seed(int(args.seed))

    train_files = [Path(x) for x in args.train_files]
    for p in train_files:
        if not p.exists():
            raise FileNotFoundError(f"Training file not found: {p}")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    model_path = output_dir / "ufo4_azel_model.keras"
    template_path = output_dir / "ufo4_azel_template.npz"
    meta_path = output_dir / "ufo4_azel_model_meta.json"

    feat_cfg = core.FeatureConfig(
        daily_harmonics=int(args.daily_harmonics),
        sidereal_harmonics=int(args.sidereal_harmonics),
        yearly_harmonics=int(args.yearly_harmonics),
        weekly_harmonics=int(args.weekly_harmonics),
        monthly_harmonics=int(args.monthly_harmonics),
    )
    hidden_units = core.parse_hidden_units(args.hidden_units)

    core.log("Loading training data...")
    unix_all, azel_all, years_all = core.load_training_data_azel(train_files)
    core.log(f"Total training rows: {len(unix_all)}")

    base_unix = float(np.min(unix_all))
    recency_weights = core.build_sample_weights(years_all, gamma=float(args.recent_weight_gamma))
    regime_weights = core.build_regime_consistency_weights(
        years=years_all,
        unix=unix_all,
        azel=azel_all,
        reference_recent_years=3,
        az_scale_deg=2.5,
        el_scale_deg=2.0,
        min_weight=0.02,
    )
    core.log_regime_weight_summary(years_all, regime_weights)
    sample_weights_all = (recency_weights.astype(np.float64) * regime_weights.astype(np.float64)).astype(np.float32)
    sample_weights_all = (sample_weights_all / np.mean(sample_weights_all)).astype(np.float32)

    template = core.build_azel_template(unix_all, azel_all, sample_weights_all)
    base_azel_all, slot_weight_all = core.lookup_template_azel(unix_all, template)

    y_residual_all = core.build_residual_targets(true_azel=azel_all, base_azel=base_azel_all)
    y_scaled_all, y_mean, y_std = core.scale_targets(y_residual_all)

    train_mask, val_mask = core.split_train_val(unix_all, years_all, val_days=int(args.val_days))
    core.log(f"Train rows: {int(np.sum(train_mask))}, Val rows: {int(np.sum(val_mask))}")

    ds_train = core.make_dataset(
        unix=unix_all[train_mask],
        base_az=base_azel_all[train_mask, 0],
        base_el=base_azel_all[train_mask, 1],
        slot_weight=slot_weight_all[train_mask],
        y=y_scaled_all[train_mask],
        sample_weight=sample_weights_all[train_mask],
        base_unix=base_unix,
        cfg=feat_cfg,
        batch_size=int(args.batch_size),
        seed=int(args.seed),
        shuffle=True,
    )
    ds_val = core.make_dataset(
        unix=unix_all[val_mask],
        base_az=base_azel_all[val_mask, 0],
        base_el=base_azel_all[val_mask, 1],
        slot_weight=slot_weight_all[val_mask],
        y=y_scaled_all[val_mask],
        sample_weight=sample_weights_all[val_mask],
        base_unix=base_unix,
        cfg=feat_cfg,
        batch_size=int(args.batch_size),
        seed=int(args.seed),
        shuffle=False,
    )

    sample_feat = core.augment_with_template_features(
        core.build_time_features_tf(tf.constant(unix_all[:4], dtype=tf.float32), base_unix=base_unix, cfg=feat_cfg),
        tf.constant(base_azel_all[:4, 0], dtype=tf.float32),
        tf.constant(base_azel_all[:4, 1], dtype=tf.float32),
        tf.constant(slot_weight_all[:4], dtype=tf.float32),
    )
    input_dim = int(sample_feat.shape[-1])
    core.log(f"Feature dimension: {input_dim}")

    model = core.build_model(
        input_dim=input_dim,
        hidden_units=hidden_units,
        dropout=float(args.dropout),
        l2_reg=float(args.l2_reg),
    )
    loss_fn = core.make_weighted_huber_loss(dim_weights=[2.0, 2.2], delta=float(args.huber_delta))
    optimizer = core.make_optimizer(learning_rate=float(args.learning_rate), weight_decay=float(args.weight_decay))

    model.compile(
        optimizer=optimizer,
        loss=loss_fn,
        metrics=[tf.keras.metrics.MeanSquaredError(name="mse")],
    )

    callbacks = [
        tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=12, restore_best_weights=True),
        tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=5, min_lr=1e-6),
    ]

    core.log("Stage 1 training (with validation)...")
    model.fit(ds_train, validation_data=ds_val, epochs=int(args.epochs), verbose=1, callbacks=callbacks)

    if int(args.fine_tune_epochs) > 0:
        core.log("Stage 2 fine-tuning on all training rows...")
        if hasattr(model.optimizer, "learning_rate"):
            model.optimizer.learning_rate.assign(float(args.learning_rate) * float(args.fine_tune_lr_ratio))
        ds_all = core.make_dataset(
            unix=unix_all,
            base_az=base_azel_all[:, 0],
            base_el=base_azel_all[:, 1],
            slot_weight=slot_weight_all,
            y=y_scaled_all,
            sample_weight=sample_weights_all,
            base_unix=base_unix,
            cfg=feat_cfg,
            batch_size=int(args.batch_size),
            seed=int(args.seed),
            shuffle=True,
        )
        model.fit(ds_all, epochs=int(args.fine_tune_epochs), verbose=1)

    ds_val_pred = core.make_predict_dataset(
        unix=unix_all[val_mask],
        base_az=base_azel_all[val_mask, 0],
        base_el=base_azel_all[val_mask, 1],
        slot_weight=slot_weight_all[val_mask],
        base_unix=base_unix,
        cfg=feat_cfg,
        batch_size=int(args.batch_size),
    )
    val_res_scaled = model.predict(ds_val_pred, verbose=1)
    val_res = core.decode_residual_predictions(val_res_scaled, mean=y_mean, std=y_std)
    calib = core.calibrate_alpha_per_target(
        true_azel=azel_all[val_mask],
        base_azel=base_azel_all[val_mask],
        pred_residual=val_res,
    )
    core.log(f"Calibrated alpha: AZ={calib.alpha_az:.3f}, EL={calib.alpha_el:.3f}")

    model.save(model_path)
    np.savez_compressed(
        template_path,
        slot_az_deg=template.slot_az_deg,
        slot_el_deg=template.slot_el_deg,
        slot_weight=template.slot_weight,
        minute_az_deg=template.minute_az_deg,
        minute_el_deg=template.minute_el_deg,
        minute_weight=template.minute_weight,
    )

    meta = {
        "target_mode": "AZ_EL_only",
        "model_target_layout": ["AZ_residual_deg", "EL_residual_deg"],
        "y_mean": y_mean.tolist(),
        "y_std": y_std.tolist(),
        "alpha_calibration": asdict(calib),
        "feature_config": asdict(feat_cfg),
        "hidden_units": hidden_units,
        "learning_rate": float(args.learning_rate),
        "weight_decay": float(args.weight_decay),
        "dropout": float(args.dropout),
        "l2_reg": float(args.l2_reg),
        "recent_weight_gamma": float(args.recent_weight_gamma),
        "regime_weighting": {
            "reference_recent_years": 3,
            "az_scale_deg": 2.5,
            "el_scale_deg": 2.0,
            "min_weight": 0.02,
        },
        "train_files": [str(x) for x in train_files],
        "base_unix": base_unix,
        "observer_lat": float(args.observer_lat),
        "observer_lon": float(args.observer_lon),
        "observer_alt_m": float(args.observer_alt_m),
        "geo_radius_km": float(args.geo_radius_km),
        "sat_name": str(args.sat_name),
        "use_latest_tle_correction": bool(args.use_latest_tle_correction),
        "latest_tle_dir": str(args.latest_tle_dir),
        "tle_correction_start": str(args.tle_correction_start),
        "tle_priority_days": float(args.tle_priority_days),
        "tle_max_weight": float(args.tle_max_weight),
        "tle_decay_hours": float(args.tle_decay_hours),
        "tle_max_hours": float(args.tle_max_hours),
        "model_path": str(model_path.name),
        "template_path": str(template_path.name),
    }
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    core.log(f"Saved model    : {model_path}")
    core.log(f"Saved template : {template_path}")
    core.log(f"Saved meta     : {meta_path}")
    core.log("Train-only run complete.")


if __name__ == "__main__":
    main()
