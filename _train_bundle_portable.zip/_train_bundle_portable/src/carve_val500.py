#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
carve_val500.py — 2017航跡から checkpoint 選択用の検証セット val500 を決定的に切り出す。

holdout2017 と同じ条件・同じ決定的手順(seed だけ 42->43 に変更)で、
trajectories_2017\\ から 500 件を val500\\ へ **移動** する。

条件(holdout2017 と同一):
  - MMSI_0_traj_*.csv(無効MMSI・複数船混在)は除外
  - データ行数(=ヘッダを除く行数)>= 101 の航跡のみ対象
決定的手順:
  1. パターン一致 CSV を **ファイル名でソート**(OS 依存を排除)
  2. 上記条件でフィルタ(n_points はヘッダを除いたデータ行数)
  3. random.Random(seed).sample(候補, N) で N 件を抽出(seed=43)
  4. shutil.move で val500\\ へ移動し、manifest に (filename, n_points) を記録

holdout2017 は既に trajectories_2017 から物理隔離済みなので、
残り 720,211 件から選ぶ val500 は holdout2017 と原理的に重複しない。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\carve_val500.py `
    --src-dir .\\claude_test\\trajectories_2017 `
    --out-dir .\\claude_test\\val500 `
    --manifest .\\claude_test\\val500_manifest.csv `
    --n 500 --seed 43 --min-points 101
"""
from __future__ import annotations

import argparse
import csv
import random
import shutil
from pathlib import Path


def count_data_rows(path: Path, stop_at: int = 0) -> int:
    """CSV のデータ行数(=総行数 - ヘッダ1行)を数える。空行は無視。

    stop_at > 0 のときは stop_at 行に達した時点で読み止めて stop_at を返す
    (「>= しきい値か」の判定だけならファイル全体を読む必要が無い高速化。
    候補集合は変わらないので seed 抽選の決定性には影響しない)。
    """
    n = 0
    with path.open("r", encoding="utf-8", errors="replace", newline="") as f:
        for i, line in enumerate(f):
            if i == 0:
                continue  # ヘッダ
            if line.strip():
                n += 1
                if stop_at and n >= stop_at:
                    return n
    return n


def main() -> int:
    ap = argparse.ArgumentParser(description="2017 から検証セット val500 を決定的に切り出す(移動)。")
    ap.add_argument("--src-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--pattern", default="MMSI_*_traj_*.csv")
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--seed", type=int, default=43)
    ap.add_argument("--min-points", type=int, default=101, help="データ行数の下限(この値以上)")
    ap.add_argument("--dry-run", action="store_true", help="移動せず選抜のみ確認")
    args = ap.parse_args()

    src = Path(args.src_dir)
    out = Path(args.out_dir)
    manifest = Path(args.manifest)

    # 1. ファイル名でソート(決定的)。MMSI_0 は除外。
    all_files = sorted(src.glob(args.pattern), key=lambda p: p.name)
    all_files = [p for p in all_files if not p.name.startswith("MMSI_0_traj_")]
    print(f"[carve] 候補(MMSI_0除外後・ソート済): {len(all_files):,} 件 <- {src}")

    # 2. n_points >= min_points でフィルタ。決定順(ソート順)を保つ。
    #    高速化: 判定は min_points 行で読み止め(候補集合は不変)。
    candidates = []
    checked = 0
    for p in all_files:
        checked += 1
        try:
            n = count_data_rows(p, stop_at=args.min_points)
        except Exception:
            continue
        if n >= args.min_points:
            candidates.append(p)
        if checked % 50000 == 0:
            print(f"  ...走査 {checked:,}/{len(all_files):,}  適格 {len(candidates):,}", flush=True)
    print(f"[carve] 適格(データ行>={args.min_points}): {len(candidates):,} 件")

    if len(candidates) < args.n:
        raise SystemExit(f"[ERROR] 適格 {len(candidates)} < 要求 {args.n} 件")

    # 3. seed=43 で決定的に N 件抽出。
    rng = random.Random(args.seed)
    picks = rng.sample(candidates, args.n)  # 抽出順を保持(manifest に記録)
    print(f"[carve] seed={args.seed} で {len(picks)} 件を抽出")

    # 選ばれた500件だけ厳密な n_points を再カウント(manifest 用)。
    npoints = {p.name: count_data_rows(p) for p in picks}

    if args.dry_run:
        print("[carve] --dry-run: 移動しません。先頭5件:")
        for p in picks[:5]:
            print(f"    {p.name}  n_points={npoints[p.name]}")
        return 0

    # 4. 移動 + manifest 記録。
    out.mkdir(parents=True, exist_ok=True)
    manifest.parent.mkdir(parents=True, exist_ok=True)
    with manifest.open("w", encoding="utf-8", newline="") as mf:
        w = csv.writer(mf)
        w.writerow(["filename", "n_points"])
        moved = 0
        for p in picks:
            dst = out / p.name
            shutil.move(str(p), str(dst))
            w.writerow([p.name, npoints[p.name]])
            moved += 1
    print(f"[carve] 移動完了: {moved} 件 -> {out}")
    print(f"[carve] manifest -> {manifest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
