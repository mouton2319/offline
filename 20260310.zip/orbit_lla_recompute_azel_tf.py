#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LLA-first GEO correction AI with AZ/EL recomputation.

Policy change:
- Do NOT predict/correct AZ/EL directly.
- Predict correction only for Lat/Lon/Alt (LLA), then recompute AZ/EL geometrically.
- Blend recomputed AZ/EL with baseline AZ/EL using validation-calibrated safe weights.

Why:
- For GEO, baseline SGP4 AZ/EL is often already strong.
- Direct AZ/EL correction can violate geometric consistency and degrade pointing.
- LLA correction + geometric AZ/EL keeps physical consistency and allows do-no-harm fallback.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import math
import os
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import tensorflow as tf
except Exception:
    tf = None

from orbit_error_ai_no_tle_tf import (
    ANGLE_COLS,
    MINUTES_PER_DAY,
    TARGET_COLS,
    FeatureConfig,
    OnlineMeanVar,
    angle_diff_deg,
    build_baseline_features,
    build_no_features,
    compute_metrics,
    deterministic_split,
    ensure_dir,
    list_stems_with_both,
    load_orbit_csv,
    log,
    now_jst_str,
    parse_tle_file,
    plot_baseline_vs_corrected,
    plot_metric_summary,
    plot_truth_baseline_corrected,
    tle_feature_vector,
    trim_horizon_and_stride,
    wrap180,
    wrap360,
)


LLA_COLS = ["Lat", "Lon", "Alt"]


def require_tensorflow() -> None:
    if tf is None:
        raise RuntimeError(
            "TensorFlow is required. Run in docker image with TF installed, e.g. orbit-tf-pip:cuda128."
        )


def parse_float_list_csv(s: str) -> List[float]:
    out: List[float] = []
    for p in str(s).split(","):
        t = p.strip()
        if not t:
            continue
        out.append(float(t))
    return out


def parse_hidden_csv(s: str) -> List[int]:
    out = [int(x.strip()) for x in str(s).split(",") if x.strip()]
    if not out:
        out = [512, 512, 256, 128]
    return out


def parse_clip_candidates(s: str) -> List[Optional[float]]:
    out: List[Optional[float]] = []
    for p in str(s).split(","):
        t = p.strip()
        if not t:
            continue
        v = float(t)
        if v <= 0:
            out.append(None)
        else:
            out.append(v)
    if not out:
        out = [None, 1.0, 1.5, 2.0]
    return out


def split_stems(
    all_stems: List[str],
    val_split: float,
    seed: int,
    split_mode: str,
) -> Tuple[List[str], List[str]]:
    mode = str(split_mode).strip().lower()
    if mode == "time":
        n_all = len(all_stems)
        n_val = int(round(float(val_split) * n_all))
        if n_val <= 0:
            n_val = 1
        if n_val >= n_all:
            n_val = max(1, n_all - 1)
        val_stems = all_stems[-n_val:]
        train_stems = all_stems[:-n_val]
    else:
        train_stems = [s for s in all_stems if deterministic_split(s, val_split, seed) == "train"]
        val_stems = [s for s in all_stems if deterministic_split(s, val_split, seed) == "val"]
    if not train_stems:
        train_stems = all_stems
    if not val_stems:
        n = max(1, int(0.1 * len(train_stems)))
        val_stems = train_stems[:n]
    return train_stems, val_stems


def load_truth_df(truth_csv: Path) -> pd.DataFrame:
    t = load_orbit_csv(truth_csv, require_targets=True)
    t = t[["UNIX"] + TARGET_COLS].copy()
    t = t.drop_duplicates("UNIX", keep="last").sort_values("UNIX").reset_index(drop=True)
    return t


def merge_baseline_truth(
    baseline_df: pd.DataFrame,
    truth_df: pd.DataFrame,
) -> pd.DataFrame:
    return (
        baseline_df[["No", "date", "UNIX"] + TARGET_COLS]
        .merge(truth_df, on="UNIX", how="inner", suffixes=("_b", "_t"))
        .sort_values("No")
        .drop_duplicates("No", keep="last")
        .reset_index(drop=True)
    )


def geodetic_to_ecef_km(
    lat_deg: np.ndarray,
    lon_deg: np.ndarray,
    alt_km: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    a = 6378.137
    f = 1.0 / 298.257223563
    e2 = f * (2.0 - f)
    lat = np.deg2rad(np.asarray(lat_deg, dtype=np.float64))
    lon = np.deg2rad(np.asarray(lon_deg, dtype=np.float64))
    alt = np.asarray(alt_km, dtype=np.float64)

    sl = np.sin(lat)
    cl = np.cos(lat)
    so = np.sin(lon)
    co = np.cos(lon)
    n = a / np.sqrt(1.0 - e2 * sl * sl)
    x = (n + alt) * cl * co
    y = (n + alt) * cl * so
    z = (n * (1.0 - e2) + alt) * sl
    return x, y, z


def recompute_azel_from_lla(
    sat_lat_deg: np.ndarray,
    sat_lon_deg: np.ndarray,
    sat_alt_km: np.ndarray,
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
) -> Tuple[np.ndarray, np.ndarray]:
    sx, sy, sz = geodetic_to_ecef_km(sat_lat_deg, sat_lon_deg, sat_alt_km)
    ox, oy, oz = geodetic_to_ecef_km(
        np.asarray([observer_lat_deg], dtype=np.float64),
        np.asarray([observer_lon_deg], dtype=np.float64),
        np.asarray([float(observer_alt_m) / 1000.0], dtype=np.float64),
    )
    dx = sx - float(ox[0])
    dy = sy - float(oy[0])
    dz = sz - float(oz[0])

    lat0 = math.radians(float(observer_lat_deg))
    lon0 = math.radians(float(observer_lon_deg))
    sl = math.sin(lat0)
    cl = math.cos(lat0)
    so = math.sin(lon0)
    co = math.cos(lon0)

    e = -so * dx + co * dy
    n = -sl * co * dx - sl * so * dy + cl * dz
    u = cl * co * dx + cl * so * dy + sl * dz

    az = np.rad2deg(np.arctan2(e, n))
    az = np.mod(az + 360.0, 360.0)
    el = np.rad2deg(np.arctan2(u, np.sqrt(e * e + n * n)))
    el = np.clip(el, -90.0, 90.0)
    return az, el


def circular_mix_deg(a_deg: np.ndarray, b_deg: np.ndarray, w_b: np.ndarray) -> np.ndarray:
    # mix baseline(a) and recomputed(b): out = (1-w)*a + w*b in circular domain
    a = np.deg2rad(np.asarray(a_deg, dtype=np.float64))
    b = np.deg2rad(np.asarray(b_deg, dtype=np.float64))
    w = np.asarray(w_b, dtype=np.float64)
    sa = np.sin(a)
    ca = np.cos(a)
    sb = np.sin(b)
    cb = np.cos(b)
    s = (1.0 - w) * sa + w * sb
    c = (1.0 - w) * ca + w * cb
    out = np.rad2deg(np.arctan2(s, c))
    return np.mod(out + 360.0, 360.0)


def build_design_matrix(
    no: np.ndarray,
    total_rows: int,
    tle_file: Path,
    baseline: np.ndarray,
    cfg: FeatureConfig,
) -> Tuple[np.ndarray, List[str]]:
    x_no, no_names, aux = build_no_features(no=no, total_rows=total_rows, cfg=cfg)
    tle = parse_tle_file(tle_file)
    tle_vec, tle_names = tle_feature_vector(tle)
    n = len(no)
    x_tle = np.repeat(tle_vec.reshape(1, -1), n, axis=0)

    feats: List[np.ndarray] = [x_no, x_tle]
    names: List[str] = list(no_names) + list(tle_names)

    if cfg.include_baseline_feature:
        bfeat, bnames = build_baseline_features(baseline_at_no=baseline)
        feats.append(bfeat)
        names.extend(bnames)

    if cfg.include_interactions:
        basis = [
            ("no_norm", aux["no_norm"]),
            ("span_sin_1", aux["span_sin_1"]),
            ("span_cos_1", aux["span_cos_1"]),
        ]
        interact_keys = {
            "tle_inc_deg",
            "tle_raan_sin",
            "tle_raan_cos",
            "tle_ecc",
            "tle_argp_sin",
            "tle_argp_cos",
            "tle_mean_anom_sin",
            "tle_mean_anom_cos",
            "tle_mean_motion_rev_per_day",
            "tle_bstar",
            "tle_ndot",
            "tle_nddot",
        }
        idx = [i for i, name in enumerate(tle_names) if name in interact_keys]
        if idx:
            x_tle_sel = x_tle[:, idx]
            tle_sel_names = [tle_names[i] for i in idx]
            for b_name, b in basis:
                z = b.reshape(-1, 1) * x_tle_sel
                feats.append(z)
                names.extend([f"{b_name}*{tn}" for tn in tle_sel_names])

    x = np.concatenate(feats, axis=1).astype(np.float64)
    return x, names


def build_y_lla(baseline: np.ndarray, truth: np.ndarray) -> np.ndarray:
    y = np.zeros((len(baseline), len(LLA_COLS)), dtype=np.float64)
    y[:, 0] = truth[:, TARGET_COLS.index("Lat")] - baseline[:, TARGET_COLS.index("Lat")]
    y[:, 1] = angle_diff_deg(truth[:, TARGET_COLS.index("Lon")], baseline[:, TARGET_COLS.index("Lon")])
    y[:, 2] = truth[:, TARGET_COLS.index("Alt")] - baseline[:, TARGET_COLS.index("Alt")]
    return y


def load_train_pair(
    stem: str,
    tle_dir: Path,
    baseline_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str]]:
    base = load_orbit_csv(baseline_dir / f"{stem}.csv", require_targets=True)
    base = trim_horizon_and_stride(
        base,
        days_horizon=days_horizon,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    merged = merge_baseline_truth(base, truth_df)
    if len(merged) == 0:
        return (
            np.zeros((0, 1), dtype=np.float64),
            np.zeros((0, len(LLA_COLS)), dtype=np.float64),
            np.zeros((0,), dtype=np.int64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0,), dtype=np.int64),
            ["dummy"],
        )

    no = merged["No"].to_numpy(np.int64)
    total_rows = int(max(1, int(no.max())))
    baseline = merged[[f"{c}_b" for c in TARGET_COLS]].to_numpy(np.float64)
    truth = merged[[f"{c}_t" for c in TARGET_COLS]].to_numpy(np.float64)
    x, names = build_design_matrix(
        no=no,
        total_rows=total_rows,
        tle_file=tle_dir / f"{stem}.txt",
        baseline=baseline,
        cfg=cfg,
    )
    y_lla = build_y_lla(baseline=baseline, truth=truth)
    return x, y_lla, no, baseline, truth, no, names


def load_infer_pair(
    tle_file: Path,
    baseline_csv: Path,
    cfg: FeatureConfig,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray, np.ndarray, List[str]]:
    base = load_orbit_csv(baseline_csv, require_targets=True)
    base = trim_horizon_and_stride(
        base,
        days_horizon=days_horizon,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    if len(base) == 0:
        return (
            base,
            np.zeros((0, 1), dtype=np.float64),
            np.zeros((0,), dtype=np.int64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            ["dummy"],
        )
    no = base["No"].to_numpy(np.int64)
    total_rows = int(max(1, int(no.max())))
    baseline = base[TARGET_COLS].to_numpy(np.float64)
    x, names = build_design_matrix(
        no=no,
        total_rows=total_rows,
        tle_file=tle_file,
        baseline=baseline,
        cfg=cfg,
    )
    return base, x, no, baseline, names


def compute_scalers(
    stems: List[str],
    tle_dir: Path,
    baseline_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str], int]:
    x_stat: Optional[OnlineMeanVar] = None
    y_stat = OnlineMeanVar(dim=len(LLA_COLS))
    names: Optional[List[str]] = None
    rows = 0
    for i, stem in enumerate(stems, start=1):
        try:
            x, y, *_rest, fnames = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                baseline_dir=baseline_dir,
                truth_df=truth_df,
                cfg=cfg,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] scaler skip {stem}: {e}")
            continue
        if len(x) == 0:
            continue
        if x_stat is None:
            x_stat = OnlineMeanVar(dim=x.shape[1])
            names = fnames
        elif x.shape[1] != x_stat.dim:
            raise ValueError(f"feature dim mismatch for {stem}: {x.shape[1]} vs {x_stat.dim}")
        x_stat.update(x)
        y_stat.update(y)
        rows += len(x)
        if i % 25 == 0:
            log(f"[SCALER] {i}/{len(stems)} files rows={rows}")

    if x_stat is None or names is None or rows == 0:
        raise RuntimeError("no usable rows for scaler")

    x_mean, x_std = x_stat.finalize()
    y_mean, y_std = y_stat.finalize()
    x_std = np.where(x_std < 1e-9, 1.0, x_std)
    y_std = np.where(y_std < 1e-9, 1.0, y_std)
    return x_mean, x_std, y_mean, y_std, names, rows


def scale_arr(x: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    return ((x - mean.reshape(1, -1)) / std.reshape(1, -1)).astype(np.float32)


def unscale_arr(x_s: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    return (x_s * std.reshape(1, -1) + mean.reshape(1, -1)).astype(np.float64)


def build_model(
    input_dim: int,
    hidden: Sequence[int],
    dropout: float,
    l2: float,
) -> "tf.keras.Model":
    require_tensorflow()
    x_in = tf.keras.Input(shape=(input_dim,), name="x")
    h = x_in
    l2_reg = tf.keras.regularizers.l2(l2) if l2 > 0 else None
    for i, units in enumerate(hidden):
        h = tf.keras.layers.Dense(units, activation=None, kernel_regularizer=l2_reg, name=f"dense_{i}")(h)
        h = tf.keras.layers.LayerNormalization(name=f"ln_{i}")(h)
        h = tf.keras.layers.Activation("swish", name=f"act_{i}")(h)
        if dropout > 0:
            h = tf.keras.layers.Dropout(dropout, name=f"drop_{i}")(h)
    out = tf.keras.layers.Dense(len(LLA_COLS), activation=None, name="lla_out")(h)
    return tf.keras.Model(inputs=x_in, outputs=out, name="lla_correction_mlp")


def build_weighted_huber_loss(delta: float, weights: np.ndarray):
    require_tensorflow()
    d = tf.constant(float(delta), dtype=tf.float32)
    w = tf.constant(np.asarray(weights, dtype=np.float32).reshape(1, -1), dtype=tf.float32)

    def _loss(y_true, y_pred):
        # Lon correction is angular error in [-180,180]
        e0 = y_pred[:, 0] - y_true[:, 0]
        e1 = tf.math.floormod((y_pred[:, 1] - y_true[:, 1]) + 180.0, 360.0) - 180.0
        e2 = y_pred[:, 2] - y_true[:, 2]
        e = tf.stack([e0, e1, e2], axis=1)
        ae = tf.abs(e)
        q = tf.minimum(ae, d)
        lin = ae - q
        huber = 0.5 * tf.square(q) + d * lin
        weighted = huber * w
        return tf.reduce_mean(tf.reduce_sum(weighted, axis=-1))

    return _loss


def predict_lla_delta(
    model: "tf.keras.Model",
    x: np.ndarray,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    batch_size: int,
) -> np.ndarray:
    x_s = scale_arr(x, x_mean, x_std)
    y_s = model.predict(x_s, batch_size=int(batch_size), verbose=0)
    return unscale_arr(y_s, y_mean, y_std)


def apply_lla_alpha_clip(
    pred_delta_lla: np.ndarray,
    alpha_vec: np.ndarray,
    clip_k_vec: np.ndarray,
    y_std: np.ndarray,
) -> np.ndarray:
    d = np.asarray(pred_delta_lla, dtype=np.float64).copy()
    a = np.asarray(alpha_vec, dtype=np.float64).reshape(1, -1)
    d = d * a
    ck = np.asarray(clip_k_vec, dtype=np.float64).reshape(-1)
    for i in range(len(LLA_COLS)):
        if np.isfinite(ck[i]) and ck[i] > 0:
            lim = float(ck[i]) * float(y_std[i])
            d[:, i] = np.clip(d[:, i], -lim, lim)
    # Lon correction remains angular
    d[:, 1] = wrap180(d[:, 1])
    return d


def apply_lla_correction(
    baseline: np.ndarray,
    delta_lla: np.ndarray,
) -> np.ndarray:
    out = np.asarray(baseline, dtype=np.float64).copy()
    out[:, TARGET_COLS.index("Lat")] = baseline[:, TARGET_COLS.index("Lat")] + delta_lla[:, 0]
    out[:, TARGET_COLS.index("Lon")] = wrap180(baseline[:, TARGET_COLS.index("Lon")] + delta_lla[:, 1])
    out[:, TARGET_COLS.index("Alt")] = baseline[:, TARGET_COLS.index("Alt")] + delta_lla[:, 2]
    return out


def day_bin_index(no: np.ndarray, edges: np.ndarray) -> np.ndarray:
    day = (np.asarray(no, dtype=np.float64).reshape(-1) - 1.0) / MINUTES_PER_DAY
    idx = np.searchsorted(edges, day, side="right") - 1
    idx = np.clip(idx, 0, len(edges) - 2)
    return idx.astype(np.int64)


def apply_azel_gamma_blend(
    corrected_lla_and_base: np.ndarray,
    baseline: np.ndarray,
    no: np.ndarray,
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
    day_edges: np.ndarray,
    gamma_matrix: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    out = np.asarray(corrected_lla_and_base, dtype=np.float64).copy()
    az_i = TARGET_COLS.index("AZ")
    el_i = TARGET_COLS.index("EL")
    lat_i = TARGET_COLS.index("Lat")
    lon_i = TARGET_COLS.index("Lon")
    alt_i = TARGET_COLS.index("Alt")

    az_rec, el_rec = recompute_azel_from_lla(
        sat_lat_deg=out[:, lat_i],
        sat_lon_deg=out[:, lon_i],
        sat_alt_km=out[:, alt_i],
        observer_lat_deg=observer_lat_deg,
        observer_lon_deg=observer_lon_deg,
        observer_alt_m=observer_alt_m,
    )
    bidx = day_bin_index(no=no, edges=day_edges)
    g_az = gamma_matrix[bidx, 0]
    g_el = gamma_matrix[bidx, 1]

    az_base = baseline[:, az_i]
    el_base = baseline[:, el_i]
    az_mix = circular_mix_deg(az_base, az_rec, w_b=g_az)
    el_mix = (1.0 - g_el) * el_base + g_el * el_rec
    out[:, az_i] = wrap360(az_mix)
    out[:, el_i] = np.clip(el_mix, -90.0, 90.0)
    return out, az_rec, el_rec


def _rmse_angle(a: np.ndarray, b: np.ndarray) -> float:
    d = angle_diff_deg(np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64))
    return float(np.sqrt(np.mean(d * d)))


def _rmse_linear(a: np.ndarray, b: np.ndarray) -> float:
    d = np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64)
    return float(np.sqrt(np.mean(d * d)))


def calibrate_lla_alpha_clip(
    y_true_lla: np.ndarray,
    y_pred_lla: np.ndarray,
    y_std: np.ndarray,
    alpha_min: float,
    alpha_max: float,
    alpha_step: float,
    clip_candidates: List[Optional[float]],
    min_improve_pct: float,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Dict[str, float]]]:
    if len(y_true_lla) == 0:
        return np.zeros((len(LLA_COLS),), dtype=np.float64), np.full((len(LLA_COLS),), np.nan), {}

    alphas = np.arange(float(alpha_min), float(alpha_max) + 1e-12, float(alpha_step), dtype=np.float64)
    if len(alphas) == 0:
        alphas = np.array([0.0], dtype=np.float64)

    alpha_vec = np.zeros((len(LLA_COLS),), dtype=np.float64)
    clip_vec = np.full((len(LLA_COLS),), np.nan, dtype=np.float64)
    details: Dict[str, Dict[str, float]] = {}

    for i, col in enumerate(LLA_COLS):
        yt = y_true_lla[:, i]
        yp = y_pred_lla[:, i]
        base_rmse = _rmse_angle(yt, np.zeros_like(yt)) if col == "Lon" else _rmse_linear(yt, np.zeros_like(yt))

        best_rmse = base_rmse
        best_alpha = 0.0
        best_ck: Optional[float] = None
        for a in alphas:
            pred_scaled = yp * float(a)
            for ck in clip_candidates:
                pred = pred_scaled.copy()
                if ck is not None and ck > 0:
                    lim = float(ck) * float(y_std[i])
                    pred = np.clip(pred, -lim, lim)
                if col == "Lon":
                    pred = wrap180(pred)
                    rmse = _rmse_angle(yt, pred)
                else:
                    rmse = _rmse_linear(yt, pred)
                if rmse < best_rmse:
                    best_rmse = rmse
                    best_alpha = float(a)
                    best_ck = ck

        improve_pct = 0.0 if base_rmse <= 0 else 100.0 * (base_rmse - best_rmse) / base_rmse
        if improve_pct < float(min_improve_pct):
            best_alpha = 0.0
            best_ck = None
            best_rmse = base_rmse

        alpha_vec[i] = best_alpha
        clip_vec[i] = np.nan if best_ck is None else float(best_ck)
        details[col] = {
            "rmse_base": float(base_rmse),
            "rmse_calib": float(best_rmse),
            "alpha": float(best_alpha),
            "clip_k_sigma": (float(best_ck) if best_ck is not None else float("nan")),
            "improve_pct": float(0.0 if base_rmse <= 0 else 100.0 * (base_rmse - best_rmse) / base_rmse),
        }

    return alpha_vec, clip_vec, details


def calibrate_azel_gamma_schedule(
    no: np.ndarray,
    baseline: np.ndarray,
    corrected_lla: np.ndarray,
    truth: np.ndarray,
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
    day_edges: np.ndarray,
    gamma_grid: List[float],
    min_improve_pct: float,
) -> Tuple[np.ndarray, Dict[str, Dict[str, float]]]:
    nb = len(day_edges) - 1
    g = np.zeros((nb, 2), dtype=np.float64)
    details: Dict[str, Dict[str, float]] = {"AZ": {}, "EL": {}}
    bidx = day_bin_index(no=no, edges=day_edges)

    az_i = TARGET_COLS.index("AZ")
    el_i = TARGET_COLS.index("EL")
    lat_i = TARGET_COLS.index("Lat")
    lon_i = TARGET_COLS.index("Lon")
    alt_i = TARGET_COLS.index("Alt")
    az_rec, el_rec = recompute_azel_from_lla(
        sat_lat_deg=corrected_lla[:, lat_i],
        sat_lon_deg=corrected_lla[:, lon_i],
        sat_alt_km=corrected_lla[:, alt_i],
        observer_lat_deg=observer_lat_deg,
        observer_lon_deg=observer_lon_deg,
        observer_alt_m=observer_alt_m,
    )
    gamma_candidates = sorted(set(float(np.clip(v, 0.0, 1.0)) for v in gamma_grid))
    if not gamma_candidates:
        gamma_candidates = [0.0, 0.5, 1.0]

    for bi in range(nb):
        lo = float(day_edges[bi])
        hi = float(day_edges[bi + 1])
        key = f"{lo:g}-{hi:g}"
        m = bidx == bi
        if not np.any(m):
            details["AZ"][key] = float("nan")
            details["EL"][key] = float("nan")
            continue

        # AZ
        az_b = baseline[m, az_i]
        az_t = truth[m, az_i]
        az_r = az_rec[m]
        base_rmse_az = _rmse_angle(az_b, az_t)
        best_rmse_az = base_rmse_az
        best_g_az = 0.0
        for gg in gamma_candidates:
            az_m = circular_mix_deg(az_b, az_r, w_b=np.full_like(az_b, gg, dtype=np.float64))
            rm = _rmse_angle(az_m, az_t)
            if rm < best_rmse_az:
                best_rmse_az = rm
                best_g_az = float(gg)
        imp_az = 0.0 if base_rmse_az <= 0 else 100.0 * (base_rmse_az - best_rmse_az) / base_rmse_az
        if imp_az < float(min_improve_pct):
            best_g_az = 0.0
        g[bi, 0] = best_g_az
        details["AZ"][key] = float(best_g_az)

        # EL
        el_b = baseline[m, el_i]
        el_t = truth[m, el_i]
        el_r = el_rec[m]
        base_rmse_el = _rmse_linear(el_b, el_t)
        best_rmse_el = base_rmse_el
        best_g_el = 0.0
        for gg in gamma_candidates:
            el_m = (1.0 - float(gg)) * el_b + float(gg) * el_r
            rm = _rmse_linear(el_m, el_t)
            if rm < best_rmse_el:
                best_rmse_el = rm
                best_g_el = float(gg)
        imp_el = 0.0 if base_rmse_el <= 0 else 100.0 * (base_rmse_el - best_rmse_el) / base_rmse_el
        if imp_el < float(min_improve_pct):
            best_g_el = 0.0
        g[bi, 1] = best_g_el
        details["EL"][key] = float(best_g_el)

    return g, details


@dataclasses.dataclass
class ModelBundle:
    feature_cfg: FeatureConfig
    feature_names: List[str]
    x_mean: np.ndarray
    x_std: np.ndarray
    y_mean: np.ndarray
    y_std: np.ndarray
    alpha_vec: np.ndarray
    clip_k_sigma_vec: np.ndarray
    azel_day_edges: np.ndarray
    azel_gamma_matrix: np.ndarray
    observer_lat_deg: float
    observer_lon_deg: float
    observer_alt_m: float
    train_rows: int
    train_files: int
    val_files: int


def is_model_file(path: Path) -> bool:
    return path.suffix.lower() in (".keras", ".h5")


def resolve_model_and_meta(model_arg: Path) -> Tuple[Path, Path]:
    if model_arg.is_dir():
        return model_arg / "model.keras", model_arg / "meta.json"
    return model_arg, model_arg.parent / "meta.json"


def save_model_and_meta(
    model: "tf.keras.Model",
    bundle: ModelBundle,
    out_model: Path,
    overwrite: bool,
    extra: Optional[Dict] = None,
) -> Tuple[Path, Path]:
    require_tensorflow()
    if is_model_file(out_model):
        model_path = out_model
        meta_path = out_model.parent / "meta.json"
        ensure_dir(out_model.parent)
    else:
        ensure_dir(out_model)
        model_path = out_model / "model.keras"
        meta_path = out_model / "meta.json"
    if (model_path.exists() or meta_path.exists()) and not overwrite:
        raise FileExistsError(f"exists: {out_model} (use --overwrite)")

    model.save(str(model_path))
    clip_json: List[Optional[float]] = []
    for v in np.asarray(bundle.clip_k_sigma_vec, dtype=np.float64).reshape(-1):
        clip_json.append(float(v) if (np.isfinite(v) and v > 0) else None)
    payload = {
        "created_at_jst": now_jst_str(),
        "model_type": "lla_recompute_azel",
        "feature_cfg": dataclasses.asdict(bundle.feature_cfg),
        "feature_names": bundle.feature_names,
        "target_cols": list(TARGET_COLS),
        "x_mean": bundle.x_mean.tolist(),
        "x_std": bundle.x_std.tolist(),
        "y_mean": bundle.y_mean.tolist(),
        "y_std": bundle.y_std.tolist(),
        "alpha_vec": bundle.alpha_vec.tolist(),
        "clip_k_sigma_vec": clip_json,
        "azel_day_edges": bundle.azel_day_edges.tolist(),
        "azel_gamma_matrix": bundle.azel_gamma_matrix.tolist(),
        "observer_lat_deg": float(bundle.observer_lat_deg),
        "observer_lon_deg": float(bundle.observer_lon_deg),
        "observer_alt_m": float(bundle.observer_alt_m),
        "train_rows": int(bundle.train_rows),
        "train_files": int(bundle.train_files),
        "val_files": int(bundle.val_files),
    }
    if extra is not None:
        payload["extra"] = extra
    meta_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return model_path, meta_path


def load_model_and_meta(model_arg: Path) -> Tuple["tf.keras.Model", ModelBundle, Dict]:
    require_tensorflow()
    model_path, meta_path = resolve_model_and_meta(model_arg)
    if not model_path.exists():
        raise FileNotFoundError(f"model not found: {model_path}")
    if not meta_path.exists():
        raise FileNotFoundError(f"meta not found: {meta_path}")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    feature_cfg = FeatureConfig(**meta["feature_cfg"])
    clip_raw = meta.get("clip_k_sigma_vec", [None, None, None])
    clip_vec = np.full((len(LLA_COLS),), np.nan, dtype=np.float64)
    for i in range(min(len(clip_raw), len(LLA_COLS))):
        v = clip_raw[i]
        if v is not None:
            clip_vec[i] = float(v)
    day_edges = np.asarray(meta.get("azel_day_edges", []), dtype=np.float64).reshape(-1)
    gamma = np.asarray(meta.get("azel_gamma_matrix", []), dtype=np.float64)
    if gamma.ndim != 2 or gamma.shape[1] != 2 or len(day_edges) != gamma.shape[0] + 1:
        day_edges = np.array([0.0, 30.0], dtype=np.float64)
        gamma = np.zeros((1, 2), dtype=np.float64)

    bundle = ModelBundle(
        feature_cfg=feature_cfg,
        feature_names=list(meta["feature_names"]),
        x_mean=np.asarray(meta["x_mean"], dtype=np.float64),
        x_std=np.asarray(meta["x_std"], dtype=np.float64),
        y_mean=np.asarray(meta["y_mean"], dtype=np.float64),
        y_std=np.asarray(meta["y_std"], dtype=np.float64),
        alpha_vec=np.asarray(meta.get("alpha_vec", [0.0, 0.0, 0.0]), dtype=np.float64),
        clip_k_sigma_vec=clip_vec,
        azel_day_edges=day_edges,
        azel_gamma_matrix=gamma,
        observer_lat_deg=float(meta.get("observer_lat_deg", 36.3022)),
        observer_lon_deg=float(meta.get("observer_lon_deg", 137.9031)),
        observer_alt_m=float(meta.get("observer_alt_m", 0.0)),
        train_rows=int(meta.get("train_rows", 0)),
        train_files=int(meta.get("train_files", 0)),
        val_files=int(meta.get("val_files", 0)),
    )
    model = tf.keras.models.load_model(str(model_path), compile=False)
    return model, bundle, meta


def format_corrected_df(base_df: pd.DataFrame, corrected: np.ndarray) -> pd.DataFrame:
    out = base_df[["No", "date", "UNIX"]].copy()
    for i, c in enumerate(TARGET_COLS):
        out[c] = corrected[:, i]
    return out


def evaluate_dataset(
    stems: List[str],
    tle_dir: Path,
    baseline_dir: Path,
    truth_df: pd.DataFrame,
    cfg: FeatureConfig,
    model: "tf.keras.Model",
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    alpha_vec: np.ndarray,
    clip_vec: np.ndarray,
    azel_day_edges: np.ndarray,
    azel_gamma_matrix: np.ndarray,
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
) -> Dict[str, float]:
    if not stems:
        return {}
    sum_b = np.zeros((len(TARGET_COLS),), dtype=np.float64)
    sum_c = np.zeros((len(TARGET_COLS),), dtype=np.float64)
    rows = 0
    for stem in stems:
        try:
            x, _y, no, baseline, truth, _no2, _names = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                baseline_dir=baseline_dir,
                truth_df=truth_df,
                cfg=cfg,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
            )
        except Exception as e:
            log(f"[WARN] eval skip {stem}: {e}")
            continue
        if len(x) == 0:
            continue
        pred_lla = predict_lla_delta(
            model=model,
            x=x,
            x_mean=x_mean,
            x_std=x_std,
            y_mean=y_mean,
            y_std=y_std,
            batch_size=batch_size,
        )
        pred_lla = apply_lla_alpha_clip(
            pred_delta_lla=pred_lla,
            alpha_vec=alpha_vec,
            clip_k_vec=clip_vec,
            y_std=y_std,
        )
        corrected = apply_lla_correction(baseline=baseline, delta_lla=pred_lla)
        corrected, _az_rec, _el_rec = apply_azel_gamma_blend(
            corrected_lla_and_base=corrected,
            baseline=baseline,
            no=no,
            observer_lat_deg=observer_lat_deg,
            observer_lon_deg=observer_lon_deg,
            observer_alt_m=observer_alt_m,
            day_edges=azel_day_edges,
            gamma_matrix=azel_gamma_matrix,
        )

        for i, c in enumerate(TARGET_COLS):
            if c in ANGLE_COLS:
                eb = angle_diff_deg(baseline[:, i], truth[:, i])
                ec = angle_diff_deg(corrected[:, i], truth[:, i])
            else:
                eb = baseline[:, i] - truth[:, i]
                ec = corrected[:, i] - truth[:, i]
            sum_b[i] += float(np.sum(eb * eb))
            sum_c[i] += float(np.sum(ec * ec))
        rows += len(x)

    if rows == 0:
        return {}
    mse_b = sum_b / rows
    mse_c = sum_c / rows
    rmse_b = np.sqrt(mse_b)
    rmse_c = np.sqrt(mse_c)
    out: Dict[str, float] = {"rows": float(rows)}
    for i, c in enumerate(TARGET_COLS):
        out[f"{c}_MSE_base"] = float(mse_b[i])
        out[f"{c}_MSE_corr"] = float(mse_c[i])
        out[f"{c}_RMSE_base"] = float(rmse_b[i])
        out[f"{c}_RMSE_corr"] = float(rmse_c[i])
    out["global_MSE_base"] = float(np.mean(mse_b))
    out["global_MSE_corr"] = float(np.mean(mse_c))
    out["global_RMSE_base"] = float(np.sqrt(out["global_MSE_base"]))
    out["global_RMSE_corr"] = float(np.sqrt(out["global_MSE_corr"]))
    out["global_RMSE_improve_pct"] = float(
        0.0
        if out["global_RMSE_base"] <= 0
        else 100.0 * (out["global_RMSE_base"] - out["global_RMSE_corr"]) / out["global_RMSE_base"]
    )
    return out


def run_predict_one(
    model: "tf.keras.Model",
    bundle: ModelBundle,
    tle_file: Path,
    baseline_csv: Path,
    out_corrected_csv: Path,
    out_pred_delta_csv: Path,
    truth_df: Optional[pd.DataFrame],
    out_metrics_csv: Optional[Path],
    plot_dir: Optional[Path],
    days: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    plot_sample_every: int,
    overwrite: bool,
    no_plot: bool,
    observer_lat_override: Optional[float],
    observer_lon_override: Optional[float],
    observer_alt_override: Optional[float],
) -> Dict[str, object]:
    base_df, x, no, baseline, names = load_infer_pair(
        tle_file=tle_file,
        baseline_csv=baseline_csv,
        cfg=bundle.feature_cfg,
        days_horizon=days,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    if len(base_df) == 0:
        raise RuntimeError(f"no rows after trim: {baseline_csv}")
    if names != bundle.feature_names:
        raise ValueError("feature names mismatch between trained model and inference")

    pred_lla_raw = predict_lla_delta(
        model=model,
        x=x,
        x_mean=bundle.x_mean,
        x_std=bundle.x_std,
        y_mean=bundle.y_mean,
        y_std=bundle.y_std,
        batch_size=batch_size,
    )
    pred_lla = apply_lla_alpha_clip(
        pred_delta_lla=pred_lla_raw,
        alpha_vec=bundle.alpha_vec,
        clip_k_vec=bundle.clip_k_sigma_vec,
        y_std=bundle.y_std,
    )
    corrected = apply_lla_correction(baseline=baseline, delta_lla=pred_lla)

    obs_lat = bundle.observer_lat_deg if observer_lat_override is None else float(observer_lat_override)
    obs_lon = bundle.observer_lon_deg if observer_lon_override is None else float(observer_lon_override)
    obs_alt = bundle.observer_alt_m if observer_alt_override is None else float(observer_alt_override)
    corrected, az_rec, el_rec = apply_azel_gamma_blend(
        corrected_lla_and_base=corrected,
        baseline=baseline,
        no=no,
        observer_lat_deg=obs_lat,
        observer_lon_deg=obs_lon,
        observer_alt_m=obs_alt,
        day_edges=bundle.azel_day_edges,
        gamma_matrix=bundle.azel_gamma_matrix,
    )

    if out_corrected_csv.exists() and not overwrite:
        raise FileExistsError(f"exists: {out_corrected_csv} (use --overwrite)")
    if out_pred_delta_csv.exists() and not overwrite:
        raise FileExistsError(f"exists: {out_pred_delta_csv} (use --overwrite)")
    ensure_dir(out_corrected_csv.parent)
    ensure_dir(out_pred_delta_csv.parent)

    corrected_df = format_corrected_df(base_df=base_df, corrected=corrected)
    corrected_df.to_csv(out_corrected_csv, index=False)
    log(f"[SAVED] corrected: {out_corrected_csv}")

    bidx = day_bin_index(no=no, edges=bundle.azel_day_edges)
    g_az = bundle.azel_gamma_matrix[bidx, 0]
    g_el = bundle.azel_gamma_matrix[bidx, 1]
    pred_df = base_df[["No", "date", "UNIX"]].copy()
    pred_df["pred_dLat_raw"] = pred_lla_raw[:, 0]
    pred_df["pred_dLon_raw"] = pred_lla_raw[:, 1]
    pred_df["pred_dAlt_raw"] = pred_lla_raw[:, 2]
    pred_df["pred_dLat"] = pred_lla[:, 0]
    pred_df["pred_dLon"] = pred_lla[:, 1]
    pred_df["pred_dAlt"] = pred_lla[:, 2]
    pred_df["alpha_Lat"] = float(bundle.alpha_vec[0])
    pred_df["alpha_Lon"] = float(bundle.alpha_vec[1])
    pred_df["alpha_Alt"] = float(bundle.alpha_vec[2])
    pred_df["az_recomputed"] = az_rec
    pred_df["el_recomputed"] = el_rec
    pred_df["gamma_AZ"] = g_az
    pred_df["gamma_EL"] = g_el
    pred_df.to_csv(out_pred_delta_csv, index=False)
    log(f"[SAVED] predicted deltas: {out_pred_delta_csv}")

    summary: Dict[str, object] = {"rows_pred": float(len(base_df))}

    if (not no_plot) and plot_dir is not None:
        plot_baseline_vs_corrected(
            stem=out_corrected_csv.stem,
            baseline_df=base_df,
            corrected_df=corrected_df,
            out_dir=plot_dir,
            sample_every=plot_sample_every,
        )
        log(f"[SAVED] baseline-vs-corrected plots: {plot_dir}")

    if truth_df is not None:
        metrics_df, merged_df = compute_metrics(
            truth_df=truth_df,
            baseline_df=base_df,
            corrected_df=corrected_df,
        )
        mpath = out_metrics_csv or (out_corrected_csv.parent / f"{out_corrected_csv.stem}_metrics.csv")
        if mpath.exists() and not overwrite:
            raise FileExistsError(f"exists: {mpath} (use --overwrite)")
        ensure_dir(mpath.parent)
        metrics_df.to_csv(mpath, index=False)
        log(f"[SAVED] metrics: {mpath}")

        b = metrics_df[metrics_df["kind"] == "baseline"].iloc[0]
        c = metrics_df[metrics_df["kind"] == "corrected"].iloc[0]
        log("[METRIC] MSE/RMSE (baseline -> corrected)")
        for col in TARGET_COLS:
            log(
                f"  {col}: MSE {float(b[f'{col}_MSE']):.6g} -> {float(c[f'{col}_MSE']):.6g} | "
                f"RMSE {float(b[f'{col}_RMSE']):.6g} -> {float(c[f'{col}_RMSE']):.6g}"
            )
        log(
            f"  GLOBAL: MSE {float(b['global_MSE']):.6g} -> {float(c['global_MSE']):.6g} | "
            f"RMSE {float(b['global_RMSE']):.6g} -> {float(c['global_RMSE']):.6g}"
        )

        summary["rows_eval"] = float(b["rows"])
        summary["global_RMSE_base"] = float(b["global_RMSE"])
        summary["global_RMSE_corr"] = float(c["global_RMSE"])
        summary["AZEL_RMSE_base"] = float(0.5 * (float(b["AZ_RMSE"]) + float(b["EL_RMSE"])))
        summary["AZEL_RMSE_corr"] = float(0.5 * (float(c["AZ_RMSE"]) + float(c["EL_RMSE"])))

        if (not no_plot) and plot_dir is not None:
            plot_truth_baseline_corrected(
                stem=out_corrected_csv.stem,
                merged_df=merged_df,
                out_dir=plot_dir,
                sample_every=plot_sample_every,
            )
            plot_metric_summary(
                stem=out_corrected_csv.stem,
                metrics_df=metrics_df,
                out_dir=plot_dir,
            )
            log(f"[SAVED] truth comparison plots: {plot_dir}")

    return summary


def train_cmd(args: argparse.Namespace) -> int:
    require_tensorflow()
    tle_dir = Path(args.tle_dir)
    baseline_dir = Path(args.baseline_dir)
    truth_csv = Path(args.truth_csv)
    out_model = Path(args.out_model)

    if not tle_dir.exists():
        raise FileNotFoundError(f"tle-dir not found: {tle_dir}")
    if not baseline_dir.exists():
        raise FileNotFoundError(f"baseline-dir not found: {baseline_dir}")
    if not truth_csv.exists():
        raise FileNotFoundError(f"truth-csv not found: {truth_csv}")

    all_stems = list_stems_with_both(tle_dir=tle_dir, csv_dir=baseline_dir)
    if not all_stems:
        log("[ERROR] no matching TLE/baseline pairs")
        return 2
    if args.max_files is not None:
        all_stems = all_stems[: int(args.max_files)]

    train_stems, val_stems = split_stems(
        all_stems=all_stems,
        val_split=float(args.val_split),
        seed=int(args.seed),
        split_mode=str(args.split_mode),
    )
    log(
        f"[INFO] files total/train/val={len(all_stems)}/{len(train_stems)}/{len(val_stems)}, "
        f"days={args.days_horizon}, step={args.step_minutes}, sample_every={args.sample_every}"
    )

    truth_df = load_truth_df(truth_csv)
    cfg = FeatureConfig(
        day_harmonics=int(args.day_harmonics),
        span_harmonics=int(args.span_harmonics),
        include_sidereal=(not bool(args.no_sidereal)),
        include_interactions=(not bool(args.no_interactions)),
        include_template_feature=False,
        include_baseline_feature=(not bool(args.no_baseline_feature)),
    )

    x_mean, x_std, y_mean, y_std, feat_names, scaler_rows = compute_scalers(
        stems=train_stems,
        tle_dir=tle_dir,
        baseline_dir=baseline_dir,
        truth_df=truth_df,
        cfg=cfg,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
    )
    log(f"[INFO] scaler rows={scaler_rows}, input_dim={len(feat_names)}")

    hidden = parse_hidden_csv(args.hidden)
    model = build_model(
        input_dim=len(feat_names),
        hidden=hidden,
        dropout=float(args.dropout),
        l2=float(args.l2),
    )
    loss_weights = np.array(
        [float(args.loss_weight_lat), float(args.loss_weight_lon), float(args.loss_weight_alt)],
        dtype=np.float64,
    )
    loss_weights = np.where(loss_weights > 0, loss_weights, 1.0)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=float(args.lr)),
        loss=build_weighted_huber_loss(delta=float(args.huber_delta), weights=loss_weights),
    )

    rng = np.random.default_rng(int(args.seed))
    best_score = float("inf")
    best_epoch = -1
    no_improve = 0
    ensure_dir(out_model if out_model.suffix == "" else out_model.parent)
    best_model_path = (out_model if out_model.suffix == "" else out_model.parent) / "_best_model.keras"

    def load_train_arrays(stem: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        x, y, no, *_ = load_train_pair(
            stem=stem,
            tle_dir=tle_dir,
            baseline_dir=baseline_dir,
            truth_df=truth_df,
            cfg=cfg,
            days_horizon=int(args.days_horizon),
            step_minutes=int(args.step_minutes),
            sample_every=int(args.sample_every),
        )
        if len(x) == 0:
            return (
                np.zeros((0, 1), dtype=np.float32),
                np.zeros((0, len(LLA_COLS)), dtype=np.float32),
                np.zeros((0,), dtype=np.float64),
            )
        x_s = scale_arr(x, x_mean, x_std)
        y_s = scale_arr(y, y_mean, y_std)
        no_norm = (no.astype(np.float64) - 1.0) / max(1.0, float(np.max(no) - 1.0))
        return x_s, y_s, no_norm

    val_eval_stems = val_stems
    if args.val_eval_max_files is not None and int(args.val_eval_max_files) > 0:
        val_eval_stems = val_eval_stems[: int(args.val_eval_max_files)]

    for epoch in range(1, int(args.epochs) + 1):
        stems = list(train_stems)
        rng.shuffle(stems)
        total_loss = 0.0
        total_rows = 0
        for stem in stems:
            try:
                x_s, y_s, no_norm = load_train_arrays(stem)
            except Exception as e:
                log(f"[WARN] train skip {stem}: {e}")
                continue
            n = len(x_s)
            if n == 0:
                continue
            idx = np.arange(n)
            rng.shuffle(idx)
            x_s = x_s[idx]
            y_s = y_s[idx]
            no_norm = no_norm[idx]
            bs = int(args.batch_size)
            for s in range(0, n, bs):
                e = min(n, s + bs)
                xb = x_s[s:e]
                yb = y_s[s:e]
                if float(args.time_weight_power) > 0:
                    w = np.power(np.clip(no_norm[s:e], 0.0, 1.0), float(args.time_weight_power)) + 1e-3
                else:
                    w = None
                loss = model.train_on_batch(xb, yb, sample_weight=w, return_dict=False)
                total_loss += float(loss) * len(xb)
                total_rows += len(xb)

        train_loss = total_loss / max(1, total_rows)

        # epoch score: AZEL RMSE using LLA corrected + recomputed AZEL (no gamma)
        v_sum = 0.0
        v_cnt = 0
        b_sum = 0.0
        for stem in val_eval_stems:
            try:
                x, _y, _no, baseline, truth, _no2, _names = load_train_pair(
                    stem=stem,
                    tle_dir=tle_dir,
                    baseline_dir=baseline_dir,
                    truth_df=truth_df,
                    cfg=cfg,
                    days_horizon=int(args.days_horizon),
                    step_minutes=int(args.step_minutes),
                    sample_every=int(args.sample_every),
                )
            except Exception:
                continue
            if len(x) == 0:
                continue

            d = predict_lla_delta(
                model=model,
                x=x,
                x_mean=x_mean,
                x_std=x_std,
                y_mean=y_mean,
                y_std=y_std,
                batch_size=int(args.batch_size),
            )
            corrected = apply_lla_correction(baseline=baseline, delta_lla=d)
            az_rec, el_rec = recompute_azel_from_lla(
                sat_lat_deg=corrected[:, TARGET_COLS.index("Lat")],
                sat_lon_deg=corrected[:, TARGET_COLS.index("Lon")],
                sat_alt_km=corrected[:, TARGET_COLS.index("Alt")],
                observer_lat_deg=float(args.observer_lat),
                observer_lon_deg=float(args.observer_lon),
                observer_alt_m=float(args.observer_alt_m),
            )
            b_rmse = 0.5 * (
                _rmse_angle(baseline[:, TARGET_COLS.index("AZ")], truth[:, TARGET_COLS.index("AZ")])
                + _rmse_linear(baseline[:, TARGET_COLS.index("EL")], truth[:, TARGET_COLS.index("EL")])
            )
            c_rmse = 0.5 * (
                _rmse_angle(az_rec, truth[:, TARGET_COLS.index("AZ")])
                + _rmse_linear(el_rec, truth[:, TARGET_COLS.index("EL")])
            )
            b_sum += b_rmse
            v_sum += c_rmse
            v_cnt += 1

        base_rmse = b_sum / max(1, v_cnt)
        score = v_sum / max(1, v_cnt)
        log(f"[EPOCH {epoch}/{args.epochs}] train_loss={train_loss:.6g} rows={total_rows}")
        log(f"  [VAL recompute] AZEL_RMSE_mean {base_rmse:.6g} -> {score:.6g}")

        improved = (best_score - score) > float(args.early_stop_min_delta)
        if improved:
            best_score = score
            best_epoch = epoch
            no_improve = 0
            model.save(str(best_model_path))
        else:
            no_improve += 1
        if int(args.early_stop_patience) > 0 and epoch >= int(args.early_stop_warmup):
            if no_improve >= int(args.early_stop_patience):
                log(
                    f"[EARLY STOP] no improve for {no_improve} epochs. "
                    f"best_epoch={best_epoch} best_score={best_score:.6g}"
                )
                break

    if best_model_path.exists():
        model = tf.keras.models.load_model(str(best_model_path), compile=False)

    # collect calibration rows
    calib_stems = val_stems if val_stems else train_stems
    y_true_list: List[np.ndarray] = []
    y_pred_list: List[np.ndarray] = []
    baseline_list: List[np.ndarray] = []
    truth_list: List[np.ndarray] = []
    no_list: List[np.ndarray] = []
    for stem in calib_stems:
        try:
            x, y, no, baseline, truth, _no2, _names = load_train_pair(
                stem=stem,
                tle_dir=tle_dir,
                baseline_dir=baseline_dir,
                truth_df=truth_df,
                cfg=cfg,
                days_horizon=int(args.days_horizon),
                step_minutes=int(args.step_minutes),
                sample_every=int(args.sample_every),
            )
        except Exception:
            continue
        if len(x) == 0:
            continue
        yp = predict_lla_delta(
            model=model,
            x=x,
            x_mean=x_mean,
            x_std=x_std,
            y_mean=y_mean,
            y_std=y_std,
            batch_size=int(args.batch_size),
        )
        y_true_list.append(y)
        y_pred_list.append(yp)
        baseline_list.append(baseline)
        truth_list.append(truth)
        no_list.append(no)

    if not y_true_list:
        log("[ERROR] no calibration rows")
        return 2
    y_true = np.concatenate(y_true_list, axis=0)
    y_pred = np.concatenate(y_pred_list, axis=0)
    baseline_all = np.concatenate(baseline_list, axis=0)
    truth_all = np.concatenate(truth_list, axis=0)
    no_all = np.concatenate(no_list, axis=0)

    alpha_vec, clip_vec, lla_calib_details = calibrate_lla_alpha_clip(
        y_true_lla=y_true,
        y_pred_lla=y_pred,
        y_std=y_std,
        alpha_min=float(args.alpha_min),
        alpha_max=float(args.alpha_max),
        alpha_step=float(args.alpha_step),
        clip_candidates=parse_clip_candidates(str(args.clip_grid)),
        min_improve_pct=float(args.lla_min_improve_pct),
    )
    log("[INFO] calibrated alpha (Lat,Lon,Alt): " + ", ".join(f"{v:.6g}" for v in alpha_vec.tolist()))
    log(
        "[INFO] calibrated clip (Lat,Lon,Alt): "
        + ", ".join("none" if (not np.isfinite(v) or v <= 0) else f"{v:.6g}" for v in clip_vec.tolist())
    )

    pred_lla_cal = apply_lla_alpha_clip(
        pred_delta_lla=y_pred,
        alpha_vec=alpha_vec,
        clip_k_vec=clip_vec,
        y_std=y_std,
    )
    corrected_lla_cal = apply_lla_correction(baseline=baseline_all, delta_lla=pred_lla_cal)

    day_edges = parse_float_list_csv(str(args.azel_day_edges))
    if len(day_edges) < 2:
        day_edges = [0.0, float(args.days_horizon)]
    if day_edges[0] > 0:
        day_edges = [0.0] + day_edges
    horizon = float(args.days_horizon)
    if day_edges[-1] < horizon:
        day_edges = day_edges + [horizon]
    day_edges = sorted(set(float(x) for x in day_edges))
    azel_day_edges = np.asarray(day_edges, dtype=np.float64)
    gamma_grid = parse_float_list_csv(str(args.azel_gamma_grid))
    azel_gamma_matrix, azel_gamma_details = calibrate_azel_gamma_schedule(
        no=no_all,
        baseline=baseline_all,
        corrected_lla=corrected_lla_cal,
        truth=truth_all,
        observer_lat_deg=float(args.observer_lat),
        observer_lon_deg=float(args.observer_lon),
        observer_alt_m=float(args.observer_alt_m),
        day_edges=azel_day_edges,
        gamma_grid=gamma_grid,
        min_improve_pct=float(args.azel_min_improve_pct),
    )
    log("[INFO] AZEL day edges: " + ",".join(f"{v:g}" for v in azel_day_edges.tolist()))
    log("[INFO] gamma AZ: " + ", ".join(f"{v:.4g}" for v in azel_gamma_matrix[:, 0].tolist()))
    log("[INFO] gamma EL: " + ", ".join(f"{v:.4g}" for v in azel_gamma_matrix[:, 1].tolist()))

    train_eval = evaluate_dataset(
        stems=train_stems,
        tle_dir=tle_dir,
        baseline_dir=baseline_dir,
        truth_df=truth_df,
        cfg=cfg,
        model=model,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        alpha_vec=alpha_vec,
        clip_vec=clip_vec,
        azel_day_edges=azel_day_edges,
        azel_gamma_matrix=azel_gamma_matrix,
        observer_lat_deg=float(args.observer_lat),
        observer_lon_deg=float(args.observer_lon),
        observer_alt_m=float(args.observer_alt_m),
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
    )
    val_eval = evaluate_dataset(
        stems=val_stems,
        tle_dir=tle_dir,
        baseline_dir=baseline_dir,
        truth_df=truth_df,
        cfg=cfg,
        model=model,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        alpha_vec=alpha_vec,
        clip_vec=clip_vec,
        azel_day_edges=azel_day_edges,
        azel_gamma_matrix=azel_gamma_matrix,
        observer_lat_deg=float(args.observer_lat),
        observer_lon_deg=float(args.observer_lon),
        observer_alt_m=float(args.observer_alt_m),
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
    )
    if train_eval:
        log(
            f"[TRAIN] global RMSE {train_eval['global_RMSE_base']:.6g} -> "
            f"{train_eval['global_RMSE_corr']:.6g} ({train_eval['global_RMSE_improve_pct']:.3f}%)"
        )
    if val_eval:
        log(
            f"[VAL] global RMSE {val_eval['global_RMSE_base']:.6g} -> "
            f"{val_eval['global_RMSE_corr']:.6g} ({val_eval['global_RMSE_improve_pct']:.3f}%)"
        )
        for c in TARGET_COLS:
            log(f"  {c}: RMSE {val_eval[f'{c}_RMSE_base']:.6g} -> {val_eval[f'{c}_RMSE_corr']:.6g}")

    bundle = ModelBundle(
        feature_cfg=cfg,
        feature_names=feat_names,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        alpha_vec=alpha_vec,
        clip_k_sigma_vec=clip_vec,
        azel_day_edges=azel_day_edges,
        azel_gamma_matrix=azel_gamma_matrix,
        observer_lat_deg=float(args.observer_lat),
        observer_lon_deg=float(args.observer_lon),
        observer_alt_m=float(args.observer_alt_m),
        train_rows=int(scaler_rows),
        train_files=int(len(train_stems)),
        val_files=int(len(val_stems)),
    )

    extra = {
        "best_epoch": int(best_epoch),
        "best_val_score_recompute_azel_rmse": float(best_score),
        "train_eval": train_eval,
        "val_eval": val_eval,
        "split_mode": str(args.split_mode),
        "lla_calibration": lla_calib_details,
        "azel_gamma_details": azel_gamma_details,
        "observer_lat": float(args.observer_lat),
        "observer_lon": float(args.observer_lon),
        "observer_alt_m": float(args.observer_alt_m),
    }
    model_path, meta_path = save_model_and_meta(
        model=model,
        bundle=bundle,
        out_model=out_model,
        overwrite=bool(args.overwrite),
        extra=extra,
    )
    summary_path = meta_path.parent / "train_summary.json"
    summary_path.write_text(json.dumps(extra, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[SAVED] model: {model_path}")
    log(f"[SAVED] meta: {meta_path}")
    log(f"[SAVED] train summary: {summary_path}")
    return 0


def predict_cmd(args: argparse.Namespace) -> int:
    model, bundle, _meta = load_model_and_meta(Path(args.model))
    truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True) if args.truth_csv else None

    out_corr = Path(args.out_corrected_csv)
    out_pred = Path(args.out_pred_delta_csv)
    out_metrics = Path(args.out_metrics_csv) if args.out_metrics_csv else None

    if args.plot_dir:
        plot_dir = Path(args.plot_dir)
    elif args.truth_csv:
        plot_dir = out_corr.parent / "plots"
    else:
        plot_dir = out_corr.parent / "plots"

    run_predict_one(
        model=model,
        bundle=bundle,
        tle_file=Path(args.tle_file),
        baseline_csv=Path(args.baseline_csv),
        out_corrected_csv=out_corr,
        out_pred_delta_csv=out_pred,
        truth_df=truth_df,
        out_metrics_csv=out_metrics,
        plot_dir=plot_dir,
        days=int(args.days),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        plot_sample_every=int(args.plot_sample_every),
        overwrite=bool(args.overwrite),
        no_plot=bool(args.no_plot),
        observer_lat_override=(float(args.observer_lat) if args.observer_lat is not None else None),
        observer_lon_override=(float(args.observer_lon) if args.observer_lon is not None else None),
        observer_alt_override=(float(args.observer_alt_m) if args.observer_alt_m is not None else None),
    )
    return 0


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="orbit_lla_recompute_azel_tf.py",
        description="LLA correction + geometric AZ/EL recomputation (single-TLE inference)",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train", help="Train model from 2023 TLE + baseline + truth")
    t.add_argument("--tle-dir", default="23467_2023")
    t.add_argument("--baseline-dir", default="23467_2023_csv")
    t.add_argument("--truth-csv", default="2023_calc_az_el.csv")
    t.add_argument("--out-model", default="orbit_lla_recompute_azel_model_tf")
    t.add_argument("--days-horizon", type=int, default=30)
    t.add_argument("--step-minutes", type=int, default=1)
    t.add_argument("--sample-every", type=int, default=1)
    t.add_argument("--val-split", type=float, default=0.15)
    t.add_argument("--split-mode", choices=["time", "hash"], default="time")
    t.add_argument("--seed", type=int, default=42)
    t.add_argument("--max-files", type=int, default=None)

    t.add_argument("--day-harmonics", type=int, default=6)
    t.add_argument("--span-harmonics", type=int, default=4)
    t.add_argument("--no-sidereal", action="store_true")
    t.add_argument("--no-interactions", action="store_true")
    t.add_argument("--no-baseline-feature", action="store_true")

    t.add_argument("--hidden", type=str, default="512,512,256,128")
    t.add_argument("--dropout", type=float, default=0.05)
    t.add_argument("--l2", type=float, default=1e-6)
    t.add_argument("--lr", type=float, default=1e-3)
    t.add_argument("--huber-delta", type=float, default=1.0)
    t.add_argument("--epochs", type=int, default=120)
    t.add_argument("--batch-size", type=int, default=2048)
    t.add_argument("--time-weight-power", type=float, default=0.0)
    t.add_argument("--early-stop-patience", type=int, default=15)
    t.add_argument("--early-stop-warmup", type=int, default=8)
    t.add_argument("--early-stop-min-delta", type=float, default=0.0)
    t.add_argument("--val-eval-max-files", type=int, default=None)

    t.add_argument("--loss-weight-lat", type=float, default=1.0)
    t.add_argument("--loss-weight-lon", type=float, default=1.0)
    t.add_argument("--loss-weight-alt", type=float, default=1.0)

    t.add_argument("--alpha-min", type=float, default=0.0)
    t.add_argument("--alpha-max", type=float, default=1.0)
    t.add_argument("--alpha-step", type=float, default=0.02)
    t.add_argument("--clip-grid", type=str, default="0,0.5,1,1.5,2,3")
    t.add_argument("--lla-min-improve-pct", type=float, default=0.2)

    t.add_argument("--observer-lat", type=float, default=36.3022)
    t.add_argument("--observer-lon", type=float, default=137.9031)
    t.add_argument("--observer-alt-m", type=float, default=0.0)
    t.add_argument("--azel-day-edges", type=str, default="0,1,3,7,14,30")
    t.add_argument("--azel-gamma-grid", type=str, default="0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0")
    t.add_argument("--azel-min-improve-pct", type=float, default=0.2)
    t.add_argument("--overwrite", action="store_true")

    pr = sub.add_parser("predict", help="Predict one TLE + baseline CSV")
    pr.add_argument("--model", required=True)
    pr.add_argument("--tle-file", required=True)
    pr.add_argument("--baseline-csv", required=True)
    pr.add_argument("--out-corrected-csv", required=True)
    pr.add_argument("--out-pred-delta-csv", required=True)
    pr.add_argument("--truth-csv", default=None)
    pr.add_argument("--out-metrics-csv", default=None)
    pr.add_argument("--plot-dir", default=None)
    pr.add_argument("--plot-sample-every", type=int, default=5)
    pr.add_argument("--no-plot", action="store_true")
    pr.add_argument("--days", type=int, default=30)
    pr.add_argument("--step-minutes", type=int, default=1)
    pr.add_argument("--sample-every", type=int, default=1)
    pr.add_argument("--batch-size", type=int, default=4096)
    pr.add_argument("--observer-lat", type=float, default=None)
    pr.add_argument("--observer-lon", type=float, default=None)
    pr.add_argument("--observer-alt-m", type=float, default=None)
    pr.add_argument("--overwrite", action="store_true")

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
    args = make_parser().parse_args(argv)
    if args.cmd == "train":
        return train_cmd(args)
    if args.cmd == "predict":
        return predict_cmd(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

