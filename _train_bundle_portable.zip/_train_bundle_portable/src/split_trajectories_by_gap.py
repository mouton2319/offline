#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
MMSI別CSV(1ファイルにそのMMSIの全航跡が入っている)を、
「航跡(trajectory)ごとに1ファイル」へ分割するスクリプト。

=== 分割の考え方 ===
リサンプリング済みデータは点の間隔が原則3分。よって連続する2点の時間差が
3分より大きければ、そこが「ある航跡の終わり」と「次の航跡の始まり」の境界とみなせる。
(実データ確認済み: 既存の block_id はまさにこの 3分ギャップ境界で切られており、
 各 block 内のギャップは全て厳密に3分・block 境界だけが数十分〜数時間。
 つまり本スクリプトのギャップ分割は block_id と一致する。)

本スクリプトは block_id に依存せず「時間ギャップ」だけで分割するので、
block_id が無い/信用できないデータでも同じ結果を再現できる。

出力:
  output-dir/MMSI_<mmsi>_traj_<NNNN>.csv  (NNNN は開始時刻順の0始まり連番)
  各ファイルは1航跡 = start から end まで連続(3分間隔)の点列。
  入力列はそのまま保持し、識別用に traj_id 列(= "<mmsi>_<NNNN>")だけ追加する。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\split_trajectories_by_gap.py `
    --input-dir .\\src\\timeseries_by_mmsi_turn\\resampled_3min `
    --output-dir .\\src\\timeseries_by_mmsi_turn\\trajectories `
    --gap-threshold-min 3.0 --min-points 2 --workers 8
"""

from __future__ import annotations

import argparse
import re
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

# CSVに最低限必要な列。
REQUIRED_COLUMNS = ["timestamp", "lon", "lat"]


def infer_mmsi_from_filename(path: Path) -> str:
    """`MMSI_123_resampled_3min.csv` のようなファイル名からMMSI文字列を推定する。"""
    stem = path.stem
    m = re.match(r"^MMSI_(.+?)_resampled_", stem)
    if m:
        return m.group(1)
    if stem.startswith("MMSI_"):
        return stem[5:]
    return stem


def normalize_mmsi(value, fallback: str) -> str:
    """MMSI値を安定した文字列に正規化する(123.0 -> 123)。"""
    if pd.isna(value):
        return fallback
    text = str(value).strip()
    if text == "":
        return fallback
    try:
        f = float(text)
        if np.isfinite(f) and float(f).is_integer():
            return str(int(f))
    except Exception:
        pass
    return text


def assign_trajectory_ids(unix_time: np.ndarray, gap_threshold_sec: float) -> np.ndarray:
    """時刻配列(秒・昇順前提)から、ギャップで区切った航跡IDを割り当てる。

    Args:
        unix_time: UNIX秒の配列(昇順)。
        gap_threshold_sec: この秒数より大きいギャップを航跡境界とみなす。

    Returns:
        各点の航跡インデックス(0始まり)。境界の手前までが同じID。
    """
    if len(unix_time) == 0:
        return np.zeros(0, dtype=np.int64)
    # 連続2点の時間差(先頭はギャップ0扱い)。
    gaps = np.zeros(len(unix_time), dtype=np.float64)
    gaps[1:] = np.diff(unix_time.astype(np.float64))
    # しきい値より大きいギャップの位置で航跡番号を+1していく(cumsum)。
    is_boundary = gaps > gap_threshold_sec
    return np.cumsum(is_boundary).astype(np.int64)


def read_csv_for_split(path: Path) -> pd.DataFrame:
    """分割用にCSVを読み、時刻を昇順整列して返す。"""
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"{path} に必要列がありません: {missing}")

    # 時刻列を用意する。unix_time があれば最優先(整数秒で安定)。
    if "unix_time" in df.columns:
        ut = pd.to_numeric(df["unix_time"], errors="coerce")
        # unix_time が秒でなくミリ秒のことがあるので桁で簡易判定(>1e12 ならミリ秒)。
        if ut.notna().any() and float(ut.dropna().abs().median()) > 1e12:
            ut = ut / 1000.0
        df["_unix"] = ut
    else:
        df["_unix"] = np.nan

    # unix_time が欠ける行は timestamp から補完する。
    if df["_unix"].isna().any():
        ts = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
        df["_unix"] = df["_unix"].fillna(ts.view("int64") / 1e9)

    # 時刻/座標が壊れた行を除外。
    df["lon"] = pd.to_numeric(df["lon"], errors="coerce")
    df["lat"] = pd.to_numeric(df["lat"], errors="coerce")
    df = df.dropna(subset=["_unix", "lon", "lat"]).copy()

    # 時刻昇順(同時刻は step_index 順)に整列。これでギャップ分割が正しく効く。
    sort_cols = ["_unix"] + (["step_index"] if "step_index" in df.columns else [])
    df = df.sort_values(sort_cols).reset_index(drop=True)
    return df


def split_one_file(
    path: Path,
    output_dir: Path,
    gap_threshold_min: float,
    min_points: int,
    overwrite: bool,
) -> Dict[str, object]:
    """1つのMMSI CSVを航跡ごとに分割して書き出す。

    Returns:
        処理結果(ok/path/mmsi/n_traj/n_written/n_skipped_short/rows/error)のdict。
    """
    try:
        df = read_csv_for_split(path)
    except Exception as e:
        return {"ok": False, "path": path.name, "mmsi": "", "n_traj": 0,
                "n_written": 0, "n_skipped_short": 0, "rows": 0, "error": str(e)}

    fallback_mmsi = infer_mmsi_from_filename(path)
    mmsi = normalize_mmsi(df["mmsi"].iloc[0], fallback_mmsi) if ("mmsi" in df.columns and len(df)) else fallback_mmsi

    gap_threshold_sec = float(gap_threshold_min) * 60.0
    traj_idx = assign_trajectory_ids(df["_unix"].to_numpy(), gap_threshold_sec)
    df = df.drop(columns=["_unix"])

    output_dir.mkdir(parents=True, exist_ok=True)
    n_traj = int(traj_idx.max()) + 1 if len(traj_idx) else 0
    n_written = 0
    n_skipped_short = 0
    out_columns = None  # 出力列順(traj_id を末尾に追加)

    for t in range(n_traj):
        sub = df.loc[traj_idx == t].copy()
        if len(sub) < int(min_points):
            n_skipped_short += 1
            continue
        traj_id = f"{mmsi}_{t:04d}"
        sub.insert(len(sub.columns), "traj_id", traj_id)  # 識別用に末尾へ追加
        out_path = output_dir / f"MMSI_{mmsi}_traj_{t:04d}.csv"
        if out_path.exists() and not overwrite:
            continue
        if out_columns is None:
            out_columns = list(sub.columns)
        sub.to_csv(out_path, index=False)
        n_written += 1

    return {"ok": True, "path": path.name, "mmsi": mmsi, "n_traj": n_traj,
            "n_written": n_written, "n_skipped_short": n_skipped_short,
            "rows": int(len(df)), "error": ""}


def _worker(args) -> Dict[str, object]:
    """ProcessPoolから split_one_file を呼ぶラッパー(Path文字列で受け渡し)。"""
    path_text, out_text, gap_min, min_points, overwrite = args
    try:
        return split_one_file(Path(path_text), Path(out_text), gap_min, min_points, overwrite)
    except Exception as e:
        return {"ok": False, "path": Path(path_text).name, "mmsi": "", "n_traj": 0,
                "n_written": 0, "n_skipped_short": 0, "rows": 0, "error": str(e)}


def list_files(input_dir: Path, pattern: str, limit_files: int) -> List[Path]:
    """対象CSVの一覧を作る(limit_files>0 なら先頭N件)。"""
    files = sorted(input_dir.glob(pattern))
    if limit_files and limit_files > 0:
        files = files[:limit_files]
    return files


def build_parser() -> argparse.ArgumentParser:
    """コマンドライン引数定義。"""
    p = argparse.ArgumentParser(description="MMSI別CSVを航跡(>Nmin ギャップ境界)ごとのファイルへ分割する。")
    p.add_argument("--input-dir", required=True, help="MMSI別CSVのフォルダ(例: resampled_3min)。")
    p.add_argument("--output-dir", required=True, help="航跡別CSVの出力フォルダ(input-dirと別にする)。")
    p.add_argument("--pattern", default="MMSI_*_resampled_3min.csv", help="入力globパターン。")
    p.add_argument("--gap-threshold-min", type=float, default=3.0,
                   help="このギャップ(分)より大きい時間差を航跡境界とみなす。既定3.0(=3分超で分割)。")
    p.add_argument("--min-points", type=int, default=2, help="この点数未満の航跡は出力しない。既定2。")
    p.add_argument("--workers", type=int, default=0, help="並列プロセス数。0/1で逐次。")
    p.add_argument("--overwrite", action="store_true", help="既存の出力があっても上書きする。")
    p.add_argument("--limit-files", type=int, default=0, help="先頭N件だけ処理(テスト用)。0で全件。")
    p.add_argument("--progress-every", type=int, default=200, help="N件ごとに進捗表示。")
    return p


def main() -> int:
    """入口。各MMSIファイルを航跡分割して書き出す。"""
    args = build_parser().parse_args()
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    if input_dir.resolve() == output_dir.resolve():
        build_parser().error("--input-dir と --output-dir は別フォルダにしてください。")
    if args.gap_threshold_min <= 0:
        build_parser().error("--gap-threshold-min は正の値にしてください。")

    files = list_files(input_dir, args.pattern, args.limit_files)
    if not files:
        raise RuntimeError(f"対象CSVがありません: {input_dir / args.pattern}")

    workers = max(0, int(args.workers or 0))
    progress_every = max(1, int(args.progress_every or 1))

    print("=" * 80)
    print("[SPLIT TRAJECTORIES BY GAP]")
    print(f"input_dir        : {input_dir}")
    print(f"output_dir       : {output_dir}")
    print(f"files            : {len(files):,}")
    print(f"gap_threshold_min: {args.gap_threshold_min:g}  (これより大きいギャップで分割)")
    print(f"min_points       : {args.min_points}")
    print(f"workers          : {workers}")
    print("=" * 80)

    results: List[Dict[str, object]] = []
    failed = 0
    task_args = [(str(p), str(output_dir), args.gap_threshold_min, args.min_points, bool(args.overwrite)) for p in files]

    if workers > 1:
        with ProcessPoolExecutor(max_workers=workers) as ex:
            for i, r in enumerate(ex.map(_worker, task_args), 1):
                results.append(r)
                if not r["ok"]:
                    failed += 1
                    print(f"[WARN] failed {r['path']}: {r['error']}", file=sys.stderr)
                if i % progress_every == 0:
                    print(f"[SPLIT] files={i:,}/{len(files):,}, failed={failed:,}")
    else:
        for i, a in enumerate(task_args, 1):
            r = _worker(a)
            results.append(r)
            if not r["ok"]:
                failed += 1
                print(f"[WARN] failed {r['path']}: {r['error']}", file=sys.stderr)
            if i % progress_every == 0:
                print(f"[SPLIT] files={i:,}/{len(files):,}, failed={failed:,}")

    # マニフェスト書き出し。
    if results:
        output_dir.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(results).to_csv(output_dir / "trajectory_manifest.csv", index=False)

    total_traj = sum(int(r["n_written"]) for r in results if r["ok"])
    total_short = sum(int(r["n_skipped_short"]) for r in results if r["ok"])
    print("=" * 80)
    print("[DONE]")
    print(f"input files        : {len(files):,}")
    print(f"failed files       : {failed:,}")
    print(f"trajectories written: {total_traj:,}")
    print(f"trajectories skipped(<min_points): {total_short:,}")
    print(f"manifest           : {output_dir / 'trajectory_manifest.csv'}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
