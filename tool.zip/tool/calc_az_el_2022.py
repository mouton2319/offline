# -*- coding=utf-8 -*-
import csv
import matplotlib
matplotlib.use('Agg')  # Aggバックエンドを使用する
import skyfield.api
from skyfield.api import wgs84
from skyfield.api import load
import os
from datetime import datetime, timedelta
import glob
import argparse
from pathlib import Path


# テキストファイルからTLEデータを取得する関数
def get_tle_from_file(filename, sat_name):
    with open(filename, 'r', encoding="utf-8", errors="replace") as file:
        lines = file.readlines()

    tle_data = []
    for i, line in enumerate(lines):
        if sat_name in line:
            # i+1 が存在することを最低限チェック
            if i + 1 < len(lines):
                tle_data.append(lines[i].strip())
                tle_data.append(lines[i + 1].strip())
            break
    return tle_data


# 衛星の経緯度と高度位置データを取得する関数
def get_satellite_positions(sat_name, tle_data, target_time):
    ts = skyfield.api.load.timescale()
    t = ts.utc(
        target_time.year, target_time.month, target_time.day,
        target_time.hour, target_time.minute, target_time.second
    )
    satellite = skyfield.api.EarthSatellite(tle_data[0], tle_data[1], sat_name, ts)

    geocentric = satellite.at(t)
    lat, lon = wgs84.latlon_of(geocentric)
    altitude = wgs84.height_of(geocentric).km
    return lat.degrees, lon.degrees, altitude


def satellite_data(tle_file, sat_name, timestamp):
    target_time = datetime.utcfromtimestamp(timestamp)
    tle_data = get_tle_from_file(tle_file, sat_name)
    if len(tle_data) < 2:
        raise ValueError(f"TLEが取得できませんでした: file={tle_file}, sat={sat_name}")
    lat, lon, alt = get_satellite_positions(sat_name, tle_data, target_time)
    print(f'{sat_name=}, {lat=}, {lon=}, {alt=}')
    return lat, lon, alt


def get_az_el(sat_name, tle_data, observer_lat, observer_lon, timestamp):
    # 時刻スケールの生成
    ts = load.timescale()
    # UnixタイムスタンプからUTC日時を生成
    dt = datetime.utcfromtimestamp(timestamp)
    # Skyfieldの時刻オブジェクトを生成
    t = ts.utc(
        dt.year, dt.month, dt.day,
        dt.hour, dt.minute, dt.second + dt.microsecond / 1e6
    )
    # 衛星オブジェクトの生成（TLEデータの1行目、2行目を使用）
    satellite = skyfield.api.EarthSatellite(tle_data[0], tle_data[1], sat_name, ts)
    # 観測者の緯度経度から位置オブジェクトを生成
    observer = wgs84.latlon(observer_lat, observer_lon)
    # 衛星と観測者の差分を計算
    difference = satellite - observer
    topocentric = difference.at(t)
    # 高度、方位、距離を取得
    alt, az, distance = topocentric.altaz()
    # 方位と高度をそれぞれ度単位で返す
    return az.degrees, alt.degrees


def ensure_csv_header(csv_path: Path):
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    if not csv_path.exists():
        with csv_path.open("w", newline="", encoding="utf-8") as f_csv:
            writer = csv.writer(f_csv)
            writer.writerow(["date", "UNIX", "Lat", "Lon", "Alt", "AZ", "EL"])


def main():
    parser = argparse.ArgumentParser(
        description="TLEファイル群から時系列でTLEを切り替えつつ、衛星のLat/Lon/AltとAZ/ELをCSVに出力します。"
    )
    # 追加要件：TLEフォルダと出力CSV名を指定可能に
    parser.add_argument("--tle-dir", default="23467_2022",
                        help="TLEファイル（YYYY-MM-DD-HH-mm-ss.txt）が入ったフォルダ（既定: 23467_2022）")
    parser.add_argument("--out-csv", default="out.csv",
                        help="出力CSVパス（既定: out.csv）")

    # 元コードは固定値なので、必要なら引数化もできるが、今回は既定を維持
    parser.add_argument("--sat-name", default="23467",
                        help="対象衛星番号（既定: 23467）")
    parser.add_argument("--observer-lat", type=float, default=36.3022,
                        help="観測点 緯度（既定: 36.3022）")
    parser.add_argument("--observer-lon", type=float, default=137.9031,
                        help="観測点 経度（既定: 137.9031）")
    parser.add_argument("--start", default="2022-01-01 00:00:00",
                        help="開始日時（ローカル表示用・timestamp算出に使用）例: 2022-01-01 00:00:00")
    parser.add_argument("--end", default="2022-12-31 23:00:00",
                        help="終了日時（ローカル表示用・timestamp算出に使用）例: 2022-12-31 23:00:00")
    parser.add_argument("--step-minutes", type=int, default=1,
                        help="時間ステップ（分）既定: 1")

    args = parser.parse_args()

    sat_name = args.sat_name
    observer_lat = args.observer_lat
    observer_lon = args.observer_lon

    start_dt = datetime.strptime(args.start, "%Y-%m-%d %H:%M:%S")
    end_dt = datetime.strptime(args.end, "%Y-%m-%d %H:%M:%S")
    step = timedelta(minutes=args.step_minutes)

    tle_dir = Path(args.tle_dir)
    if not tle_dir.exists() or not tle_dir.is_dir():
        raise FileNotFoundError(f"TLEフォルダが見つかりません: {tle_dir}")

    # === TLE ファイル一覧を取得・整形 ===
    # ファイル名は "YYYY-MM-DD_HH-mm-ss.txt" 形式である前提
    tle_files = glob.glob(str(tle_dir / "*.txt"))
    tle_files_info = []

    for file_path in tle_files:
        basename = os.path.basename(file_path)
        time_str = os.path.splitext(basename)[0]
        try:
            file_dt = datetime.strptime(time_str, "%Y-%m-%d_%H-%M-%S")
            file_ts = file_dt.timestamp()
            tle_files_info.append((file_ts, file_path))
        except ValueError:
            print(f"ファイル名 {basename} は指定の形式と一致しません。スキップします。")

    tle_files_info.sort(key=lambda x: x[0])

    # CSVヘッダー作成
    csv_path = Path(args.out_csv)
    ensure_csv_header(csv_path)

    print(f"[INFO] tle_dir   : {tle_dir.resolve()}")
    print(f"[INFO] out_csv  : {csv_path.resolve()}")
    print(f"[INFO] sat_name : {sat_name}")
    print(f"[INFO] span     : {start_dt} -> {end_dt} (step={args.step_minutes} min)")
    print(f"[INFO] tle files: {len(tle_files_info)}")

    # === 時間ループ ===
    current_dt = start_dt
    tle_index = 0
    current_tle_file = None

    while current_dt <= end_dt:
        current_ts = current_dt.timestamp()

        # 現在時刻より未来ではない最新のファイルを選ぶ
        while tle_index < len(tle_files_info) and tle_files_info[tle_index][0] <= current_ts:
            current_tle_file = tle_files_info[tle_index][1]
            tle_index += 1

        if current_tle_file is None:
            print(f"{current_dt} に対応する TLE ファイルが見つかりません。スキップします。")
            current_dt += step
            continue

        tle_data = get_tle_from_file(current_tle_file, sat_name)
        if len(tle_data) < 2:
            print(f"[WARN] TLE取得失敗: time={current_dt}, file={current_tle_file}")
            current_dt += step
            continue

        lat, lon, alt = satellite_data(current_tle_file, sat_name, current_ts)
        az, el = get_az_el(sat_name, tle_data, observer_lat, observer_lon, current_ts)

        print(f"時刻: {current_dt} (UNIX: {current_ts})")
        print(f"  使用 TLE ファイル: {current_tle_file}")
        print(f"  衛星データ: 緯度={lat}, 経度={lon}, 高度={alt}")
        print(f"  方位/仰角: az={az}, el={el}")
        print("-" * 50)

        with csv_path.open("a", newline="", encoding="utf-8") as f_csv:
            writer = csv.writer(f_csv)
            writer.writerow([
                current_dt.strftime("%Y-%m-%d %H:%M:%S"),
                current_ts, lat, lon, alt, az, el
            ])

        current_dt += step


if __name__ == "__main__":
    main()
