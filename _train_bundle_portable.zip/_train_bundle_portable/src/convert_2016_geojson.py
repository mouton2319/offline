# convert_2016_geojson.py

import subprocess
import shutil
from pathlib import Path


YEAR = 2016
GDB_PATH = Path("Atlantic.gdb")
OUT_DIR = Path(".")  # 出力先。必要なら Path("geojson") などに変更


def main():
    if shutil.which("ogr2ogr") is None:
        raise RuntimeError(
            "ogr2ogr が見つかりません。OSGeo4W Shell から実行してください。"
        )

    if not GDB_PATH.exists():
        raise FileNotFoundError(f"{GDB_PATH} が見つかりません。")

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    for month in range(1, 13):
        mm = f"{month:02d}"

        layer_name = f"Tracks_{YEAR}_{mm}"
        output_geojson = OUT_DIR / f"{layer_name}.geojson"

        print("=" * 80)
        print(f"Converting: {layer_name}")
        print(f"Output    : {output_geojson}")
        print("=" * 80)

        if output_geojson.exists():
            print(f"[SKIP] 既に存在します: {output_geojson}")
            print("       再作成したい場合は、既存ファイルを削除してから実行してください。")
            continue

        cmd = [
            "ogr2ogr",
            "-f", "GeoJSON",
            "-t_srs", "EPSG:4326",
            "-lco", "RFC7946=YES",
            "-lco", "COORDINATE_PRECISION=6",
            "-progress",
            str(output_geojson),
            str(GDB_PATH),
            layer_name,
        ]

        print("[CMD]")
        print(" ".join(f'"{x}"' if " " in x else x for x in cmd))
        print()

        result = subprocess.run(cmd)

        if result.returncode != 0:
            raise RuntimeError(f"変換に失敗しました: {layer_name}")

        print(f"[OK] {layer_name} -> {output_geojson}")

    print()
    print("[DONE] 12か月分の変換処理が完了しました。")


if __name__ == "__main__":
    main()