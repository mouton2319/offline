import numpy as np, pandas as pd
P=86164.0905/60.0
H=4

def load_year(y):
    df=pd.read_csv(f'/work/{y}_calc_az_el.csv', usecols=['date','AZ','EL'])
    dt=pd.to_datetime(df['date'])
    df['day_key']=dt.dt.strftime('%m-%d')
    df['minute']=dt.dt.hour*60+dt.dt.minute
    return df

def fit_day(minute, values):
    t=minute.to_numpy(dtype=float)
    y=values.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/P
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    return np.linalg.lstsq(X,y,rcond=None)[0]

def eval_day(minute, beta):
    t=minute.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/P
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    return X@beta

frames={y:load_year(y) for y in range(2017,2025)}
coefs={y:{} for y in range(2017,2025)}
for y,df in frames.items():
    for day,g in df.groupby('day_key'):
        coefs[y][day]=(fit_day(g['minute'], g['AZ']), fit_day(g['minute'], g['EL']))
truth=frames[2024]
pred_az=[]; pred_el=[]; true_az=[]; true_el=[]
for day,g in truth.groupby('day_key'):
    hist=[]
    for y in range(2017,2024):
        if day in coefs[y]: hist.append((y,coefs[y][day]))
    years=np.array([y for y,_ in hist], dtype=float)
    az_mat=np.stack([c[0] for _,c in hist], axis=0)
    el_mat=np.stack([c[1] for _,c in hist], axis=0)
    yrs=years[-4:] if len(years)>=4 else years
    A=np.c_[np.ones_like(yrs), yrs]
    B=np.linalg.lstsq(A, az_mat[-len(yrs):], rcond=None)[0]; b_az=np.array([1,2024.0])@B
    B=np.linalg.lstsq(A, el_mat[-len(yrs):], rcond=None)[0]; b_el=np.array([1,2024.0])@B
    pred_az.append(eval_day(g['minute'], b_az)); pred_el.append(eval_day(g['minute'], b_el))
    true_az.append(g['AZ'].to_numpy()); true_el.append(g['EL'].to_numpy())
az=np.abs(np.concatenate(pred_az)-np.concatenate(true_az)); el=np.abs(np.concatenate(pred_el)-np.concatenate(true_el))
print('sidereal daily coeff mean', float((az.mean()+el.mean())/2), 'max', float(max(az.max(), el.max())))
