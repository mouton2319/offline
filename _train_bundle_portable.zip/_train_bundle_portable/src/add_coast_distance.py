#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡CSVの各点 (lon, lat) について「最寄りの海岸線までの最短距離(km)」を計算し、
新しい特徴量列として追加するスクリプト。cartopy 同梱の Natural Earth(physical/land)
だけを使う(追加ダウンロード不要)。

=== 計算方法(精度重視・グリッド近似ではない) ===
1. Natural Earth の陸地ポリゴンを読み込み、その境界線(=海岸線)を多数の LineString に分解。
2. それらを shapely 2.0 の STRtree(空間索引)に載せる。
3. 各AIS点について query_nearest で「最寄りの海岸線ジオメトリ」を一括(ベクトル化)取得。
4. shapely.shortest_line で「点→海岸線上の最近点」を求め、その2点間を
   haversine(球面距離)で km 換算する。→ これが coast_dist_km。
5. ついでに陸海判定 is_on_land(陸地ポリゴン内なら1)も付与する。

既存の geo_features.py は EDT グリッド方式(約550m解像度・高速な近似)。
本スクリプトは「点ごとに最近傍海岸線への厳密距離」を出す版で、精度は高いが計算は重め。
全データ(~1.5億点)に一気に適用すると時間がかかるため、--workers で並列化し、
まず --limit-files で試すこと。高速優先なら geo_features.py(--add-geo)を使う。

提供する列:
  coast_dist_km : 最寄り海岸線までの最短距離(km)。沿岸・港湾で小、外洋で大。
  is_on_land    : 陸地ポリゴン内なら1.0、海上なら0.0(補間/接岸点の検出に有用)。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\add_coast_distance.py `
    --input-dir .\\src\\timeseries_by_mmsi_turn\\trajectories `
    --output-dir .\\src\\timeseries_by_mmsi_turn\\trajectories_coast `
    --pattern "MMSI_*_traj_*.csv" --resolution 10m --workers 6
"""

from __future__ import annotations

import argparse
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

# 追加する地理特徴量の列名。
COAST_FEATURES = ["coast_dist_km", "is_on_land"]

# プロセス(worker)内で海岸線索引を1回だけ構築してキャッシュする。
_LAND_CACHE: dict = {}


def haversine_km(lon1, lat1, lon2, lat2) -> np.ndarray:
    """緯度経度2点間の球面距離(km)。配列対応・ベクトル化。"""
    R = 6371.0088  # 地球平均半径(km)
    lon1 = np.radians(np.asarray(lon1, dtype=np.float64))
    lat1 = np.radians(np.asarray(lat1, dtype=np.float64))
    lon2 = np.radians(np.asarray(lon2, dtype=np.float64))
    lat2 = np.radians(np.asarray(lat2, dtype=np.float64))
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2.0) ** 2
    return 2.0 * R * np.arcsin(np.sqrt(np.clip(a, 0.0, 1.0)))


def _build_land_index(resolution: str) -> dict:
    """Natural Earth 陸地から「海岸線STRtree + 陸地ポリゴン(prepare済み)」を構築。

    重い処理なので worker ごとに1回だけ行い、_LAND_CACHE に保存する。

    Returns:
        {"tree": STRtree, "coast": ndarray(LineString), "land": MultiPolygon}
    """
    if resolution in _LAND_CACHE:
        return _LAND_CACHE[resolution]

    import shapely
    import cartopy.io.shapereader as shpreader
    from shapely.ops import unary_union

    land_shp = shpreader.natural_earth(resolution=resolution, category="physical", name="land")
    geoms = list(shpreader.Reader(land_shp).geometries())
    land_union = unary_union(geoms)              # 陸海判定(contains)用の全陸地
    shapely.prepare(land_union)                  # contains を桁違いに速くする前処理

    # 陸地境界(=海岸線)を個々の LineString に分解して STRtree に載せる。
    boundaries = land_union.boundary             # MultiLineString
    coast_parts = shapely.get_parts(boundaries)  # 多数の LineString 配列
    if coast_parts.size == 0:
        coast_parts = np.asarray([boundaries], dtype=object)
    tree = shapely.STRtree(coast_parts)

    entry = {"tree": tree, "coast": coast_parts, "land": land_union}
    _LAND_CACHE[resolution] = entry
    return entry


def add_coast_features(df: pd.DataFrame, resolution: str = "10m") -> None:
    """DataFrame に coast_dist_km / is_on_land 列を破壊的に追加する。

    Args:
        df: lon/lat 列を持つ DataFrame。
        resolution: Natural Earth 解像度("10m"/"50m"/"110m")。
    """
    import shapely

    if df.empty:
        for c in COAST_FEATURES:
            df[c] = np.float32(0.0)
        return

    idx = _build_land_index(resolution)
    tree = idx["tree"]
    coast = idx["coast"]
    land = idx["land"]

    lon = df["lon"].to_numpy(dtype=np.float64)
    lat = df["lat"].to_numpy(dtype=np.float64)
    pts = shapely.points(lon, lat)               # 各点を shapely Point 配列に

    # --- 最寄り海岸線ジオメトリのindexを一括取得 ---
    # query_nearest は (source_idx, tree_idx) のペア配列を返す(同距離の同点は複数)。
    # 各点について最初の1件だけ採用する。
    res = np.asarray(tree.query_nearest(pts))
    nearest = np.zeros(len(pts), dtype=np.int64)
    if res.ndim == 2 and res.shape[0] == 2:
        src, tgt = res[0], res[1]
        first = np.ones(len(src), dtype=bool)
        if len(src) > 1:
            first[1:] = src[1:] != src[:-1]      # 同一source の先頭だけ True
        nearest[src[first]] = tgt[first]
    else:
        # まれに 1次元で返る実装差に備える。
        nearest = res.astype(np.int64)

    nearest_geoms = coast[nearest]

    # --- 点→海岸線上の最近点 を求めて haversine で km 化 ---
    lines = shapely.shortest_line(pts, nearest_geoms)   # 2点 LineString の配列
    coords = shapely.get_coordinates(lines)             # (2N, 2): 点, 海岸最近点 が交互
    coords = coords.reshape(-1, 2, 2)
    coast_lon = coords[:, 1, 0]                          # 海岸線上の最近点 lon
    coast_lat = coords[:, 1, 1]                          # 同 lat
    dist_km = haversine_km(lon, lat, coast_lon, coast_lat)

    # --- 陸海判定 ---
    on_land = shapely.contains_xy(land, lon, lat)

    df["coast_dist_km"] = dist_km.astype(np.float32)
    df["is_on_land"] = on_land.astype(np.float32)


def process_one_file(path: Path, output_dir: Path, resolution: str, overwrite: bool) -> Dict[str, object]:
    """1ファイルに coast 特徴量を付与して output_dir へ書き出す。"""
    out_path = output_dir / path.name
    if out_path.exists() and not overwrite:
        return {"ok": True, "skipped": True, "path": path.name, "rows": 0, "error": ""}
    try:
        df = pd.read_csv(path)
        if "lon" not in df.columns or "lat" not in df.columns:
            raise ValueError("lon/lat 列がありません")
        df["lon"] = pd.to_numeric(df["lon"], errors="coerce")
        df["lat"] = pd.to_numeric(df["lat"], errors="coerce")
        add_coast_features(df, resolution=resolution)
        output_dir.mkdir(parents=True, exist_ok=True)
        df.to_csv(out_path, index=False)
        return {"ok": True, "skipped": False, "path": path.name, "rows": int(len(df)), "error": ""}
    except Exception as e:
        return {"ok": False, "skipped": False, "path": path.name, "rows": 0, "error": str(e)}


def _worker(args) -> Dict[str, object]:
    """ProcessPool 用ラッパー。"""
    path_text, out_text, resolution, overwrite = args
    return process_one_file(Path(path_text), Path(out_text), resolution, overwrite)


def list_files(input_dir: Path, pattern: str, limit_files: int) -> List[Path]:
    files = sorted(input_dir.glob(pattern))
    if limit_files and limit_files > 0:
        files = files[:limit_files]
    return files


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="航跡CSVに海岸線までの最短距離(coast_dist_km)を追加する(cartopy + shapely)。")
    p.add_argument("--input-dir", required=True, help="入力CSVフォルダ(航跡別CSV等)。")
    p.add_argument("--output-dir", required=True, help="出力フォルダ(input-dirと別にする)。")
    p.add_argument("--pattern", default="MMSI_*_traj_*.csv", help="入力globパターン。")
    p.add_argument("--resolution", default="10m", choices=["10m", "50m", "110m"],
                   help="Natural Earth の海岸線解像度。10mが最も詳細(既定)。")
    p.add_argument("--workers", type=int, default=0, help="並列プロセス数。0/1で逐次。各workerが海岸線索引を1回構築。")
    p.add_argument("--overwrite", action="store_true", help="既存の出力を上書きする。")
    p.add_argument("--limit-files", type=int, default=0, help="先頭N件だけ処理(まず試す用)。0で全件。")
    p.add_argument("--progress-every", type=int, default=200, help="N件ごとに進捗表示。")
    return p


def main() -> int:
    args = build_parser().parse_args()
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    if input_dir.resolve() == output_dir.resolve():
        build_parser().error("--input-dir と --output-dir は別フォルダにしてください。")

    files = list_files(input_dir, args.pattern, args.limit_files)
    if not files:
        raise RuntimeError(f"対象CSVがありません: {input_dir / args.pattern}")

    workers = max(0, int(args.workers or 0))
    progress_every = max(1, int(args.progress_every or 1))

    print("=" * 80)
    print("[ADD COAST DISTANCE]")
    print(f"input_dir  : {input_dir}")
    print(f"output_dir : {output_dir}")
    print(f"files      : {len(files):,}")
    print(f"resolution : {args.resolution}")
    print(f"workers    : {workers}")
    print("=" * 80)

    results: List[Dict[str, object]] = []
    failed = 0
    task_args = [(str(p), str(output_dir), args.resolution, bool(args.overwrite)) for p in files]

    if workers > 1:
        with ProcessPoolExecutor(max_workers=workers) as ex:
            for i, r in enumerate(ex.map(_worker, task_args), 1):
                results.append(r)
                if not r["ok"]:
                    failed += 1
                    print(f"[WARN] failed {r['path']}: {r['error']}", file=sys.stderr)
                if i % progress_every == 0:
                    print(f"[COAST] files={i:,}/{len(files):,}, failed={failed:,}")
    else:
        for i, a in enumerate(task_args, 1):
            r = _worker(a)
            results.append(r)
            if not r["ok"]:
                failed += 1
                print(f"[WARN] failed {r['path']}: {r['error']}", file=sys.stderr)
            if i % progress_every == 0:
                print(f"[COAST] files={i:,}/{len(files):,}, failed={failed:,}")

    if results:
        output_dir.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(results).to_csv(output_dir / "coast_manifest.csv", index=False)

    written = sum(1 for r in results if r["ok"] and not r["skipped"])
    print("=" * 80)
    print("[DONE]")
    print(f"written : {written:,}")
    print(f"failed  : {failed:,}")
    print(f"manifest: {output_dir / 'coast_manifest.csv'}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
