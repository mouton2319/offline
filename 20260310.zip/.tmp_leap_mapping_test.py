import numpy as np, pandas as pd
import ufo4_orbit_predict_tf as core
import ufo4_harmonic_azel_tf as hm

def wrap180(x): return ((x+180)%360)-180
prev_u, prev=core.load_orbit_numeric_azel('/work/2023_calc_az_el.csv')
truth_u, truth=core.load_orbit_numeric_azel('/work/2024_calc_az_el.csv')
# base template lookup same slot
w=np.ones((len(prev_u),),dtype=np.float32)
tpl=core.build_azel_template(prev_u, prev, w)
same,_=core.lookup_template_azel(truth_u, tpl)
# shift prediction unix by +/-1day after Mar1 2024
preds={('same',0):same}
for day_shift in [-2,-1,1,2]:
    u=truth_u.copy()
    after= u >= (pd.Timestamp('2024-03-01 00:00:00').timestamp() - 9*3600)
    u2=u.copy(); u2[after] -= day_shift*86400.0
    p,_=core.lookup_template_azel(u2, tpl)
    preds[(f'after_mar1_{day_shift:+d}d',day_shift)] = p
for name,_ in preds:
    p=preds[(name,_)]
    az=np.abs(hm.angle_diff_deg(p[:,0], truth[:,0])); el=np.abs(p[:,1]-truth[:,1])
    print(name, 'mean', float((az.mean()+el.mean())/2), 'max', float(max(az.max(), el.max())))
