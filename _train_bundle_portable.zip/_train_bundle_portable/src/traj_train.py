#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡予測(v1)の学習スクリプト。共通ライブラリ traj_common.py のモデル/データセットを使う。

各航跡の start→end を1系列として、decoder-only 因果Transformerで
「これまでの道筋 → 次の一歩(次の移動量)」を学習する。1ファイル=1航跡、長さは任意。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\traj_train.py `
    --data-dir .\\claude_test\\trajectories_full `
    --out-dir .\\claude_test\\artifacts_traj_full `
    --epochs 4 --batch-size 256 --max-len 256 --num-workers 8 --scaler-sample 3000 --device cuda
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import asdict
from functools import partial
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from traj_common import (
    TrajConfig, TrajectoryDataset, collate_trajectories,
    build_model, fit_stats, list_traj_files,
)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="航跡 decoder-only Transformer(v1) を学習する。")
    p.add_argument("--data-dir", required=True, help="航跡別CSVのフォルダ(split_trajectories_by_gap.py の出力)")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--pattern", default="MMSI_*_traj_*.csv")
    p.add_argument("--feature-cols", default="", help="dx,dy に加える数値列をカンマ区切りで(例: coast_dist_km,speed_kmh)")
    p.add_argument("--limit-files", type=int, default=0, help="先頭N航跡だけ使う(テスト用)")
    p.add_argument("--max-len", type=int, default=256, help="系列最大長。超過は学習時ランダム切り出し")
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--nhead", type=int, default=8)
    p.add_argument("--num-layers", type=int, default=3)
    p.add_argument("--dim-feedforward", type=int, default=256)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--interval-minutes", type=float, default=3.0)
    p.add_argument("--scaler-sample", type=int, default=2000, help="標準化統計に使う航跡サンプル数")
    p.add_argument("--num-workers", type=int, default=0, help="DataLoaderワーカー数。Windowsは0で安定、増やすなら2〜8")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="")
    return p


def main() -> int:
    args = build_parser().parse_args()
    data_dir = Path(args.data_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    files = list_traj_files(data_dir, args.pattern, args.limit_files)
    if not files:
        raise FileNotFoundError(f"航跡CSVがありません: {data_dir / args.pattern}")

    feature_cols = [c.strip() for c in (args.feature_cols.split(",") if args.feature_cols else []) if c.strip()]
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)

    print("=" * 80)
    print("[TRAIN traj_decoder_only_v1]")
    print(f"data_dir    : {data_dir}")
    print(f"trajectories: {len(files):,}")
    print(f"feature_cols: {feature_cols if feature_cols else '(dx,dy のみ)'}")
    print(f"max_len     : {args.max_len}  d_model={args.d_model} layers={args.num_layers} heads={args.nhead}")
    print("=" * 80)

    print("[1/2] 標準化統計を推定中...")
    disp_mean, disp_std, feat_mean, feat_std = fit_stats(files, feature_cols, args.scaler_sample, args.seed)
    input_dim = 2 + len(feature_cols)

    cfg = TrajConfig(
        feature_cols=feature_cols, input_dim=input_dim,
        d_model=args.d_model, nhead=args.nhead, num_layers=args.num_layers,
        dim_feedforward=args.dim_feedforward, dropout=args.dropout, max_len=args.max_len,
        interval_minutes=args.interval_minutes,
        disp_mean=disp_mean.tolist(), disp_std=disp_std.tolist(),
        feat_mean=feat_mean.tolist(), feat_std=feat_std.tolist(),
    )

    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    ds = TrajectoryDataset(files, feature_cols, args.max_len, train=True, seed=args.seed)
    # num-workers>0(Windows spawn)でもworkerへ渡せるよう、lambdaではなくpicklableなpartialにする。
    collate = partial(collate_trajectories, disp_mean=cfg.disp_mean, disp_std=cfg.disp_std,
                      feat_mean=cfg.feat_mean, feat_std=cfg.feat_std)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
                        collate_fn=collate, pin_memory=(device.type == "cuda"), drop_last=False,
                        persistent_workers=(args.num_workers > 0),
                        prefetch_factor=(4 if args.num_workers > 0 else None))

    model = build_model(cfg).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"[MODEL] params={n_params:,}  input_dim={input_dim}  device={device}")

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    crit = nn.SmoothL1Loss(reduction="none")
    best = float("inf")
    best_path = out_dir / "traj_model.pt"

    print("[2/2] 学習...")
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses = []
        for batch in loader:
            x = batch["x"].to(device); y = batch["y"].to(device)
            valid = batch["valid"].to(device)
            pad = batch["pad"].to(device)
            opt.zero_grad(set_to_none=True)
            pred = model(x, pad_mask=pad)                  # [B,L,2]
            per = crit(pred, y).sum(dim=-1)                # [B,L]
            m = valid.float()
            loss = (per * m).sum() / m.sum().clamp_min(1.0)  # 有効位置だけ平均
            if not torch.isfinite(loss):
                continue
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            opt.step()
            losses.append(float(loss.item()))
        tr = float(np.mean(losses)) if losses else float("nan")
        print(f"[EPOCH {epoch:03d}] train_loss(SmoothL1, std-disp)={tr:.6f}")
        # シンプル版では train_loss を指標に best を更新(検証分割は次段階で追加)。
        if np.isfinite(tr) and tr < best:
            best = tr
            torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, best_path)
            print(f"[SAVE] {best_path}  best_train_loss={best:.6f}")

    with (out_dir / "traj_config.json").open("w", encoding="utf-8") as fp:
        json.dump(asdict(cfg), fp, ensure_ascii=False, indent=2)
    print("=" * 80)
    print(f"[DONE] model={best_path}  best_train_loss={best:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
