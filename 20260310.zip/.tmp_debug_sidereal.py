import json, numpy as np
from pathlib import Path
import ufo4_predict_tf as pred
import ufo4_sidereal_coeff_model as scm
import ufo4_orbit_predict_tf as core

model_dir=Path('ufo4_azel_model_artifacts')
meta=json.loads((model_dir/'ufo4_azel_model_meta.json').read_text())
sid_cfg=scm.cfg_from_dict(meta.get('sidereal_coeff_config', {}))
model_path=model_dir/meta['model_path']
template_path=model_dir/meta['template_path']
model,corr,aa,ae=scm.load_saved_model(model_path, scm.cfg_to_dict(sid_cfg))
tpl=pred._load_template_pack(template_path)
dates, unix = core.load_template_with_dates(Path('2024_calc_az_el.csv'))
unix=np.asarray(unix, dtype=np.float64)
out0, base0, delta0 = scm.apply_transition_delta_model(model, tpl, unix[:10], None, 1.0, 1.0)
out1, base1, delta1 = scm.apply_transition_delta_model(model, tpl, unix[:10], corr, aa, ae)
print('base0==base1', np.allclose(base0, base1))
print('delta0 first', delta0[:5])
print('out0 first', out0[:5])
print('corr extra first', np.column_stack([((out1[:,0]-out0[:,0]+540)%360)-180, out1[:,1]-out0[:,1]])[:5])
print('delta1 first', delta1[:5])
print('out1 first', out1[:5])
print('gamma shape', np.asarray(model['gamma_delta']).shape)
print('gamma abs max', np.abs(np.asarray(model['gamma_delta'])).max())
if corr:
    print('corr beta abs max', np.abs(np.asarray(corr['beta_corr'])).max())
