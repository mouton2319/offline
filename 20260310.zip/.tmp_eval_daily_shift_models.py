import numpy as np, pandas as pd
from collections import defaultdict

MAX_SHIFT=30

def wrap180(x):
    return ((x + 180.0) % 360.0) - 180.0

def load_year(y):
    df=pd.read_csv(f'/work/{y}_calc_az_el.csv', usecols=['date','AZ','EL'])
    dt=pd.to_datetime(df['date'])
    df['day_key']=dt.dt.strftime('%m-%d')
    df['minute']=dt.dt.hour*60+dt.dt.minute
    return df

def day_params(prev_day, cur_day, max_shift=MAX_SHIFT):
    p=prev_day.set_index('minute')[['AZ','EL']].reindex(range(1440))
    c=cur_day.set_index('minute')[['AZ','EL']].reindex(range(1440))
    best=None
    for s in range(-max_shift, max_shift+1):
        ps=p.shift(s)
        m=ps.notna().all(axis=1) & c.notna().all(axis=1)
        if m.sum()<1000:
            continue
        da=wrap180(c.loc[m,'AZ'].to_numpy()-ps.loc[m,'AZ'].to_numpy())
        de=c.loc[m,'EL'].to_numpy()-ps.loc[m,'EL'].to_numpy()
        az_off=float(np.median(da))
        el_off=float(np.median(de))
        rem=np.maximum(np.abs(wrap180(ps.loc[m,'AZ'].to_numpy()+az_off-c.loc[m,'AZ'].to_numpy())), np.abs(ps.loc[m,'EL'].to_numpy()+el_off-c.loc[m,'EL'].to_numpy()))
        score=float(np.quantile(rem,0.99))
        if best is None or score<best[0]:
            best=(score,s,az_off,el_off,float(rem.max()),float(rem.mean()))
    return best

def apply_day(prev_day, shift, az_off, el_off):
    p=prev_day.set_index('minute')[['AZ','EL']].reindex(range(1440)).shift(int(round(shift)))
    p=p.interpolate(limit_direction='both')
    out=p.copy()
    out['AZ']=((out['AZ'].to_numpy()+az_off)%360.0)
    out['EL']=out['EL'].to_numpy()+el_off
    return out

frames={y:load_year(y) for y in range(2017,2025)}
params=defaultdict(dict)
for y in range(2018,2025):
    prev=frames[y-1]
    cur=frames[y]
    for day, gcur in cur.groupby('day_key'):
        gprev=prev[prev['day_key']==day]
        if len(gprev)==0:
            continue
        params[y][day]=day_params(gprev, gcur)

# evaluate oracle lower bound
mx=[]
for day,g in frames[2024].groupby('day_key'):
    if day not in params[2024]:
        continue
    _,s,az_off,el_off,mxday,meanday=params[2024][day]
    pred=apply_day(frames[2023][frames[2023]['day_key']==day], s, az_off, el_off)
    t=g.set_index('minute')[['AZ','EL']].reindex(range(1440))
    da=np.abs(wrap180(pred['AZ'].to_numpy()-t['AZ'].to_numpy()))
    de=np.abs(pred['EL'].to_numpy()-t['EL'].to_numpy())
    mx.append((day,float(da.mean()),float(de.mean()),float(max(da.max(),de.max()))))
print('oracle daily shift+offset 2024 overall max', max(r[3] for r in mx), 'mean', np.mean([(r[1]+r[2])/2 for r in mx]))

methods={}
methods['last']=lambda hist,target: hist[-1]
def rec_lin(hist,target):
    yrs=np.array([h[0] for h in hist],dtype=float)
    vals=np.array([h[1:] for h in hist],dtype=float)
    if len(hist)==1: return tuple(vals[0])
    X=np.c_[np.ones_like(yrs), yrs]
    B=np.linalg.lstsq(X, vals, rcond=None)[0]
    pred=np.array([1.0,float(target)])@B
    pred[0]=np.clip(pred[0], -MAX_SHIFT, MAX_SHIFT)
    return tuple(pred)
methods['linear']=rec_lin
def recent_mean(hist,target):
    vals=np.array([h[1:] for h in hist[-3:]],dtype=float)
    pred=np.mean(vals,axis=0)
    pred[0]=np.clip(pred[0], -MAX_SHIFT, MAX_SHIFT)
    return tuple(pred)
methods['mean3']=recent_mean

def damped(hist,target):
    if len(hist)<2:
        return hist[-1][1:]
    a=np.array(hist[-1][1:],dtype=float)
    b=np.array(hist[-2][1:],dtype=float)
    pred=a+0.5*(a-b)
    pred[0]=np.clip(pred[0], -MAX_SHIFT, MAX_SHIFT)
    return tuple(pred)
methods['damped']=damped

for name, fn in methods.items():
    print('\nmethod', name)
    for target in range(2021,2025):
        rows=[]
        prev_year=target-1
        for day,g in frames[target].groupby('day_key'):
            hist=[]
            for y in range(2018,target+0):
                if day in params[y]:
                    _,s,az_off,el_off,_,_=params[y][day]
                    hist.append((y,s,az_off,el_off))
            if len(hist)==0:
                continue
            s,az_off,el_off=fn(hist,target)
            pred=apply_day(frames[prev_year][frames[prev_year]['day_key']==day], s, az_off, el_off)
            t=g.set_index('minute')[['AZ','EL']].reindex(range(1440))
            da=np.abs(wrap180(pred['AZ'].to_numpy()-t['AZ'].to_numpy()))
            de=np.abs(pred['EL'].to_numpy()-t['EL'].to_numpy())
            rows.append((float((da.mean()+de.mean())/2), float(max(da.max(),de.max()))))
        print(target, 'mean', float(np.mean([r[0] for r in rows])), 'max', float(np.max([r[1] for r in rows])))
