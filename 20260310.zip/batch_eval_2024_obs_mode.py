#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Batch evaluation runner for orbit_geo_7d23d_analog online observation mode.

Runs predict for all matching 2024 TLE/baseline pairs and aggregates AZ/EL metrics.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def log(msg: str) -> None:
    print(msg, flush=True)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def parse_stem_datetime(stem: str) -> Optional[dt.datetime]:
    m = re.search(r"(\d{4}-\d{2}-\d{2})[_-](\d{2})-(\d{2})-(\d{2})", str(stem))
    if m is None:
        return None
    try:
        d0 = dt.datetime.strptime(m.group(1), "%Y-%m-%d")
    except Exception:
        return None
    return d0.replace(hour=int(m.group(2)), minute=int(m.group(3)), second=int(m.group(4)))


def list_stems(tle_dir: Path, baseline_dir: Path, max_files: Optional[int]) -> List[str]:
    tle = {p.stem for p in tle_dir.glob("*.txt") if p.is_file()}
    bsv = {p.stem for p in baseline_dir.glob("*.csv") if p.is_file()}
    stems = sorted(tle.intersection(bsv))
    stems = [s for s in stems if parse_stem_datetime(s) is not None]
    stems.sort(key=lambda x: parse_stem_datetime(x))
    if max_files is not None and max_files > 0:
        stems = stems[: int(max_files)]
    return stems


def add_optional_arg(cmd: List[str], flag: str, value: Optional[object]) -> None:
    if value is None:
        return
    cmd.extend([flag, str(value)])


def build_predict_cmd(
    args: argparse.Namespace,
    stem: str,
    tle_file: Path,
    baseline_csv: Path,
    out_corrected_csv: Path,
    out_pred_error_csv: Path,
    out_metrics_csv: Path,
    plot_dir: Optional[Path],
) -> List[str]:
    cmd = [
        str(args.python_exe),
        str(args.predict_script),
        "predict",
        "--model",
        str(args.model),
        "--tle-file",
        str(tle_file),
        "--baseline-csv",
        str(baseline_csv),
        "--truth-csv",
        str(args.truth_csv),
        "--obs-truth-csv",
        str(args.obs_truth_csv),
        "--predictor-mode",
        str(args.predictor_mode),
        "--out-corrected-csv",
        str(out_corrected_csv),
        "--out-pred-error-csv",
        str(out_pred_error_csv),
        "--out-metrics-csv",
        str(out_metrics_csv),
        "--obs-hours",
        str(float(args.obs_hours)),
        "--obs-min-valid",
        str(int(args.obs_min_valid)),
        "--obs-assim-strength",
        str(float(args.obs_assim_strength)),
        "--obs-pool-size",
        str(int(args.obs_pool_size)),
        "--obs-sign-flip-margin",
        str(float(args.obs_sign_flip_margin)),
        "--obs-conf-floor",
        str(float(args.obs_conf_floor)),
        "--ood-conf-floor",
        str(float(args.ood_conf_floor)),
        "--min-ood-conf-apply",
        str(float(args.min_ood_conf_apply)),
        "--overwrite",
    ]
    if bool(args.obs_sign_flip):
        cmd.append("--obs-sign-flip")
    else:
        cmd.append("--no-obs-sign-flip")

    if bool(args.no_plot):
        cmd.append("--no-plot")
    else:
        if plot_dir is not None:
            cmd.extend(["--plot-dir", str(plot_dir)])

    add_optional_arg(cmd, "--hybrid-weight", args.hybrid_weight)
    add_optional_arg(cmd, "--days-horizon", args.days_horizon)
    add_optional_arg(cmd, "--fit-days", args.fit_days)
    add_optional_arg(cmd, "--pre-days", args.pre_days)
    add_optional_arg(cmd, "--step-minutes", args.step_minutes)
    add_optional_arg(cmd, "--sample-every", args.sample_every)
    add_optional_arg(cmd, "--k", args.k)
    add_optional_arg(cmd, "--tau", args.tau)
    add_optional_arg(cmd, "--year-half-life", args.year_half_life)
    add_optional_arg(cmd, "--doy-sigma", args.doy_sigma)
    add_optional_arg(cmd, "--neighbor-pool-mult", args.neighbor_pool_mult)
    add_optional_arg(cmd, "--alpha-az", args.alpha_az)
    add_optional_arg(cmd, "--alpha-el", args.alpha_el)
    add_optional_arg(cmd, "--cap-deg", args.cap_deg)
    add_optional_arg(cmd, "--transition-hours", args.transition_hours)
    add_optional_arg(cmd, "--auto-lowerr-th", args.auto_lowerr_th)
    add_optional_arg(cmd, "--auto-max-neighbor-dist", args.auto_max_neighbor_dist)
    add_optional_arg(cmd, "--auto-max-unc-az", args.auto_max_unc_az)
    add_optional_arg(cmd, "--auto-max-unc-el", args.auto_max_unc_el)
    add_optional_arg(cmd, "--auto-max-corr-ratio", args.auto_max_corr_ratio)
    if args.causal_predict is True:
        cmd.append("--causal-predict")
    elif args.causal_predict is False:
        cmd.append("--no-causal-predict")
    cmd += [x for x in str(args.extra_predict_args).split(" ") if x.strip()]
    return cmd


def read_metric_pair(path: Path, segment: str) -> Tuple[float, float, float, float]:
    if not path.exists():
        return np.nan, np.nan, np.nan, np.nan
    df = pd.read_csv(path)
    sub = df[df["segment"] == segment].copy()
    if len(sub) == 0:
        return np.nan, np.nan, np.nan, np.nan
    b = sub[sub["kind"] == "baseline"]
    c = sub[sub["kind"] == "corrected"]
    if len(b) == 0 or len(c) == 0:
        return np.nan, np.nan, np.nan, np.nan
    b0 = b.iloc[0]
    c0 = c.iloc[0]
    baz = float(b0["AZ_RMSE"]) if pd.notna(b0["AZ_RMSE"]) else np.nan
    bez = float(b0["EL_RMSE"]) if pd.notna(b0["EL_RMSE"]) else np.nan
    caz = float(c0["AZ_RMSE"]) if pd.notna(c0["AZ_RMSE"]) else np.nan
    cez = float(c0["EL_RMSE"]) if pd.notna(c0["EL_RMSE"]) else np.nan
    return baz, bez, caz, cez


def safe_improve_pct(base: float, corr: float) -> float:
    if not np.isfinite(base) or not np.isfinite(corr) or abs(base) <= 1e-12:
        return np.nan
    return float((base - corr) / base * 100.0)


def finite_mean(series: pd.Series) -> float:
    x = pd.to_numeric(series, errors="coerce").to_numpy(dtype=np.float64)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return np.nan
    return float(np.mean(x))


def finite_median(series: pd.Series) -> float:
    x = pd.to_numeric(series, errors="coerce").to_numpy(dtype=np.float64)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return np.nan
    return float(np.median(x))


def read_diag(path: Path) -> Dict:
    out = {
        "ood_conf": np.nan,
        "ood_conf_raw": np.nan,
        "corr_scale": np.nan,
        "neighbor0_dist": np.nan,
        "neighbor_dist_w": np.nan,
        "unc_az_rms": np.nan,
        "unc_el_rms": np.nan,
        "corr_ratio": np.nan,
        "est_base_az_rmse": np.nan,
        "est_base_el_rmse": np.nan,
        "est_base_azel_rmse": np.nan,
        "gate_reason": "",
        "obs_assim_used": False,
        "obs_valid_rows": 0,
        "obs_weight_gain": np.nan,
        "obs_sign_az": np.nan,
        "obs_sign_el": np.nan,
        "obs_conf_floor": np.nan,
        "alpha_AZ": np.nan,
        "alpha_EL": np.nan,
        "k": np.nan,
        "tau": np.nan,
        "predictor_mode": "",
        "hybrid_weight": np.nan,
    }
    if not path.exists():
        return out
    df = pd.read_csv(path)
    if len(df) == 0:
        return out
    p0 = df.iloc[0]
    for k in out.keys():
        if k not in p0.index:
            continue
        v = p0[k]
        if k in ("gate_reason", "predictor_mode"):
            out[k] = "" if pd.isna(v) else str(v)
        elif k == "obs_assim_used":
            out[k] = bool(v)
        elif k == "obs_valid_rows":
            out[k] = int(v) if pd.notna(v) else 0
        else:
            out[k] = float(v) if pd.notna(v) else np.nan
    return out


def aggregate(summary_ok: pd.DataFrame) -> Dict:
    def count_sign(s: pd.Series) -> Tuple[int, int, int]:
        x = pd.to_numeric(s, errors="coerce").to_numpy(dtype=np.float64)
        x = x[np.isfinite(x)]
        wins = int(np.sum(x > 1e-12))
        losses = int(np.sum(x < -1e-12))
        ties = int(np.sum(np.abs(x) <= 1e-12))
        return wins, losses, ties

    imp_full = pd.to_numeric(summary_ok["improve_azel_pct_full"], errors="coerce")
    imp_fut = pd.to_numeric(summary_ok["improve_azel_pct_fut"], errors="coerce")
    az_imp = pd.to_numeric(summary_ok["improve_az_pct_full"], errors="coerce")
    el_imp = pd.to_numeric(summary_ok["improve_el_pct_full"], errors="coerce")
    wins_full, losses_full, ties_full = count_sign(imp_full)
    wins_fut, losses_fut, ties_fut = count_sign(imp_fut)
    wins_az, losses_az, ties_az = count_sign(az_imp)
    wins_el, losses_el, ties_el = count_sign(el_imp)
    obs_used_rate = float(np.mean(summary_ok["obs_assim_used"].astype(np.float64))) if len(summary_ok) else np.nan
    return {
        "n_total_ok": int(len(summary_ok)),
        "mean_improve_azel_pct_full": finite_mean(imp_full) if len(summary_ok) else np.nan,
        "median_improve_azel_pct_full": finite_median(imp_full) if len(summary_ok) else np.nan,
        "mean_improve_azel_pct_future_23d": finite_mean(imp_fut) if len(summary_ok) else np.nan,
        "median_improve_azel_pct_future_23d": finite_median(imp_fut) if len(summary_ok) else np.nan,
        "wins_full": wins_full,
        "losses_full": losses_full,
        "ties_full": ties_full,
        "wins_future_23d": wins_fut,
        "losses_future_23d": losses_fut,
        "ties_future_23d": ties_fut,
        "wins_az_full": wins_az,
        "losses_az_full": losses_az,
        "ties_az_full": ties_az,
        "wins_el_full": wins_el,
        "losses_el_full": losses_el,
        "ties_el_full": ties_el,
        "obs_assim_used_rate": obs_used_rate,
    }


def make_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="Batch run predict (online obs mode) for all 2024 TLE and aggregate AZ/EL improvements."
    )
    ap.add_argument("--predict-script", default="orbit_geo_7d23d_analog.py")
    ap.add_argument("--python-exe", default=sys.executable)
    ap.add_argument("--model", required=True)
    ap.add_argument("--tle-dir", required=True)
    ap.add_argument("--baseline-dir", required=True)
    ap.add_argument("--truth-csv", required=True)
    ap.add_argument("--obs-truth-csv", default=None,
                    help="Observation AZ/EL csv for online assimilation. Default: --truth-csv")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--max-files", type=int, default=None)
    ap.add_argument("--skip-existing", action="store_true",
                    help="Skip predict when corrected/pred/metrics files already exist.")
    ap.add_argument("--no-plot", action="store_true")
    ap.add_argument("--predictor-mode", choices=["basis", "direct", "hybrid"], default="hybrid")
    ap.add_argument("--hybrid-weight", type=float, default=0.7)
    ap.add_argument("--days-horizon", type=int, default=None)
    ap.add_argument("--fit-days", type=int, default=None)
    ap.add_argument("--pre-days", type=int, default=None)
    ap.add_argument("--step-minutes", type=int, default=None)
    ap.add_argument("--sample-every", type=int, default=None)
    ap.add_argument("--k", type=int, default=None)
    ap.add_argument("--tau", type=float, default=None)
    ap.add_argument("--year-half-life", type=float, default=None)
    ap.add_argument("--doy-sigma", type=float, default=None)
    ap.add_argument("--causal-predict", action=argparse.BooleanOptionalAction, default=None)
    ap.add_argument("--neighbor-pool-mult", type=int, default=None)
    ap.add_argument("--alpha-az", type=float, default=None)
    ap.add_argument("--alpha-el", type=float, default=None)
    ap.add_argument("--cap-deg", type=float, default=None)
    ap.add_argument("--ood-conf-floor", type=float, default=0.0)
    ap.add_argument("--min-ood-conf-apply", type=float, default=0.0)
    ap.add_argument("--transition-hours", type=float, default=None)
    ap.add_argument("--auto-lowerr-th", type=float, default=None)
    ap.add_argument("--auto-max-neighbor-dist", type=float, default=None)
    ap.add_argument("--auto-max-unc-az", type=float, default=None)
    ap.add_argument("--auto-max-unc-el", type=float, default=None)
    ap.add_argument("--auto-max-corr-ratio", type=float, default=None)
    ap.add_argument("--obs-hours", type=float, default=12.0)
    ap.add_argument("--obs-min-valid", type=int, default=60)
    ap.add_argument("--obs-assim-strength", type=float, default=3.0)
    ap.add_argument("--obs-pool-size", type=int, default=120)
    ap.add_argument("--obs-sign-flip", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--obs-sign-flip-margin", type=float, default=1e-6)
    ap.add_argument("--obs-conf-floor", type=float, default=0.1)
    ap.add_argument("--extra-predict-args", default="")
    ap.add_argument("--top-n", type=int, default=20)
    return ap


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = make_parser().parse_args(argv)
    args.predict_script = Path(args.predict_script)
    args.model = Path(args.model)
    args.tle_dir = Path(args.tle_dir)
    args.baseline_dir = Path(args.baseline_dir)
    args.truth_csv = Path(args.truth_csv)
    args.obs_truth_csv = Path(args.obs_truth_csv) if args.obs_truth_csv else Path(args.truth_csv)
    out_dir = Path(args.out_dir)

    for pth, name in [
        (args.predict_script, "predict-script"),
        (args.model, "model"),
        (args.tle_dir, "tle-dir"),
        (args.baseline_dir, "baseline-dir"),
        (args.truth_csv, "truth-csv"),
        (args.obs_truth_csv, "obs-truth-csv"),
    ]:
        if not pth.exists():
            raise FileNotFoundError(f"{name} not found: {pth}")

    corrected_dir = out_dir / "corrected"
    pred_error_dir = out_dir / "pred_error"
    metrics_dir = out_dir / "metrics"
    logs_dir = out_dir / "logs"
    plots_dir = out_dir / "plots"
    for p in [out_dir, corrected_dir, pred_error_dir, metrics_dir, logs_dir]:
        ensure_dir(p)
    if not args.no_plot:
        ensure_dir(plots_dir)

    stems = list_stems(args.tle_dir, args.baseline_dir, args.max_files)
    if len(stems) == 0:
        raise RuntimeError("no matching stems between --tle-dir and --baseline-dir")
    log(f"[INFO] targets: {len(stems)}")

    rows: List[Dict] = []
    for i, stem in enumerate(stems, start=1):
        tle_file = args.tle_dir / f"{stem}.txt"
        baseline_csv = args.baseline_dir / f"{stem}.csv"
        out_corr = corrected_dir / f"{stem}.csv"
        out_pred = pred_error_dir / f"{stem}_pred_error.csv"
        out_met = metrics_dir / f"{stem}_metrics.csv"
        out_log = logs_dir / f"{stem}.log"

        status = "ok"
        error = ""
        do_run = True
        if args.skip_existing and out_corr.exists() and out_pred.exists() and out_met.exists():
            do_run = False

        if do_run:
            plot_arg = plots_dir if (not args.no_plot) else None
            cmd = build_predict_cmd(
                args=args,
                stem=stem,
                tle_file=tle_file,
                baseline_csv=baseline_csv,
                out_corrected_csv=out_corr,
                out_pred_error_csv=out_pred,
                out_metrics_csv=out_met,
                plot_dir=plot_arg,
            )
            p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore")
            out_log.write_text((p.stdout or "") + "\n" + (p.stderr or ""), encoding="utf-8")
            if p.returncode != 0:
                status = "error"
                error = f"predict failed rc={p.returncode}"
                log(f"[WARN] {i}/{len(stems)} {stem} failed")
        if i % 20 == 0 or i == len(stems):
            log(f"[INFO] progress {i}/{len(stems)}")

        rec: Dict = {"stem": stem, "status": status, "error": error}
        if status == "ok":
            try:
                diag = read_diag(out_pred)
                rec.update(diag)
                baz, bel, caz, cel = read_metric_pair(out_met, "full_30d")
                bazf, belf, cazf, celf = read_metric_pair(out_met, "future_23d")
                rec["az_rmse_base_full"] = baz
                rec["el_rmse_base_full"] = bel
                rec["az_rmse_corr_full"] = caz
                rec["el_rmse_corr_full"] = cel
                rec["azel_rmse_base_full"] = (
                    0.5 * (baz + bel) if np.isfinite(baz) and np.isfinite(bel) else np.nan
                )
                rec["azel_rmse_corr_full"] = (
                    0.5 * (caz + cel) if np.isfinite(caz) and np.isfinite(cel) else np.nan
                )
                rec["improve_az_pct_full"] = safe_improve_pct(baz, caz)
                rec["improve_el_pct_full"] = safe_improve_pct(bel, cel)
                rec["improve_azel_pct_full"] = safe_improve_pct(rec["azel_rmse_base_full"], rec["azel_rmse_corr_full"])
                rec["az_rmse_base_fut"] = bazf
                rec["el_rmse_base_fut"] = belf
                rec["az_rmse_corr_fut"] = cazf
                rec["el_rmse_corr_fut"] = celf
                rec["azel_rmse_base_fut"] = (
                    0.5 * (bazf + belf) if np.isfinite(bazf) and np.isfinite(belf) else np.nan
                )
                rec["azel_rmse_corr_fut"] = (
                    0.5 * (cazf + celf) if np.isfinite(cazf) and np.isfinite(celf) else np.nan
                )
                rec["improve_azel_pct_fut"] = safe_improve_pct(rec["azel_rmse_base_fut"], rec["azel_rmse_corr_fut"])
            except Exception as e:
                rec["status"] = "error"
                rec["error"] = f"parse failed: {e}"
        rows.append(rec)

    summary = pd.DataFrame(rows)
    summary_csv = out_dir / "summary.csv"
    summary.to_csv(summary_csv, index=False)
    log(f"[SAVED] summary: {summary_csv}")

    ok = summary[summary["status"] == "ok"].copy()
    agg = {
        "n_total": int(len(summary)),
        "n_ok": int(len(ok)),
        "n_error": int(np.sum(summary["status"] != "ok")),
    }
    if len(ok) > 0:
        agg.update(aggregate(ok))
    agg_json = out_dir / "aggregate.json"
    agg_json.write_text(json.dumps(agg, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[SAVED] aggregate: {agg_json}")

    if len(ok) > 0:
        top_n = max(1, int(args.top_n))
        top = ok.sort_values("improve_azel_pct_full", ascending=False).head(top_n)
        worst = ok.sort_values("improve_azel_pct_full", ascending=True).head(top_n)
        top_csv = out_dir / "top_improved_full.csv"
        worst_csv = out_dir / "worst_full.csv"
        top.to_csv(top_csv, index=False)
        worst.to_csv(worst_csv, index=False)
        log(f"[SAVED] top improved: {top_csv}")
        log(f"[SAVED] worst cases: {worst_csv}")

        mean_imp = finite_mean(ok["improve_azel_pct_full"])
        losses = int(np.sum(pd.to_numeric(ok["improve_azel_pct_full"], errors="coerce").to_numpy(dtype=np.float64) < -1e-12))
        log(f"[RESULT] mean AZEL improve full_30d = {mean_imp:.6f}% | losses={losses}/{len(ok)}")
    else:
        log("[RESULT] no successful rows")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
