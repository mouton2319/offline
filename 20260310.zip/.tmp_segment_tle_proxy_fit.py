import numpy as np, pandas as pd, math, json
from pathlib import Path
import ufo4_orbit_predict_tf as core

BASE='ufo4_2024_prediction_tf/predicted_calc_az_el.csv'
TRUTH='2024_calc_az_el.csv'
TLE_DIR='pred_tle - コピー'
SAT='23467'
OBS_LAT=36.3022
OBS_LON=137.9031
PRIORITY_DAYS=7

def wrap180(x):
    return ((x+180)%360)-180

def design(unix, epoch, order_min=3):
    u=np.asarray(unix,dtype=float)
    d=(u-epoch)/86400.0
    sec_local=u+9*3600.0
    minute_phase=2*np.pi*(sec_local%86400.0)/86400.0
    cols=[np.ones_like(u), d, d*d]
    for k in range(1,order_min+1):
        cols += [np.sin(k*minute_phase), np.cos(k*minute_phase), d*np.sin(k*minute_phase), d*np.cos(k*minute_phase)]
    return np.column_stack(cols)

def fit_ridge(X,y,l2=1e-3):
    xtx=X.T@X + np.eye(X.shape[1])*l2
    xty=X.T@y
    return np.linalg.solve(xtx, xty)

base=pd.read_csv(BASE)
truth=pd.read_csv(TRUTH)
assert np.allclose(base['UNIX'].to_numpy(), truth['UNIX'].to_numpy())
unix=base['UNIX'].to_numpy(dtype=float)
base_az=base['AZ'].to_numpy(dtype=float); base_el=base['EL'].to_numpy(dtype=float)
true_az=truth['AZ'].to_numpy(dtype=float); true_el=truth['EL'].to_numpy(dtype=float)
out_az=base_az.copy(); out_el=base_el.copy()

# build segments
segments=core.collect_tle_files(Path(TLE_DIR))
print('segments', len(segments))
for i,(epoch,path) in enumerate(segments):
    seg_start=epoch
    seg_end=segments[i+1][0] if i+1<len(segments) else int(unix.max())+60
    seg_mask=(unix>=seg_start)&(unix<seg_end)
    if not np.any(seg_mask):
        continue
    u_seg=unix[seg_mask]
    idx=np.where(seg_mask)[0]
    tle=core.propagate_tle_azel_at_unix(path,SAT,OBS_LAT,OBS_LON,u_seg)
    # trusted window
    fit_mask=(u_seg>=epoch)&(u_seg<epoch+PRIORITY_DAYS*86400)
    if fit_mask.sum()<100:
        continue
    X=design(u_seg[fit_mask], epoch, order_min=4)
    y_az=wrap180(tle[fit_mask,0]-base_az[idx][fit_mask])
    y_el=tle[fit_mask,1]-base_el[idx][fit_mask]
    b_az=fit_ridge(X,y_az,l2=1e-2)
    b_el=fit_ridge(X,y_el,l2=1e-2)
    X_all=design(u_seg, epoch, order_min=4)
    corr_az=X_all@b_az
    corr_el=X_all@b_el
    # cap by trusted residual spread
    az_cap=max(0.1, np.quantile(np.abs(y_az),0.99)*1.5)
    el_cap=max(0.1, np.quantile(np.abs(y_el),0.99)*1.5)
    corr_az=np.clip(corr_az,-az_cap,az_cap)
    corr_el=np.clip(corr_el,-el_cap,el_cap)
    # within trusted window, blend to tle direct. after that, corrected baseline.
    oaz=(base_az[idx]+corr_az)%360.0
    oel=base_el[idx]+corr_el
    tw=core.compute_tle_blend_weights(u_seg, epoch, epoch, PRIORITY_DAYS, 1.0, 24*21, 0.0)
    # use proxy-corrected baseline as model side
    s=np.sin(np.deg2rad(oaz))*(1-tw)+np.sin(np.deg2rad(tle[:,0]))*tw
    c=np.cos(np.deg2rad(oaz))*(1-tw)+np.cos(np.deg2rad(tle[:,0]))*tw
    out_az[idx]=(np.rad2deg(np.arctan2(s,c))%360.0)
    out_el[idx]=oel*(1-tw)+tle[:,1]*tw

az=np.abs(wrap180(out_az-true_az)); el=np.abs(out_el-true_el)
print('overall mean', float((az.mean()+el.mean())/2), 'max', float(max(az.max(), el.max())))
worst=np.argsort(np.maximum(az,el))[-20:][::-1]
for j in worst[:10]:
    print(j, truth.iloc[j]['date'], az[j], el[j], out_az[j], out_el[j], true_az[j], true_el[j])
