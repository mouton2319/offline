#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Transfer-learning LLA correction with geometric AZ/EL recomputation.

Core design:
- Target inference is single-TLE only.
- Train LLA correction model (Lat/Lon/Alt) and recompute AZ/EL geometrically.
- Optionally use auxiliary satellites for pretraining, then fine-tune on target.
- Calibrate conservative LLA alpha/clip and AZ/EL gamma schedule on target val only.

This script is intended for cases where baseline single-TLE SGP4 is already strong
and direct AZ/EL correction often degrades performance.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import tensorflow as tf
except Exception:
    tf = None

from orbit_error_ai_no_tle_tf import (
    FeatureConfig,
    OnlineMeanVar,
    TARGET_COLS,
    angle_diff_deg,
    compute_metrics,
    ensure_dir,
    list_stems_with_both,
    load_orbit_csv,
    log,
    now_jst_str,
    plot_baseline_vs_corrected,
    plot_metric_summary,
    plot_truth_baseline_corrected,
)
from orbit_lla_recompute_azel_tf import (
    LLA_COLS,
    apply_azel_gamma_blend,
    apply_lla_alpha_clip,
    apply_lla_correction,
    build_model,
    calibrate_azel_gamma_schedule,
    calibrate_lla_alpha_clip,
    load_infer_pair,
    load_train_pair,
    load_truth_df,
    parse_clip_candidates,
    parse_float_list_csv,
    parse_hidden_csv,
    predict_lla_delta,
    split_stems,
)


def require_tensorflow() -> None:
    if tf is None:
        raise RuntimeError(
            "TensorFlow is required. Run in docker image with TF installed, e.g. orbit-tf-pip:cuda128."
        )


@dataclasses.dataclass
class SatDataset:
    name: str
    tle_dir: Path
    baseline_dir: Path
    truth_csv: Path
    truth_df: pd.DataFrame
    train_stems: List[str]
    val_stems: List[str]
    is_target: bool


@dataclasses.dataclass
class ModelBundle:
    feature_cfg: FeatureConfig
    feature_names: List[str]
    sat_names: List[str]
    target_sat_name: str
    x_mean: np.ndarray
    x_std: np.ndarray
    y_mean: np.ndarray
    y_std: np.ndarray
    alpha_vec: np.ndarray
    clip_k_sigma_vec: np.ndarray
    lla_azel_scale_vec: np.ndarray
    azel_day_edges: np.ndarray
    azel_gamma_matrix: np.ndarray
    observer_lat_deg: float
    observer_lon_deg: float
    observer_alt_m: float
    train_rows: int
    train_files: int
    val_files: int


def parse_aux_dataset_specs(specs: Optional[List[str]]) -> List[Tuple[str, Path, Path, Path]]:
    out: List[Tuple[str, Path, Path, Path]] = []
    if not specs:
        return out
    for raw in specs:
        parts = [p.strip() for p in str(raw).split(":")]
        if len(parts) != 4:
            raise ValueError(
                f"--aux-dataset format error: {raw}. Expected name:tle_dir:baseline_dir:truth_csv"
            )
        name = parts[0]
        tle_dir = Path(parts[1])
        baseline_dir = Path(parts[2])
        truth_csv = Path(parts[3])
        out.append((name, tle_dir, baseline_dir, truth_csv))
    return out


def build_dataset(
    name: str,
    tle_dir: Path,
    baseline_dir: Path,
    truth_csv: Path,
    val_split: float,
    split_mode: str,
    seed: int,
    max_files: Optional[int],
    is_target: bool,
) -> SatDataset:
    if not tle_dir.exists():
        raise FileNotFoundError(f"tle-dir not found: {tle_dir}")
    if not baseline_dir.exists():
        raise FileNotFoundError(f"baseline-dir not found: {baseline_dir}")
    if not truth_csv.exists():
        raise FileNotFoundError(f"truth-csv not found: {truth_csv}")

    stems = list_stems_with_both(tle_dir=tle_dir, csv_dir=baseline_dir)
    if not stems:
        raise RuntimeError(f"no matching TLE/baseline pairs: {name}")
    if max_files is not None:
        stems = stems[: int(max_files)]
    train_stems, val_stems = split_stems(
        all_stems=stems,
        val_split=float(val_split),
        seed=int(seed),
        split_mode=str(split_mode),
    )
    truth_df = load_truth_df(truth_csv)
    return SatDataset(
        name=name,
        tle_dir=tle_dir,
        baseline_dir=baseline_dir,
        truth_csv=truth_csv,
        truth_df=truth_df,
        train_stems=train_stems,
        val_stems=val_stems,
        is_target=is_target,
    )


def sat_onehot(name: str, sat_names: List[str]) -> np.ndarray:
    if name not in sat_names:
        raise ValueError(f"unknown sat name for onehot: {name}")
    v = np.zeros((len(sat_names),), dtype=np.float64)
    v[sat_names.index(name)] = 1.0
    return v


def append_sat_feature(
    x_base: np.ndarray,
    base_names: List[str],
    sat_vec: np.ndarray,
    sat_names: List[str],
) -> Tuple[np.ndarray, List[str]]:
    n = len(x_base)
    sat_block = np.repeat(sat_vec.reshape(1, -1), n, axis=0)
    x = np.concatenate([x_base, sat_block], axis=1).astype(np.float64)
    names = list(base_names) + [f"sat_{s}" for s in sat_names]
    return x, names


def compute_scalers(
    datasets: List[SatDataset],
    sat_names: List[str],
    cfg: FeatureConfig,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str], int]:
    x_stat: Optional[OnlineMeanVar] = None
    y_stat = OnlineMeanVar(dim=len(LLA_COLS))
    names: Optional[List[str]] = None
    rows = 0

    for ds in datasets:
        svec = sat_onehot(ds.name, sat_names)
        for stem in ds.train_stems:
            try:
                x_base, y, _no, _baseline, _truth, _no2, base_names = load_train_pair(
                    stem=stem,
                    tle_dir=ds.tle_dir,
                    baseline_dir=ds.baseline_dir,
                    truth_df=ds.truth_df,
                    cfg=cfg,
                    days_horizon=days_horizon,
                    step_minutes=step_minutes,
                    sample_every=sample_every,
                )
            except Exception as e:
                log(f"[WARN] scaler skip {ds.name}:{stem}: {e}")
                continue
            if len(x_base) == 0:
                continue
            x, fn = append_sat_feature(
                x_base=x_base,
                base_names=base_names,
                sat_vec=svec,
                sat_names=sat_names,
            )
            if x_stat is None:
                x_stat = OnlineMeanVar(dim=x.shape[1])
                names = fn
            elif x.shape[1] != x_stat.dim:
                raise ValueError(f"feature dim mismatch: {x.shape[1]} vs {x_stat.dim}")
            x_stat.update(x)
            y_stat.update(y)
            rows += len(x)

    if x_stat is None or names is None or rows == 0:
        raise RuntimeError("no usable rows for scaler")
    x_mean, x_std = x_stat.finalize()
    y_mean, y_std = y_stat.finalize()
    x_std = np.where(x_std < 1e-9, 1.0, x_std)
    y_std = np.where(y_std < 1e-9, 1.0, y_std)
    return x_mean, x_std, y_mean, y_std, names, rows


def scale_arr(x: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    return ((x - mean.reshape(1, -1)) / std.reshape(1, -1)).astype(np.float32)


def tf_wrap180_deg(x_deg: "tf.Tensor") -> "tf.Tensor":
    return tf.math.floormod(x_deg + 180.0, 360.0) - 180.0


def tf_angle_diff_deg(a_deg: "tf.Tensor", b_deg: "tf.Tensor") -> "tf.Tensor":
    d_rad = (a_deg - b_deg) * (np.pi / 180.0)
    return tf.atan2(tf.sin(d_rad), tf.cos(d_rad)) * (180.0 / np.pi)


def tf_geodetic_to_ecef_km(
    lat_deg: "tf.Tensor",
    lon_deg: "tf.Tensor",
    alt_km: "tf.Tensor",
) -> Tuple["tf.Tensor", "tf.Tensor", "tf.Tensor"]:
    a = tf.constant(6378.137, dtype=tf.float32)
    f = tf.constant(1.0 / 298.257223563, dtype=tf.float32)
    e2 = f * (2.0 - f)
    lat = lat_deg * (np.pi / 180.0)
    lon = lon_deg * (np.pi / 180.0)
    sl = tf.sin(lat)
    cl = tf.cos(lat)
    so = tf.sin(lon)
    co = tf.cos(lon)
    n = a / tf.sqrt(1.0 - e2 * sl * sl)
    x = (n + alt_km) * cl * co
    y = (n + alt_km) * cl * so
    z = (n * (1.0 - e2) + alt_km) * sl
    return x, y, z


def tf_recompute_azel_from_lla(
    sat_lat_deg: "tf.Tensor",
    sat_lon_deg: "tf.Tensor",
    sat_alt_km: "tf.Tensor",
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
) -> Tuple["tf.Tensor", "tf.Tensor"]:
    sx, sy, sz = tf_geodetic_to_ecef_km(sat_lat_deg, sat_lon_deg, sat_alt_km)
    ox, oy, oz = tf_geodetic_to_ecef_km(
        tf.constant([observer_lat_deg], dtype=tf.float32),
        tf.constant([observer_lon_deg], dtype=tf.float32),
        tf.constant([float(observer_alt_m) / 1000.0], dtype=tf.float32),
    )
    dx = sx - ox[0]
    dy = sy - oy[0]
    dz = sz - oz[0]

    lat0 = float(observer_lat_deg) * (np.pi / 180.0)
    lon0 = float(observer_lon_deg) * (np.pi / 180.0)
    sl = float(np.sin(lat0))
    cl = float(np.cos(lat0))
    so = float(np.sin(lon0))
    co = float(np.cos(lon0))

    e = -so * dx + co * dy
    n = -sl * co * dx - sl * so * dy + cl * dz
    u = cl * co * dx + cl * so * dy + sl * dz

    az = tf.atan2(e, n) * (180.0 / np.pi)
    az = tf.math.floormod(az + 360.0, 360.0)
    el = tf.atan2(u, tf.sqrt(e * e + n * n + 1e-12)) * (180.0 / np.pi)
    el = tf.clip_by_value(el, -90.0, 90.0)
    return az, el


def tf_huber_per_sample(err: "tf.Tensor", delta: float) -> "tf.Tensor":
    ae = tf.abs(err)
    d = tf.constant(float(delta), dtype=tf.float32)
    quad = 0.5 * tf.square(err)
    lin = d * (ae - 0.5 * d)
    return tf.where(ae <= d, quad, lin)


def load_train_arrays(
    ds: SatDataset,
    stem: str,
    sat_names: List[str],
    cfg: FeatureConfig,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    x_base, y, no, baseline, truth, _no2, base_names = load_train_pair(
        stem=stem,
        tle_dir=ds.tle_dir,
        baseline_dir=ds.baseline_dir,
        truth_df=ds.truth_df,
        cfg=cfg,
        days_horizon=days_horizon,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    if len(x_base) == 0:
        return (
            np.zeros((0, 1), dtype=np.float32),
            np.zeros((0, len(LLA_COLS)), dtype=np.float32),
            np.zeros((0,), dtype=np.float64),
            np.zeros((0, 3), dtype=np.float32),
            np.zeros((0, 2), dtype=np.float32),
        )
    x, _ = append_sat_feature(
        x_base=x_base,
        base_names=base_names,
        sat_vec=sat_onehot(ds.name, sat_names),
        sat_names=sat_names,
    )
    x_s = scale_arr(x, x_mean, x_std)
    y_s = scale_arr(y, y_mean, y_std)
    no_norm = (no.astype(np.float64) - 1.0) / max(1.0, float(np.max(no) - 1.0))
    b_lla = np.stack(
        [
            baseline[:, TARGET_COLS.index("Lat")],
            baseline[:, TARGET_COLS.index("Lon")],
            baseline[:, TARGET_COLS.index("Alt")],
        ],
        axis=1,
    ).astype(np.float32)
    t_azel = np.stack(
        [
            truth[:, TARGET_COLS.index("AZ")],
            truth[:, TARGET_COLS.index("EL")],
        ],
        axis=1,
    ).astype(np.float32)
    return x_s, y_s, no_norm, b_lla, t_azel


def predict_lla_delta_with_sat(
    model: "tf.keras.Model",
    ds: SatDataset,
    stem: str,
    sat_names: List[str],
    cfg: FeatureConfig,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    x_base, _y, no, baseline, truth, _no2, base_names = load_train_pair(
        stem=stem,
        tle_dir=ds.tle_dir,
        baseline_dir=ds.baseline_dir,
        truth_df=ds.truth_df,
        cfg=cfg,
        days_horizon=days_horizon,
        step_minutes=step_minutes,
        sample_every=sample_every,
    )
    if len(x_base) == 0:
        return (
            np.zeros((0, len(LLA_COLS)), dtype=np.float64),
            np.zeros((0,), dtype=np.int64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
            np.zeros((0, len(TARGET_COLS)), dtype=np.float64),
        )
    x, _ = append_sat_feature(
        x_base=x_base,
        base_names=base_names,
        sat_vec=sat_onehot(ds.name, sat_names),
        sat_names=sat_names,
    )
    x_s = scale_arr(x, x_mean, x_std)
    y_s = model.predict(x_s, batch_size=int(batch_size), verbose=0)
    y = (y_s * y_std.reshape(1, -1) + y_mean.reshape(1, -1)).astype(np.float64)
    return y, no, baseline, truth


def calibrate_lla_scale_for_azel(
    baseline: np.ndarray,
    truth: np.ndarray,
    pred_delta_lla: np.ndarray,
    observer_lat_deg: float,
    observer_lon_deg: float,
    observer_alt_m: float,
    latlon_scale_grid: List[float],
    alt_scale_grid: List[float],
    min_improve_pct: float,
) -> Tuple[np.ndarray, Dict[str, float]]:
    from orbit_lla_recompute_azel_tf import recompute_azel_from_lla

    lat_i = TARGET_COLS.index("Lat")
    lon_i = TARGET_COLS.index("Lon")
    alt_i = TARGET_COLS.index("Alt")
    az_i = TARGET_COLS.index("AZ")
    el_i = TARGET_COLS.index("EL")
    az_t = truth[:, az_i]
    el_t = truth[:, el_i]
    base_rmse_az = float(np.sqrt(np.mean(angle_diff_deg(baseline[:, az_i], az_t) ** 2)))
    base_rmse_el = float(np.sqrt(np.mean((baseline[:, el_i] - el_t) ** 2)))
    base_obj = 0.5 * (base_rmse_az + base_rmse_el)

    ll_grid = sorted(set(float(np.clip(v, 0.0, 2.0)) for v in latlon_scale_grid))
    alt_grid = sorted(set(float(np.clip(v, 0.0, 2.0)) for v in alt_scale_grid))
    if not ll_grid:
        ll_grid = [1.0]
    if not alt_grid:
        alt_grid = [1.0]

    best_obj = base_obj
    best_ll = 0.0
    best_alt = 0.0
    best_az = base_rmse_az
    best_el = base_rmse_el

    for s_ll in ll_grid:
        for s_alt in alt_grid:
            d = np.asarray(pred_delta_lla, dtype=np.float64).copy()
            d[:, 0] *= float(s_ll)
            d[:, 1] *= float(s_ll)
            d[:, 2] *= float(s_alt)
            lat = baseline[:, lat_i] + d[:, 0]
            lon = np.mod(baseline[:, lon_i] + d[:, 1] + 180.0, 360.0) - 180.0
            alt = baseline[:, alt_i] + d[:, 2]
            az_r, el_r = recompute_azel_from_lla(
                sat_lat_deg=lat,
                sat_lon_deg=lon,
                sat_alt_km=alt,
                observer_lat_deg=observer_lat_deg,
                observer_lon_deg=observer_lon_deg,
                observer_alt_m=observer_alt_m,
            )
            rmse_az = float(np.sqrt(np.mean(angle_diff_deg(az_r, az_t) ** 2)))
            rmse_el = float(np.sqrt(np.mean((el_r - el_t) ** 2)))
            obj = 0.5 * (rmse_az + rmse_el)
            if obj < best_obj:
                best_obj = obj
                best_ll = float(s_ll)
                best_alt = float(s_alt)
                best_az = rmse_az
                best_el = rmse_el

    improve_pct = 0.0 if base_obj <= 0 else 100.0 * (base_obj - best_obj) / base_obj
    if improve_pct < float(min_improve_pct):
        best_ll = 0.0
        best_alt = 0.0
        best_obj = base_obj
        best_az = base_rmse_az
        best_el = base_rmse_el

    svec = np.array([best_ll, best_ll, best_alt], dtype=np.float64)
    info = {
        "base_obj": float(base_obj),
        "best_obj": float(best_obj),
        "base_rmse_az": float(base_rmse_az),
        "base_rmse_el": float(base_rmse_el),
        "best_rmse_az": float(best_az),
        "best_rmse_el": float(best_el),
        "scale_latlon": float(best_ll),
        "scale_alt": float(best_alt),
        "improve_pct": float(0.0 if base_obj <= 0 else 100.0 * (base_obj - best_obj) / base_obj),
    }
    return svec, info


def target_val_score(
    model: "tf.keras.Model",
    target_ds: SatDataset,
    sat_names: List[str],
    cfg: FeatureConfig,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    observer_lat: float,
    observer_lon: float,
    observer_alt_m: float,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    max_files: Optional[int],
) -> Tuple[float, float]:
    stems = target_ds.val_stems
    if max_files is not None and int(max_files) > 0:
        stems = stems[: int(max_files)]
    c_sum = 0.0
    b_sum = 0.0
    cnt = 0
    for stem in stems:
        try:
            pred_lla, _no, baseline, truth = predict_lla_delta_with_sat(
                model=model,
                ds=target_ds,
                stem=stem,
                sat_names=sat_names,
                cfg=cfg,
                x_mean=x_mean,
                x_std=x_std,
                y_mean=y_mean,
                y_std=y_std,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
                batch_size=batch_size,
            )
        except Exception:
            continue
        if len(pred_lla) == 0:
            continue
        corr = apply_lla_correction(baseline=baseline, delta_lla=pred_lla)
        az_i = TARGET_COLS.index("AZ")
        el_i = TARGET_COLS.index("EL")
        lat_i = TARGET_COLS.index("Lat")
        lon_i = TARGET_COLS.index("Lon")
        alt_i = TARGET_COLS.index("Alt")
        from orbit_lla_recompute_azel_tf import recompute_azel_from_lla

        az_rec, el_rec = recompute_azel_from_lla(
            sat_lat_deg=corr[:, lat_i],
            sat_lon_deg=corr[:, lon_i],
            sat_alt_km=corr[:, alt_i],
            observer_lat_deg=observer_lat,
            observer_lon_deg=observer_lon,
            observer_alt_m=observer_alt_m,
        )
        b_rmse = 0.5 * (
            float(np.sqrt(np.mean(angle_diff_deg(baseline[:, az_i], truth[:, az_i]) ** 2)))
            + float(np.sqrt(np.mean((baseline[:, el_i] - truth[:, el_i]) ** 2)))
        )
        c_rmse = 0.5 * (
            float(np.sqrt(np.mean(angle_diff_deg(az_rec, truth[:, az_i]) ** 2)))
            + float(np.sqrt(np.mean((el_rec - truth[:, el_i]) ** 2)))
        )
        b_sum += b_rmse
        c_sum += c_rmse
        cnt += 1
    if cnt == 0:
        return float("inf"), float("inf")
    return b_sum / cnt, c_sum / cnt


def evaluate_target_dataset(
    model: "tf.keras.Model",
    target_ds: SatDataset,
    sat_names: List[str],
    cfg: FeatureConfig,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    alpha_vec: np.ndarray,
    clip_vec: np.ndarray,
    lla_azel_scale_vec: np.ndarray,
    azel_day_edges: np.ndarray,
    azel_gamma_matrix: np.ndarray,
    observer_lat: float,
    observer_lon: float,
    observer_alt_m: float,
    days_horizon: int,
    step_minutes: int,
    sample_every: int,
    batch_size: int,
    use_val: bool,
) -> Dict[str, float]:
    stems = target_ds.val_stems if use_val else target_ds.train_stems
    sum_b = np.zeros((len(TARGET_COLS),), dtype=np.float64)
    sum_c = np.zeros((len(TARGET_COLS),), dtype=np.float64)
    rows = 0
    for stem in stems:
        try:
            pred_lla, no, baseline, truth = predict_lla_delta_with_sat(
                model=model,
                ds=target_ds,
                stem=stem,
                sat_names=sat_names,
                cfg=cfg,
                x_mean=x_mean,
                x_std=x_std,
                y_mean=y_mean,
                y_std=y_std,
                days_horizon=days_horizon,
                step_minutes=step_minutes,
                sample_every=sample_every,
                batch_size=batch_size,
            )
        except Exception:
            continue
        if len(pred_lla) == 0:
            continue
        d = apply_lla_alpha_clip(
            pred_delta_lla=pred_lla,
            alpha_vec=alpha_vec,
            clip_k_vec=clip_vec,
            y_std=y_std,
        )
        svec = np.asarray(lla_azel_scale_vec, dtype=np.float64).reshape(1, -1)
        if svec.shape[1] == d.shape[1]:
            d = d * svec
        corr = apply_lla_correction(baseline=baseline, delta_lla=d)
        corr, _az_rec, _el_rec = apply_azel_gamma_blend(
            corrected_lla_and_base=corr,
            baseline=baseline,
            no=no,
            observer_lat_deg=observer_lat,
            observer_lon_deg=observer_lon,
            observer_alt_m=observer_alt_m,
            day_edges=azel_day_edges,
            gamma_matrix=azel_gamma_matrix,
        )
        for i, c in enumerate(TARGET_COLS):
            if c in {"Lon", "AZ"}:
                eb = angle_diff_deg(baseline[:, i], truth[:, i])
                ec = angle_diff_deg(corr[:, i], truth[:, i])
            else:
                eb = baseline[:, i] - truth[:, i]
                ec = corr[:, i] - truth[:, i]
            sum_b[i] += float(np.sum(eb * eb))
            sum_c[i] += float(np.sum(ec * ec))
        rows += len(corr)
    if rows == 0:
        return {}
    mse_b = sum_b / rows
    mse_c = sum_c / rows
    rmse_b = np.sqrt(mse_b)
    rmse_c = np.sqrt(mse_c)
    out: Dict[str, float] = {"rows": float(rows)}
    for i, c in enumerate(TARGET_COLS):
        out[f"{c}_MSE_base"] = float(mse_b[i])
        out[f"{c}_MSE_corr"] = float(mse_c[i])
        out[f"{c}_RMSE_base"] = float(rmse_b[i])
        out[f"{c}_RMSE_corr"] = float(rmse_c[i])
    out["global_MSE_base"] = float(np.mean(mse_b))
    out["global_MSE_corr"] = float(np.mean(mse_c))
    out["global_RMSE_base"] = float(np.sqrt(out["global_MSE_base"]))
    out["global_RMSE_corr"] = float(np.sqrt(out["global_MSE_corr"]))
    out["global_RMSE_improve_pct"] = float(
        0.0
        if out["global_RMSE_base"] <= 0
        else 100.0 * (out["global_RMSE_base"] - out["global_RMSE_corr"]) / out["global_RMSE_base"]
    )
    return out


def save_model_and_meta(
    model: "tf.keras.Model",
    bundle: ModelBundle,
    out_model: Path,
    overwrite: bool,
    extra: Optional[Dict] = None,
) -> Tuple[Path, Path]:
    if out_model.suffix.lower() in (".keras", ".h5"):
        model_path = out_model
        meta_path = out_model.parent / "meta.json"
        ensure_dir(out_model.parent)
    else:
        ensure_dir(out_model)
        model_path = out_model / "model.keras"
        meta_path = out_model / "meta.json"
    if (model_path.exists() or meta_path.exists()) and not overwrite:
        raise FileExistsError(f"exists: {out_model} (use --overwrite)")
    model.save(str(model_path))
    clip_json: List[Optional[float]] = []
    for v in np.asarray(bundle.clip_k_sigma_vec, dtype=np.float64).reshape(-1):
        clip_json.append(float(v) if (np.isfinite(v) and v > 0) else None)
    payload = {
        "created_at_jst": now_jst_str(),
        "model_type": "transfer_lla_recompute_azel",
        "feature_cfg": dataclasses.asdict(bundle.feature_cfg),
        "feature_names": bundle.feature_names,
        "sat_names": bundle.sat_names,
        "target_sat_name": bundle.target_sat_name,
        "x_mean": bundle.x_mean.tolist(),
        "x_std": bundle.x_std.tolist(),
        "y_mean": bundle.y_mean.tolist(),
        "y_std": bundle.y_std.tolist(),
        "alpha_vec": bundle.alpha_vec.tolist(),
        "clip_k_sigma_vec": clip_json,
        "lla_azel_scale_vec": bundle.lla_azel_scale_vec.tolist(),
        "azel_day_edges": bundle.azel_day_edges.tolist(),
        "azel_gamma_matrix": bundle.azel_gamma_matrix.tolist(),
        "observer_lat_deg": float(bundle.observer_lat_deg),
        "observer_lon_deg": float(bundle.observer_lon_deg),
        "observer_alt_m": float(bundle.observer_alt_m),
        "train_rows": int(bundle.train_rows),
        "train_files": int(bundle.train_files),
        "val_files": int(bundle.val_files),
    }
    if extra:
        payload["extra"] = extra
    meta_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return model_path, meta_path


def load_model_and_meta(model_arg: Path) -> Tuple["tf.keras.Model", ModelBundle, Dict]:
    if model_arg.is_dir():
        model_path = model_arg / "model.keras"
        meta_path = model_arg / "meta.json"
    else:
        model_path = model_arg
        meta_path = model_arg.parent / "meta.json"
    if not model_path.exists():
        raise FileNotFoundError(f"model not found: {model_path}")
    if not meta_path.exists():
        raise FileNotFoundError(f"meta not found: {meta_path}")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    feature_cfg = FeatureConfig(**meta["feature_cfg"])
    clip_raw = meta.get("clip_k_sigma_vec", [None, None, None])
    clip_vec = np.full((len(LLA_COLS),), np.nan, dtype=np.float64)
    for i in range(min(len(clip_raw), len(LLA_COLS))):
        v = clip_raw[i]
        if v is not None:
            clip_vec[i] = float(v)
    day_edges = np.asarray(meta.get("azel_day_edges", []), dtype=np.float64).reshape(-1)
    gamma = np.asarray(meta.get("azel_gamma_matrix", []), dtype=np.float64)
    if gamma.ndim != 2 or gamma.shape[1] != 2 or len(day_edges) != gamma.shape[0] + 1:
        day_edges = np.array([0.0, 30.0], dtype=np.float64)
        gamma = np.zeros((1, 2), dtype=np.float64)

    bundle = ModelBundle(
        feature_cfg=feature_cfg,
        feature_names=list(meta["feature_names"]),
        sat_names=[str(s) for s in meta.get("sat_names", [])],
        target_sat_name=str(meta.get("target_sat_name", "target")),
        x_mean=np.asarray(meta["x_mean"], dtype=np.float64),
        x_std=np.asarray(meta["x_std"], dtype=np.float64),
        y_mean=np.asarray(meta["y_mean"], dtype=np.float64),
        y_std=np.asarray(meta["y_std"], dtype=np.float64),
        alpha_vec=np.asarray(meta.get("alpha_vec", [0.0, 0.0, 0.0]), dtype=np.float64),
        clip_k_sigma_vec=clip_vec,
        lla_azel_scale_vec=np.asarray(meta.get("lla_azel_scale_vec", [1.0, 1.0, 1.0]), dtype=np.float64),
        azel_day_edges=day_edges,
        azel_gamma_matrix=gamma,
        observer_lat_deg=float(meta.get("observer_lat_deg", 36.3022)),
        observer_lon_deg=float(meta.get("observer_lon_deg", 137.9031)),
        observer_alt_m=float(meta.get("observer_alt_m", 0.0)),
        train_rows=int(meta.get("train_rows", 0)),
        train_files=int(meta.get("train_files", 0)),
        val_files=int(meta.get("val_files", 0)),
    )
    model = tf.keras.models.load_model(str(model_path), compile=False)
    return model, bundle, meta


def train_cmd(args: argparse.Namespace) -> int:
    require_tensorflow()
    target_ds = build_dataset(
        name=str(args.target_name),
        tle_dir=Path(args.target_tle_dir),
        baseline_dir=Path(args.target_baseline_dir),
        truth_csv=Path(args.target_truth_csv),
        val_split=float(args.val_split),
        split_mode=str(args.split_mode),
        seed=int(args.seed),
        max_files=(int(args.max_target_files) if args.max_target_files is not None else None),
        is_target=True,
    )
    aux_specs = parse_aux_dataset_specs(args.aux_dataset)
    aux_datasets: List[SatDataset] = []
    for name, tle_dir, baseline_dir, truth_csv in aux_specs:
        ds = build_dataset(
            name=name,
            tle_dir=tle_dir,
            baseline_dir=baseline_dir,
            truth_csv=truth_csv,
            val_split=float(args.val_split),
            split_mode=str(args.split_mode),
            seed=int(args.seed),
            max_files=(int(args.max_aux_files) if args.max_aux_files is not None else None),
            is_target=False,
        )
        aux_datasets.append(ds)

    datasets = [target_ds] + aux_datasets
    sat_names = [ds.name for ds in datasets]
    log(
        f"[INFO] datasets={','.join(sat_names)} | "
        f"target train/val={len(target_ds.train_stems)}/{len(target_ds.val_stems)} | "
        f"aux count={len(aux_datasets)}"
    )

    cfg = FeatureConfig(
        day_harmonics=int(args.day_harmonics),
        span_harmonics=int(args.span_harmonics),
        include_sidereal=(not bool(args.no_sidereal)),
        include_interactions=(not bool(args.no_interactions)),
        include_template_feature=False,
        include_baseline_feature=(not bool(args.no_baseline_feature)),
    )

    x_mean, x_std, y_mean, y_std, feat_names, scaler_rows = compute_scalers(
        datasets=datasets,
        sat_names=sat_names,
        cfg=cfg,
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
    )
    log(f"[INFO] scaler rows={scaler_rows}, input_dim={len(feat_names)}")

    model = build_model(
        input_dim=len(feat_names),
        hidden=parse_hidden_csv(args.hidden),
        dropout=float(args.dropout),
        l2=float(args.l2),
    )
    loss_weights_np = np.array(
        [float(args.loss_weight_lat), float(args.loss_weight_lon), float(args.loss_weight_alt)],
        dtype=np.float64,
    )
    loss_weights_np = np.where(loss_weights_np > 0, loss_weights_np, 1.0)
    optimizer = tf.keras.optimizers.Adam(learning_rate=float(args.lr_pretrain))
    y_mean_tf = tf.constant(y_mean.reshape(1, -1).astype(np.float32))
    y_std_tf = tf.constant(y_std.reshape(1, -1).astype(np.float32))
    lla_w_tf = tf.constant(loss_weights_np.reshape(1, -1).astype(np.float32))
    lla_huber_delta = float(args.huber_delta)
    az_huber_delta = float(args.az_huber_delta)
    el_huber_delta = float(args.el_huber_delta)
    w_az = float(args.loss_weight_az)
    w_el = float(args.loss_weight_el)
    obs_lat = float(args.observer_lat)
    obs_lon = float(args.observer_lon)
    obs_alt_m = float(args.observer_alt_m)

    rng = np.random.default_rng(int(args.seed))
    best_score = float("inf")
    best_epoch = -1
    no_improve = 0
    out_model = Path(args.out_model)
    ensure_dir(out_model if out_model.suffix == "" else out_model.parent)
    best_model_path = (out_model if out_model.suffix == "" else out_model.parent) / "_best_model.keras"

    def train_epoch(records: List[Tuple[SatDataset, str]], batch_size: int, time_weight_power: float) -> Tuple[float, int]:
        total_loss = 0.0
        total_rows = 0
        for ds, stem in records:
            try:
                x_s, y_s, no_norm, b_lla, t_azel = load_train_arrays(
                    ds=ds,
                    stem=stem,
                    sat_names=sat_names,
                    cfg=cfg,
                    x_mean=x_mean,
                    x_std=x_std,
                    y_mean=y_mean,
                    y_std=y_std,
                    days_horizon=int(args.days_horizon),
                    step_minutes=int(args.step_minutes),
                    sample_every=int(args.sample_every),
                )
            except Exception as e:
                log(f"[WARN] train skip {ds.name}:{stem}: {e}")
                continue
            n = len(x_s)
            if n == 0:
                continue
            idx = np.arange(n)
            rng.shuffle(idx)
            x_s = x_s[idx]
            y_s = y_s[idx]
            no_norm = no_norm[idx]
            b_lla = b_lla[idx]
            t_azel = t_azel[idx]
            bs = int(batch_size)
            for s in range(0, n, bs):
                e = min(n, s + bs)
                xb = x_s[s:e]
                yb = y_s[s:e]
                bb = b_lla[s:e]
                tb = t_azel[s:e]
                if float(time_weight_power) > 0:
                    w = np.power(np.clip(no_norm[s:e], 0.0, 1.0), float(time_weight_power)) + 1e-3
                else:
                    w = np.ones((len(xb),), dtype=np.float32)
                xb_tf = tf.convert_to_tensor(xb, dtype=tf.float32)
                yb_tf = tf.convert_to_tensor(yb, dtype=tf.float32)
                bb_tf = tf.convert_to_tensor(bb, dtype=tf.float32)
                tb_tf = tf.convert_to_tensor(tb, dtype=tf.float32)
                w_tf = tf.convert_to_tensor(w.reshape(-1, 1), dtype=tf.float32)

                with tf.GradientTape() as tape:
                    pred_s = model(xb_tf, training=True)
                    pred_lla = pred_s * y_std_tf + y_mean_tf
                    true_lla = yb_tf * y_std_tf + y_mean_tf

                    err_lla = pred_lla - true_lla
                    lla_huber = tf_huber_per_sample(err_lla, delta=lla_huber_delta)
                    lla_loss_sample = tf.reduce_sum(lla_w_tf * lla_huber, axis=1, keepdims=True)
                    lla_loss = tf.reduce_sum(lla_loss_sample * w_tf) / (
                        tf.reduce_sum(w_tf) + tf.constant(1e-8, dtype=tf.float32)
                    )

                    total_batch_loss = lla_loss
                    if (w_az > 0.0) or (w_el > 0.0):
                        corr_lat = bb_tf[:, 0] + pred_lla[:, 0]
                        corr_lon = tf_wrap180_deg(bb_tf[:, 1] + pred_lla[:, 1])
                        corr_alt = bb_tf[:, 2] + pred_lla[:, 2]
                        az_p, el_p = tf_recompute_azel_from_lla(
                            sat_lat_deg=corr_lat,
                            sat_lon_deg=corr_lon,
                            sat_alt_km=corr_alt,
                            observer_lat_deg=obs_lat,
                            observer_lon_deg=obs_lon,
                            observer_alt_m=obs_alt_m,
                        )
                        az_err = tf_angle_diff_deg(az_p, tb_tf[:, 0])
                        el_err = el_p - tb_tf[:, 1]
                        az_loss = tf.reduce_sum(
                            tf_huber_per_sample(az_err, delta=az_huber_delta)[:, None] * w_tf
                        ) / (tf.reduce_sum(w_tf) + tf.constant(1e-8, dtype=tf.float32))
                        el_loss = tf.reduce_sum(
                            tf_huber_per_sample(el_err, delta=el_huber_delta)[:, None] * w_tf
                        ) / (tf.reduce_sum(w_tf) + tf.constant(1e-8, dtype=tf.float32))
                        total_batch_loss = total_batch_loss + float(w_az) * az_loss + float(w_el) * el_loss

                grads = tape.gradient(total_batch_loss, model.trainable_variables)
                gv = [(g, v) for g, v in zip(grads, model.trainable_variables) if g is not None]
                if gv:
                    optimizer.apply_gradients(gv)
                total_loss += float(total_batch_loss) * len(xb)
                total_rows += len(xb)
        return total_loss / max(1, total_rows), total_rows

    def eval_score() -> Tuple[float, float]:
        return target_val_score(
            model=model,
            target_ds=target_ds,
            sat_names=sat_names,
            cfg=cfg,
            x_mean=x_mean,
            x_std=x_std,
            y_mean=y_mean,
            y_std=y_std,
            observer_lat=float(args.observer_lat),
            observer_lon=float(args.observer_lon),
            observer_alt_m=float(args.observer_alt_m),
            days_horizon=int(args.days_horizon),
            step_minutes=int(args.step_minutes),
            sample_every=int(args.sample_every),
            batch_size=int(args.batch_size),
            max_files=(int(args.val_eval_max_files) if args.val_eval_max_files else None),
        )

    # Stage 1: pretrain with target + sampled aux
    epochs_pre = int(args.epochs_pretrain)
    epochs_ft = int(args.epochs_finetune)
    if len(aux_datasets) == 0:
        epochs_pre = 0

    target_records = [(target_ds, s) for s in target_ds.train_stems]

    epoch = 0
    for _ in range(epochs_pre):
        epoch += 1
        optimizer.learning_rate.assign(float(args.lr_pretrain))

        records = list(target_records)
        for ds in aux_datasets:
            n_aux = int(max(1, round(len(target_records) * float(args.aux_ratio_per_dataset))))
            if len(ds.train_stems) <= n_aux:
                sel = list(ds.train_stems)
            else:
                sel = list(rng.choice(np.asarray(ds.train_stems), size=n_aux, replace=False))
            records.extend((ds, s) for s in sel)
        rng.shuffle(records)

        train_loss, train_rows = train_epoch(
            records=records,
            batch_size=int(args.batch_size),
            time_weight_power=float(args.time_weight_power),
        )
        base_rmse, score = eval_score()
        log(f"[EPOCH {epoch}] stage=pretrain train_loss={train_loss:.6g} rows={train_rows}")
        log(f"  [VAL recompute] AZEL_RMSE_mean {base_rmse:.6g} -> {score:.6g}")

        improved = (best_score - score) > float(args.early_stop_min_delta)
        if improved:
            best_score = score
            best_epoch = epoch
            no_improve = 0
            model.save(str(best_model_path))
        else:
            no_improve += 1

    # Stage 2: fine-tune on target only
    for _ in range(epochs_ft):
        epoch += 1
        optimizer.learning_rate.assign(float(args.lr_finetune))
        records = list(target_records)
        rng.shuffle(records)
        train_loss, train_rows = train_epoch(
            records=records,
            batch_size=int(args.batch_size),
            time_weight_power=float(args.time_weight_power),
        )
        base_rmse, score = eval_score()
        log(f"[EPOCH {epoch}] stage=finetune train_loss={train_loss:.6g} rows={train_rows}")
        log(f"  [VAL recompute] AZEL_RMSE_mean {base_rmse:.6g} -> {score:.6g}")

        improved = (best_score - score) > float(args.early_stop_min_delta)
        if improved:
            best_score = score
            best_epoch = epoch
            no_improve = 0
            model.save(str(best_model_path))
        else:
            no_improve += 1

        if int(args.early_stop_patience) > 0 and epoch >= int(args.early_stop_warmup):
            if no_improve >= int(args.early_stop_patience):
                log(
                    f"[EARLY STOP] no improve for {no_improve} epochs. "
                    f"best_epoch={best_epoch} best_score={best_score:.6g}"
                )
                break

    if best_model_path.exists():
        model = tf.keras.models.load_model(str(best_model_path), compile=False)

    # Calibration on target val
    y_true_list: List[np.ndarray] = []
    y_pred_list: List[np.ndarray] = []
    baseline_list: List[np.ndarray] = []
    truth_list: List[np.ndarray] = []
    no_list: List[np.ndarray] = []
    for stem in target_ds.val_stems if target_ds.val_stems else target_ds.train_stems:
        try:
            pred_lla, no, baseline, truth = predict_lla_delta_with_sat(
                model=model,
                ds=target_ds,
                stem=stem,
                sat_names=sat_names,
                cfg=cfg,
                x_mean=x_mean,
                x_std=x_std,
                y_mean=y_mean,
                y_std=y_std,
                days_horizon=int(args.days_horizon),
                step_minutes=int(args.step_minutes),
                sample_every=int(args.sample_every),
                batch_size=int(args.batch_size),
            )
            # true lla delta
            y_true = np.zeros_like(pred_lla)
            y_true[:, 0] = truth[:, TARGET_COLS.index("Lat")] - baseline[:, TARGET_COLS.index("Lat")]
            y_true[:, 1] = angle_diff_deg(truth[:, TARGET_COLS.index("Lon")], baseline[:, TARGET_COLS.index("Lon")])
            y_true[:, 2] = truth[:, TARGET_COLS.index("Alt")] - baseline[:, TARGET_COLS.index("Alt")]
        except Exception:
            continue
        if len(pred_lla) == 0:
            continue
        y_true_list.append(y_true)
        y_pred_list.append(pred_lla)
        baseline_list.append(baseline)
        truth_list.append(truth)
        no_list.append(no)

    if not y_true_list:
        log("[ERROR] no calibration rows on target")
        return 2
    y_true = np.concatenate(y_true_list, axis=0)
    y_pred = np.concatenate(y_pred_list, axis=0)
    baseline_all = np.concatenate(baseline_list, axis=0)
    truth_all = np.concatenate(truth_list, axis=0)
    no_all = np.concatenate(no_list, axis=0)

    alpha_vec, clip_vec, lla_details = calibrate_lla_alpha_clip(
        y_true_lla=y_true,
        y_pred_lla=y_pred,
        y_std=y_std,
        alpha_min=float(args.alpha_min),
        alpha_max=float(args.alpha_max),
        alpha_step=float(args.alpha_step),
        clip_candidates=parse_clip_candidates(str(args.clip_grid)),
        min_improve_pct=float(args.lla_min_improve_pct),
    )
    log("[INFO] calibrated alpha (Lat,Lon,Alt): " + ", ".join(f"{v:.6g}" for v in alpha_vec.tolist()))
    log(
        "[INFO] calibrated clip (Lat,Lon,Alt): "
        + ", ".join("none" if (not np.isfinite(v) or v <= 0) else f"{v:.6g}" for v in clip_vec.tolist())
    )

    pred_lla_cal = apply_lla_alpha_clip(
        pred_delta_lla=y_pred,
        alpha_vec=alpha_vec,
        clip_k_vec=clip_vec,
        y_std=y_std,
    )
    lla_azel_scale_vec, lla_azel_scale_info = calibrate_lla_scale_for_azel(
        baseline=baseline_all,
        truth=truth_all,
        pred_delta_lla=pred_lla_cal,
        observer_lat_deg=float(args.observer_lat),
        observer_lon_deg=float(args.observer_lon),
        observer_alt_m=float(args.observer_alt_m),
        latlon_scale_grid=parse_float_list_csv(str(args.azel_latlon_scale_grid)),
        alt_scale_grid=parse_float_list_csv(str(args.azel_alt_scale_grid)),
        min_improve_pct=float(args.azel_scale_min_improve_pct),
    )
    pred_lla_for_azel = pred_lla_cal * lla_azel_scale_vec.reshape(1, -1)
    corr_lla = apply_lla_correction(baseline=baseline_all, delta_lla=pred_lla_for_azel)
    log(
        "[INFO] LLA->AZEL scale (Lat,Lon,Alt): "
        + ", ".join(f"{v:.6g}" for v in lla_azel_scale_vec.tolist())
    )

    day_edges = parse_float_list_csv(str(args.azel_day_edges))
    if len(day_edges) < 2:
        day_edges = [0.0, float(args.days_horizon)]
    if day_edges[0] > 0:
        day_edges = [0.0] + day_edges
    if day_edges[-1] < float(args.days_horizon):
        day_edges = day_edges + [float(args.days_horizon)]
    day_edges = sorted(set(float(v) for v in day_edges))
    azel_day_edges = np.asarray(day_edges, dtype=np.float64)
    azel_gamma_matrix, gamma_details = calibrate_azel_gamma_schedule(
        no=no_all,
        baseline=baseline_all,
        corrected_lla=corr_lla,
        truth=truth_all,
        observer_lat_deg=float(args.observer_lat),
        observer_lon_deg=float(args.observer_lon),
        observer_alt_m=float(args.observer_alt_m),
        day_edges=azel_day_edges,
        gamma_grid=parse_float_list_csv(str(args.azel_gamma_grid)),
        min_improve_pct=float(args.azel_min_improve_pct),
    )
    log("[INFO] AZEL day edges: " + ",".join(f"{v:g}" for v in azel_day_edges.tolist()))
    log("[INFO] gamma AZ: " + ", ".join(f"{v:.4g}" for v in azel_gamma_matrix[:, 0].tolist()))
    log("[INFO] gamma EL: " + ", ".join(f"{v:.4g}" for v in azel_gamma_matrix[:, 1].tolist()))

    train_eval = evaluate_target_dataset(
        model=model,
        target_ds=target_ds,
        sat_names=sat_names,
        cfg=cfg,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        alpha_vec=alpha_vec,
        clip_vec=clip_vec,
        lla_azel_scale_vec=lla_azel_scale_vec,
        azel_day_edges=azel_day_edges,
        azel_gamma_matrix=azel_gamma_matrix,
        observer_lat=float(args.observer_lat),
        observer_lon=float(args.observer_lon),
        observer_alt_m=float(args.observer_alt_m),
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        use_val=False,
    )
    val_eval = evaluate_target_dataset(
        model=model,
        target_ds=target_ds,
        sat_names=sat_names,
        cfg=cfg,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        alpha_vec=alpha_vec,
        clip_vec=clip_vec,
        lla_azel_scale_vec=lla_azel_scale_vec,
        azel_day_edges=azel_day_edges,
        azel_gamma_matrix=azel_gamma_matrix,
        observer_lat=float(args.observer_lat),
        observer_lon=float(args.observer_lon),
        observer_alt_m=float(args.observer_alt_m),
        days_horizon=int(args.days_horizon),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
        batch_size=int(args.batch_size),
        use_val=True,
    )
    if bool(args.strict_no_harm_azel) and val_eval:
        az_bad = val_eval.get("AZ_RMSE_corr", 0.0) > val_eval.get("AZ_RMSE_base", 0.0)
        el_bad = val_eval.get("EL_RMSE_corr", 0.0) > val_eval.get("EL_RMSE_base", 0.0)
        if az_bad:
            azel_gamma_matrix[:, 0] = 0.0
            log("[GUARD] AZ validation worsened; forcing gamma_AZ=0 for all bins.")
        if el_bad:
            azel_gamma_matrix[:, 1] = 0.0
            log("[GUARD] EL validation worsened; forcing gamma_EL=0 for all bins.")
        if az_bad or el_bad:
            train_eval = evaluate_target_dataset(
                model=model,
                target_ds=target_ds,
                sat_names=sat_names,
                cfg=cfg,
                x_mean=x_mean,
                x_std=x_std,
                y_mean=y_mean,
                y_std=y_std,
                alpha_vec=alpha_vec,
                clip_vec=clip_vec,
                lla_azel_scale_vec=lla_azel_scale_vec,
                azel_day_edges=azel_day_edges,
                azel_gamma_matrix=azel_gamma_matrix,
                observer_lat=float(args.observer_lat),
                observer_lon=float(args.observer_lon),
                observer_alt_m=float(args.observer_alt_m),
                days_horizon=int(args.days_horizon),
                step_minutes=int(args.step_minutes),
                sample_every=int(args.sample_every),
                batch_size=int(args.batch_size),
                use_val=False,
            )
            val_eval = evaluate_target_dataset(
                model=model,
                target_ds=target_ds,
                sat_names=sat_names,
                cfg=cfg,
                x_mean=x_mean,
                x_std=x_std,
                y_mean=y_mean,
                y_std=y_std,
                alpha_vec=alpha_vec,
                clip_vec=clip_vec,
                lla_azel_scale_vec=lla_azel_scale_vec,
                azel_day_edges=azel_day_edges,
                azel_gamma_matrix=azel_gamma_matrix,
                observer_lat=float(args.observer_lat),
                observer_lon=float(args.observer_lon),
                observer_alt_m=float(args.observer_alt_m),
                days_horizon=int(args.days_horizon),
                step_minutes=int(args.step_minutes),
                sample_every=int(args.sample_every),
                batch_size=int(args.batch_size),
                use_val=True,
            )
    if train_eval:
        log(
            f"[TRAIN] global RMSE {train_eval['global_RMSE_base']:.6g} -> "
            f"{train_eval['global_RMSE_corr']:.6g} ({train_eval['global_RMSE_improve_pct']:.3f}%)"
        )
    if val_eval:
        log(
            f"[VAL] global RMSE {val_eval['global_RMSE_base']:.6g} -> "
            f"{val_eval['global_RMSE_corr']:.6g} ({val_eval['global_RMSE_improve_pct']:.3f}%)"
        )
        for c in TARGET_COLS:
            log(f"  {c}: RMSE {val_eval[f'{c}_RMSE_base']:.6g} -> {val_eval[f'{c}_RMSE_corr']:.6g}")

    bundle = ModelBundle(
        feature_cfg=cfg,
        feature_names=feat_names,
        sat_names=sat_names,
        target_sat_name=target_ds.name,
        x_mean=x_mean,
        x_std=x_std,
        y_mean=y_mean,
        y_std=y_std,
        alpha_vec=alpha_vec,
        clip_k_sigma_vec=clip_vec,
        lla_azel_scale_vec=lla_azel_scale_vec,
        azel_day_edges=azel_day_edges,
        azel_gamma_matrix=azel_gamma_matrix,
        observer_lat_deg=float(args.observer_lat),
        observer_lon_deg=float(args.observer_lon),
        observer_alt_m=float(args.observer_alt_m),
        train_rows=int(scaler_rows),
        train_files=int(len(target_ds.train_stems)),
        val_files=int(len(target_ds.val_stems)),
    )
    extra = {
        "datasets": sat_names,
        "target": target_ds.name,
        "best_epoch": int(best_epoch),
        "best_val_score_recompute_azel_rmse": float(best_score),
        "train_eval": train_eval,
        "val_eval": val_eval,
        "lla_calibration": lla_details,
        "lla_azel_scale_calibration": lla_azel_scale_info,
        "azel_gamma_details": gamma_details,
        "split_mode": str(args.split_mode),
    }
    model_path, meta_path = save_model_and_meta(
        model=model,
        bundle=bundle,
        out_model=out_model,
        overwrite=bool(args.overwrite),
        extra=extra,
    )
    summary_path = meta_path.parent / "train_summary.json"
    summary_path.write_text(json.dumps(extra, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[SAVED] model: {model_path}")
    log(f"[SAVED] meta: {meta_path}")
    log(f"[SAVED] train summary: {summary_path}")
    return 0


def predict_cmd(args: argparse.Namespace) -> int:
    require_tensorflow()
    model, bundle, _meta = load_model_and_meta(Path(args.model))
    truth_df = load_orbit_csv(Path(args.truth_csv), require_targets=True) if args.truth_csv else None

    base_df, x_base, no, baseline, base_names = load_infer_pair(
        tle_file=Path(args.tle_file),
        baseline_csv=Path(args.baseline_csv),
        cfg=bundle.feature_cfg,
        days_horizon=int(args.days),
        step_minutes=int(args.step_minutes),
        sample_every=int(args.sample_every),
    )
    if len(base_df) == 0:
        raise RuntimeError(f"no rows after trim: {args.baseline_csv}")
    x, names = append_sat_feature(
        x_base=x_base,
        base_names=base_names,
        sat_vec=sat_onehot(bundle.target_sat_name, bundle.sat_names),
        sat_names=bundle.sat_names,
    )
    if names != bundle.feature_names:
        raise ValueError("feature names mismatch between model and inference")

    x_s = scale_arr(x, bundle.x_mean, bundle.x_std)
    y_s = model.predict(x_s, batch_size=int(args.batch_size), verbose=0)
    pred_lla_raw = (y_s * bundle.y_std.reshape(1, -1) + bundle.y_mean.reshape(1, -1)).astype(np.float64)
    pred_lla = apply_lla_alpha_clip(
        pred_delta_lla=pred_lla_raw,
        alpha_vec=bundle.alpha_vec,
        clip_k_vec=bundle.clip_k_sigma_vec,
        y_std=bundle.y_std,
    )
    svec = np.asarray(bundle.lla_azel_scale_vec, dtype=np.float64).reshape(1, -1)
    if svec.shape[1] == pred_lla.shape[1]:
        pred_lla = pred_lla * svec
    corr = apply_lla_correction(baseline=baseline, delta_lla=pred_lla)

    obs_lat = bundle.observer_lat_deg if args.observer_lat is None else float(args.observer_lat)
    obs_lon = bundle.observer_lon_deg if args.observer_lon is None else float(args.observer_lon)
    obs_alt = bundle.observer_alt_m if args.observer_alt_m is None else float(args.observer_alt_m)
    corr, az_rec, el_rec = apply_azel_gamma_blend(
        corrected_lla_and_base=corr,
        baseline=baseline,
        no=no,
        observer_lat_deg=obs_lat,
        observer_lon_deg=obs_lon,
        observer_alt_m=obs_alt,
        day_edges=bundle.azel_day_edges,
        gamma_matrix=bundle.azel_gamma_matrix,
    )

    out_corr = Path(args.out_corrected_csv)
    out_pred = Path(args.out_pred_delta_csv)
    out_metrics = Path(args.out_metrics_csv) if args.out_metrics_csv else None
    if out_corr.exists() and not args.overwrite:
        raise FileExistsError(f"exists: {out_corr} (use --overwrite)")
    if out_pred.exists() and not args.overwrite:
        raise FileExistsError(f"exists: {out_pred} (use --overwrite)")
    ensure_dir(out_corr.parent)
    ensure_dir(out_pred.parent)

    corr_df = base_df[["No", "date", "UNIX"]].copy()
    for i, c in enumerate(TARGET_COLS):
        corr_df[c] = corr[:, i]
    corr_df.to_csv(out_corr, index=False)

    from orbit_lla_recompute_azel_tf import day_bin_index

    bidx = day_bin_index(no=no, edges=bundle.azel_day_edges)
    g_az = bundle.azel_gamma_matrix[bidx, 0]
    g_el = bundle.azel_gamma_matrix[bidx, 1]
    pred_df = base_df[["No", "date", "UNIX"]].copy()
    pred_df["pred_dLat_raw"] = pred_lla_raw[:, 0]
    pred_df["pred_dLon_raw"] = pred_lla_raw[:, 1]
    pred_df["pred_dAlt_raw"] = pred_lla_raw[:, 2]
    pred_df["pred_dLat"] = pred_lla[:, 0]
    pred_df["pred_dLon"] = pred_lla[:, 1]
    pred_df["pred_dAlt"] = pred_lla[:, 2]
    pred_df["scale_Lat"] = float(bundle.lla_azel_scale_vec[0]) if len(bundle.lla_azel_scale_vec) > 0 else 1.0
    pred_df["scale_Lon"] = float(bundle.lla_azel_scale_vec[1]) if len(bundle.lla_azel_scale_vec) > 1 else 1.0
    pred_df["scale_Alt"] = float(bundle.lla_azel_scale_vec[2]) if len(bundle.lla_azel_scale_vec) > 2 else 1.0
    pred_df["alpha_Lat"] = float(bundle.alpha_vec[0])
    pred_df["alpha_Lon"] = float(bundle.alpha_vec[1])
    pred_df["alpha_Alt"] = float(bundle.alpha_vec[2])
    pred_df["az_recomputed"] = az_rec
    pred_df["el_recomputed"] = el_rec
    pred_df["gamma_AZ"] = g_az
    pred_df["gamma_EL"] = g_el
    pred_df.to_csv(out_pred, index=False)

    log(f"[SAVED] corrected: {out_corr}")
    log(f"[SAVED] predicted deltas: {out_pred}")

    if args.plot_dir:
        plot_dir = Path(args.plot_dir)
    elif args.truth_csv:
        plot_dir = out_corr.parent / "plots"
    else:
        plot_dir = out_corr.parent / "plots"

    if (not args.no_plot) and plot_dir is not None:
        plot_baseline_vs_corrected(
            stem=out_corr.stem,
            baseline_df=base_df,
            corrected_df=corr_df,
            out_dir=plot_dir,
            sample_every=int(args.plot_sample_every),
        )
        log(f"[SAVED] baseline-vs-corrected plots: {plot_dir}")

    if truth_df is not None:
        metrics_df, merged_df = compute_metrics(
            truth_df=truth_df,
            baseline_df=base_df,
            corrected_df=corr_df,
        )
        mpath = out_metrics or (out_corr.parent / f"{out_corr.stem}_metrics.csv")
        if mpath.exists() and not args.overwrite:
            raise FileExistsError(f"exists: {mpath} (use --overwrite)")
        ensure_dir(mpath.parent)
        metrics_df.to_csv(mpath, index=False)
        log(f"[SAVED] metrics: {mpath}")
        b = metrics_df[metrics_df["kind"] == "baseline"].iloc[0]
        c = metrics_df[metrics_df["kind"] == "corrected"].iloc[0]
        log("[METRIC] MSE/RMSE (baseline -> corrected)")
        for col in TARGET_COLS:
            log(
                f"  {col}: MSE {float(b[f'{col}_MSE']):.6g} -> {float(c[f'{col}_MSE']):.6g} | "
                f"RMSE {float(b[f'{col}_RMSE']):.6g} -> {float(c[f'{col}_RMSE']):.6g}"
            )
        log(
            f"  GLOBAL: MSE {float(b['global_MSE']):.6g} -> {float(c['global_MSE']):.6g} | "
            f"RMSE {float(b['global_RMSE']):.6g} -> {float(c['global_RMSE']):.6g}"
        )
        if (not args.no_plot) and plot_dir is not None:
            plot_truth_baseline_corrected(
                stem=out_corr.stem,
                merged_df=merged_df,
                out_dir=plot_dir,
                sample_every=int(args.plot_sample_every),
            )
            plot_metric_summary(
                stem=out_corr.stem,
                metrics_df=metrics_df,
                out_dir=plot_dir,
            )
            log(f"[SAVED] truth comparison plots: {plot_dir}")

    return 0


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="orbit_transfer_lla_reazel_tf.py",
        description="Transfer-learning LLA correction + geometric AZ/EL recompute (single-TLE inference)",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train", help="Train target model with optional auxiliary satellites")
    t.add_argument("--target-name", default="UFO4")
    t.add_argument("--target-tle-dir", default="23467_2023")
    t.add_argument("--target-baseline-dir", default="23467_2023_csv")
    t.add_argument("--target-truth-csv", default="2023_calc_az_el.csv")
    t.add_argument(
        "--aux-dataset",
        action="append",
        default=None,
        help="Optional auxiliary dataset: name:tle_dir:baseline_dir:truth_csv (repeatable)",
    )
    t.add_argument("--out-model", default="orbit_transfer_lla_reazel_model_tf")

    t.add_argument("--days-horizon", type=int, default=30)
    t.add_argument("--step-minutes", type=int, default=1)
    t.add_argument("--sample-every", type=int, default=1)
    t.add_argument("--val-split", type=float, default=0.15)
    t.add_argument("--split-mode", choices=["time", "hash"], default="time")
    t.add_argument("--seed", type=int, default=42)
    t.add_argument("--max-target-files", type=int, default=None)
    t.add_argument("--max-aux-files", type=int, default=None)

    t.add_argument("--day-harmonics", type=int, default=6)
    t.add_argument("--span-harmonics", type=int, default=4)
    t.add_argument("--no-sidereal", action="store_true")
    t.add_argument("--no-interactions", action="store_true")
    t.add_argument("--no-baseline-feature", action="store_true")

    t.add_argument("--hidden", type=str, default="512,512,256,128")
    t.add_argument("--dropout", type=float, default=0.05)
    t.add_argument("--l2", type=float, default=1e-6)
    t.add_argument("--huber-delta", type=float, default=1.0)
    t.add_argument("--az-huber-delta", type=float, default=0.05)
    t.add_argument("--el-huber-delta", type=float, default=0.03)
    t.add_argument("--batch-size", type=int, default=1024)
    t.add_argument("--time-weight-power", type=float, default=2.0)
    t.add_argument("--epochs-pretrain", type=int, default=80)
    t.add_argument("--epochs-finetune", type=int, default=120)
    t.add_argument("--aux-ratio-per-dataset", type=float, default=1.0)
    t.add_argument("--lr-pretrain", type=float, default=8e-4)
    t.add_argument("--lr-finetune", type=float, default=3e-4)
    t.add_argument("--early-stop-patience", type=int, default=20)
    t.add_argument("--early-stop-warmup", type=int, default=10)
    t.add_argument("--early-stop-min-delta", type=float, default=0.0)
    t.add_argument("--val-eval-max-files", type=int, default=20)

    t.add_argument("--loss-weight-lat", type=float, default=2.0)
    t.add_argument("--loss-weight-lon", type=float, default=2.0)
    t.add_argument("--loss-weight-alt", type=float, default=1.0)
    t.add_argument("--loss-weight-az", type=float, default=4.0)
    t.add_argument("--loss-weight-el", type=float, default=4.0)

    t.add_argument("--alpha-min", type=float, default=0.0)
    t.add_argument("--alpha-max", type=float, default=1.0)
    t.add_argument("--alpha-step", type=float, default=0.02)
    t.add_argument("--clip-grid", type=str, default="0,0.5,1,1.5,2")
    t.add_argument("--lla-min-improve-pct", type=float, default=0.2)
    t.add_argument("--observer-lat", type=float, default=36.3022)
    t.add_argument("--observer-lon", type=float, default=137.9031)
    t.add_argument("--observer-alt-m", type=float, default=0.0)
    t.add_argument("--azel-day-edges", type=str, default="0,1,3,7,14,30")
    t.add_argument("--azel-gamma-grid", type=str, default="0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1")
    t.add_argument("--azel-min-improve-pct", type=float, default=0.2)
    t.add_argument("--azel-latlon-scale-grid", type=str, default="0,0.05,0.1,0.2,0.3,0.5,0.7,1.0")
    t.add_argument("--azel-alt-scale-grid", type=str, default="0,0.2,0.5,0.8,1.0")
    t.add_argument("--azel-scale-min-improve-pct", type=float, default=0.2)
    t.add_argument("--strict-no-harm-azel", action=argparse.BooleanOptionalAction, default=True)
    t.add_argument("--overwrite", action="store_true")

    pr = sub.add_parser("predict", help="Predict one target TLE")
    pr.add_argument("--model", required=True)
    pr.add_argument("--tle-file", required=True)
    pr.add_argument("--baseline-csv", required=True)
    pr.add_argument("--out-corrected-csv", required=True)
    pr.add_argument("--out-pred-delta-csv", required=True)
    pr.add_argument("--truth-csv", default=None)
    pr.add_argument("--out-metrics-csv", default=None)
    pr.add_argument("--plot-dir", default=None)
    pr.add_argument("--plot-sample-every", type=int, default=5)
    pr.add_argument("--no-plot", action="store_true")
    pr.add_argument("--days", type=int, default=30)
    pr.add_argument("--step-minutes", type=int, default=1)
    pr.add_argument("--sample-every", type=int, default=1)
    pr.add_argument("--batch-size", type=int, default=4096)
    pr.add_argument("--observer-lat", type=float, default=None)
    pr.add_argument("--observer-lon", type=float, default=None)
    pr.add_argument("--observer-alt-m", type=float, default=None)
    pr.add_argument("--overwrite", action="store_true")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
    args = make_parser().parse_args(argv)
    if args.cmd == "train":
        return train_cmd(args)
    if args.cmd == "predict":
        return predict_cmd(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
