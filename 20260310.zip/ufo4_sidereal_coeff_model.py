#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sidereal coefficient model for GEO AZ/EL.

The model predicts trig targets [sin(AZ), cos(AZ), sin(EL), cos(EL)] from:
- sidereal-day harmonics
- annual harmonics
- sidereal x annual cross terms
- smooth year-state basis across training years

An optional linear correction model is then trained from forward backtest
residuals to correct persistent year-local biases.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Dict, Iterable, List, Tuple

import numpy as np

import ufo4_harmonic_azel_tf as hm
import ufo4_orbit_predict_tf as core


@dataclass
class SiderealCoeffConfig:
    sidereal_harmonics: int = 4
    yearly_harmonics: int = 2
    year_poly_order: int = 2
    use_year_cycle_2: bool = True
    use_year_cycle_3: bool = True
    ridge: float = 1.0e-3
    correction_ridge: float = 5.0e-3
    chunk_rows: int = 60000
    min_history_years_for_correction: int = 3
    correction_cap_az: float = 0.80
    correction_cap_el: float = 0.80


def cfg_to_dict(cfg: SiderealCoeffConfig) -> Dict[str, int | float | bool]:
    return asdict(cfg)


def cfg_from_dict(d: Dict[str, int | float | bool]) -> SiderealCoeffConfig:
    return SiderealCoeffConfig(
        sidereal_harmonics=max(1, int(d.get("sidereal_harmonics", 4))),
        yearly_harmonics=max(0, int(d.get("yearly_harmonics", 2))),
        year_poly_order=max(0, int(d.get("year_poly_order", 2))),
        use_year_cycle_2=bool(d.get("use_year_cycle_2", True)),
        use_year_cycle_3=bool(d.get("use_year_cycle_3", True)),
        ridge=float(d.get("ridge", 1.0e-3)),
        correction_ridge=float(d.get("correction_ridge", 5.0e-3)),
        chunk_rows=max(10000, int(d.get("chunk_rows", 60000))),
        min_history_years_for_correction=max(2, int(d.get("min_history_years_for_correction", 3))),
        correction_cap_az=float(d.get("correction_cap_az", 0.80)),
        correction_cap_el=float(d.get("correction_cap_el", 0.80)),
    )


def default_candidate_cfgs(base: SiderealCoeffConfig) -> List[SiderealCoeffConfig]:
    out: List[SiderealCoeffConfig] = []
    for sid_h in (4, 6, 8):
        for yr_h in (2, 3):
            for ridge in (1.0e-4, 1.0e-3):
                cfg = cfg_from_dict(cfg_to_dict(base))
                cfg.sidereal_harmonics = int(sid_h)
                cfg.yearly_harmonics = int(yr_h)
                cfg.ridge = float(ridge)
                out.append(cfg)
    return out


def _compute_local_year_from_unix(unix: np.ndarray) -> np.ndarray:
    sec_local = np.asarray(np.round(unix), dtype=np.int64) + int(core.JST_OFFSET_SEC)
    dt_y = sec_local.astype("datetime64[s]").astype("datetime64[Y]")
    return (dt_y.astype(np.int64) + 1970).astype(np.int32)


def _build_time_basis(unix: np.ndarray, cfg: SiderealCoeffConfig) -> np.ndarray:
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    u_local = u + float(core.JST_OFFSET_SEC)
    two_pi = 2.0 * math.pi
    phase_sid = two_pi * u_local / hm.SECONDS_PER_SIDEREAL_DAY
    phase_year = two_pi * u_local / hm.SECONDS_PER_TROPICAL_YEAR

    cols: List[np.ndarray] = [np.ones_like(u, dtype=np.float64)]
    sid_sin: List[np.ndarray] = []
    sid_cos: List[np.ndarray] = []
    year_sin: List[np.ndarray] = []
    year_cos: List[np.ndarray] = []

    for k in range(1, int(cfg.sidereal_harmonics) + 1):
        arg = phase_sid * float(k)
        ss = np.sin(arg)
        cc = np.cos(arg)
        sid_sin.append(ss)
        sid_cos.append(cc)
        cols.append(ss)
        cols.append(cc)

    for k in range(1, int(cfg.yearly_harmonics) + 1):
        arg = phase_year * float(k)
        ss = np.sin(arg)
        cc = np.cos(arg)
        year_sin.append(ss)
        year_cos.append(cc)
        cols.append(ss)
        cols.append(cc)

    for i in range(len(sid_sin)):
        for j in range(len(year_sin)):
            cols.append(sid_sin[i] * year_sin[j])
            cols.append(sid_sin[i] * year_cos[j])
            cols.append(sid_cos[i] * year_sin[j])
            cols.append(sid_cos[i] * year_cos[j])

    return np.column_stack(cols).astype(np.float64)


def _build_year_basis(
    years: np.ndarray,
    year_center: float,
    year_origin: float,
    cfg: SiderealCoeffConfig,
) -> np.ndarray:
    y = np.asarray(years, dtype=np.float64).reshape(-1)
    yr_centered = y - float(year_center)
    yr_origin = y - float(year_origin)

    cols: List[np.ndarray] = [np.ones_like(y, dtype=np.float64)]
    for order in range(1, int(cfg.year_poly_order) + 1):
        cols.append(np.power(yr_centered, int(order)))

    if bool(cfg.use_year_cycle_2):
        arg = math.pi * yr_origin
        cols.append(np.sin(arg))
        cols.append(np.cos(arg))

    if bool(cfg.use_year_cycle_3):
        arg = (2.0 * math.pi / 3.0) * yr_origin
        cols.append(np.sin(arg))
        cols.append(np.cos(arg))

    return np.column_stack(cols).astype(np.float64)


def design_dim(cfg: SiderealCoeffConfig) -> int:
    tb = 1 + 2 * int(cfg.sidereal_harmonics) + 2 * int(cfg.yearly_harmonics) + 4 * int(cfg.sidereal_harmonics) * int(cfg.yearly_harmonics)
    yb = 1 + int(cfg.year_poly_order)
    if bool(cfg.use_year_cycle_2):
        yb += 2
    if bool(cfg.use_year_cycle_3):
        yb += 2
    return int(tb * yb)


def _combine_basis(time_basis: np.ndarray, year_basis: np.ndarray) -> np.ndarray:
    if time_basis.shape[0] != year_basis.shape[0]:
        raise ValueError("time/year basis row mismatch")
    blocks = [time_basis * year_basis[:, j : j + 1] for j in range(year_basis.shape[1])]
    return np.concatenate(blocks, axis=1).astype(np.float64)


def build_design_matrix(
    unix: np.ndarray,
    years: np.ndarray,
    year_center: float,
    year_origin: float,
    cfg: SiderealCoeffConfig,
) -> np.ndarray:
    tb = _build_time_basis(unix, cfg)
    yb = _build_year_basis(years, year_center=year_center, year_origin=year_origin, cfg=cfg)
    return _combine_basis(tb, yb)


def _safe_solve(xtx: np.ndarray, xty: np.ndarray) -> np.ndarray:
    try:
        return np.linalg.solve(xtx, xty)
    except np.linalg.LinAlgError:
        return np.linalg.pinv(xtx) @ xty


def fit_trig4_model(
    year_data: Dict[int, Tuple[np.ndarray, np.ndarray]],
    train_years: Iterable[int],
    cfg: SiderealCoeffConfig,
    weight_by_year: Dict[int, np.ndarray] | None = None,
    year_center: float | None = None,
    year_origin: float | None = None,
) -> Dict[str, np.ndarray | float | dict]:
    years = sorted(int(y) for y in train_years)
    if not years:
        raise ValueError("fit_trig4_model requires at least one year")
    yc = float(np.mean(years) if year_center is None else year_center)
    yo = float(np.min(years) if year_origin is None else year_origin)
    dim = int(design_dim(cfg))
    xtx = np.eye(dim, dtype=np.float64) * float(max(1.0e-12, cfg.ridge))
    xty = np.zeros((dim, 4), dtype=np.float64)

    for yy in years:
        unix, azel = year_data[int(yy)]
        target = hm.normalize_trig4_np(hm.azel_to_trig4(azel)).astype(np.float64)
        row_w = None
        if weight_by_year is not None and int(yy) in weight_by_year:
            row_w = np.asarray(weight_by_year[int(yy)], dtype=np.float64).reshape(-1)
        if row_w is None or row_w.shape[0] != unix.shape[0]:
            row_w = np.ones((unix.shape[0],), dtype=np.float64)
        row_w = np.where(np.isfinite(row_w), row_w, 0.0)
        if float(np.sum(row_w)) <= 0.0:
            row_w[:] = 1.0

        for start in range(0, unix.shape[0], int(cfg.chunk_rows)):
            end = min(unix.shape[0], start + int(cfg.chunk_rows))
            years_chunk = np.full((end - start,), int(yy), dtype=np.float64)
            x = build_design_matrix(
                unix=unix[start:end],
                years=years_chunk,
                year_center=yc,
                year_origin=yo,
                cfg=cfg,
            )
            sw = np.sqrt(row_w[start:end]).reshape(-1, 1)
            xw = x * sw
            yw = target[start:end] * sw
            xtx += xw.T @ xw
            xty += xw.T @ yw

    beta = _safe_solve(xtx, xty)
    return {
        "year_center": float(yc),
        "year_origin": float(yo),
        "beta_trig4": np.asarray(beta, dtype=np.float64),
        "config": cfg_to_dict(cfg),
    }


def predict_trig4(
    model: Dict[str, np.ndarray | float | dict],
    unix: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    cfg = cfg_from_dict(model["config"])
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    years = _compute_local_year_from_unix(u).astype(np.float64)
    x = build_design_matrix(
        unix=u,
        years=years,
        year_center=float(model["year_center"]),
        year_origin=float(model["year_origin"]),
        cfg=cfg,
    )
    trig4 = x @ np.asarray(model["beta_trig4"], dtype=np.float64)
    trig4 = hm.normalize_trig4_np(trig4).astype(np.float64)
    azel = hm.trig4_to_azel(trig4).astype(np.float64)
    return trig4, azel


def _build_correction_features(
    model: Dict[str, np.ndarray | float | dict],
    unix: np.ndarray,
    base_trig4: np.ndarray,
    base_azel: np.ndarray,
) -> np.ndarray:
    cfg = cfg_from_dict(model["config"])
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    years = _compute_local_year_from_unix(u).astype(np.float64)
    x = build_design_matrix(
        unix=u,
        years=years,
        year_center=float(model["year_center"]),
        year_origin=float(model["year_origin"]),
        cfg=cfg,
    )
    base_t = hm.normalize_trig4_np(base_trig4).astype(np.float64)
    baz = np.asarray(base_azel, dtype=np.float64)
    d_az = hm.angle_diff_deg(baz[:, 0], np.roll(baz[:, 0], 1)) / 180.0
    d_el = (baz[:, 1] - np.roll(baz[:, 1], 1)) / 90.0
    if d_az.shape[0] > 1:
        d_az[0] = d_az[1]
        d_el[0] = d_el[1]
    else:
        d_az[0] = 0.0
        d_el[0] = 0.0
    return np.concatenate(
        [
            x,
            base_t.astype(np.float64),
            d_az.reshape(-1, 1).astype(np.float64),
            d_el.reshape(-1, 1).astype(np.float64),
        ],
        axis=1,
    )


def fit_forward_correction(
    year_data: Dict[int, Tuple[np.ndarray, np.ndarray]],
    ordered_years: Iterable[int],
    cfg: SiderealCoeffConfig,
    weight_by_year: Dict[int, np.ndarray] | None,
    year_center: float,
    year_origin: float,
) -> Dict[str, np.ndarray | float | list | dict] | None:
    years = sorted(int(y) for y in ordered_years)
    if len(years) < max(3, int(cfg.min_history_years_for_correction) + 1):
        return None

    feat_dim: int | None = None
    xtx = None
    xty = None
    used_years: List[int] = []

    for target_year in years:
        hist_years = [yy for yy in years if yy < int(target_year)]
        if len(hist_years) < int(cfg.min_history_years_for_correction):
            continue
        base_model = fit_trig4_model(
            year_data=year_data,
            train_years=hist_years,
            cfg=cfg,
            weight_by_year=weight_by_year,
            year_center=year_center,
            year_origin=year_origin,
        )
        unix_t, true_azel = year_data[int(target_year)]
        base_trig4, base_azel = predict_trig4(base_model, unix_t)
        feat = _build_correction_features(
            model=base_model,
            unix=unix_t,
            base_trig4=base_trig4,
            base_azel=base_azel,
        )
        target = np.column_stack(
            [
                hm.angle_diff_deg(true_azel[:, 0], base_azel[:, 0]),
                true_azel[:, 1] - base_azel[:, 1],
            ]
        ).astype(np.float64)
        row_w = None
        if weight_by_year is not None and int(target_year) in weight_by_year:
            row_w = np.asarray(weight_by_year[int(target_year)], dtype=np.float64).reshape(-1)
        if row_w is None or row_w.shape[0] != feat.shape[0]:
            row_w = np.ones((feat.shape[0],), dtype=np.float64)
        row_w = np.where(np.isfinite(row_w), row_w, 0.0)
        if float(np.sum(row_w)) <= 0.0:
            row_w[:] = 1.0

        if feat_dim is None:
            feat_dim = int(feat.shape[1])
            xtx = np.eye(feat_dim, dtype=np.float64) * float(max(1.0e-12, cfg.correction_ridge))
            xty = np.zeros((feat_dim, 2), dtype=np.float64)

        for start in range(0, feat.shape[0], int(cfg.chunk_rows)):
            end = min(feat.shape[0], start + int(cfg.chunk_rows))
            sw = np.sqrt(row_w[start:end]).reshape(-1, 1)
            xw = feat[start:end] * sw
            yw = target[start:end] * sw
            xtx += xw.T @ xw
            xty += xw.T @ yw

        used_years.append(int(target_year))

    if feat_dim is None or xtx is None or xty is None:
        return None

    beta = _safe_solve(xtx, xty)
    return {
        "beta_corr": np.asarray(beta, dtype=np.float64),
        "config": cfg_to_dict(cfg),
        "used_years": used_years,
        "feature_dim": int(feat_dim),
        "correction_cap_az": float(cfg.correction_cap_az),
        "correction_cap_el": float(cfg.correction_cap_el),
    }


def apply_correction(
    model: Dict[str, np.ndarray | float | dict],
    corr_model: Dict[str, np.ndarray | float | list | dict] | None,
    unix: np.ndarray,
    alpha_az: float = 1.0,
    alpha_el: float = 1.0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    base_trig4, base_azel = predict_trig4(model, unix)
    if not corr_model:
        return base_azel.copy(), base_azel.copy(), np.zeros((base_azel.shape[0], 2), dtype=np.float64)

    feat = _build_correction_features(
        model=model,
        unix=unix,
        base_trig4=base_trig4,
        base_azel=base_azel,
    )
    delta = feat @ np.asarray(corr_model["beta_corr"], dtype=np.float64)
    delta[:, 0] = np.clip(
        float(alpha_az) * delta[:, 0],
        -abs(float(corr_model.get("correction_cap_az", 0.80))),
        abs(float(corr_model.get("correction_cap_az", 0.80))),
    )
    delta[:, 1] = np.clip(
        float(alpha_el) * delta[:, 1],
        -abs(float(corr_model.get("correction_cap_el", 0.80))),
        abs(float(corr_model.get("correction_cap_el", 0.80))),
    )

    out = base_azel.copy()
    out[:, 0] = core.wrap360(out[:, 0] + delta[:, 0])
    out[:, 1] = np.clip(out[:, 1] + delta[:, 1], -90.0, 90.0)
    return out, base_azel, delta


def load_saved_model(path, config_dict: Dict[str, int | float | bool]) -> Tuple[Dict[str, np.ndarray | float | dict], Dict[str, np.ndarray | float | list | dict] | None, float, float]:
    z = np.load(path)
    model = {
        "year_center": float(np.asarray(z["year_center"]).reshape(-1)[0]),
        "year_origin": float(np.asarray(z["year_origin"]).reshape(-1)[0]),
        "config": dict(config_dict),
    }
    if "gamma_delta" in z:
        model["gamma_delta"] = np.asarray(z["gamma_delta"], dtype=np.float64)
    elif "beta_trig4" in z:
        model["beta_trig4"] = np.asarray(z["beta_trig4"], dtype=np.float64)
    else:
        raise KeyError("saved sidereal model is missing both gamma_delta and beta_trig4")
    corr = None
    if "beta_corr" in z:
        corr = {
            "beta_corr": np.asarray(z["beta_corr"], dtype=np.float64),
            "config": dict(config_dict),
            "feature_dim": int(np.asarray(z["beta_corr"]).shape[0]),
            "correction_cap_az": float(np.asarray(z["correction_cap_az"]).reshape(-1)[0]) if "correction_cap_az" in z else 0.80,
            "correction_cap_el": float(np.asarray(z["correction_cap_el"]).reshape(-1)[0]) if "correction_cap_el" in z else 0.80,
            "used_years": np.asarray(z["correction_used_years"], dtype=np.int32).tolist() if "correction_used_years" in z else [],
        }
    alpha_az = float(np.asarray(z["alpha_az"]).reshape(-1)[0]) if "alpha_az" in z else 1.0
    alpha_el = float(np.asarray(z["alpha_el"]).reshape(-1)[0]) if "alpha_el" in z else 1.0
    return model, corr, alpha_az, alpha_el


def _fit_linear_multi_target(x: np.ndarray, y: np.ndarray, weight: np.ndarray, ridge: float) -> np.ndarray:
    xx = np.asarray(x, dtype=np.float64)
    yy = np.asarray(y, dtype=np.float64)
    ww = np.asarray(weight, dtype=np.float64).reshape(-1)
    if xx.shape[0] != yy.shape[0] or xx.shape[0] != ww.shape[0]:
        raise ValueError("linear multi-target fit length mismatch")
    ww = np.where(np.isfinite(ww), ww, 0.0)
    if float(np.sum(ww)) <= 0.0:
        ww = np.ones_like(ww, dtype=np.float64)
    sw = np.sqrt(ww).reshape(-1, 1)
    xw = xx * sw
    yw = yy * sw
    xtx = xw.T @ xw
    xtx += np.eye(xtx.shape[0], dtype=np.float64) * float(max(1.0e-12, ridge))
    xty = xw.T @ yw
    return _safe_solve(xtx, xty)


def _build_prev_template(unix_prev: np.ndarray, azel_prev: np.ndarray) -> core.TemplatePack:
    tpl = core.build_azel_template(
        unix=np.asarray(unix_prev, dtype=np.float64),
        azel=np.asarray(azel_prev, dtype=np.float64),
        weight=np.ones((len(unix_prev),), dtype=np.float32),
    )
    slot_w = np.asarray(tpl.slot_weight, dtype=np.float64).reshape(-1)
    valid = slot_w > 0.0
    if slot_w.size == 0 or np.all(valid):
        return tpl
    valid_idx = np.flatnonzero(valid)
    if valid_idx.size == 0:
        return tpl
    all_idx = np.arange(slot_w.shape[0], dtype=np.int32)
    right_pos = np.searchsorted(valid_idx, all_idx, side="left")
    right_pos = np.clip(right_pos, 0, valid_idx.size - 1)
    left_pos = np.clip(right_pos - 1, 0, valid_idx.size - 1)
    left_idx = valid_idx[left_pos]
    right_idx = valid_idx[right_pos]
    choose_right = np.abs(right_idx - all_idx) < np.abs(all_idx - left_idx)
    nearest_idx = np.where(choose_right, right_idx, left_idx).astype(np.int32)

    slot_az = np.asarray(tpl.slot_az_deg, dtype=np.float64).copy()
    slot_el = np.asarray(tpl.slot_el_deg, dtype=np.float64).copy()
    slot_w_filled = slot_w.copy()
    miss = ~valid
    slot_az[miss] = slot_az[nearest_idx[miss]]
    slot_el[miss] = slot_el[nearest_idx[miss]]
    slot_w_filled[miss] = slot_w[nearest_idx[miss]]
    return core.TemplatePack(
        slot_az_deg=slot_az.astype(np.float64),
        slot_el_deg=slot_el.astype(np.float64),
        slot_weight=slot_w_filled.astype(np.float64),
        minute_az_deg=np.asarray(tpl.minute_az_deg, dtype=np.float64),
        minute_el_deg=np.asarray(tpl.minute_el_deg, dtype=np.float64),
        minute_weight=np.asarray(tpl.minute_weight, dtype=np.float64),
    )


def _fit_pair_delta_beta(
    unix_prev: np.ndarray,
    azel_prev: np.ndarray,
    unix_cur: np.ndarray,
    azel_cur: np.ndarray,
    cfg: SiderealCoeffConfig,
    row_weight: np.ndarray | None,
) -> Tuple[np.ndarray, core.TemplatePack]:
    tpl_prev = _build_prev_template(unix_prev, azel_prev)
    base_azel, _ = core.lookup_template_azel(np.asarray(unix_cur, dtype=np.float64), tpl_prev)
    target = np.column_stack(
        [
            hm.angle_diff_deg(np.asarray(azel_cur, dtype=np.float64)[:, 0], base_azel[:, 0]),
            np.asarray(azel_cur, dtype=np.float64)[:, 1] - base_azel[:, 1],
        ]
    ).astype(np.float64)
    x = _build_time_basis(np.asarray(unix_cur, dtype=np.float64), cfg)
    ww = np.asarray(row_weight, dtype=np.float64).reshape(-1) if row_weight is not None else np.ones((x.shape[0],), dtype=np.float64)
    beta = _fit_linear_multi_target(x, target, ww, float(cfg.ridge))
    return np.asarray(beta, dtype=np.float64), tpl_prev


def _predict_pair_delta_from_beta(beta_pair: np.ndarray, unix: np.ndarray, cfg: SiderealCoeffConfig) -> np.ndarray:
    x = _build_time_basis(np.asarray(unix, dtype=np.float64), cfg)
    delta = x @ np.asarray(beta_pair, dtype=np.float64)
    return np.asarray(delta, dtype=np.float64)


def fit_transition_delta_model(
    year_data: Dict[int, Tuple[np.ndarray, np.ndarray]],
    train_years: Iterable[int],
    cfg: SiderealCoeffConfig,
    weight_by_year: Dict[int, np.ndarray] | None = None,
    year_center: float | None = None,
    year_origin: float | None = None,
) -> Dict[str, np.ndarray | float | dict | list]:
    years = sorted(int(y) for y in train_years)
    pair_years = [yy for yy in years if int(yy - 1) in year_data]
    if len(pair_years) < 2:
        raise ValueError("transition delta model requires at least two consecutive-year pairs")
    yc = float(np.mean(pair_years) if year_center is None else year_center)
    yo = float(np.min(pair_years) if year_origin is None else year_origin)

    beta_rows: List[np.ndarray] = []
    pair_weights: List[float] = []
    for cur_year in pair_years:
        unix_prev, azel_prev = year_data[int(cur_year - 1)]
        unix_cur, azel_cur = year_data[int(cur_year)]
        ww = None
        if weight_by_year is not None and int(cur_year) in weight_by_year:
            ww = weight_by_year[int(cur_year)]
        beta_pair, _ = _fit_pair_delta_beta(
            unix_prev=unix_prev,
            azel_prev=azel_prev,
            unix_cur=unix_cur,
            azel_cur=azel_cur,
            cfg=cfg,
            row_weight=ww,
        )
        beta_rows.append(beta_pair.reshape(-1))
        pair_weights.append(float(np.mean(ww)) if ww is not None else 1.0)

    y_pair = np.asarray(pair_years, dtype=np.float64)
    x_year = _build_year_basis(y_pair, year_center=yc, year_origin=yo, cfg=cfg)
    y_beta = np.stack(beta_rows, axis=0).astype(np.float64)
    w_pair = np.asarray(pair_weights, dtype=np.float64)
    gamma = _fit_linear_multi_target(x_year, y_beta, w_pair, float(cfg.ridge))
    return {
        "year_center": float(yc),
        "year_origin": float(yo),
        "gamma_delta": np.asarray(gamma, dtype=np.float64),
        "config": cfg_to_dict(cfg),
        "pair_years": [int(v) for v in pair_years],
    }


def _predict_beta_for_year(
    model: Dict[str, np.ndarray | float | dict | list],
    year_value: float,
) -> np.ndarray:
    cfg = cfg_from_dict(model["config"])
    x_year = _build_year_basis(
        years=np.asarray([float(year_value)], dtype=np.float64),
        year_center=float(model["year_center"]),
        year_origin=float(model["year_origin"]),
        cfg=cfg,
    )
    beta_flat = x_year @ np.asarray(model["gamma_delta"], dtype=np.float64)
    time_dim = _build_time_basis(np.asarray([0.0], dtype=np.float64), cfg).shape[1]
    return np.asarray(beta_flat.reshape(time_dim, 2), dtype=np.float64)


def predict_transition_delta(
    model: Dict[str, np.ndarray | float | dict | list],
    unix: np.ndarray,
) -> np.ndarray:
    cfg = cfg_from_dict(model["config"])
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    years = _compute_local_year_from_unix(u).astype(np.int32)
    out = np.zeros((u.shape[0], 2), dtype=np.float64)
    for yy in sorted({int(v) for v in years.tolist()}):
        mask = years == int(yy)
        if not np.any(mask):
            continue
        beta_pair = _predict_beta_for_year(model, float(yy))
        out[mask] = _predict_pair_delta_from_beta(beta_pair, u[mask], cfg)
    return out


def _build_transition_correction_features(
    tpl_prev: core.TemplatePack,
    model: Dict[str, np.ndarray | float | dict | list],
    unix: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    cfg = cfg_from_dict(model["config"])
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    base_azel, _ = core.lookup_template_azel(u, tpl_prev)
    delta = predict_transition_delta(model, u)
    pred = base_azel.copy()
    pred[:, 0] = core.wrap360(pred[:, 0] + delta[:, 0])
    pred[:, 1] = np.clip(pred[:, 1] + delta[:, 1], -90.0, 90.0)
    feat = np.concatenate(
        [
            _build_time_basis(u, cfg),
            hm.azel_to_trig4(base_azel).astype(np.float64),
            hm.azel_to_trig4(pred).astype(np.float64),
            delta.astype(np.float64),
        ],
        axis=1,
    )
    return feat, base_azel, pred


def fit_transition_correction_model(
    year_data: Dict[int, Tuple[np.ndarray, np.ndarray]],
    ordered_years: Iterable[int],
    cfg: SiderealCoeffConfig,
    weight_by_year: Dict[int, np.ndarray] | None,
    year_center: float,
    year_origin: float,
) -> Dict[str, np.ndarray | float | list | dict] | None:
    years = sorted(int(y) for y in ordered_years)
    min_hist = max(3, int(cfg.min_history_years_for_correction))
    target_years = [yy for yy in years if len([pp for pp in years if pp < yy]) >= min_hist]
    if not target_years:
        return None

    xtx = None
    xty = None
    feat_dim = None
    used_years: List[int] = []
    for target_year in target_years:
        hist_years = [yy for yy in years if yy < int(target_year)]
        if (target_year - 1) not in year_data:
            continue
        base_model = fit_transition_delta_model(
            year_data=year_data,
            train_years=hist_years,
            cfg=cfg,
            weight_by_year=weight_by_year,
            year_center=year_center,
            year_origin=year_origin,
        )
        unix_prev, azel_prev = year_data[int(target_year - 1)]
        unix_cur, true_azel = year_data[int(target_year)]
        tpl_prev = _build_prev_template(unix_prev, azel_prev)
        feat, _, pred = _build_transition_correction_features(tpl_prev, base_model, unix_cur)
        residual = np.column_stack(
            [
                hm.angle_diff_deg(true_azel[:, 0], pred[:, 0]),
                true_azel[:, 1] - pred[:, 1],
            ]
        ).astype(np.float64)
        ww = None
        if weight_by_year is not None and int(target_year) in weight_by_year:
            ww = np.asarray(weight_by_year[int(target_year)], dtype=np.float64).reshape(-1)
        if ww is None or ww.shape[0] != feat.shape[0]:
            ww = np.ones((feat.shape[0],), dtype=np.float64)
        ww = np.where(np.isfinite(ww), ww, 0.0)
        if float(np.sum(ww)) <= 0.0:
            ww[:] = 1.0
        if feat_dim is None:
            feat_dim = int(feat.shape[1])
            xtx = np.eye(feat_dim, dtype=np.float64) * float(max(1.0e-12, cfg.correction_ridge))
            xty = np.zeros((feat_dim, 2), dtype=np.float64)
        sw = np.sqrt(ww).reshape(-1, 1)
        xw = feat * sw
        yw = residual * sw
        xtx += xw.T @ xw
        xty += xw.T @ yw
        used_years.append(int(target_year))

    if feat_dim is None or xtx is None or xty is None:
        return None
    beta = _safe_solve(xtx, xty)
    return {
        "beta_corr": np.asarray(beta, dtype=np.float64),
        "config": cfg_to_dict(cfg),
        "feature_dim": int(feat_dim),
        "correction_cap_az": float(cfg.correction_cap_az),
        "correction_cap_el": float(cfg.correction_cap_el),
        "used_years": used_years,
    }


def apply_transition_delta_model(
    model: Dict[str, np.ndarray | float | dict | list],
    tpl_prev: core.TemplatePack,
    unix: np.ndarray,
    corr_model: Dict[str, np.ndarray | float | list | dict] | None = None,
    alpha_az: float = 1.0,
    alpha_el: float = 1.0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    feat, base_azel, pred = _build_transition_correction_features(tpl_prev, model, unix)
    if not corr_model:
        delta_total = np.column_stack(
            [
                hm.angle_diff_deg(pred[:, 0], base_azel[:, 0]),
                pred[:, 1] - base_azel[:, 1],
            ]
        ).astype(np.float64)
        return pred, base_azel, delta_total

    corr = feat @ np.asarray(corr_model["beta_corr"], dtype=np.float64)
    corr[:, 0] = np.clip(
        float(alpha_az) * corr[:, 0],
        -abs(float(corr_model.get("correction_cap_az", 0.80))),
        abs(float(corr_model.get("correction_cap_az", 0.80))),
    )
    corr[:, 1] = np.clip(
        float(alpha_el) * corr[:, 1],
        -abs(float(corr_model.get("correction_cap_el", 0.80))),
        abs(float(corr_model.get("correction_cap_el", 0.80))),
    )
    out = pred.copy()
    out[:, 0] = core.wrap360(out[:, 0] + corr[:, 0])
    out[:, 1] = np.clip(out[:, 1] + corr[:, 1], -90.0, 90.0)
    delta_total = np.column_stack(
        [
            hm.angle_diff_deg(out[:, 0], base_azel[:, 0]),
            out[:, 1] - base_azel[:, 1],
        ]
    ).astype(np.float64)
    return out, base_azel, delta_total


def tune_correction_alpha(
    true_azel: np.ndarray,
    base_azel: np.ndarray,
    delta_azel: np.ndarray,
    steps: int = 25,
) -> Tuple[float, float]:
    truth = np.asarray(true_azel, dtype=np.float64)
    base = np.asarray(base_azel, dtype=np.float64)
    delta = np.asarray(delta_azel, dtype=np.float64)

    def _score(pred: np.ndarray, col: int) -> float:
        if col == 0:
            err = np.abs(hm.angle_diff_deg(pred[:, 0], truth[:, 0]))
        else:
            err = np.abs(pred[:, 1] - truth[:, 1])
        return float(np.max(err) + 0.25 * np.mean(err))

    alpha_grid = np.linspace(0.0, 1.20, int(max(5, steps)), dtype=np.float64)
    best_az = 1.0
    best_el = 1.0
    best_score_az = float("inf")
    best_score_el = float("inf")

    for aa in alpha_grid:
        pred = base.copy()
        pred[:, 0] = core.wrap360(pred[:, 0] + aa * delta[:, 0])
        sc = _score(pred, 0)
        if sc < best_score_az:
            best_score_az = sc
            best_az = float(aa)

    for aa in alpha_grid:
        pred = base.copy()
        pred[:, 1] = np.clip(pred[:, 1] + aa * delta[:, 1], -90.0, 90.0)
        sc = _score(pred, 1)
        if sc < best_score_el:
            best_score_el = sc
            best_el = float(aa)

    return float(best_az), float(best_el)
