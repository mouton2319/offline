#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡予測【CV残差ターゲット版】の学習スクリプト。

通常版 traj_train.py との違いは「学習ターゲット」だけ(diffで比較しやすいよう別ファイル):
  - 通常版   : 次の移動量 disp[i+1] を直接予測
  - CV残差版 : 等速予測 cv[i](=直近 cv_n 点の平均移動量) からの残差 disp[i+1]-cv[i] を予測
直進では残差≈0となり自動的にCV相当になる。モデルは曲がり/減速だけを学ぶ。
モデル・データセット・特徴量は traj_common.py を共有(通常版と同一)。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\traj_train_cvres.py `
    --data-dir .\\claude_test\\trajectories_full `
    --out-dir .\\claude_test\\artifacts_traj_full_cvres `
    --feature-cols "coast_dist_km,turn_rate" --cv-n-last 6 `
    --epochs 4 --batch-size 256 --max-len 256 --num-workers 8 --scaler-sample 3000 --device cuda
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import asdict
from functools import partial
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from traj_common import (
    TrajConfig, TrajectoryDataset, build_model, fit_stats, list_traj_files,
    cv_disp_from_seq, lonlat_to_disp_km,
)


def collate_cvres(batch, disp_mean, disp_std, feat_mean, feat_std, res_mean, res_std, cv_n):
    """通常版 collate_trajectories との唯一の違い: 目標Yを「移動量」ではなく
    「CV残差 disp[i+1]-cv[i]」にする(cv[i]=直近cv_n点の平均移動量)。"""
    B = len(batch)
    lengths = [b["feats"].shape[0] for b in batch]
    Lmax = max(lengths)
    F = batch[0]["feats"].shape[1]
    X = torch.zeros(B, Lmax, F)
    Y = torch.zeros(B, Lmax, 2)
    valid = torch.zeros(B, Lmax, dtype=torch.bool)
    pad = torch.ones(B, Lmax, dtype=torch.bool)
    rm = torch.tensor(res_mean); rs = torch.tensor(res_std)
    for i, b in enumerate(batch):
        L = b["feats"].shape[0]
        X[i, :L] = b["feats"]
        pad[i, :L] = False
        if L >= 2:
            disp = b["disp"].numpy().astype(np.float64)          # [L,2]
            cv = cv_disp_from_seq(disp, cv_n)                    # [L,2] 各位置の等速予測
            resid = disp[1:L] - cv[:L - 1]                       # [L-1,2] = 目標(CV残差)
            Y[i, :L - 1] = (torch.from_numpy(resid).float() - rm) / rs
            valid[i, :L - 1] = True
    fm = torch.tensor(feat_mean) if feat_mean else None
    fs = torch.tensor(feat_std) if feat_std else None
    if fm is not None and fm.numel() == F:
        X = (X - fm) / fs
        X = X * (~pad).unsqueeze(-1)
    return {"x": X, "y": Y, "valid": valid, "pad": pad}


def fit_res_stats(files, feature_cols, cv_n, sample, seed):
    """CV残差(disp[i+1]-cv[i])の mean/std をサンプル航跡から推定する。"""
    rng = random.Random(seed)
    picks = files if len(files) <= sample else rng.sample(files, sample)
    res_all = []
    for p in picks:
        try:
            df = pd.read_csv(p)
            lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
            lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
        except Exception:
            continue
        disp = lonlat_to_disp_km(lon, lat)
        if len(disp) >= 2:
            cv = cv_disp_from_seq(disp, cv_n)
            res_all.append(disp[1:] - cv[:-1])
    res = np.concatenate(res_all, axis=0) if res_all else np.zeros((1, 2))
    rmean = res.mean(axis=0); rstd = res.std(axis=0)
    rstd = np.where(rstd < 1e-6, 1.0, rstd)
    return rmean, rstd


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="航跡 decoder-only Transformer【CV残差版】を学習する。")
    p.add_argument("--data-dir", required=True, nargs="+", help="航跡別CSVフォルダ(複数指定可: 2016と2017を同時に)")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--pattern", default="MMSI_*_traj_*.csv")
    p.add_argument("--feature-cols", default="")
    p.add_argument("--cv-n-last", type=int, default=6, help="等速(CV)予測に使う直近点数")
    p.add_argument("--limit-files", type=int, default=0)
    p.add_argument("--max-len", type=int, default=256)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--nhead", type=int, default=8)
    p.add_argument("--num-layers", type=int, default=3)
    p.add_argument("--dim-feedforward", type=int, default=256)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--interval-minutes", type=float, default=3.0)
    p.add_argument("--scaler-sample", type=int, default=2000)
    p.add_argument("--num-workers", type=int, default=0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="")
    return p


def main() -> int:
    args = build_parser().parse_args()
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    files = []
    for d in args.data_dir:                       # 複数フォルダ(2016+2017)を結合
        files += list_traj_files(Path(d), args.pattern, 0)
    if args.limit_files and args.limit_files > 0:
        files = files[:args.limit_files]
    if not files:
        raise FileNotFoundError(f"航跡CSVがありません: {args.data_dir} / {args.pattern}")
    feature_cols = [c.strip() for c in (args.feature_cols.split(",") if args.feature_cols else []) if c.strip()]
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)

    print("=" * 80); print("[TRAIN traj_decoder_only_v1  target=CV残差]")
    print(f"data_dir    : {args.data_dir}")
    print(f"trajectories: {len(files):,}")
    print(f"feature_cols: {feature_cols if feature_cols else '(dx,dy のみ)'}")
    print(f"cv_n_last   : {args.cv_n_last}   max_len: {args.max_len}  d_model={args.d_model}"); print("=" * 80)

    print("[1/2] 標準化統計を推定中(disp/feat/CV残差)...")
    disp_mean, disp_std, feat_mean, feat_std = fit_stats(files, feature_cols, args.scaler_sample, args.seed)
    res_mean, res_std = fit_res_stats(files, feature_cols, args.cv_n_last, args.scaler_sample, args.seed)
    input_dim = 2 + len(feature_cols)

    cfg = TrajConfig(
        feature_cols=feature_cols, input_dim=input_dim,
        d_model=args.d_model, nhead=args.nhead, num_layers=args.num_layers,
        dim_feedforward=args.dim_feedforward, dropout=args.dropout, max_len=args.max_len,
        interval_minutes=args.interval_minutes,
        disp_mean=disp_mean.tolist(), disp_std=disp_std.tolist(),
        feat_mean=feat_mean.tolist(), feat_std=feat_std.tolist(),
        target_mode="cv_residual", cv_n_last=args.cv_n_last,
        res_mean=res_mean.tolist(), res_std=res_std.tolist(),
    )

    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    ds = TrajectoryDataset(files, feature_cols, args.max_len, train=True, seed=args.seed)
    collate = partial(collate_cvres, disp_mean=cfg.disp_mean, disp_std=cfg.disp_std,
                      feat_mean=cfg.feat_mean, feat_std=cfg.feat_std,
                      res_mean=cfg.res_mean, res_std=cfg.res_std, cv_n=cfg.cv_n_last)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
                        collate_fn=collate, pin_memory=(device.type == "cuda"), drop_last=False,
                        persistent_workers=(args.num_workers > 0),
                        prefetch_factor=(4 if args.num_workers > 0 else None))
    model = build_model(cfg).to(device)
    print(f"[MODEL] params={sum(p.numel() for p in model.parameters()):,}  input_dim={input_dim}  device={device}")

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    crit = nn.SmoothL1Loss(reduction="none")
    best = float("inf"); best_path = out_dir / "traj_model.pt"
    print("[2/2] 学習...")
    for epoch in range(1, args.epochs + 1):
        model.train(); losses = []
        for batch in loader:
            x = batch["x"].to(device); y = batch["y"].to(device)
            valid = batch["valid"].to(device); pad = batch["pad"].to(device)
            opt.zero_grad(set_to_none=True)
            pred = model(x, pad_mask=pad)
            per = crit(pred, y).sum(dim=-1); m = valid.float()
            loss = (per * m).sum() / m.sum().clamp_min(1.0)
            if not torch.isfinite(loss):
                continue
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip); opt.step()
            losses.append(float(loss.item()))
        tr = float(np.mean(losses)) if losses else float("nan")
        print(f"[EPOCH {epoch:03d}] train_loss(SmoothL1, std-residual)={tr:.6f}")
        if np.isfinite(tr) and tr < best:
            best = tr; torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, best_path)
            print(f"[SAVE] {best_path}  best_train_loss={best:.6f}")
    with (out_dir / "traj_config.json").open("w", encoding="utf-8") as fp:
        json.dump(asdict(cfg), fp, ensure_ascii=False, indent=2)
    print("=" * 80); print(f"[DONE] model={best_path}  best_train_loss={best:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
