import numpy as np, pandas as pd
from collections import defaultdict

H=2


def load_year(y):
    df=pd.read_csv(f'{y}_calc_az_el.csv', usecols=['date','AZ','EL'])
    dt=pd.to_datetime(df['date'])
    df['day_key']=dt.dt.strftime('%m-%d')
    df['minute']=dt.dt.hour*60+dt.dt.minute
    return df

def fit_day(minute, values, H=2):
    t=minute.to_numpy(dtype=float)
    y=values.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/1440.0
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    beta=np.linalg.lstsq(X,y,rcond=None)[0]
    return beta

def eval_day(minute, beta, H=2):
    t=minute.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/1440.0
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    return X@beta

frames={y:load_year(y) for y in range(2017,2025)}
coefs={y:{} for y in range(2017,2025)}
recon_err={}
for y,df in frames.items():
    az_all=[]; el_all=[]; az_true=[]; el_true=[]
    for day,g in df.groupby('day_key'):
        baz=fit_day(g['minute'], g['AZ'], H)
        bel=fit_day(g['minute'], g['EL'], H)
        coefs[y][day]=(baz,bel)
        paz=eval_day(g['minute'], baz, H); pel=eval_day(g['minute'], bel, H)
        az_all.append(np.abs(paz-g['AZ'].to_numpy())); el_all.append(np.abs(pel-g['EL'].to_numpy()))
    az=np.concatenate(az_all); el=np.concatenate(el_all)
    recon_err[y]=(float((az.mean()+el.mean())/2), float(max(az.max(), el.max())))
print('within-day reconstruction errors', recon_err)

truth=frames[2024]
for method in ['repeat','linear_recent4','last_delta','damped_delta']:
    pred_az=[]; pred_el=[]; true_az=[]; true_el=[]
    missing=0
    for day,g in truth.groupby('day_key'):
        hist=[]
        for y in range(2017,2024):
            if day in coefs[y]:
                hist.append((y, coefs[y][day]))
        if not hist:
            missing += len(g)
            continue
        years=np.array([y for y,_ in hist], dtype=float)
        az_mat=np.stack([c[0] for _,c in hist], axis=0)
        el_mat=np.stack([c[1] for _,c in hist], axis=0)
        if method=='repeat':
            b_az=az_mat[-1]; b_el=el_mat[-1]
        elif method=='linear_recent4':
            yrs=years[-4:]; A=np.c_[np.ones_like(yrs), yrs]
            B=np.linalg.lstsq(A, az_mat[-4:], rcond=None)[0]; b_az=np.array([1,2024.0])@B
            B=np.linalg.lstsq(A, el_mat[-4:], rcond=None)[0]; b_el=np.array([1,2024.0])@B
        elif method=='last_delta':
            if len(az_mat)>=2:
                b_az=az_mat[-1] + (az_mat[-1]-az_mat[-2])
                b_el=el_mat[-1] + (el_mat[-1]-el_mat[-2])
            else:
                b_az=az_mat[-1]; b_el=el_mat[-1]
        elif method=='damped_delta':
            if len(az_mat)>=2:
                b_az=az_mat[-1] + 0.25*(az_mat[-1]-az_mat[-2])
                b_el=el_mat[-1] + 0.25*(el_mat[-1]-el_mat[-2])
            else:
                b_az=az_mat[-1]; b_el=el_mat[-1]
        paz=eval_day(g['minute'], b_az, H)
        pel=eval_day(g['minute'], b_el, H)
        pred_az.append(paz); pred_el.append(pel)
        true_az.append(g['AZ'].to_numpy()); true_el.append(g['EL'].to_numpy())
    az=np.abs(np.concatenate(pred_az)-np.concatenate(true_az))
    el=np.abs(np.concatenate(pred_el)-np.concatenate(true_el))
    print(method, 'mean', float((az.mean()+el.mean())/2), 'max', float(max(az.max(), el.max())), 'missing', missing)
