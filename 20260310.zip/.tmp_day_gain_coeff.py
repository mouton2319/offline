import numpy as np, pandas as pd
from collections import defaultdict
H=4

def load_year(y):
    df=pd.read_csv(f'/work/{y}_calc_az_el.csv', usecols=['date','AZ','EL'])
    dt=pd.to_datetime(df['date'])
    df['day_key']=dt.dt.strftime('%m-%d')
    df['minute']=dt.dt.hour*60+dt.dt.minute
    return df

def fit_day(minute, values, H=4):
    t=minute.to_numpy(dtype=float)
    y=values.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/1440.0
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    return np.linalg.lstsq(X,y,rcond=None)[0]

def eval_day(minute, beta, H=4):
    t=minute.to_numpy(dtype=float)
    cols=[np.ones_like(t)]
    for k in range(1,H+1):
        ang=2*np.pi*k*t/1440.0
        cols += [np.sin(ang), np.cos(ang)]
    X=np.column_stack(cols)
    return X@beta

frames={y:load_year(y) for y in range(2017,2025)}
coefs={y:{} for y in range(2017,2025)}
for y,df in frames.items():
    for day,g in df.groupby('day_key'):
        coefs[y][day]=(fit_day(g['minute'], g['AZ'], H), fit_day(g['minute'], g['EL'], H))

def predict_day(day, target):
    hist=[]
    for y in range(2017,target):
        if day in coefs[y]: hist.append((y,coefs[y][day]))
    years=np.array([y for y,_ in hist], dtype=float)
    az_mat=np.stack([c[0] for _,c in hist], axis=0)
    el_mat=np.stack([c[1] for _,c in hist], axis=0)
    yrs=years[-4:] if len(years)>=4 else years
    A=np.c_[np.ones_like(yrs), yrs]
    B=np.linalg.lstsq(A, az_mat[-len(yrs):], rcond=None)[0]; b_az=np.array([1,target])@B
    B=np.linalg.lstsq(A, el_mat[-len(yrs):], rcond=None)[0]; b_el=np.array([1,target])@B
    return b_az,b_el

gains=defaultdict(list)
for target in [2021,2022,2023]:
    cur=frames[target]
    prev=frames[target-1]
    for day,g in cur.groupby('day_key'):
        if day not in coefs[target-1]:
            continue
        b_rep_az,b_rep_el=coefs[target-1][day]
        b_mod_az,b_mod_el=predict_day(day,target)
        rep_az=eval_day(g['minute'], b_rep_az, H); rep_el=eval_day(g['minute'], b_rep_el, H)
        mod_az=eval_day(g['minute'], b_mod_az, H); mod_el=eval_day(g['minute'], b_mod_el, H)
        da_rep=np.abs(rep_az-g['AZ'].to_numpy()); de_rep=np.abs(rep_el-g['EL'].to_numpy())
        da_mod=np.abs(mod_az-g['AZ'].to_numpy()); de_mod=np.abs(mod_el-g['EL'].to_numpy())
        mx_rep=max(da_rep.max(), de_rep.max()); mx_mod=max(da_mod.max(), de_mod.max())
        # gain 1 when consistently better, else 0, with soft fallback
        gains[day].append((mx_rep,mx_mod,float((da_rep.mean()+de_rep.mean())/2), float((da_mod.mean()+de_mod.mean())/2)))

gain_map={}
for d,vals in gains.items():
    better=sum(1 for a,b,_,_ in vals if b<a)
    if better>=2:
        imp=np.median([(a-b)/max(a,1e-9) for a,b,_,_ in vals])
        gain_map[d]=max(0.0, min(1.0, imp))
    else:
        gain_map[d]=0.0

# evaluate 2024
cur=frames[2024]
errs=[]
for day,g in cur.groupby('day_key'):
    if day not in coefs[2023]:
        continue
    b_rep_az,b_rep_el=coefs[2023][day]
    b_mod_az,b_mod_el=predict_day(day,2024)
    rep_az=eval_day(g['minute'], b_rep_az, H); rep_el=eval_day(g['minute'], b_rep_el, H)
    mod_az=eval_day(g['minute'], b_mod_az, H); mod_el=eval_day(g['minute'], b_mod_el, H)
    w=gain_map.get(day,0.0)
    pred_az=(1-w)*rep_az + w*mod_az
    pred_el=(1-w)*rep_el + w*mod_el
    da=np.abs(pred_az-g['AZ'].to_numpy()); de=np.abs(pred_el-g['EL'].to_numpy())
    errs.append((day,w,float((da.mean()+de.mean())/2), float(max(da.max(),de.max()))))
errs=np.array([(m,e,x,y) for m,e,x,y in errs], dtype=object)
print('nonzero gains', sum(1 for v in gain_map.values() if v>0), 'of', len(gain_map))
mx=max(float(r[3]) for r in errs); mean=np.mean([float(r[2]) for r in errs])
print('2024 blend mean', mean, 'max', mx)
worst=sorted(errs, key=lambda r: float(r[3]), reverse=True)[:20]
for r in worst:
    print(r)
