#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡予測【CV残差ターゲット版 + LRスケジュール + 検証ベースcheckpoint選択】の学習スクリプト。

土台は traj_train_cvres.py。diff で変更点が見えるよう別ファイルにし、以下だけを追加:

  (1) LRスケジュール:
      --warmup-steps N(既定500)まで線形warmup、その後 cosine decay で
      最終LR --lr-min(既定 lr の 1/20)へ。**ステップ単位**で更新。
      総ステップ数 = len(loader) * epochs から算出し LambdaLR で自作。

  (2) 検証ベースの checkpoint 選択:
      --val-dir を追加。各エポック終了時に val セットで MAE を計算し、
      **val MAE が最良のエポックの checkpoint を traj_model.pt に保存**。
      全エポックの checkpoint も traj_model_ep{N}.pt として残す(1個 ~18MB)。
      val 評価は eval_batch.py の rollout 関数を import して再利用する
      (visualize と数値一致検証済みのバッチ自己回帰プロトコル)。

  (3) ログに各エポックの train_loss と val MAE を出力。

注意: val 評価は **同一プロセス内**でモデルを eval() にして実施し、終わったら
train() に戻す(DataLoader の persistent_workers と干渉させない)。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\traj_train_cvres_sched.py `
    --data-dir .\\claude_test\\trajectories_full `
    --out-dir .\\claude_test\\artifacts_traj_full_cvres_big8 `
    --val-dir .\\claude_test\\val500 `
    --cv-n-last 6 --max-len 256 --batch-size 256 --num-workers 16 --scaler-sample 3000 `
    --d-model 256 --nhead 8 --num-layers 6 --dim-feedforward 1024 `
    --epochs 8 --device cuda
"""

from __future__ import annotations

import argparse
import json
import math
import random
import sys
from dataclasses import asdict
from functools import partial
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parent))
from traj_common import (   # noqa: E402
    TrajConfig, TrajectoryDataset, build_model, fit_stats, list_traj_files,
    cv_disp_from_seq, lonlat_to_disp_km,
)
# 検証 MAE は eval_batch.py のバッチ自己回帰(visualize と数値一致検証済み)を再利用。
from eval_batch import (   # noqa: E402
    read_traj, classify_regime, batched_rollout_ai, rollout_cv_single,
    haversine_km_arr,
)


# === traj_train_cvres.py と同一(collate / 残差統計) ============================
def collate_cvres(batch, disp_mean, disp_std, feat_mean, feat_std, res_mean, res_std, cv_n):
    """通常版 collate_trajectories との唯一の違い: 目標Yを「移動量」ではなく
    「CV残差 disp[i+1]-cv[i]」にする(cv[i]=直近cv_n点の平均移動量)。"""
    B = len(batch)
    lengths = [b["feats"].shape[0] for b in batch]
    Lmax = max(lengths)
    F = batch[0]["feats"].shape[1]
    X = torch.zeros(B, Lmax, F)
    Y = torch.zeros(B, Lmax, 2)
    valid = torch.zeros(B, Lmax, dtype=torch.bool)
    pad = torch.ones(B, Lmax, dtype=torch.bool)
    rm = torch.tensor(res_mean); rs = torch.tensor(res_std)
    for i, b in enumerate(batch):
        L = b["feats"].shape[0]
        X[i, :L] = b["feats"]
        pad[i, :L] = False
        if L >= 2:
            disp = b["disp"].numpy().astype(np.float64)          # [L,2]
            cv = cv_disp_from_seq(disp, cv_n)                    # [L,2] 各位置の等速予測
            resid = disp[1:L] - cv[:L - 1]                       # [L-1,2] = 目標(CV残差)
            Y[i, :L - 1] = (torch.from_numpy(resid).float() - rm) / rs
            valid[i, :L - 1] = True
    fm = torch.tensor(feat_mean) if feat_mean else None
    fs = torch.tensor(feat_std) if feat_std else None
    if fm is not None and fm.numel() == F:
        X = (X - fm) / fs
        X = X * (~pad).unsqueeze(-1)
    return {"x": X, "y": Y, "valid": valid, "pad": pad}


def fit_res_stats(files, feature_cols, cv_n, sample, seed):
    """CV残差(disp[i+1]-cv[i])の mean/std をサンプル航跡から推定する。"""
    rng = random.Random(seed)
    picks = files if len(files) <= sample else rng.sample(files, sample)
    res_all = []
    for p in picks:
        try:
            df = pd.read_csv(p)
            lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
            lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
        except Exception:
            continue
        disp = lonlat_to_disp_km(lon, lat)
        if len(disp) >= 2:
            cv = cv_disp_from_seq(disp, cv_n)
            res_all.append(disp[1:] - cv[:-1])
    res = np.concatenate(res_all, axis=0) if res_all else np.zeros((1, 2))
    rmean = res.mean(axis=0); rstd = res.std(axis=0)
    rstd = np.where(rstd < 1e-6, 1.0, rstd)
    return rmean, rstd


# === 追加(1) LRスケジュール ====================================================
def make_warmup_cosine_lambda(total_steps: int, warmup_steps: int, lr_min_ratio: float):
    """ステップ数 -> LR倍率 を返す関数(LambdaLR 用)。

    - step < warmup_steps: 0 -> 1.0 へ線形warmup
    - 以降: 1.0 -> lr_min_ratio へ cosine decay(total_steps で lr_min_ratio に到達)
    lr_min_ratio = lr_min / lr(既定 1/20)。
    """
    warmup_steps = max(0, int(warmup_steps))
    total_steps = max(1, int(total_steps))
    decay_steps = max(1, total_steps - warmup_steps)

    def fn(step: int) -> float:
        if warmup_steps > 0 and step < warmup_steps:
            return float(step + 1) / float(warmup_steps)  # 1..warmup で 1.0 に到達
        prog = min(1.0, float(step - warmup_steps) / float(decay_steps))
        cos = 0.5 * (1.0 + math.cos(math.pi * prog))       # 1 -> 0
        return lr_min_ratio + (1.0 - lr_min_ratio) * cos    # 1 -> lr_min_ratio

    return fn


# === 追加(2) 検証 MAE(eval_batch のバッチ自己回帰を同一プロセスで再利用)=====
def evaluate_val_mae(model, cfg, val_files, device, input_len_arg, steps_arg,
                     gpu_batch, stop_gate):
    """val セットの平均 ai_mae(km)を返す。eval_batch.evaluate と同じプロトコル・
    同じ rollout(バッチ自己回帰)。モデルは呼び出し前後で train/eval を管理する。"""
    from collections import defaultdict
    cv_n = int(cfg.cv_n_last)
    stop_thresh_reg = float(getattr(cfg, "stop_thresh_km", 0.0) or 0.03)

    items = []
    for p in val_files:
        lon, lat = read_traj(p)
        n = len(lon)
        input_len = min(int(input_len_arg), n - 1)
        steps = min(int(steps_arg), n - input_len)
        if input_len < 2 or steps < 1:
            continue
        hist_lon, hist_lat = lon[:input_len], lat[:input_len]
        truth_lon = lon[input_len:input_len + steps]
        truth_lat = lat[input_len:input_len + steps]
        disp = lonlat_to_disp_km(hist_lon, hist_lat)
        regime = classify_regime(truth_lon, truth_lat, hist_lon, hist_lat,
                                 stop_thresh=stop_thresh_reg)
        items.append(dict(filename=p.name, input_len=input_len, steps=steps,
                          hist_lon=hist_lon, hist_lat=hist_lat,
                          truth_lon=truth_lon, truth_lat=truth_lat,
                          disp=disp, regime=regime))
    if not items:
        return float("nan"), {}

    # input_len ごとにグループ化してバッチロールアウト。
    pred_map = {}
    groups = defaultdict(list)
    for it in items:
        groups[it["input_len"]].append(it)
    for ilen, grp in groups.items():
        steps_max = max(g["steps"] for g in grp)
        gin = [dict(disp=g["disp"], lon0=float(g["hist_lon"][-1]),
                    lat0=float(g["hist_lat"][-1]), steps=g["steps"]) for g in grp]
        plon, plat = batched_rollout_ai(model, cfg, gin, steps_max, device,
                                        int(gpu_batch), stop_gate)
        for i, g in enumerate(grp):
            s = g["steps"]
            pred_map[g["filename"]] = (plon[i, :s], plat[i, :s])

    ai_maes = []
    cv_maes = []
    reg_ai = defaultdict(list)
    for it in items:
        fn = it["filename"]
        truth_lon, truth_lat = it["truth_lon"], it["truth_lat"]
        ai_lon, ai_lat = pred_map[fn]
        ai_err = haversine_km_arr(ai_lon, ai_lat, truth_lon, truth_lat)
        cv_lon, cv_lat = rollout_cv_single(it["hist_lon"], it["hist_lat"], it["steps"], cv_n)
        cv_err = haversine_km_arr(cv_lon, cv_lat, truth_lon, truth_lat)
        ai_maes.append(float(ai_err.mean()))
        cv_maes.append(float(cv_err.mean()))
        reg_ai[it["regime"]].append(float(ai_err.mean()))
    val_mae = float(np.mean(ai_maes))
    extra = {
        "cv_mae": float(np.mean(cv_maes)),
        "n": len(ai_maes),
        "regime": {k: (float(np.mean(v)), len(v)) for k, v in reg_ai.items()},
    }
    return val_mae, extra


# === CLI =======================================================================
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="航跡 decoder-only Transformer【CV残差版 + LRスケジュール + 検証checkpoint選択】を学習する。")
    p.add_argument("--data-dir", required=True, nargs="+", help="航跡別CSVフォルダ(複数指定可: 2016と2017を同時に)")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--pattern", default="MMSI_*_traj_*.csv")
    p.add_argument("--feature-cols", default="")
    p.add_argument("--cv-n-last", type=int, default=6, help="等速(CV)予測に使う直近点数")
    p.add_argument("--limit-files", type=int, default=0)
    p.add_argument("--max-len", type=int, default=256)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--nhead", type=int, default=8)
    p.add_argument("--num-layers", type=int, default=3)
    p.add_argument("--dim-feedforward", type=int, default=256)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--interval-minutes", type=float, default=3.0)
    p.add_argument("--scaler-sample", type=int, default=2000)
    p.add_argument("--num-workers", type=int, default=0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="")
    # --- 追加(1) LRスケジュール ---
    p.add_argument("--warmup-steps", type=int, default=500, help="線形warmupのステップ数")
    p.add_argument("--lr-min", type=float, default=-1.0,
                   help="cosine decay の最終LR。負なら lr/20 を使う。")
    # --- 追加(2) 検証ベースcheckpoint選択 ---
    p.add_argument("--val-dir", default="", help="検証セット(val500)のフォルダ。指定時は val MAE で checkpoint 選択")
    p.add_argument("--val-pattern", default="*.csv")
    p.add_argument("--val-input-len", type=int, default=80)
    p.add_argument("--val-steps", type=int, default=20)
    p.add_argument("--val-gpu-batch", type=int, default=256)
    p.add_argument("--stop-gate", default="soft", choices=["soft", "hard"],
                   help="停止ゲート版のときの val 評価モード(このスクリプトの既定モデルは非停止なので無関係)")
    return p


def main() -> int:
    args = build_parser().parse_args()
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    files = []
    for d in args.data_dir:                       # 複数フォルダ(2016+2017)を結合
        files += list_traj_files(Path(d), args.pattern, 0)
    if args.limit_files and args.limit_files > 0:
        files = files[:args.limit_files]
    if not files:
        raise FileNotFoundError(f"航跡CSVがありません: {args.data_dir} / {args.pattern}")
    feature_cols = [c.strip() for c in (args.feature_cols.split(",") if args.feature_cols else []) if c.strip()]
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)

    # 検証セット(任意)
    val_files = []
    if args.val_dir:
        val_files = sorted(Path(args.val_dir).glob(args.val_pattern))
        if not val_files:
            print(f"[WARN] val-dir に一致なし: {args.val_dir}/{args.val_pattern}")

    print("=" * 80); print("[TRAIN traj_decoder_only_v1  target=CV残差  +LRsched +val-checkpoint]")
    print(f"data_dir    : {args.data_dir}")
    print(f"trajectories: {len(files):,}")
    print(f"val_dir     : {args.val_dir or '(なし: train_loss で選択)'}   val_files: {len(val_files):,}")
    print(f"feature_cols: {feature_cols if feature_cols else '(dx,dy のみ)'}")
    print(f"cv_n_last   : {args.cv_n_last}   max_len: {args.max_len}  d_model={args.d_model}")
    print(f"epochs={args.epochs}  batch={args.batch_size}  lr={args.lr}  warmup={args.warmup_steps}")
    print("=" * 80)

    print("[1/2] 標準化統計を推定中(disp/feat/CV残差)...")
    disp_mean, disp_std, feat_mean, feat_std = fit_stats(files, feature_cols, args.scaler_sample, args.seed)
    res_mean, res_std = fit_res_stats(files, feature_cols, args.cv_n_last, args.scaler_sample, args.seed)
    input_dim = 2 + len(feature_cols)

    cfg = TrajConfig(
        feature_cols=feature_cols, input_dim=input_dim,
        d_model=args.d_model, nhead=args.nhead, num_layers=args.num_layers,
        dim_feedforward=args.dim_feedforward, dropout=args.dropout, max_len=args.max_len,
        interval_minutes=args.interval_minutes,
        disp_mean=disp_mean.tolist(), disp_std=disp_std.tolist(),
        feat_mean=feat_mean.tolist(), feat_std=feat_std.tolist(),
        target_mode="cv_residual", cv_n_last=args.cv_n_last,
        res_mean=res_mean.tolist(), res_std=res_std.tolist(),
    )

    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    ds = TrajectoryDataset(files, feature_cols, args.max_len, train=True, seed=args.seed)
    collate = partial(collate_cvres, disp_mean=cfg.disp_mean, disp_std=cfg.disp_std,
                      feat_mean=cfg.feat_mean, feat_std=cfg.feat_std,
                      res_mean=cfg.res_mean, res_std=cfg.res_std, cv_n=cfg.cv_n_last)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
                        collate_fn=collate, pin_memory=(device.type == "cuda"), drop_last=False,
                        persistent_workers=(args.num_workers > 0),
                        prefetch_factor=(4 if args.num_workers > 0 else None))
    model = build_model(cfg).to(device)
    print(f"[MODEL] params={sum(p.numel() for p in model.parameters()):,}  input_dim={input_dim}  device={device}")

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    crit = nn.SmoothL1Loss(reduction="none")

    # --- 追加(1) LRスケジュール(ステップ単位) ---
    steps_per_epoch = len(loader)
    total_steps = steps_per_epoch * args.epochs
    lr_min = args.lr_min if args.lr_min >= 0 else (args.lr / 20.0)
    lr_min_ratio = (lr_min / args.lr) if args.lr > 0 else 0.05
    lr_lambda = make_warmup_cosine_lambda(total_steps, args.warmup_steps, lr_min_ratio)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_lambda=lr_lambda)
    print(f"[SCHED] steps/epoch={steps_per_epoch}  total_steps={total_steps}  "
          f"warmup={args.warmup_steps}  lr={args.lr:g} -> lr_min={lr_min:g}(比 {lr_min_ratio:.4f})")

    best_val = float("inf"); best_epoch = -1
    best_path = out_dir / "traj_model.pt"
    history = []   # (epoch, train_loss, val_mae)
    print("[2/2] 学習...")
    for epoch in range(1, args.epochs + 1):
        model.train(); losses = []
        for batch in loader:
            x = batch["x"].to(device); y = batch["y"].to(device)
            valid = batch["valid"].to(device); pad = batch["pad"].to(device)
            opt.zero_grad(set_to_none=True)
            pred = model(x, pad_mask=pad)
            per = crit(pred, y).sum(dim=-1); m = valid.float()
            loss = (per * m).sum() / m.sum().clamp_min(1.0)
            if not torch.isfinite(loss):
                sched.step()   # ステップ数の整合は保つ
                continue
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip); opt.step()
            sched.step()       # --- ステップ単位でLR更新 ---
            losses.append(float(loss.item()))
        tr = float(np.mean(losses)) if losses else float("nan")
        cur_lr = opt.param_groups[0]["lr"]

        # 各エポックの checkpoint を残す。
        ep_path = out_dir / f"traj_model_ep{epoch}.pt"
        torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, ep_path)

        # --- 追加(2) 検証ベース選択 ---
        if val_files:
            model.eval()
            val_mae, extra = evaluate_val_mae(
                model, cfg, val_files, device,
                args.val_input_len, args.val_steps, args.val_gpu_batch, args.stop_gate)
            model.train()   # 学習に戻す(DataLoader worker とは無関係)
            reg = extra.get("regime", {})
            reg_s = "  ".join(f"{k}={v[0]:.3f}(N{v[1]})" for k, v in sorted(reg.items()))
            print(f"[EPOCH {epoch:03d}] train_loss={tr:.6f}  lr={cur_lr:.3e}  "
                  f"val_MAE={val_mae:.4f}km  (val_CV={extra.get('cv_mae', float('nan')):.4f}, "
                  f"N={extra.get('n', 0)})  [{reg_s}]")
            history.append((epoch, tr, val_mae))
            if np.isfinite(val_mae) and val_mae < best_val:
                best_val = val_mae; best_epoch = epoch
                torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, best_path)
                print(f"[SAVE] {best_path}  best_val_MAE={best_val:.4f}km (ep{best_epoch})")
        else:
            # val 無し: train_loss で選択(従来動作の互換)。
            print(f"[EPOCH {epoch:03d}] train_loss={tr:.6f}  lr={cur_lr:.3e}")
            history.append((epoch, tr, float("nan")))
            if np.isfinite(tr) and tr < best_val:
                best_val = tr; best_epoch = epoch
                torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, best_path)
                print(f"[SAVE] {best_path}  best_train_loss={best_val:.6f}")

    with (out_dir / "traj_config.json").open("w", encoding="utf-8") as fp:
        json.dump(asdict(cfg), fp, ensure_ascii=False, indent=2)

    # エポック別サマリ(train_loss / val MAE)を JSON でも残す。
    with (out_dir / "train_history.json").open("w", encoding="utf-8") as fp:
        json.dump({
            "history": [{"epoch": e, "train_loss": t, "val_mae": v} for (e, t, v) in history],
            "best_epoch": best_epoch, "best_val": best_val,
            "selection": ("val_mae" if val_files else "train_loss"),
        }, fp, ensure_ascii=False, indent=2)

    print("=" * 80)
    print("[SUMMARY] epoch  train_loss   val_MAE(km)")
    for (e, t, v) in history:
        mark = "  <== 選択" if e == best_epoch else ""
        print(f"          {e:5d}  {t:10.6f}   {v:8.4f}{mark}")
    tag = "val_MAE" if val_files else "train_loss"
    print(f"[DONE] model={best_path}  best_epoch={best_epoch}  best_{tag}={best_val:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
