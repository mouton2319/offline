import numpy as np
import ufo4_orbit_predict_tf as core
import ufo4_harmonic_azel_tf as hm

def load(y):
    u,f=core.load_orbit_numeric_full(f'{y}_calc_az_el.csv')
    return u.astype(np.float64), f[:,3:5].astype(np.float64)

def align_prev_to_cur(prev_u, prev_a, cur_u):
    tpl=core.build_azel_template(prev_u, prev_a, np.ones((len(prev_u),),dtype=np.float32))
    base,_=core.lookup_template_azel(cur_u, tpl)
    return base

years={y:load(y) for y in range(2021,2025)}
base23=align_prev_to_cur(*years[2022], years[2023][0])
d23=np.column_stack([hm.angle_diff_deg(years[2023][1][:,0], base23[:,0]), years[2023][1][:,1]-base23[:,1]])
base24=align_prev_to_cur(*years[2023], years[2024][0])
truth=years[2024][1]
n=min(len(base24), len(d23))
base24=base24[:n]; truth=truth[:n]; d23=d23[:n]
best=None
for alpha in np.linspace(0,1.2,25):
    pred=base24.copy(); pred[:,0]=core.wrap360(pred[:,0]+alpha*d23[:,0]); pred[:,1]=np.clip(pred[:,1]+alpha*d23[:,1], -90, 90)
    az=np.abs(hm.angle_diff_deg(pred[:,0], truth[:,0])); el=np.abs(pred[:,1]-truth[:,1])
    s=(az.mean()+el.mean())/2; mx=max(az.max(), el.max())
    if best is None or mx<best[1]: best=(alpha,mx,s)
    print('alpha',alpha,'mean',s,'max',mx)
print('best',best)
