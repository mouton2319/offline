import numpy as np
from pathlib import Path
import ufo4_orbit_predict_tf as core
import ufo4_harmonic_azel_tf as hm

truth_unix, truth_full = core.load_orbit_numeric_full(Path('2024_calc_az_el.csv'))
truth_azel = truth_full[:,3:5].astype(np.float64)
pred = np.zeros_like(truth_azel)
tle_list = core.collect_tle_files(Path('23467_2024'))
print('tle count', len(tle_list))
for i, (epoch, path) in enumerate(tle_list):
    if i + 1 < len(tle_list):
        mask = (truth_unix >= float(epoch)) & (truth_unix < float(tle_list[i+1][0]))
    else:
        mask = truth_unix >= float(epoch)
    if not np.any(mask):
        continue
    idx=np.where(mask)[0]
    pred[idx] = core.propagate_tle_azel_at_unix(path, '23467', 36.3022, 137.9031, truth_unix[idx])
az=np.abs(hm.angle_diff_deg(pred[:,0], truth_azel[:,0]))
el=np.abs(pred[:,1]-truth_azel[:,1])
print('rows', len(pred))
print('mae', float((az.mean()+el.mean())/2))
print('max', float(max(az.max(), el.max())))
print('bad idx count', int(np.sum((az>0.1)|(el>0.1))))
print('first 5 bad', np.where((az>0.1)|(el>0.1))[0][:5])
