#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
航跡予測【CV残差+停止ゲート版】の学習スクリプト。

CV残差版 traj_train_cvres.py との違い(diffで比較しやすいよう別ファイル):
  - ヘッド出力を3ch (残差dx, 残差dy, 停止logit) にする
  - 「停止」= 次ステップの移動量 |disp[i+1]| < stop_thresh_km (既定0.03km/3分 ≈ 0.6km/h)
  - 損失 = SmoothL1(残差; 移動中の位置のみ) + w * BCE(停止logit; 全教師位置)
    残差の標準化統計も「移動中」のみから推定する(停止時の巨大なCV打ち消し残差で
    stdが膨らむのを防ぐ)
推論の復元式: dxy = (1 - sigmoid(停止logit)) * (cv + 残差)。
急停止時にCV外挿を即座に減衰させる(等速平均のcv_nステップ減衰待ちを不要にする)のが狙い。
モデル・データセット・特徴量は traj_common.py を共有。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\\src\\traj_train_cvres_stop.py `
    --data-dir .\\claude_test\\trajectories_full `
    --out-dir .\\claude_test\\artifacts_traj_full_cvres_stop `
    --cv-n-last 6 --epochs 4 --batch-size 512 --max-len 256 --num-workers 16 --scaler-sample 3000 --device cuda
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import asdict
from functools import partial
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from traj_common import (
    TrajConfig, TrajectoryDataset, build_model, fit_stats, list_traj_files,
    cv_disp_from_seq, lonlat_to_disp_km,
)


def collate_cvres_stop(batch, disp_mean, disp_std, feat_mean, feat_std, res_mean, res_std, cv_n, stop_thresh):
    """CV残差版 collate_cvres との違い: 目標Yを3chにし、停止ラベルと移動マスクを追加する。
    Y[..., :2] = 標準化したCV残差, Y[..., 2] = 停止ラベル(0/1)。
    move = 教師あり かつ 次ステップが移動中(残差損失はここだけに掛ける)。"""
    B = len(batch)
    lengths = [b["feats"].shape[0] for b in batch]
    Lmax = max(lengths)
    F = batch[0]["feats"].shape[1]
    X = torch.zeros(B, Lmax, F)
    Y = torch.zeros(B, Lmax, 3)
    valid = torch.zeros(B, Lmax, dtype=torch.bool)
    move = torch.zeros(B, Lmax, dtype=torch.bool)
    pad = torch.ones(B, Lmax, dtype=torch.bool)
    rm = torch.tensor(res_mean); rs = torch.tensor(res_std)
    for i, b in enumerate(batch):
        L = b["feats"].shape[0]
        X[i, :L] = b["feats"]
        pad[i, :L] = False
        if L >= 2:
            disp = b["disp"].numpy().astype(np.float64)          # [L,2]
            cv = cv_disp_from_seq(disp, cv_n)                    # [L,2] 各位置の等速予測
            resid = disp[1:L] - cv[:L - 1]                       # [L-1,2] = 目標(CV残差)
            stop = np.linalg.norm(disp[1:L], axis=1) < stop_thresh   # [L-1] 次ステップが停止か
            Y[i, :L - 1, :2] = (torch.from_numpy(resid).float() - rm) / rs
            Y[i, :L - 1, 2] = torch.from_numpy(stop.astype(np.float32))
            valid[i, :L - 1] = True
            move[i, :L - 1] = torch.from_numpy(~stop)
    fm = torch.tensor(feat_mean) if feat_mean else None
    fs = torch.tensor(feat_std) if feat_std else None
    if fm is not None and fm.numel() == F:
        X = (X - fm) / fs
        X = X * (~pad).unsqueeze(-1)
    return {"x": X, "y": Y, "valid": valid, "move": move, "pad": pad}


def fit_res_stats_moving(files, feature_cols, cv_n, stop_thresh, sample, seed):
    """CV残差(disp[i+1]-cv[i])の mean/std を「移動中」の教師位置だけから推定する。
    あわせて停止ラベルの比率も返す(クラス不均衡の確認用)。"""
    rng = random.Random(seed)
    picks = files if len(files) <= sample else rng.sample(files, sample)
    res_all = []
    n_stop = 0; n_all = 0
    for p in picks:
        try:
            df = pd.read_csv(p)
            lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
            lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
        except Exception:
            continue
        disp = lonlat_to_disp_km(lon, lat)
        if len(disp) >= 2:
            cv = cv_disp_from_seq(disp, cv_n)
            resid = disp[1:] - cv[:-1]
            stop = np.linalg.norm(disp[1:], axis=1) < stop_thresh
            n_stop += int(stop.sum()); n_all += len(stop)
            if (~stop).any():
                res_all.append(resid[~stop])
    res = np.concatenate(res_all, axis=0) if res_all else np.zeros((1, 2))
    rmean = res.mean(axis=0); rstd = res.std(axis=0)
    rstd = np.where(rstd < 1e-6, 1.0, rstd)
    stop_ratio = (n_stop / n_all) if n_all else 0.0
    return rmean, rstd, stop_ratio


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="航跡 decoder-only Transformer【CV残差+停止ゲート版】を学習する。")
    p.add_argument("--data-dir", required=True, nargs="+", help="航跡別CSVフォルダ(複数指定可: 2016と2017を同時に)")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--pattern", default="MMSI_*_traj_*.csv")
    p.add_argument("--feature-cols", default="")
    p.add_argument("--cv-n-last", type=int, default=6, help="等速(CV)予測に使う直近点数")
    p.add_argument("--stop-thresh-km", type=float, default=0.03, help="次ステップ移動量がこの値未満なら「停止」(km/step)")
    p.add_argument("--stop-loss-weight", type=float, default=1.0, help="停止BCE損失の重み")
    p.add_argument("--limit-files", type=int, default=0)
    p.add_argument("--max-len", type=int, default=256)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--nhead", type=int, default=8)
    p.add_argument("--num-layers", type=int, default=3)
    p.add_argument("--dim-feedforward", type=int, default=256)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--interval-minutes", type=float, default=3.0)
    p.add_argument("--scaler-sample", type=int, default=2000)
    p.add_argument("--num-workers", type=int, default=0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="")
    return p


def main() -> int:
    args = build_parser().parse_args()
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    files = []
    for d in args.data_dir:                       # 複数フォルダ(2016+2017)を結合
        files += list_traj_files(Path(d), args.pattern, 0)
    if args.limit_files and args.limit_files > 0:
        files = files[:args.limit_files]
    if not files:
        raise FileNotFoundError(f"航跡CSVがありません: {args.data_dir} / {args.pattern}")
    feature_cols = [c.strip() for c in (args.feature_cols.split(",") if args.feature_cols else []) if c.strip()]
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)

    print("=" * 80); print("[TRAIN traj_decoder_only_v1  target=CV残差+停止ゲート]")
    print(f"data_dir    : {args.data_dir}")
    print(f"trajectories: {len(files):,}")
    print(f"feature_cols: {feature_cols if feature_cols else '(dx,dy のみ)'}")
    print(f"cv_n_last   : {args.cv_n_last}   stop_thresh: {args.stop_thresh_km} km/step   max_len: {args.max_len}  d_model={args.d_model}"); print("=" * 80)

    print("[1/2] 標準化統計を推定中(disp/feat/CV残差[移動中のみ])...")
    disp_mean, disp_std, feat_mean, feat_std = fit_stats(files, feature_cols, args.scaler_sample, args.seed)
    res_mean, res_std, stop_ratio = fit_res_stats_moving(
        files, feature_cols, args.cv_n_last, args.stop_thresh_km, args.scaler_sample, args.seed)
    print(f"[STATS] 停止ラベル比率(サンプル)={stop_ratio:.3f}  res_std={np.round(res_std, 4).tolist()}")
    input_dim = 2 + len(feature_cols)

    cfg = TrajConfig(
        feature_cols=feature_cols, input_dim=input_dim,
        d_model=args.d_model, nhead=args.nhead, num_layers=args.num_layers,
        dim_feedforward=args.dim_feedforward, dropout=args.dropout, max_len=args.max_len,
        interval_minutes=args.interval_minutes,
        disp_mean=disp_mean.tolist(), disp_std=disp_std.tolist(),
        feat_mean=feat_mean.tolist(), feat_std=feat_std.tolist(),
        target_mode="cv_residual_stop", cv_n_last=args.cv_n_last,
        res_mean=res_mean.tolist(), res_std=res_std.tolist(),
        out_dim=3, stop_thresh_km=args.stop_thresh_km,
    )

    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    ds = TrajectoryDataset(files, feature_cols, args.max_len, train=True, seed=args.seed)
    collate = partial(collate_cvres_stop, disp_mean=cfg.disp_mean, disp_std=cfg.disp_std,
                      feat_mean=cfg.feat_mean, feat_std=cfg.feat_std,
                      res_mean=cfg.res_mean, res_std=cfg.res_std, cv_n=cfg.cv_n_last,
                      stop_thresh=cfg.stop_thresh_km)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
                        collate_fn=collate, pin_memory=(device.type == "cuda"), drop_last=False,
                        persistent_workers=(args.num_workers > 0),
                        prefetch_factor=(4 if args.num_workers > 0 else None))
    model = build_model(cfg).to(device)
    print(f"[MODEL] params={sum(p.numel() for p in model.parameters()):,}  input_dim={input_dim}  out_dim=3  device={device}")

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    crit = nn.SmoothL1Loss(reduction="none")
    bce = nn.BCEWithLogitsLoss(reduction="none")
    best = float("inf"); best_path = out_dir / "traj_model.pt"
    print("[2/2] 学習...")
    for epoch in range(1, args.epochs + 1):
        model.train(); losses = []; res_losses = []; stop_losses = []
        for batch in loader:
            x = batch["x"].to(device); y = batch["y"].to(device)
            valid = batch["valid"].to(device); move = batch["move"].to(device)
            pad = batch["pad"].to(device)
            opt.zero_grad(set_to_none=True)
            pred = model(x, pad_mask=pad)                               # [B,L,3]
            per = crit(pred[..., :2], y[..., :2]).sum(dim=-1)
            mm = move.float()
            res_loss = (per * mm).sum() / mm.sum().clamp_min(1.0)       # 残差: 移動中のみ
            sb = bce(pred[..., 2], y[..., 2])
            vm = valid.float()
            stop_loss = (sb * vm).sum() / vm.sum().clamp_min(1.0)       # 停止: 全教師位置
            loss = res_loss + args.stop_loss_weight * stop_loss
            if not torch.isfinite(loss):
                continue
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip); opt.step()
            losses.append(float(loss.item()))
            res_losses.append(float(res_loss.item())); stop_losses.append(float(stop_loss.item()))
        tr = float(np.mean(losses)) if losses else float("nan")
        rl = float(np.mean(res_losses)) if res_losses else float("nan")
        sl = float(np.mean(stop_losses)) if stop_losses else float("nan")
        print(f"[EPOCH {epoch:03d}] train_loss={tr:.6f}  (res={rl:.6f}  stop_bce={sl:.6f})")
        if np.isfinite(tr) and tr < best:
            best = tr; torch.save({"state_dict": model.state_dict(), "cfg": asdict(cfg)}, best_path)
            print(f"[SAVE] {best_path}  best_train_loss={best:.6f}")
    with (out_dir / "traj_config.json").open("w", encoding="utf-8") as fp:
        json.dump(asdict(cfg), fp, ensure_ascii=False, indent=2)
    print("=" * 80); print(f"[DONE] model={best_path}  best_train_loss={best:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
