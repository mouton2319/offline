#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
eval_batch.py — モデル1つを多数の航跡で高速評価する(バッチ自己回帰)。

プロトコルは visualize_trajectory_prediction.py と同一:
  各航跡の先頭 input_len=80 点を入力、次の steps=20 点を予測し実測と比較。
  可変 steps: steps = min(steps, n - input_len)、input_len = min(input_len, n-1)。

高速化: 全航跡が同じ input_len ならロールアウトのコンテキスト長が揃うので、
複数航跡を [B, ctx, F] にまとめて1ステップずつ同時に前進させる。
input_len が異なる航跡はグループ分けし、各グループを個別にバッチ処理する。

復元式は traj_common の cfg.target_mode で分岐し、visualize の rollout_ai と厳密に一致:
  - "disp":              dxy = nxt*disp_std + disp_mean
  - "cv_residual":       dxy = cv + (nxt*res_std + res_mean)  (cv=直近cv_n_last点平均)
  - "cv_residual_stop":  p=sigmoid(logit)。soft→dxy=(1-p)*(cv+res) / hard→p>0.5でdxy=0

CVベースライン(--model CV)はモデル無しで等速外挿(直近 cv_n_last 点平均)。

サブコマンド compare: 2つの結果CSVで ai_mae のペア差を統計検定。

実行例(PowerShell):
  $env:PYTHONUTF8='1'
  python .\src\eval_batch.py `
    --model .\claude_test\artifacts_traj_full_cvres_stop\traj_model.pt `
    --data-dir .\claude_test\holdout10 --stop-gate hard `
    --out-csv .\claude_test\eval_results\check.csv --device cuda
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from traj_common import (   # noqa: E402
    load_model, lonlat_to_disp_km, km_per_deg_lon, KM_PER_DEG_LAT,
    cv_disp_from_seq,
)


# ---------------------------------------------------------------------------
# 誤差(visualize と同一の haversine)
# ---------------------------------------------------------------------------
def haversine_km_arr(lon1, lat1, lon2, lat2) -> np.ndarray:
    """2点間の球面距離(km)。配列対応。visualize_trajectory_prediction.py と同式。"""
    R = 6371.0088
    lon1, lat1, lon2, lat2 = map(lambda a: np.radians(np.asarray(a, dtype=np.float64)),
                                 (lon1, lat1, lon2, lat2))
    dlon, dlat = lon2 - lon1, lat2 - lat1
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return 2.0 * R * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def _km_per_deg_lon_arr(lat: np.ndarray) -> np.ndarray:
    """緯度配列に対する経度1度あたりkm(km_per_deg_lon のベクトル版、下限も一致)。"""
    from traj_common import KM_PER_DEG_LON_AT_EQUATOR
    return np.maximum(KM_PER_DEG_LON_AT_EQUATOR * np.cos(np.radians(lat)), 1e-6)


# ---------------------------------------------------------------------------
# 航跡CSVの読み込み(visualize と同じソート)
# ---------------------------------------------------------------------------
def read_traj(path: Path):
    """1航跡CSVを読み lon/lat(float64) を返す。unix_time/timestamp でソート。"""
    df = pd.read_csv(path, usecols=lambda c: c in ("lon", "lat", "unix_time", "timestamp"))
    if "unix_time" in df.columns:
        df = df.sort_values("unix_time").reset_index(drop=True)
    elif "timestamp" in df.columns:
        df = (df.assign(_t=pd.to_datetime(df["timestamp"], utc=True, errors="coerce"))
                .sort_values("_t").reset_index(drop=True))
    lon = pd.to_numeric(df["lon"], errors="coerce").to_numpy(dtype=np.float64)
    lat = pd.to_numeric(df["lat"], errors="coerce").to_numpy(dtype=np.float64)
    return lon, lat


# ---------------------------------------------------------------------------
# レジーム分類(truth のみから計算、モデル出力に依存しない)
# ---------------------------------------------------------------------------
def classify_regime(truth_lon: np.ndarray, truth_lat: np.ndarray,
                    hist_lon: np.ndarray, hist_lat: np.ndarray,
                    stop_thresh: float = 0.03, turn_deg: float = 60.0) -> str:
    """実測の未来20点を運動学で分類する。
      stop_seg: 未来点の各ステップ移動量 |disp|<stop_thresh km/step が3点以上
      turn:     stop_segでなく、未来点の方位変化合計の絶対値が turn_deg 以上
      cruise:   それ以外
    移動量は「直前点(=履歴末尾) -> 未来点1 -> ... 」の連続差分から求める(実測ベース)。
    """
    # 履歴末尾を起点に未来点を連結して、各未来ステップの移動量を得る。
    lon = np.concatenate([hist_lon[-1:], truth_lon])
    lat = np.concatenate([hist_lat[-1:], truth_lat])
    disp = lonlat_to_disp_km(lon, lat)[1:]     # 未来各ステップの移動量 [S,2](先頭0を除く)
    if len(disp) == 0:
        return "cruise"
    speed = np.hypot(disp[:, 0], disp[:, 1])   # km/step
    n_stop = int(np.sum(speed < stop_thresh))
    if n_stop >= 3:
        return "stop_seg"
    # 方位変化合計(移動している点のみで方位を定義)
    heading = np.arctan2(disp[:, 0], disp[:, 1])   # 北=0, 東=+
    if len(heading) >= 2:
        dh = np.diff(heading)
        dh = np.arctan2(np.sin(dh), np.cos(dh))     # [-pi,pi]
        total_turn_deg = abs(np.degrees(np.sum(dh)))
    else:
        total_turn_deg = 0.0
    if total_turn_deg >= turn_deg:
        return "turn"
    return "cruise"


# ---------------------------------------------------------------------------
# CVベースラインのロールアウト(visualize.rollout_cv と同一、バッチ版)
# ---------------------------------------------------------------------------
def rollout_cv_single(hist_lon, hist_lat, steps, n_last):
    """等速直線(CV)ベースライン(visualize.rollout_cv と厳密に同一)。"""
    disp = lonlat_to_disp_km(hist_lon, hist_lat)
    if len(disp) < 2:
        return (np.full(steps, hist_lon[-1]), np.full(steps, hist_lat[-1]))
    n = max(1, min(int(n_last), len(disp) - 1))
    v = disp[-n:].mean(axis=0)
    cur_lon, cur_lat = float(hist_lon[-1]), float(hist_lat[-1])
    out_lon, out_lat = [], []
    for _ in range(int(steps)):
        cur_lon = cur_lon + v[0] / km_per_deg_lon(cur_lat)
        cur_lat = cur_lat + v[1] / KM_PER_DEG_LAT
        out_lon.append(cur_lon); out_lat.append(cur_lat)
    return np.asarray(out_lon), np.asarray(out_lat)


# ---------------------------------------------------------------------------
# バッチ自己回帰(AIモデル)
# ---------------------------------------------------------------------------
def batched_rollout_ai(model, cfg, group, steps_max, device, gpu_batch, stop_gate):
    """input_len が揃った航跡群(group)をバッチで自己回帰予測する。

    group[i] = dict(disp=[P,2](履歴の移動量), lon0, lat0, steps)
    すべて同じ P(=len(disp))を持つ前提(呼び出し側で input_len ごとに分割済み)。
    返り値: pred_lon[i], pred_lat[i] (各 [steps_max])。
    各航跡の有効ステップは group[i]["steps"](steps_max 以下)。
    """
    import torch
    mode = getattr(cfg, "target_mode", "disp")
    max_ctx = int(cfg.max_len)
    cv_n = int(cfg.cv_n_last)
    dm = np.asarray(cfg.disp_mean, dtype=np.float64)
    ds = np.asarray(cfg.disp_std, dtype=np.float64)
    fm = np.asarray(cfg.feat_mean, dtype=np.float64)
    fs = np.asarray(cfg.feat_std, dtype=np.float64)
    res_mean = np.asarray(cfg.res_mean, dtype=np.float64)
    res_std = np.asarray(cfg.res_std, dtype=np.float64)

    B = len(group)
    P = group[0]["disp"].shape[0]
    # seq_disp: [B, cur_len, 2] を numpy で保持(各ステップで末尾に追記)
    seq = np.stack([g["disp"] for g in group], axis=0).astype(np.float64)  # [B, P, 2]
    cur_lon = np.array([g["lon0"] for g in group], dtype=np.float64)       # 各航跡の現在地
    cur_lat = np.array([g["lat0"] for g in group], dtype=np.float64)
    out_lon = np.zeros((B, steps_max), dtype=np.float64)
    out_lat = np.zeros((B, steps_max), dtype=np.float64)

    model.eval()
    with torch.no_grad():
        for t in range(steps_max):
            cur_len = seq.shape[1]
            ctx = min(cur_len, max_ctx)
            ctx_disp = seq[:, cur_len - ctx:, :]          # [B, ctx, 2]
            # 標準化(feature_cols=[] 前提: 特徴は dx,dy のみ)
            x = (ctx_disp - fm) / fs                       # fm/fs は2次元(dx,dy)
            # GPUバッチはチャンク分割
            nxt = np.zeros((B, int(getattr(cfg, "out_dim", 2) or 2)), dtype=np.float64)
            for s in range(0, B, gpu_batch):
                e = min(B, s + gpu_batch)
                xt = torch.from_numpy(x[s:e].astype(np.float32)).to(device)   # [b, ctx, F]
                pad = torch.zeros(xt.shape[0], ctx, dtype=torch.bool, device=device)
                out = model(xt, pad_mask=pad)[:, -1].cpu().numpy()            # [b, out_dim]
                nxt[s:e, :out.shape[1]] = out

            # 復元(mode 別、rollout_ai と厳密に同一の数式)
            if mode == "cv_residual":
                residual = nxt[:, :2] * res_std + res_mean
                cv = seq[:, -cv_n:, :].mean(axis=1)         # 直近 cv_n 点平均 [B,2]
                dxy = cv + residual
            elif mode == "cv_residual_stop":
                residual = nxt[:, :2] * res_std + res_mean
                p_stop = 1.0 / (1.0 + np.exp(-nxt[:, 2]))    # [B]
                cv = seq[:, -cv_n:, :].mean(axis=1)          # [B,2]
                if stop_gate == "hard":
                    dxy = np.where((p_stop > 0.5)[:, None], 0.0, cv + residual)
                else:  # soft
                    dxy = (1.0 - p_stop)[:, None] * (cv + residual)
            else:  # disp
                dxy = nxt[:, :2] * ds + dm

            # lon/lat 更新(現在 lat の km_per_deg_lon を使う: rollout_ai と一致)
            new_lon = cur_lon + dxy[:, 0] / _km_per_deg_lon_arr(cur_lat)
            new_lat = cur_lat + dxy[:, 1] / KM_PER_DEG_LAT
            out_lon[:, t] = new_lon
            out_lat[:, t] = new_lat
            # seq に今ステップの移動量を追記
            seq = np.concatenate([seq, dxy[:, None, :]], axis=1)
            cur_lon, cur_lat = new_lon, new_lat
    return out_lon, out_lat


# ---------------------------------------------------------------------------
# multi-horizon 直接予測(target_mode="cv_residual_mh")
# ロールアウト不要: 入力履歴の1回のforwardで最終位置の [H,2] を得て20点を復元する。
# ---------------------------------------------------------------------------
def _predict_mh_cum(model, cfg, group, device, gpu_batch):
    """1モデルで multi-horizon の「起点からの累積変位 cum [B,H,2](km)」を返す。

    cum[b,h] = h*cv_last[b] + (out[b,h]*mh_res_std[h] + mh_res_mean[h])
    位置(lon/lat)への変換は行わない。アンサンブルでは物理量(cum)を
    モデル間で平均してから位置に変換するため、この段を分離している。
    """
    import torch
    max_ctx = int(cfg.max_len)
    cv_n = int(cfg.cv_n_last)
    H = int(getattr(cfg, "horizon", 20))
    fm = np.asarray(cfg.feat_mean, dtype=np.float64)
    fs = np.asarray(cfg.feat_std, dtype=np.float64)
    mh_mean = np.asarray(cfg.mh_res_mean, dtype=np.float64)   # [H,2]
    mh_std = np.asarray(cfg.mh_res_std, dtype=np.float64)     # [H,2]

    B = len(group)
    seq = np.stack([g["disp"] for g in group], axis=0).astype(np.float64)  # [B, P, 2]
    P = seq.shape[1]
    ctx = min(P, max_ctx)
    ctx_disp = seq[:, P - ctx:, :]                            # [B, ctx, 2]
    x = (ctx_disp - fm) / fs                                  # 標準化(dx,dy のみ)

    # 直近 cv_n 点の平均移動量(1歩あたりのCV速度)
    # cfg.cv_n_last==0 は「アンカー無し変種」: CV項ゼロ。seq[:, -0:] は空でなく全体
    # スライスになる事故を避け、明示ゼロ [B,2] を使う(復元は residual のみ)。
    if cv_n <= 0:
        cv_last = np.zeros((B, 2), dtype=np.float64)          # [B,2] アンカー無し
    else:
        cv_last = seq[:, -cv_n:, :].mean(axis=1)              # [B,2]

    out = np.zeros((B, H, 2), dtype=np.float64)
    model.eval()
    with torch.no_grad():
        for s in range(0, B, gpu_batch):
            e = min(B, s + gpu_batch)
            xt = torch.from_numpy(x[s:e].astype(np.float32)).to(device)   # [b, ctx, F]
            pad = torch.zeros(xt.shape[0], ctx, dtype=torch.bool, device=device)
            o = model(xt, pad_mask=pad)[:, -1].cpu().numpy()              # [b, 2*H]
            out[s:e] = o.reshape(e - s, H, 2)

    # 各horizonの累積残差 -> 累積変位(位置変換前の物理量)
    residual = out * mh_std[None, :, :] + mh_mean[None, :, :]             # [B,H,2]
    h_idx = np.arange(1, H + 1, dtype=np.float64)[None, :, None]          # [1,H,1]
    cum = h_idx * cv_last[:, None, :] + residual                         # [B,H,2] 累積変位km
    return cum


# ---------------------------------------------------------------------------
# multi-horizon 確率版 MDN(target_mode="cv_residual_mdn")
# 出力 [H,K,5](モードごとに logit(1)+μ(2)+log_b(2))。各horizonで最大重みモードの
# μを採用して復元する。--mdn-fallback THRESH>0 のとき、最大重み w_max<THRESH の
# horizon は純CV(dxy_cum[h]=h*cv_last)へフォールバックする。
# ---------------------------------------------------------------------------
def batched_predict_mdn(model, cfg, group, device, gpu_batch, fallback_thresh=0.0):
    """input_len が揃った航跡群(group)を1回のforwardで MDN 予測する(単一モデル)。

    復元式(mdnスクリプトの val 評価と厳密に一致):
      最終位置の出力 [H,K,5] -> 各horizon h で w=softmax_k(logit) の argmaxモード k* を選び
        residual[h] = μ_{h,k*} * mh_res_std[h] + mh_res_mean[h]
        cum[h]      = h*cv_last + residual[h]              (起点からの累積変位 km)
      fallback_thresh>0 かつ w_max[h] < fallback_thresh のときは、その horizon の
      モデル残差を使わず純CV: cum[h] = h*cv_last(residual=0)にフォールバックする。
      lon_h = lon0 + cumx[h]/km_per_deg_lon(lat0)、lat_h = lat0 + cumy[h]/KM_PER_DEG_LAT
    返り値: pred_lon[i], pred_lat[i](各 [H])。有効ステップは group[i]["steps"]。
    """
    import torch
    max_ctx = int(cfg.max_len)
    cv_n = int(cfg.cv_n_last)
    H = int(getattr(cfg, "horizon", 20))
    K = int(getattr(cfg, "mdn_k", 3))
    fm = np.asarray(cfg.feat_mean, dtype=np.float64)
    fs = np.asarray(cfg.feat_std, dtype=np.float64)
    mh_mean = np.asarray(cfg.mh_res_mean, dtype=np.float64)   # [H,2]
    mh_std = np.asarray(cfg.mh_res_std, dtype=np.float64)     # [H,2]

    B = len(group)
    seq = np.stack([g["disp"] for g in group], axis=0).astype(np.float64)  # [B,P,2]
    P = seq.shape[1]
    ctx = min(P, max_ctx)
    ctx_disp = seq[:, P - ctx:, :]
    x = (ctx_disp - fm) / fs
    cur_lon = np.array([g["lon0"] for g in group], dtype=np.float64)
    cur_lat = np.array([g["lat0"] for g in group], dtype=np.float64)
    cv_last = seq[:, -cv_n:, :].mean(axis=1)                  # [B,2]

    out = np.zeros((B, H * K * 5), dtype=np.float64)
    model.eval()
    with torch.no_grad():
        for s in range(0, B, gpu_batch):
            e = min(B, s + gpu_batch)
            xt = torch.from_numpy(x[s:e].astype(np.float32)).to(device)   # [b, ctx, F]
            pad = torch.zeros(xt.shape[0], ctx, dtype=torch.bool, device=device)
            o = model(xt, pad_mask=pad)[:, -1].cpu().numpy()              # [b, H*K*5]
            out[s:e] = o

    # 各horizonの最大重みモードのμと重みを取り出す。
    p = out.reshape(B, H, K, 5)
    logit = p[..., 0]                                         # [B,H,K]
    mu = p[..., 1:3]                                          # [B,H,K,2]
    mm = logit - logit.max(axis=2, keepdims=True)             # softmax(オーバーフロー回避)
    ex = np.exp(mm)
    w = ex / ex.sum(axis=2, keepdims=True)                    # [B,H,K]
    kbest = np.argmax(w, axis=2)                              # [B,H]
    bi = np.arange(B)[:, None]; hi = np.arange(H)[None, :]
    mu_sel = mu[bi, hi, kbest]                                # [B,H,2]
    w_max = w[bi, hi, kbest]                                  # [B,H]

    residual = mu_sel * mh_std[None, :, :] + mh_mean[None, :, :]          # [B,H,2]
    # フォールバック: w_max<THRESH の horizon は残差0(純CV)にする。
    if fallback_thresh and fallback_thresh > 0.0:
        fb = (w_max < float(fallback_thresh))                # [B,H] True=フォールバック
        residual = np.where(fb[:, :, None], 0.0, residual)   # 純CV(residual=0)

    h_idx = np.arange(1, H + 1, dtype=np.float64)[None, :, None]          # [1,H,1]
    cum = h_idx * cv_last[:, None, :] + residual                         # [B,H,2]
    lon_scale = _km_per_deg_lon_arr(cur_lat)                             # [B]
    out_lon = cur_lon[:, None] + cum[:, :, 0] / lon_scale[:, None]        # [B,H]
    out_lat = cur_lat[:, None] + cum[:, :, 1] / KM_PER_DEG_LAT           # [B,H]
    return out_lon, out_lat


def batched_predict_mh(models, cfgs, group, device, gpu_batch):
    """input_len が揃った航跡群(group)を1回のforwardで multi-horizon 予測する。

    models/cfgs はリスト(単一モデルでも要素1のリスト)。複数モデル時は各モデルの
    「復元後の累積変位 cum [B,H,2](km、物理量)」を平均してから位置に変換する
    (logitや標準化値でなく物理量の平均)。cv_last は履歴のみから決まりモデル非依存。

    group[i] = dict(disp=[P,2](履歴の移動量), lon0, lat0, steps)
    復元式(mhスクリプトの val 評価と厳密に一致):
      各horizon h(1..H) について
        cum[h]  = h*cv_last + residual[h]              (起点からの累積変位 km)
        lon_h = lon0 + cumx[h]/km_per_deg_lon(lat0)
        lat_h = lat0 + cumy[h]/KM_PER_DEG_LAT
    返り値: pred_lon[i], pred_lat[i] (各 [H])。有効ステップは group[i]["steps"]。
    """
    cur_lon = np.array([g["lon0"] for g in group], dtype=np.float64)
    cur_lat = np.array([g["lat0"] for g in group], dtype=np.float64)

    # 各モデルの累積変位を計算し、物理量(km)のまま平均する。
    cums = [_predict_mh_cum(m, c, group, device, gpu_batch) for m, c in zip(models, cfgs)]
    cum = np.mean(np.stack(cums, axis=0), axis=0)                        # [B,H,2] 平均累積変位km

    # 平均後の累積変位 -> lon/lat(位置変換は最後に1回だけ)
    lon_scale = _km_per_deg_lon_arr(cur_lat)                              # [B]
    out_lon = cur_lon[:, None] + cum[:, :, 0] / lon_scale[:, None]        # [B,H]
    out_lat = cur_lat[:, None] + cum[:, :, 1] / KM_PER_DEG_LAT            # [B,H]
    return out_lon, out_lat


# ---------------------------------------------------------------------------
# 評価本体
# ---------------------------------------------------------------------------
def evaluate(args) -> int:
    import torch

    data_dir = Path(args.data_dir)
    files = sorted(data_dir.glob(args.pattern))
    if args.limit_files and args.limit_files > 0:
        files = files[: args.limit_files]
    if not files:
        print(f"[ERROR] 航跡が見つかりません: {data_dir}/{args.pattern}", file=sys.stderr)
        return 2
    print(f"[eval] 対象航跡: {len(files)} 件 <- {data_dir}")

    is_cv = (str(args.model).upper() == "CV")
    # --model はカンマ区切りで複数パスを受け付ける(アンサンブル、mh専用)。
    model_paths = [s.strip() for s in str(args.model).split(",") if s.strip()]
    is_ensemble = (not is_cv) and (len(model_paths) >= 2)
    if is_cv:
        models, cfgs = None, None
        cv_n = int(args.cv_n_last)
        stop_thresh_reg = 0.03
        print("[eval] モデル: CVベースライン(等速外挿)")
    else:
        device = torch.device(args.device if args.device else
                              ("cuda" if torch.cuda.is_available() else "cpu"))
        models, cfgs = [], []
        for mp in model_paths:
            m, c = load_model(Path(mp), device)
            models.append(m); cfgs.append(c)
        cfg = cfgs[0]   # cv_n/stop_thresh/target_mode はモデル間で共通の前提
        # MDN はアンサンブル非対応: 複数指定されたらエラー。
        if is_ensemble:
            mdn_bad = [mp for mp, c in zip(model_paths, cfgs)
                       if getattr(c, "target_mode", "disp") == "cv_residual_mdn"]
            if mdn_bad:
                print(f"[ERROR] MDN(cv_residual_mdn)はアンサンブル非対応です。単一モデルで指定してください。"
                      f"該当: {mdn_bad}", file=sys.stderr)
                return 2
        if is_ensemble:
            # アンサンブルは mh 専用: 全モデルが cv_residual_mh であることを検証。
            bad = [mp for mp, c in zip(model_paths, cfgs)
                   if getattr(c, "target_mode", "disp") != "cv_residual_mh"]
            if bad:
                print(f"[ERROR] アンサンブルは target_mode='cv_residual_mh' のモデル専用です。"
                      f"非対応のモデル: {bad}", file=sys.stderr)
                return 2
            print(f"[eval] アンサンブル: {len(models)} モデル(mh、累積変位kmを平均)")
            for mp in model_paths:
                print(f"        - {mp}")
        for c in cfgs:
            if c.feature_cols:
                print(f"[WARN] cfg.feature_cols が空でない({c.feature_cols})。"
                      f"バッチ版は dx,dy のみ対応のため 1件ずつのフォールバックは未実装。"
                      f"結果が visualize と一致しない可能性あり。", file=sys.stderr)
        cv_n = int(cfg.cv_n_last)
        stop_thresh_reg = float(getattr(cfg, "stop_thresh_km", 0.0) or 0.03)
        print(f"[eval] モデル: {model_paths[0] if not is_ensemble else '(複数)'}"
              f"  target_mode={cfg.target_mode}  stop_gate={args.stop_gate}  device={device}")

    input_len_arg = int(args.input_len)
    steps_arg = int(args.steps)

    # --- 各航跡の準備(input_len/steps を可変で確定、履歴/実測を分離) ---
    items = []   # dict(filename, lon, lat, input_len, steps, hist_lon, hist_lat, truth_lon, truth_lat, disp, regime)
    skipped = 0
    for p in files:
        lon, lat = read_traj(p)
        n = len(lon)
        input_len = min(input_len_arg, n - 1)
        steps = min(steps_arg, n - input_len)
        if input_len < 2 or steps < 1:
            skipped += 1
            continue
        hist_lon, hist_lat = lon[:input_len], lat[:input_len]
        truth_lon = lon[input_len:input_len + steps]
        truth_lat = lat[input_len:input_len + steps]
        disp = lonlat_to_disp_km(hist_lon, hist_lat)   # [input_len, 2]
        regime = classify_regime(truth_lon, truth_lat, hist_lon, hist_lat,
                                 stop_thresh=stop_thresh_reg)
        items.append(dict(
            filename=p.name, input_len=input_len, steps=steps,
            hist_lon=hist_lon, hist_lat=hist_lat,
            truth_lon=truth_lon, truth_lat=truth_lat,
            disp=disp, regime=regime,
        ))
    if skipped:
        print(f"[eval][WARN] 短すぎてスキップ: {skipped} 件")

    # --- AI予測(input_len ごとにグループ化してバッチロールアウト) ---
    pred_map = {}   # filename -> (pred_lon[steps], pred_lat[steps])
    if not is_cv:
        from collections import defaultdict
        groups = defaultdict(list)
        for it in items:
            groups[it["input_len"]].append(it)
        mode0 = getattr(cfg, "target_mode", "disp")
        is_mh = (mode0 == "cv_residual_mh")
        is_mdn = (mode0 == "cv_residual_mdn")
        for ilen, grp in groups.items():
            steps_max = max(g["steps"] for g in grp)
            gin = [dict(disp=g["disp"],
                        lon0=float(g["hist_lon"][-1]), lat0=float(g["hist_lat"][-1]),
                        steps=g["steps"]) for g in grp]
            if is_mdn:
                # MDN(確率版): 1回forward -> 各horizonで最大重みモードのμを採用。
                # --mdn-fallback THRESH で不確実horizonを純CVへフォールバック。単一モデルのみ。
                plon, plat = batched_predict_mdn(models[0], cfgs[0], gin, device,
                                                 int(args.gpu_batch),
                                                 fallback_thresh=float(args.mdn_fallback))
            elif is_mh:
                # multi-horizon: ロールアウト不要。1回のforwardで [H,2] を直接予測。
                # models/cfgs はリスト(単一=要素1、複数=アンサンブル)。
                # 既存の disp / cv_residual / cv_residual_stop 経路は不変。
                plon, plat = batched_predict_mh(models, cfgs, gin, device, int(args.gpu_batch))
            else:
                # 非mh(単一モデルのみ。アンサンブルはmh専用で上で検証済み)。
                plon, plat = batched_rollout_ai(models[0], cfgs[0], gin, steps_max, device,
                                                int(args.gpu_batch), args.stop_gate)
            for i, g in enumerate(grp):
                s = g["steps"]
                pred_map[g["filename"]] = (plon[i, :s], plat[i, :s])

    # --- 行ごとの誤差を計算 ---
    rows = []
    for it in items:
        fn = it["filename"]
        steps = it["steps"]
        hist_lon, hist_lat = it["hist_lon"], it["hist_lat"]
        truth_lon, truth_lat = it["truth_lon"], it["truth_lat"]

        # CV(常に計算: cv_mae 列とスキル比のため)
        cv_lon, cv_lat = rollout_cv_single(hist_lon, hist_lat, steps, cv_n)
        cv_err = haversine_km_arr(cv_lon, cv_lat, truth_lon, truth_lat)

        if is_cv:
            ai_lon, ai_lat = cv_lon, cv_lat
            ai_err = cv_err.copy()
        else:
            ai_lon, ai_lat = pred_map[fn]
            ai_err = haversine_km_arr(ai_lon, ai_lat, truth_lon, truth_lat)

        row = {
            "filename": fn,
            "ai_mae": float(ai_err.mean()),
            "cv_mae": float(cv_err.mean()),
            "steps": int(steps),
            "regime": it["regime"],
        }
        for k in range(20):
            row[f"err_s{k + 1}"] = float(ai_err[k]) if k < steps else np.nan
        rows.append(row)

    df = pd.DataFrame(rows)
    out_csv = Path(args.out_csv)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)
    print(f"[eval] per-trajectory CSV -> {out_csv}")

    # --- サマリ出力 ---
    print_summary(df)
    return 0


def _trim_mean(x: np.ndarray, prop: float = 0.10) -> float:
    """両側 prop を切り落とすトリム平均。"""
    x = np.sort(np.asarray(x, dtype=np.float64))
    n = len(x)
    k = int(math.floor(n * prop))
    if n - 2 * k <= 0:
        return float(np.mean(x))
    return float(np.mean(x[k:n - k]))


def _step_means(df: pd.DataFrame, cols):
    return {c: float(np.nanmean(df[c].to_numpy())) for c in cols}


def print_summary(df: pd.DataFrame):
    ai = df["ai_mae"].to_numpy(dtype=np.float64)
    cv = df["cv_mae"].to_numpy(dtype=np.float64)
    n = len(df)
    print("=" * 66)
    print(f"[summary] N={n}")
    print(f"  AI  mean={ai.mean():.4f}  median={np.median(ai):.4f}  trim10={_trim_mean(ai):.4f}")
    print(f"  CV  mean={cv.mean():.4f}  median={np.median(cv):.4f}  trim10={_trim_mean(cv):.4f}")
    skill = 1.0 - ai.mean() / cv.mean() if cv.mean() > 0 else float("nan")
    print(f"  CVスキル比 (1 - meanAI/meanCV) = {skill:.4f}")
    sm = _step_means(df, ["err_s1", "err_s5", "err_s10", "err_s15", "err_s20"])
    print("  ステップ別平均: " + "  ".join(f"{k}={v:.4f}" for k, v in sm.items()))
    # レジームスライス
    print("  --- レジーム別 ---")
    for reg in ["stop_seg", "turn", "cruise"]:
        sub = df[df["regime"] == reg]
        if len(sub) == 0:
            print(f"    {reg:9s}: N=0")
            continue
        a = sub["ai_mae"].to_numpy(dtype=np.float64)
        c = sub["cv_mae"].to_numpy(dtype=np.float64)
        sk = 1.0 - a.mean() / c.mean() if c.mean() > 0 else float("nan")
        print(f"    {reg:9s}: N={len(sub):4d}  AImean={a.mean():.4f}  "
              f"AImedian={np.median(a):.4f}  CVmean={c.mean():.4f}  skill={sk:.4f}")
    print("=" * 66)


# ---------------------------------------------------------------------------
# compare サブコマンド
# ---------------------------------------------------------------------------
def compare(args) -> int:
    from scipy import stats
    a = pd.read_csv(args.csv_a)
    b = pd.read_csv(args.csv_b)
    merged = pd.merge(a[["filename", "ai_mae"]], b[["filename", "ai_mae"]],
                      on="filename", suffixes=("_a", "_b"))
    n = len(merged)
    if n == 0:
        print("[compare][ERROR] 共通ファイルがありません。", file=sys.stderr)
        return 2
    da = merged["ai_mae_a"].to_numpy(dtype=np.float64)
    db = merged["ai_mae_b"].to_numpy(dtype=np.float64)
    diff = da - db            # A - B (正=Bの方が良い)
    mean_diff = float(diff.mean())
    se = float(diff.std(ddof=1) / math.sqrt(n)) if n > 1 else float("nan")
    tval = mean_diff / se if se and not math.isnan(se) and se > 0 else float("nan")
    # Wilcoxon 符号順位検定(差が全て0だと例外になるので保護)
    try:
        w_stat, w_p = stats.wilcoxon(da, db)
    except Exception as e:
        w_stat, w_p = float("nan"), float("nan")
        print(f"[compare][WARN] wilcoxon 失敗: {e}", file=sys.stderr)

    print("=" * 66)
    print(f"[compare] A={Path(args.csv_a).name}  B={Path(args.csv_b).name}")
    print(f"  共通N={n}")
    print(f"  A mean_ai_mae={da.mean():.4f}   B mean_ai_mae={db.mean():.4f}")
    print(f"  ペア差 (A-B): 平均={mean_diff:+.4f}  SE={se:.4f}  (正=Bが良い)")
    print(f"  t値 = {tval:+.3f}   (自由度 {n - 1})")
    print(f"  Wilcoxon: stat={w_stat:.1f}  p={w_p:.3e}")
    print("=" * 66)
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> int:
    p = argparse.ArgumentParser(description="モデル1つを多数航跡でバッチ評価する。")
    sub = p.add_subparsers(dest="cmd")

    # compare サブコマンド
    pc = sub.add_parser("compare", help="2つの結果CSVで ai_mae のペア差検定")
    pc.add_argument("csv_a")
    pc.add_argument("csv_b")

    # 既定(評価)の引数
    p.add_argument("--model", help="traj_model.pt のパス、または 'CV'(等速ベースライン)")
    p.add_argument("--data-dir", help="航跡CSVのディレクトリ")
    p.add_argument("--pattern", default="*.csv")
    p.add_argument("--out-csv", help="per-trajectory 結果の保存先")
    p.add_argument("--input-len", type=int, default=80)
    p.add_argument("--steps", type=int, default=20)
    p.add_argument("--cv-n-last", type=int, default=6, help="CVベースラインの直近点数")
    p.add_argument("--gpu-batch", type=int, default=256, help="GPUに載せる航跡数(チャンク)")
    p.add_argument("--stop-gate", default="soft", choices=["soft", "hard"])
    p.add_argument("--mdn-fallback", type=float, default=0.0,
                   help="MDN専用: 最大重みモードの重み w_max がこの閾値未満の horizon を"
                        "純CV(residual=0)にフォールバックする。0=無効(既定)。")
    p.add_argument("--limit-files", type=int, default=0)
    p.add_argument("--device", default="")

    args = p.parse_args()
    if args.cmd == "compare":
        return compare(args)
    if not args.model or not args.data_dir or not args.out_csv:
        p.error("評価には --model, --data-dir, --out-csv が必要です。")
    return evaluate(args)


if __name__ == "__main__":
    raise SystemExit(main())
