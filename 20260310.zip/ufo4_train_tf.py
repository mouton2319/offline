#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Train-only script: periodic trig features + LSTM for UFO4 GEO AZ/EL.

Model design:
- Input time is encoded as cyclic sin/cos features from UNIX time.
- Baseline AZ/EL is built by repeating the previous year's same-slot values.
- Baseline AZ/EL is also encoded as sin/cos features.
- The LSTM predicts absolute trig targets:
  [sin(AZ), cos(AZ), sin(EL), cos(EL)].
- An optional learned post-correction model is trained from pseudo-inference
  errors on consecutive-year validation simulations.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np

import ufo4_harmonic_azel_tf as hm
import ufo4_lla_physical_model as lpm
import ufo4_orbit_predict_tf as core
import ufo4_sidereal_coeff_model as scm


@dataclass
class PairRecord:
    prev_year: int
    cur_year: int
    prev_tpl: core.TemplatePack
    unix_cur: np.ndarray
    true_azel: np.ndarray
    repeat_base_cur: np.ndarray
    feat_ext: np.ndarray
    target_trig: np.ndarray
    sample_w: np.ndarray


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train LSTM AZ/EL predictor with cyclic trig features.")
    p.add_argument(
        "--train-files",
        nargs="+",
        default=[f"{y}_calc_az_el.csv" for y in range(2017, 2024)],
        help="Training CSVs (default: 2017..2023).",
    )
    p.add_argument("--output-dir", default="ufo4_azel_model_artifacts")
    p.add_argument("--model-kind", choices=["sidereal_coeff", "lstm_trig4"], default="lstm_trig4")

    p.add_argument("--epochs", type=int, default=80)
    p.add_argument("--fine-tune-epochs", type=int, default=12)
    p.add_argument("--batch-size", type=int, default=512)
    p.add_argument("--learning-rate", type=float, default=2.0e-3)
    p.add_argument("--fine-tune-learning-rate", type=float, default=7.0e-4)
    p.add_argument("--patience", type=int, default=10)
    p.add_argument("--val-days", type=int, default=90)
    p.add_argument("--recent-weight-gamma", type=float, default=2.2)
    p.add_argument("--gradient-clipnorm", type=float, default=1.0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--allow-year-gaps", action="store_true")
    p.add_argument("--auto-extend-train-files", dest="auto_extend_train_files", action="store_true")
    p.add_argument("--no-auto-extend-train-files", dest="auto_extend_train_files", action="store_false")
    p.add_argument("--holdout-latest-available-year", dest="holdout_latest_available_year", action="store_true")
    p.add_argument("--no-holdout-latest-available-year", dest="holdout_latest_available_year", action="store_false")

    p.add_argument("--seq-len", type=int, default=360)
    p.add_argument("--sequence-stride", type=int, default=5)
    p.add_argument("--lstm-units-1", type=int, default=96)
    p.add_argument("--lstm-units-2", type=int, default=48)
    p.add_argument("--dense-units", type=int, default=32)
    p.add_argument("--dropout", type=float, default=0.12)
    p.add_argument("--recurrent-dropout", type=float, default=0.0)
    p.add_argument("--time-yearly-harmonics", type=int, default=3)
    p.add_argument("--loss-mse-weight", type=float, default=0.12)

    p.add_argument("--error-correction-enabled", dest="error_correction_enabled", action="store_true")
    p.add_argument("--no-error-correction", dest="error_correction_enabled", action="store_false")
    p.add_argument("--error-daily-harmonics", type=int, default=12)
    p.add_argument("--error-yearly-harmonics", type=int, default=8)
    p.add_argument("--error-drift-order", type=int, default=2)
    p.add_argument("--error-ridge", type=float, default=1.0e-2)
    p.add_argument("--error-slot-smooth-window", type=int, default=181)
    p.add_argument("--error-recent-gamma", type=float, default=2.0)
    p.add_argument("--error-az-cap", type=float, default=1.00)
    p.add_argument("--error-el-cap", type=float, default=1.00)
    p.add_argument("--year-start-correction-days", type=int, default=45)
    p.add_argument("--year-start-correction-smooth-window", type=int, default=181)
    p.add_argument("--recent-slot-overlay-enabled", dest="recent_slot_overlay_enabled", action="store_true")
    p.add_argument("--no-recent-slot-overlay", dest="recent_slot_overlay_enabled", action="store_false")
    p.add_argument("--recent-slot-overlay-recent-pairs", type=int, default=3)
    p.add_argument("--recent-slot-overlay-smooth-window", type=int, default=1)
    p.add_argument("--recent-slot-overlay-az-cap", type=float, default=1.00)
    p.add_argument("--recent-slot-overlay-el-cap", type=float, default=1.00)
    p.add_argument("--repeat-trend-enabled", dest="repeat_trend_enabled", action="store_true")
    p.add_argument("--no-repeat-trend-correction", dest="repeat_trend_enabled", action="store_false")
    p.add_argument("--repeat-trend-recent-pairs", type=int, default=4)
    p.add_argument("--repeat-trend-max-shift-minutes", type=int, default=12)
    p.add_argument("--repeat-trend-search-sample-step", type=int, default=20)
    p.add_argument("--repeat-trend-smooth-window", type=int, default=181)
    p.add_argument("--repeat-trend-shift-smooth-days", type=int, default=9)
    p.add_argument("--repeat-trend-gain-smooth-days", type=int, default=15)
    p.add_argument("--repeat-trend-recent-gamma", type=float, default=2.0)
    p.add_argument("--repeat-trend-az-cap", type=float, default=1.00)
    p.add_argument("--repeat-trend-el-cap", type=float, default=1.00)
    p.add_argument("--sidereal-ridge", type=float, default=1.0e-3)
    p.add_argument("--sidereal-correction-ridge", type=float, default=5.0e-3)
    p.add_argument("--sidereal-chunk-rows", type=int, default=60000)
    p.add_argument("--lla-physical-enabled", dest="lla_physical_enabled", action="store_true")
    p.add_argument("--no-lla-physical-model", dest="lla_physical_enabled", action="store_false")

    p.add_argument("--observer-lat", type=float, default=36.3022)
    p.add_argument("--observer-lon", type=float, default=137.9031)
    p.add_argument("--observer-alt-m", type=float, default=0.0)
    p.add_argument("--geo-radius-km", type=float, default=42164.0)
    p.add_argument("--sat-name", default="23467")

    p.add_argument("--use-latest-tle-correction", dest="use_latest_tle_correction", action="store_true")
    p.add_argument("--no-latest-tle-correction", dest="use_latest_tle_correction", action="store_false")
    p.add_argument("--latest-tle-dir", default="pred_tle")
    p.add_argument("--tle-correction-start", default="")
    p.add_argument("--tle-priority-days", type=float, default=7.0)
    p.add_argument("--tle-max-weight", type=float, default=1.0)
    p.add_argument("--tle-decay-hours", type=float, default=336.0)
    p.add_argument("--tle-max-hours", type=float, default=0.0)
    p.add_argument("--tle-adapt-epochs", type=int, default=0)
    p.add_argument("--tle-adapt-lr", type=float, default=1.0e-3)
    p.add_argument("--tle-adapt-reg", type=float, default=5.0e-4)
    p.add_argument("--tle-adapt-min-rows", type=int, default=120)

    p.set_defaults(
        use_latest_tle_correction=True,
        error_correction_enabled=True,
        auto_extend_train_files=True,
        holdout_latest_available_year=True,
        recent_slot_overlay_enabled=True,
        repeat_trend_enabled=True,
        lla_physical_enabled=True,
    )
    return p.parse_args()


def _metric_block(err: np.ndarray) -> Dict[str, float]:
    x = np.asarray(err, dtype=np.float64)
    return {
        "mae": float(np.mean(np.abs(x))),
        "rmse": float(np.sqrt(np.mean(np.square(x)))),
        "max_abs_error": float(np.max(np.abs(x))),
        "bias": float(np.mean(x)),
    }


def _compute_azel_metrics(true_azel: np.ndarray, pred_azel: np.ndarray) -> Dict[str, Dict[str, float]]:
    az_err = hm.angle_diff_deg(pred_azel[:, 0], true_azel[:, 0])
    el_err = pred_azel[:, 1] - true_azel[:, 1]
    out = {"AZ": _metric_block(az_err), "EL": _metric_block(el_err)}
    out["overall"] = {
        "mae_mean": float((out["AZ"]["mae"] + out["EL"]["mae"]) * 0.5),
        "rmse_mean": float((out["AZ"]["rmse"] + out["EL"]["rmse"]) * 0.5),
        "max_abs_error_max": float(max(out["AZ"]["max_abs_error"], out["EL"]["max_abs_error"])),
        "bias_mean": float((out["AZ"]["bias"] + out["EL"]["bias"]) * 0.5),
    }
    return out


def _compute_overall_max_p99(true_azel: np.ndarray, pred_azel: np.ndarray) -> Tuple[float, float]:
    az_err = hm.angle_diff_deg(pred_azel[:, 0], true_azel[:, 0])
    el_err = pred_azel[:, 1] - true_azel[:, 1]
    mm = np.maximum(np.abs(az_err), np.abs(el_err))
    if mm.size == 0:
        return 0.0, 0.0
    return float(np.max(mm)), float(np.quantile(mm, 0.99))


def _compute_month_bias(unix: np.ndarray, true_azel: np.ndarray, pred_azel: np.ndarray) -> Dict[str, Dict[str, float]]:
    mon = core.compute_month_from_unix_local(unix)
    out: Dict[str, Dict[str, float]] = {}
    for mm in range(1, 13):
        mask = mon == mm
        if not np.any(mask):
            continue
        az_err = hm.angle_diff_deg(pred_azel[mask, 0], true_azel[mask, 0])
        el_err = pred_azel[mask, 1] - true_azel[mask, 1]
        out[f"{mm:02d}"] = {
            "az_bias": float(np.mean(az_err)),
            "el_bias": float(np.mean(el_err)),
            "rows": int(np.sum(mask)),
        }
    return out


def _circular_smooth_deg(values_deg: np.ndarray, window: int) -> np.ndarray:
    v = np.asarray(values_deg, dtype=np.float64).reshape(-1)
    w = int(max(1, window))
    if v.size == 0 or w <= 1:
        return v.copy()
    if w % 2 == 0:
        w += 1
    pad = w // 2
    rad = np.deg2rad(v)
    ss = np.sin(rad)
    cc = np.cos(rad)
    kernel = np.ones((w,), dtype=np.float64) / float(w)
    ss_ext = np.concatenate([ss[-pad:], ss, ss[:pad]])
    cc_ext = np.concatenate([cc[-pad:], cc, cc[:pad]])
    ss_sm = np.convolve(ss_ext, kernel, mode="valid")
    cc_sm = np.convolve(cc_ext, kernel, mode="valid")
    return ((np.rad2deg(np.arctan2(ss_sm, cc_sm)) + 180.0) % 360.0) - 180.0


def _linear_smooth(values: np.ndarray, window: int) -> np.ndarray:
    v = np.asarray(values, dtype=np.float64).reshape(-1)
    w = int(max(1, window))
    if v.size == 0 or w <= 1:
        return v.copy()
    if w % 2 == 0:
        w += 1
    pad = w // 2
    kernel = np.ones((w,), dtype=np.float64) / float(w)
    ext = np.concatenate([v[-pad:], v, v[:pad]])
    return np.convolve(ext, kernel, mode="valid")


def _save_template_pack(path: Path, tpl: core.TemplatePack, reference_year: int) -> None:
    tpl_filled = _fill_template_missing_slots_local(tpl)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        reference_year=np.asarray([int(reference_year)], dtype=np.int32),
        template_mode=np.asarray([str(getattr(tpl_filled, "mode", "sidereal_phase"))], dtype="<U32"),
        slot_az_deg=np.asarray(tpl_filled.slot_az_deg, dtype=np.float32),
        slot_el_deg=np.asarray(tpl_filled.slot_el_deg, dtype=np.float32),
        slot_weight=np.asarray(tpl_filled.slot_weight, dtype=np.float32),
        minute_az_deg=np.asarray(tpl_filled.minute_az_deg, dtype=np.float32),
        minute_el_deg=np.asarray(tpl_filled.minute_el_deg, dtype=np.float32),
        minute_weight=np.asarray(tpl_filled.minute_weight, dtype=np.float32),
    )


def _fill_template_missing_slots_local(tpl: core.TemplatePack) -> core.TemplatePack:
    slot_w = np.asarray(tpl.slot_weight, dtype=np.float64).reshape(-1)
    valid = slot_w > 0.0
    if slot_w.size == 0 or np.all(valid):
        return tpl
    valid_idx = np.flatnonzero(valid)
    if valid_idx.size == 0:
        return tpl
    all_idx = np.arange(slot_w.shape[0], dtype=np.int32)
    right_pos = np.searchsorted(valid_idx, all_idx, side="left")
    right_pos = np.clip(right_pos, 0, valid_idx.size - 1)
    left_pos = np.clip(right_pos - 1, 0, valid_idx.size - 1)
    left_idx = valid_idx[left_pos]
    right_idx = valid_idx[right_pos]
    choose_right = np.abs(right_idx - all_idx) < np.abs(all_idx - left_idx)
    nearest_idx = np.where(choose_right, right_idx, left_idx).astype(np.int32)

    slot_az = np.asarray(tpl.slot_az_deg, dtype=np.float64).copy()
    slot_el = np.asarray(tpl.slot_el_deg, dtype=np.float64).copy()
    slot_w_filled = slot_w.copy()
    miss = ~valid
    slot_az[miss] = slot_az[nearest_idx[miss]]
    slot_el[miss] = slot_el[nearest_idx[miss]]
    slot_w_filled[miss] = np.maximum(slot_w[nearest_idx[miss]], 1.0e-6)
    return core.TemplatePack(
        slot_az_deg=slot_az,
        slot_el_deg=slot_el,
        slot_weight=slot_w_filled,
        minute_az_deg=np.asarray(tpl.minute_az_deg, dtype=np.float64).copy(),
        minute_el_deg=np.asarray(tpl.minute_el_deg, dtype=np.float64).copy(),
        minute_weight=np.asarray(tpl.minute_weight, dtype=np.float64).copy(),
    )


def _compute_year_from_unix_local(unix: np.ndarray) -> np.ndarray:
    sec_local = np.asarray(np.round(unix), dtype=np.int64) + int(core.JST_OFFSET_SEC)
    dt_y = sec_local.astype("datetime64[s]").astype("datetime64[Y]")
    return (dt_y.astype(np.int64) + 1970).astype(np.int32)


def _compute_common_day_index(unix: np.ndarray) -> np.ndarray:
    return (core.compute_slot_index(np.asarray(unix, dtype=np.float64)) // int(core.MINUTES_PER_DAY)).astype(np.int32)


def _compute_common_week_index(unix: np.ndarray) -> np.ndarray:
    return (_compute_common_day_index(unix) // 7).astype(np.int32)


def _compute_common_month_index_from_day(day_idx: np.ndarray) -> np.ndarray:
    dd = np.asarray(day_idx, dtype=np.int32).reshape(-1)
    out = np.zeros_like(dd, dtype=np.int32)
    month_lengths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    start = 0
    for mm, ml in enumerate(month_lengths, start=1):
        end = start + int(ml)
        mask = (dd >= start) & (dd < end)
        out[mask] = int(mm)
        start = end
    return out


def _apply_segment_blend_gain(
    key_idx: np.ndarray,
    pred_repeat: np.ndarray | None,
    pred_corr: np.ndarray,
    gain_map: Dict[str, float] | None,
) -> np.ndarray:
    if pred_repeat is None or not gain_map:
        return np.asarray(pred_corr, dtype=np.float64).copy()
    key = np.asarray(key_idx, dtype=np.int32).reshape(-1)
    rep = np.asarray(pred_repeat, dtype=np.float64)
    cor = np.asarray(pred_corr, dtype=np.float64)
    out = cor.copy()
    for kk in sorted(set(int(v) for v in np.unique(key))):
        mask = key == kk
        if not np.any(mask):
            continue
        gain = float(gain_map.get(f"{kk:02d}", 0.0))
        gain = float(np.clip(gain, 0.0, 1.0))
        if gain >= 0.999:
            continue
        if gain <= 0.0:
            out[mask] = rep[mask]
            continue
        d_az = hm.angle_diff_deg(cor[mask, 0], rep[mask, 0])
        d_el = cor[mask, 1] - rep[mask, 1]
        out[mask, 0] = core.wrap360(rep[mask, 0] + gain * d_az)
        out[mask, 1] = np.clip(rep[mask, 1] + gain * d_el, -90.0, 90.0)
    return out


def _shift_unix_within_day(unix: np.ndarray, shift_minutes: int) -> np.ndarray:
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    if u.size == 0 or int(shift_minutes) == 0:
        return u.copy()
    return (u + float(int(shift_minutes) * 60)).astype(np.float64)


def _lookup_template_with_row_shifts(unix: np.ndarray, tpl: core.TemplatePack, shift_by_row: np.ndarray) -> np.ndarray:
    u = np.asarray(unix, dtype=np.float64).reshape(-1)
    shifts = np.asarray(shift_by_row, dtype=np.int32).reshape(-1)
    if u.shape[0] != shifts.shape[0]:
        raise ValueError("unix/shift length mismatch")
    shifted = u.copy()
    for sh in np.unique(shifts):
        mask = shifts == int(sh)
        if not np.any(mask):
            continue
        shifted[mask] = _shift_unix_within_day(u[mask], int(sh))
    pred, _ = core.lookup_template_azel(shifted, tpl)
    return np.asarray(pred, dtype=np.float64)


def _fill_slot_series_from_minute(values: np.ndarray, valid_mask: np.ndarray) -> np.ndarray:
    out = np.asarray(values, dtype=np.float64).reshape(-1).copy()
    valid = np.asarray(valid_mask, dtype=bool).reshape(-1)
    if out.size == 0:
        return out
    if np.all(valid):
        return out
    minute_idx = np.arange(out.shape[0], dtype=np.int32) % int(core.MINUTES_PER_DAY)
    minute_sum = np.zeros((core.MINUTES_PER_DAY,), dtype=np.float64)
    minute_w = np.zeros((core.MINUTES_PER_DAY,), dtype=np.float64)
    np.add.at(minute_sum, minute_idx[valid], out[valid])
    np.add.at(minute_w, minute_idx[valid], 1.0)
    minute_mean = np.zeros((core.MINUTES_PER_DAY,), dtype=np.float64)
    mv = minute_w > 0.0
    minute_mean[mv] = minute_sum[mv] / minute_w[mv]
    fallback = float(np.mean(out[valid])) if np.any(valid) else 0.0
    minute_mean[~mv] = fallback
    miss = ~valid
    out[miss] = minute_mean[minute_idx[miss]]
    return out


def _fit_weighted_linear_coefficients(
    y: np.ndarray,
    x: np.ndarray,
    weight: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    yy = np.asarray(y, dtype=np.float64)
    one_dim = yy.ndim == 1
    if one_dim:
        yy = yy.reshape(-1, 1)
    xx = np.asarray(x, dtype=np.float64).reshape(-1, 1)
    ww = np.asarray(weight, dtype=np.float64).reshape(-1, 1)
    if yy.shape[0] != xx.shape[0] or yy.shape[0] != ww.shape[0]:
        raise ValueError("linear-fit length mismatch")
    sw = float(np.sum(ww))
    if yy.shape[0] <= 1 or sw <= 0.0:
        intercept = np.mean(yy, axis=0)
        slope = np.zeros_like(intercept)
    else:
        sx = float(np.sum(ww * xx))
        sxx = float(np.sum(ww * xx * xx))
        sy = np.sum(yy * ww, axis=0)
        sxy = np.sum(yy * ww * xx, axis=0)
        denom = sw * sxx - sx * sx
        if abs(float(denom)) < 1.0e-12:
            intercept = sy / max(sw, 1.0e-12)
            slope = np.zeros_like(intercept)
        else:
            slope = (sw * sxy - sx * sy) / denom
            intercept = (sy - slope * sx) / sw
    if one_dim:
        return intercept.reshape(-1)[:1], slope.reshape(-1)[:1]
    return intercept.reshape(-1), slope.reshape(-1)


def _search_daily_phase_shifts(
    rec: PairRecord,
    max_shift_minutes: int,
    sample_step: int,
) -> np.ndarray:
    day_idx = _compute_common_day_index(rec.unix_cur)
    out = np.zeros((core.COMMON_DAYS_PER_YEAR,), dtype=np.int32)
    for dd in range(core.COMMON_DAYS_PER_YEAR):
        idx = np.flatnonzero(day_idx == dd)
        if idx.size == 0:
            out[dd] = 0
            continue
        stride = max(1, int(sample_step))
        idx = idx[::stride]
        best_shift = 0
        best_score = float("inf")
        ww = np.asarray(rec.sample_w[idx], dtype=np.float64).reshape(-1)
        ww = np.where(np.isfinite(ww), ww, 0.0)
        if float(np.sum(ww)) <= 0.0:
            ww = np.ones_like(ww, dtype=np.float64)
        for sh in range(-abs(int(max_shift_minutes)), abs(int(max_shift_minutes)) + 1):
            pred = _lookup_template_with_row_shifts(
                unix=rec.unix_cur[idx],
                tpl=rec.prev_tpl,
                shift_by_row=np.full((idx.shape[0],), int(sh), dtype=np.int32),
            )
            da = np.abs(hm.angle_diff_deg(pred[:, 0], rec.true_azel[idx, 0]))
            de = np.abs(pred[:, 1] - rec.true_azel[idx, 1])
            score = float(np.sum(ww * (0.5 * (da + de))) / max(np.sum(ww), 1.0e-9))
            if score < best_score:
                best_score = score
                best_shift = int(sh)
        out[dd] = int(best_shift)
    return out


def _predict_repeat_trend_components_for_record(
    rec: PairRecord,
    pack: Dict[str, np.ndarray | float | dict],
) -> Tuple[np.ndarray, np.ndarray]:
    year_center = float(pack["year_center"])
    max_shift_minutes = int(pack["max_shift_minutes"])
    az_cap = float(pack["az_cap"])
    el_cap = float(pack["el_cap"])

    mon = core.compute_month_from_unix_local(rec.unix_cur)
    day_idx = _compute_common_day_index(rec.unix_cur)
    yy = _compute_year_from_unix_local(rec.unix_cur).astype(np.float64)
    shift_row = np.zeros((rec.unix_cur.shape[0],), dtype=np.int32)
    if ("day_shift_intercept" in pack) and ("day_shift_slope" in pack):
        shift_base = np.asarray(pack["day_shift_intercept"], dtype=np.float64)[day_idx]
        shift_drift = np.asarray(pack["day_shift_slope"], dtype=np.float64)[day_idx] * (yy - year_center)
        raw = shift_base + shift_drift
        shift_row = np.clip(np.rint(raw), -abs(max_shift_minutes), abs(max_shift_minutes)).astype(np.int32)
    else:
        month_shift_intercept = np.asarray(pack["month_shift_intercept"], dtype=np.float64).reshape(-1)
        month_shift_slope = np.asarray(pack["month_shift_slope"], dtype=np.float64).reshape(-1)
        for mm in range(1, 13):
            mask = mon == mm
            if not np.any(mask):
                continue
            raw = month_shift_intercept[mm - 1] + month_shift_slope[mm - 1] * (yy[mask] - year_center)
            shift_row[mask] = np.clip(np.rint(raw), -abs(max_shift_minutes), abs(max_shift_minutes)).astype(np.int32)

    base = _lookup_template_with_row_shifts(rec.unix_cur, rec.prev_tpl, shift_row)
    slot_idx = core.compute_slot_index(rec.unix_cur)
    da = np.asarray(pack["slot_az_intercept"], dtype=np.float64)[slot_idx]
    da = da + np.asarray(pack["slot_az_slope"], dtype=np.float64)[slot_idx] * (yy - year_center)
    de = np.asarray(pack["slot_el_intercept"], dtype=np.float64)[slot_idx]
    de = de + np.asarray(pack["slot_el_slope"], dtype=np.float64)[slot_idx] * (yy - year_center)
    da = np.clip(da, -abs(az_cap), abs(az_cap))
    de = np.clip(de, -abs(el_cap), abs(el_cap))

    out = base.copy()
    out[:, 0] = core.wrap360(out[:, 0] + da)
    out[:, 1] = np.clip(out[:, 1] + de, -90.0, 90.0)
    return base, out


def _predict_repeat_trend_for_record(rec: PairRecord, pack: Dict[str, np.ndarray | float | dict]) -> np.ndarray:
    base, out = _predict_repeat_trend_components_for_record(rec, pack)
    day_gain = pack.get("day_gain", None)
    week_gain_map = pack.get("week_gain_map", {}) or {}
    month_gain_map = pack.get("month_gain_map", {}) or {}
    if day_gain is not None:
        key_idx = _compute_common_day_index(rec.unix_cur)
        gain_map = {f"{ii:02d}": float(day_gain[ii]) for ii in range(len(day_gain))}
    else:
        if week_gain_map:
            key_idx = _compute_common_week_index(rec.unix_cur)
        else:
            key_idx = core.compute_month_from_unix_local(rec.unix_cur)
        gain_map = week_gain_map if week_gain_map else month_gain_map
    if gain_map:
        blend = out.copy()
        for kk in sorted(set(int(v) for v in np.unique(key_idx))):
            mask = key_idx == kk
            if not np.any(mask):
                continue
            g = float(gain_map.get(f"{int(kk):02d}", 1.0))
            g = max(0.0, min(1.0, g))
            if g >= 0.999:
                continue
            if g <= 0.0:
                blend[mask] = base[mask]
                continue
            d_az = hm.angle_diff_deg(out[mask, 0], base[mask, 0])
            d_el = out[mask, 1] - base[mask, 1]
            blend[mask, 0] = core.wrap360(base[mask, 0] + g * d_az)
            blend[mask, 1] = np.clip(base[mask, 1] + g * d_el, -90.0, 90.0)
        out = blend
    return out


def _fit_repeat_trend_pack_from_records(
    records: List[PairRecord],
    recent_pairs: int,
    max_shift_minutes: int,
    search_sample_step: int,
    smooth_window: int,
    shift_smooth_days: int,
    recent_gamma: float,
    az_cap: float,
    el_cap: float,
) -> Dict[str, np.ndarray | float | dict] | None:
    if not records:
        return None
    recs = sorted(records, key=lambda r: int(r.cur_year))
    recs = recs[-max(1, int(recent_pairs)) :]
    years = np.asarray([float(rec.cur_year) for rec in recs], dtype=np.float64)
    year_center = float(np.mean(years))
    xx = years - year_center
    if years.shape[0] <= 1:
        ww = np.ones_like(years, dtype=np.float64)
    else:
        pos = (years - float(np.min(years))) / max(float(np.max(years) - np.min(years)), 1.0)
        ww = np.exp(float(recent_gamma) * pos)

    day_shift_mat = np.zeros((len(recs), core.COMMON_DAYS_PER_YEAR), dtype=np.float64)
    res_az_mat = np.zeros((len(recs), core.SLOTS_PER_YEAR), dtype=np.float64)
    res_el_mat = np.zeros((len(recs), core.SLOTS_PER_YEAR), dtype=np.float64)

    for i, rec in enumerate(recs):
        day_shift = _search_daily_phase_shifts(
            rec=rec,
            max_shift_minutes=int(max_shift_minutes),
            sample_step=int(search_sample_step),
        )
        if int(shift_smooth_days) > 1:
            day_shift = np.rint(_linear_smooth(day_shift.astype(np.float64), int(shift_smooth_days))).astype(np.int32)
            day_shift = np.clip(day_shift, -abs(int(max_shift_minutes)), abs(int(max_shift_minutes)))
        shift_row = np.zeros((rec.unix_cur.shape[0],), dtype=np.int32)
        day_idx = _compute_common_day_index(rec.unix_cur)
        shift_row = np.asarray(day_shift[day_idx], dtype=np.int32)
        day_shift_mat[i, :] = day_shift.astype(np.float64)

        pred = _lookup_template_with_row_shifts(rec.unix_cur, rec.prev_tpl, shift_row)
        slot_idx = core.compute_slot_index(rec.unix_cur)
        row_w = np.asarray(rec.sample_w, dtype=np.float64).reshape(-1)
        if float(np.sum(row_w)) <= 0.0:
            row_w = np.ones_like(row_w, dtype=np.float64)

        az_res = np.clip(hm.angle_diff_deg(rec.true_azel[:, 0], pred[:, 0]), -abs(float(az_cap)), abs(float(az_cap)))
        el_res = np.clip(rec.true_azel[:, 1] - pred[:, 1], -abs(float(el_cap)), abs(float(el_cap)))

        slot_az_sum = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
        slot_el_sum = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
        slot_w = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
        np.add.at(slot_az_sum, slot_idx, row_w * az_res)
        np.add.at(slot_el_sum, slot_idx, row_w * el_res)
        np.add.at(slot_w, slot_idx, row_w)

        valid = slot_w > 0.0
        full_az = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
        full_el = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
        full_az[valid] = slot_az_sum[valid] / slot_w[valid]
        full_el[valid] = slot_el_sum[valid] / slot_w[valid]
        full_az = _fill_slot_series_from_minute(full_az, valid)
        full_el = _fill_slot_series_from_minute(full_el, valid)
        full_az = np.clip(_linear_smooth(full_az, int(smooth_window)), -abs(float(az_cap)), abs(float(az_cap)))
        full_el = np.clip(_linear_smooth(full_el, int(smooth_window)), -abs(float(el_cap)), abs(float(el_cap)))
        res_az_mat[i] = full_az
        res_el_mat[i] = full_el

    shift_intercept, shift_slope = _fit_weighted_linear_coefficients(day_shift_mat, xx, ww)
    az_intercept, az_slope = _fit_weighted_linear_coefficients(res_az_mat, xx, ww)
    el_intercept, el_slope = _fit_weighted_linear_coefficients(res_el_mat, xx, ww)
    shift_intercept = _linear_smooth(shift_intercept, int(shift_smooth_days))
    shift_slope = _linear_smooth(shift_slope, int(shift_smooth_days))
    az_intercept = np.clip(_linear_smooth(az_intercept, int(smooth_window)), -abs(float(az_cap)), abs(float(az_cap)))
    az_slope = _linear_smooth(az_slope, int(smooth_window))
    el_intercept = np.clip(_linear_smooth(el_intercept, int(smooth_window)), -abs(float(el_cap)), abs(float(el_cap)))
    el_slope = _linear_smooth(el_slope, int(smooth_window))

    return {
        "year_center": float(year_center),
        "max_shift_minutes": int(max_shift_minutes),
        "az_cap": float(az_cap),
        "el_cap": float(el_cap),
        "day_shift_intercept": np.asarray(shift_intercept, dtype=np.float32),
        "day_shift_slope": np.asarray(shift_slope, dtype=np.float32),
        "slot_az_intercept": np.asarray(az_intercept, dtype=np.float32),
        "slot_az_slope": np.asarray(az_slope, dtype=np.float32),
        "slot_el_intercept": np.asarray(el_intercept, dtype=np.float32),
        "slot_el_slope": np.asarray(el_slope, dtype=np.float32),
        "month_gain_map": {},
        "recent_pairs_used": int(len(recs)),
    }


def _train_repeat_trend_correction(
    records: List[PairRecord],
    recent_pairs: int,
    max_shift_minutes: int,
    search_sample_step: int,
    smooth_window: int,
    shift_smooth_days: int,
    gain_smooth_days: int,
    recent_gamma: float,
    az_cap: float,
    el_cap: float,
) -> Dict[str, np.ndarray | float | dict] | None:
    pack = _fit_repeat_trend_pack_from_records(
        records=records,
        recent_pairs=int(recent_pairs),
        max_shift_minutes=int(max_shift_minutes),
        search_sample_step=int(search_sample_step),
        smooth_window=int(smooth_window),
        shift_smooth_days=int(shift_smooth_days),
        recent_gamma=float(recent_gamma),
        az_cap=float(az_cap),
        el_cap=float(el_cap),
    )
    if pack is None:
        return None

    recs = sorted(records, key=lambda r: int(r.cur_year))
    rep_sum = np.zeros((core.COMMON_DAYS_PER_YEAR,), dtype=np.float64)
    cor_sum = np.zeros((core.COMMON_DAYS_PER_YEAR,), dtype=np.float64)
    weight_sum = np.zeros((core.COMMON_DAYS_PER_YEAR,), dtype=np.float64)
    if len(recs) >= 3:
        for end_idx in range(2, len(recs)):
            hist = recs[max(0, end_idx - max(1, int(recent_pairs))) : end_idx]
            eval_rec = recs[end_idx]
            sub_pack = _fit_repeat_trend_pack_from_records(
                records=hist,
                recent_pairs=int(recent_pairs),
                max_shift_minutes=int(max_shift_minutes),
                search_sample_step=int(search_sample_step),
                smooth_window=int(smooth_window),
                shift_smooth_days=int(shift_smooth_days),
                recent_gamma=float(recent_gamma),
                az_cap=float(az_cap),
                el_cap=float(el_cap),
            )
            if sub_pack is None:
                continue
            pred_shift, pred_corr = _predict_repeat_trend_components_for_record(eval_rec, sub_pack)
            rep_az = np.abs(hm.angle_diff_deg(pred_shift[:, 0], eval_rec.true_azel[:, 0]))
            rep_el = np.abs(pred_shift[:, 1] - eval_rec.true_azel[:, 1])
            cor_az = np.abs(hm.angle_diff_deg(pred_corr[:, 0], eval_rec.true_azel[:, 0]))
            cor_el = np.abs(pred_corr[:, 1] - eval_rec.true_azel[:, 1])
            rep_err = 0.5 * (rep_az + rep_el)
            cor_err = 0.5 * (cor_az + cor_el)
            ww = np.asarray(eval_rec.sample_w, dtype=np.float64).reshape(-1)
            if float(np.sum(ww)) <= 0.0:
                ww = np.ones_like(ww, dtype=np.float64)
            day_idx = _compute_common_day_index(eval_rec.unix_cur)
            for dd in range(core.COMMON_DAYS_PER_YEAR):
                mask = day_idx == dd
                if not np.any(mask):
                    continue
                rep_sum[dd] += float(np.sum(ww[mask] * rep_err[mask]))
                cor_sum[dd] += float(np.sum(ww[mask] * cor_err[mask]))
                weight_sum[dd] += float(np.sum(ww[mask]))

    day_gain = np.ones((core.COMMON_DAYS_PER_YEAR,), dtype=np.float64)
    for dd in range(core.COMMON_DAYS_PER_YEAR):
        if weight_sum[dd] <= 0.0:
            day_gain[dd] = 1.0
            continue
        rep_mae = rep_sum[dd] / max(weight_sum[dd], 1.0e-9)
        cor_mae = cor_sum[dd] / max(weight_sum[dd], 1.0e-9)
        if cor_mae >= rep_mae:
            day_gain[dd] = 0.0
        else:
            day_gain[dd] = float(max(0.0, min(1.0, (rep_mae - cor_mae) / max(rep_mae, 1.0e-9))))
    if int(gain_smooth_days) > 1:
        day_gain = np.clip(_linear_smooth(day_gain, int(gain_smooth_days)), 0.0, 1.0)
    pack["day_gain"] = np.asarray(day_gain, dtype=np.float32)

    week_gain_map: Dict[str, float] = {}
    for kk in range(53):
        lo = 7 * kk
        hi = min(7 * (kk + 1), core.COMMON_DAYS_PER_YEAR)
        if lo >= hi:
            break
        week_gain_map[f"{kk:02d}"] = float(np.mean(day_gain[lo:hi]))
    month_gain_map: Dict[str, float] = {}
    month_idx = _compute_common_month_index_from_day(np.arange(core.COMMON_DAYS_PER_YEAR, dtype=np.int32))
    for mm in range(1, 13):
        mask = month_idx == mm
        if not np.any(mask):
            month_gain_map[f"{mm:02d}"] = 1.0
            continue
        month_gain_map[f"{mm:02d}"] = float(np.mean(day_gain[mask]))
    pack["week_gain_map"] = week_gain_map
    pack["month_gain_map"] = month_gain_map
    return pack


def _discover_year_csvs(search_dir: Path) -> Dict[int, Path]:
    out: Dict[int, Path] = {}
    for p in sorted(search_dir.glob("*_calc_az_el.csv")):
        try:
            yy = int(core.parse_year_from_path(p))
        except Exception:
            continue
        out[int(yy)] = p
    return out


def _resolve_train_files(raw_paths: List[str], auto_extend: bool, holdout_latest_available_year: bool) -> List[Path]:
    train_files = [Path(x) for x in raw_paths]
    for p in train_files:
        if not p.exists():
            raise FileNotFoundError(f"Training file not found: {p}")

    years_to_path: Dict[int, Path] = {}
    for p in train_files:
        years_to_path[int(core.parse_year_from_path(p))] = p
    if not years_to_path:
        raise RuntimeError("No training files were provided.")

    if bool(auto_extend):
        base_dir = train_files[0].parent if all(p.parent == train_files[0].parent for p in train_files) else Path(".")
        discovered = _discover_year_csvs(base_dir)
        latest = max(years_to_path)
        max_discovered = max(discovered) if discovered else latest
        extend_limit = int(max_discovered - 1) if bool(holdout_latest_available_year) else int(max_discovered)
        added: List[int] = []
        next_year = latest + 1
        while next_year in discovered and next_year <= extend_limit:
            years_to_path[int(next_year)] = discovered[int(next_year)]
            added.append(int(next_year))
            next_year += 1
        if added:
            core.log(
                "Auto-extended --train-files with newer local yearly CSVs: "
                + ", ".join(str(v) for v in added)
            )

    return [years_to_path[yy] for yy in sorted(years_to_path)]


def _build_year_data(train_files: List[Path]) -> Dict[int, Tuple[np.ndarray, np.ndarray]]:
    out: Dict[int, Tuple[np.ndarray, np.ndarray]] = {}
    for p in train_files:
        year = int(core.parse_year_from_path(p))
        out[year] = core.load_orbit_numeric_azel(p)
    return out


def _build_year_data_full(train_files: List[Path]) -> Dict[int, Tuple[np.ndarray, np.ndarray, np.ndarray]]:
    out: Dict[int, Tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
    for p in train_files:
        year = int(core.parse_year_from_path(p))
        unix, full = core.load_orbit_numeric_full(p)
        out[year] = (
            np.asarray(unix, dtype=np.float64),
            np.asarray(full[:, 3:5], dtype=np.float64),
            np.asarray(full[:, 0:3], dtype=np.float64),
        )
    return out


def _build_pair_record(
    year_data: Dict[int, Tuple[np.ndarray, np.ndarray]],
    weight_by_year: Dict[int, np.ndarray],
    prev_year: int,
    cur_year: int,
    lcfg: hm.LSTMConfig,
) -> PairRecord:
    unix_prev, azel_prev = year_data[prev_year]
    unix_cur, azel_cur = year_data[cur_year]
    tpl_prev = core.build_azel_template(
        unix=unix_prev,
        azel=azel_prev,
        weight=np.ones((len(unix_prev),), dtype=np.float32),
    )
    tpl_prev = _fill_template_missing_slots_local(tpl_prev)

    prefix_len = max(0, int(lcfg.seq_len) - 1)
    if prefix_len > 0:
        prefix_unix = np.asarray(unix_prev[-prefix_len:], dtype=np.float64)
    else:
        prefix_unix = np.zeros((0,), dtype=np.float64)
    ext_unix = np.concatenate([prefix_unix, unix_cur.astype(np.float64)], axis=0)
    ext_base, ext_slot_w = core.lookup_template_azel(ext_unix, tpl_prev)
    feat_ext = hm.build_lstm_step_features_np(
        unix=ext_unix,
        base_azel=ext_base,
        slot_weight=ext_slot_w,
        yearly_harmonics=int(lcfg.time_yearly_harmonics),
    )
    repeat_base_cur = np.asarray(ext_base[-unix_cur.shape[0] :], dtype=np.float64)

    target_trig = hm.normalize_trig4_np(hm.azel_to_trig4(azel_cur))
    sample_w = np.asarray(weight_by_year[cur_year], dtype=np.float32).reshape(-1)
    if sample_w.shape[0] != unix_cur.shape[0]:
        raise RuntimeError(f"Weight length mismatch for year={cur_year}: {sample_w.shape[0]} vs {unix_cur.shape[0]}")

    return PairRecord(
        prev_year=int(prev_year),
        cur_year=int(cur_year),
        prev_tpl=tpl_prev,
        unix_cur=np.asarray(unix_cur, dtype=np.float64),
        true_azel=np.asarray(azel_cur, dtype=np.float64),
        repeat_base_cur=repeat_base_cur,
        feat_ext=np.asarray(feat_ext, dtype=np.float32),
        target_trig=np.asarray(target_trig, dtype=np.float32),
        sample_w=np.asarray(sample_w, dtype=np.float32),
    )


def _slice_pair_arrays(record: PairRecord, start_idx: int, end_idx: int, seq_len: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    start = int(max(0, start_idx))
    end = int(min(end_idx, record.target_trig.shape[0]))
    if end <= start:
        return (
            np.zeros((0, int(seq_len), record.feat_ext.shape[1]), dtype=np.float32),
            np.zeros((0, 4), dtype=np.float32),
            np.zeros((0,), dtype=np.float32),
        )
    feat = record.feat_ext[start : end + int(seq_len) - 1]
    target = record.target_trig[start:end]
    weight = record.sample_w[start:end]
    return feat, target, weight


def _make_seq_dataset(
    tf,
    feat_ext: np.ndarray,
    target_trig: np.ndarray,
    sample_w: np.ndarray,
    seq_len: int,
    stride: int,
    batch_size: int,
    shuffle: bool,
    seed: int,
):
    n_targets = int(target_trig.shape[0])
    if n_targets <= 0:
        return None, 0

    feat_t = tf.constant(np.asarray(feat_ext, dtype=np.float32))
    target_t = tf.constant(np.asarray(target_trig, dtype=np.float32))
    weight_t = tf.constant(np.asarray(sample_w, dtype=np.float32).reshape(-1))
    starts = np.arange(0, n_targets, max(1, int(stride)), dtype=np.int32)
    ds = tf.data.Dataset.from_tensor_slices(starts)
    if shuffle:
        ds = ds.shuffle(buffer_size=min(len(starts), 100_000), seed=int(seed), reshuffle_each_iteration=True)

    seq_len_tf = int(seq_len)

    def _mapper(i):
        x = feat_t[i : i + seq_len_tf]
        y = target_t[i]
        w = weight_t[i]
        return x, y, w

    ds = ds.map(_mapper, num_parallel_calls=tf.data.AUTOTUNE)
    ds = ds.batch(int(batch_size), drop_remainder=False)
    ds = ds.prefetch(tf.data.AUTOTUNE)
    return ds, int(len(starts))


def _concat_datasets(datasets):
    bag = [ds for ds in datasets if ds is not None]
    if not bag:
        return None
    out = bag[0]
    for ds in bag[1:]:
        out = out.concatenate(ds)
    return out


def _make_periodic_trig_loss(tf, mse_weight: float):
    mse_w = tf.constant(float(mse_weight), dtype=tf.float32)

    def loss_fn(y_true, y_pred):
        yp = hm.normalize_trig4_tf(y_pred)
        az_dot = tf.reduce_sum(yp[:, 0:2] * y_true[:, 0:2], axis=1)
        el_dot = tf.reduce_sum(yp[:, 2:4] * y_true[:, 2:4], axis=1)
        az_loss = 1.0 - tf.clip_by_value(az_dot, -1.0, 1.0)
        el_loss = 1.0 - tf.clip_by_value(el_dot, -1.0, 1.0)
        mse = tf.reduce_mean(tf.square(yp - y_true), axis=1)
        return az_loss + el_loss + mse_w * mse

    return loss_fn


def _make_trig_mse_metric(tf):
    def metric_fn(y_true, y_pred):
        yp = hm.normalize_trig4_tf(y_pred)
        return tf.reduce_mean(tf.square(yp - y_true), axis=1)

    return metric_fn


def _build_lstm_model(tf, seq_len: int, feat_dim: int, lcfg: hm.LSTMConfig):
    inp = tf.keras.Input(shape=(int(seq_len), int(feat_dim)), dtype=tf.float32, name="seq")
    x = tf.keras.layers.LayerNormalization(name="ln_in")(inp)
    x = tf.keras.layers.LSTM(
        int(lcfg.lstm_units_1),
        return_sequences=bool(int(lcfg.lstm_units_2) > 0),
        dropout=float(lcfg.dropout),
        recurrent_dropout=float(lcfg.recurrent_dropout),
        name="lstm_1",
    )(x)
    if int(lcfg.lstm_units_2) > 0:
        x = tf.keras.layers.LSTM(
            int(lcfg.lstm_units_2),
            return_sequences=False,
            dropout=float(lcfg.dropout),
            recurrent_dropout=float(lcfg.recurrent_dropout),
            name="lstm_2",
        )(x)
    if int(lcfg.dense_units) > 0:
        x = tf.keras.layers.Dense(int(lcfg.dense_units), activation="swish", name="dense_1")(x)
        if float(lcfg.dropout) > 0.0:
            x = tf.keras.layers.Dropout(min(0.3, float(lcfg.dropout)), name="dropout_1")(x)
    out = tf.keras.layers.Dense(4, activation="tanh", name="trig4_raw")(x)
    return tf.keras.Model(inputs=inp, outputs=out, name="ufo4_lstm_trig4_model")


def _predict_trig4_windows(tf, model, feat_ext: np.ndarray, n_targets: int, seq_len: int, batch_size: int, verbose: int) -> np.ndarray:
    if int(n_targets) <= 0:
        return np.zeros((0, 4), dtype=np.float32)
    ds = tf.keras.utils.timeseries_dataset_from_array(
        data=np.asarray(feat_ext, dtype=np.float32),
        targets=None,
        sequence_length=int(seq_len),
        sequence_stride=1,
        shuffle=False,
        batch_size=int(batch_size),
    )
    pred_raw = model.predict(ds, verbose=int(verbose))
    pred_raw = np.asarray(pred_raw, dtype=np.float32)
    if pred_raw.shape[0] != int(n_targets):
        pred_raw = pred_raw[: int(n_targets)]
    return hm.normalize_trig4_np(pred_raw)


def _baseline_prediction_for_record(
    rec: PairRecord,
    repeat_trend_pack: Dict[str, np.ndarray | float | dict] | None,
) -> np.ndarray:
    if repeat_trend_pack is None:
        return np.asarray(rec.repeat_base_cur, dtype=np.float64)
    return _predict_repeat_trend_for_record(rec, repeat_trend_pack)


def _train_error_correction(
    tf,
    model,
    records: List[PairRecord],
    seq_len: int,
    batch_size: int,
    anchor_unix: float,
    cfg: hm.ErrorCorrectionConfig,
    ridge: float,
    slot_smooth_window: int,
    recent_gamma: float,
    az_cap: float,
    el_cap: float,
    repeat_trend_pack: Dict[str, np.ndarray | float | dict] | None,
) -> Dict[str, np.ndarray | float]:
    if not records:
        raise RuntimeError("No consecutive-year records are available for error correction.")

    years = sorted({int(rec.cur_year) for rec in records})
    y_min = min(years)
    y_max = max(years)

    n_slots = core.SLOTS_PER_YEAR
    slot_sin = np.zeros((n_slots,), dtype=np.float64)
    slot_cos = np.zeros((n_slots,), dtype=np.float64)
    slot_el_sum = np.zeros((n_slots,), dtype=np.float64)
    slot_w = np.zeros((n_slots,), dtype=np.float64)

    d = hm.error_feature_dim(cfg)
    xtx = np.zeros((d, d), dtype=np.float64)
    xty_az = np.zeros((d,), dtype=np.float64)
    xty_el = np.zeros((d,), dtype=np.float64)
    pair_years: List[Tuple[int, int]] = []

    pred_cache: Dict[int, np.ndarray] = {}
    for rec in records:
        pred_azel = _baseline_prediction_for_record(rec, repeat_trend_pack)
        pred_cache[rec.cur_year] = pred_azel
        pair_years.append((int(rec.prev_year), int(rec.cur_year)))

        az_res = hm.angle_diff_deg(rec.true_azel[:, 0], pred_azel[:, 0])
        el_res = rec.true_azel[:, 1] - pred_azel[:, 1]

        if y_max > y_min:
            pos = (float(rec.cur_year) - float(y_min)) / float(y_max - y_min)
            wy = float(math.exp(float(recent_gamma) * pos))
        else:
            wy = 1.0

        slot_idx = core.compute_slot_index(rec.unix_cur)
        az_rad = np.deg2rad(az_res)
        np.add.at(slot_sin, slot_idx, wy * np.sin(az_rad))
        np.add.at(slot_cos, slot_idx, wy * np.cos(az_rad))
        np.add.at(slot_el_sum, slot_idx, wy * el_res)
        np.add.at(slot_w, slot_idx, wy)

    slot_az_bias = np.zeros((n_slots,), dtype=np.float64)
    slot_el_bias = np.zeros((n_slots,), dtype=np.float64)
    valid = slot_w > 0.0
    slot_az_bias[valid] = ((np.rad2deg(np.arctan2(slot_sin[valid], slot_cos[valid])) + 180.0) % 360.0) - 180.0
    slot_el_bias[valid] = slot_el_sum[valid] / slot_w[valid]
    slot_az_bias = _circular_smooth_deg(slot_az_bias, int(slot_smooth_window))
    slot_el_bias = _linear_smooth(slot_el_bias, int(slot_smooth_window))

    for rec in records:
        pred_azel = pred_cache[rec.cur_year]
        slot_idx = core.compute_slot_index(rec.unix_cur)
        base_az = core.wrap360(pred_azel[:, 0] + slot_az_bias[slot_idx])
        base_el = pred_azel[:, 1] + slot_el_bias[slot_idx]
        az_res2 = hm.angle_diff_deg(rec.true_azel[:, 0], base_az)
        el_res2 = rec.true_azel[:, 1] - base_el
        az_res2 = np.clip(az_res2, -abs(float(az_cap)), abs(float(az_cap)))
        el_res2 = np.clip(el_res2, -abs(float(el_cap)), abs(float(el_cap)))

        if y_max > y_min:
            pos = (float(rec.cur_year) - float(y_min)) / float(y_max - y_min)
            wy = float(math.exp(float(recent_gamma) * pos))
        else:
            wy = 1.0
        ww = np.full((len(rec.unix_cur),), wy, dtype=np.float64)

        x = hm.build_error_features_np(
            rec.unix_cur,
            anchor_unix=anchor_unix,
            cfg=cfg,
            base_azel=np.column_stack([base_az, base_el]),
        )
        xw = x * ww.reshape(-1, 1)
        xtx += x.T @ xw
        xty_az += x.T @ (ww * az_res2)
        xty_el += x.T @ (ww * el_res2)

    reg = np.eye(d, dtype=np.float64) * float(ridge)
    beta_az = np.linalg.solve(xtx + reg, xty_az)
    beta_el = np.linalg.solve(xtx + reg, xty_el)

    return {
        "slot_az_bias_deg": slot_az_bias.astype(np.float32),
        "slot_el_bias_deg": slot_el_bias.astype(np.float32),
        "slot_weight": slot_w.astype(np.float32),
        "beta_az": beta_az.astype(np.float32),
        "beta_el": beta_el.astype(np.float32),
        "pair_years": np.asarray(pair_years, dtype=np.int32),
    }


def _train_year_start_correction(
    tf,
    model,
    records: List[PairRecord],
    seq_len: int,
    batch_size: int,
    recent_gamma: float,
    window_days: int,
    smooth_window: int,
    az_cap: float,
    el_cap: float,
    repeat_trend_pack: Dict[str, np.ndarray | float | dict] | None,
) -> Dict[str, np.ndarray | int]:
    horizon = max(0, int(window_days) * core.MINUTES_PER_DAY)
    if horizon <= 0:
        return {
            "days": int(window_days),
            "slot_az_bias_deg": np.zeros((0,), dtype=np.float32),
            "slot_el_bias_deg": np.zeros((0,), dtype=np.float32),
            "weight": np.zeros((0,), dtype=np.float32),
        }

    years = sorted({int(rec.cur_year) for rec in records})
    y_min = min(years)
    y_max = max(years)
    az_sin = np.zeros((horizon,), dtype=np.float64)
    az_cos = np.zeros((horizon,), dtype=np.float64)
    el_sum = np.zeros((horizon,), dtype=np.float64)
    ww = np.zeros((horizon,), dtype=np.float64)

    for rec in records:
        pred_azel = _baseline_prediction_for_record(rec, repeat_trend_pack)
        n = min(int(horizon), int(rec.unix_cur.shape[0]))
        if n <= 0:
            continue
        if y_max > y_min:
            pos = (float(rec.cur_year) - float(y_min)) / float(y_max - y_min)
            wy = float(math.exp(float(recent_gamma) * pos))
        else:
            wy = 1.0
        da = hm.angle_diff_deg(rec.true_azel[:n, 0], pred_azel[:n, 0])
        de = rec.true_azel[:n, 1] - pred_azel[:n, 1]
        da = np.clip(da, -abs(float(az_cap)), abs(float(az_cap)))
        de = np.clip(de, -abs(float(el_cap)), abs(float(el_cap)))
        az_rad = np.deg2rad(da)
        az_sin[:n] += wy * np.sin(az_rad)
        az_cos[:n] += wy * np.cos(az_rad)
        el_sum[:n] += wy * de
        ww[:n] += wy

    az_bias = np.zeros((horizon,), dtype=np.float64)
    el_bias = np.zeros((horizon,), dtype=np.float64)
    valid = ww > 0.0
    az_bias[valid] = ((np.rad2deg(np.arctan2(az_sin[valid], az_cos[valid])) + 180.0) % 360.0) - 180.0
    el_bias[valid] = el_sum[valid] / ww[valid]
    az_bias = _circular_smooth_deg(az_bias, int(smooth_window))
    el_bias = _linear_smooth(el_bias, int(smooth_window))
    az_bias = np.clip(az_bias, -abs(float(az_cap)), abs(float(az_cap)))
    el_bias = np.clip(el_bias, -abs(float(el_cap)), abs(float(el_cap)))

    return {
        "days": int(window_days),
        "slot_az_bias_deg": az_bias.astype(np.float32),
        "slot_el_bias_deg": el_bias.astype(np.float32),
        "weight": ww.astype(np.float32),
    }


def _apply_year_start_correction_local(unix: np.ndarray, pred_azel: np.ndarray, pack: Dict[str, np.ndarray | int]) -> np.ndarray:
    horizon = int(max(0, int(pack.get("days", 0)))) * core.MINUTES_PER_DAY
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if horizon <= 0:
        return out
    slot_idx = core.compute_slot_index(unix)
    use = slot_idx < horizon
    if np.any(use):
        saz = np.asarray(pack["slot_az_bias_deg"], dtype=np.float64)
        sel = np.asarray(pack["slot_el_bias_deg"], dtype=np.float64)
        out[use, 0] = core.wrap360(out[use, 0] + saz[slot_idx[use]])
        out[use, 1] = np.clip(out[use, 1] + sel[slot_idx[use]], -90.0, 90.0)
    return out


def _apply_learned_error_correction_local(
    unix: np.ndarray,
    pred_azel: np.ndarray,
    anchor_unix: float,
    corr_pack: Dict[str, np.ndarray | float],
    cfg: hm.ErrorCorrectionConfig,
    az_cap: float,
    el_cap: float,
) -> np.ndarray:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    slot_idx = core.compute_slot_index(unix)
    out[:, 0] = core.wrap360(out[:, 0] + np.asarray(corr_pack["slot_az_bias_deg"], dtype=np.float64)[slot_idx])
    out[:, 1] = out[:, 1] + np.asarray(corr_pack["slot_el_bias_deg"], dtype=np.float64)[slot_idx]

    x = hm.build_error_features_np(
        unix=np.asarray(unix, dtype=np.float64),
        anchor_unix=float(anchor_unix),
        cfg=cfg,
        base_azel=out,
    )
    da = x @ np.asarray(corr_pack["beta_az"], dtype=np.float64).reshape(-1)
    de = x @ np.asarray(corr_pack["beta_el"], dtype=np.float64).reshape(-1)
    da = np.clip(da, -abs(float(az_cap)), abs(float(az_cap)))
    de = np.clip(de, -abs(float(el_cap)), abs(float(el_cap)))
    out[:, 0] = core.wrap360(out[:, 0] + da)
    out[:, 1] = np.clip(out[:, 1] + de, -90.0, 90.0)
    return out


def _apply_month_blend_gain_local(
    unix: np.ndarray,
    pred_repeat: np.ndarray | None,
    pred_corr: np.ndarray,
    gain_map: Dict[str, float] | None,
) -> np.ndarray:
    mon = core.compute_month_from_unix_local(unix)
    return _apply_segment_blend_gain(mon, pred_repeat, pred_corr, gain_map)


def _build_recent_slot_overlay_from_records(
    records: List[PairRecord],
    recent_pairs: int,
    smooth_window: int,
    az_cap: float,
    el_cap: float,
) -> Dict[str, np.ndarray] | None:
    recs = sorted(records, key=lambda r: int(r.cur_year))
    recs = recs[-max(1, int(recent_pairs)) :]
    if not recs:
        return None

    slot_sin = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
    slot_cos = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
    slot_el_sum = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
    slot_w = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)

    weight_seq = np.arange(1, len(recs) + 1, dtype=np.float64)
    for rec, ww_year in zip(recs, weight_seq):
        slot_idx = core.compute_slot_index(rec.unix_cur)
        az_res = hm.angle_diff_deg(rec.true_azel[:, 0], rec.repeat_base_cur[:, 0])
        el_res = rec.true_azel[:, 1] - rec.repeat_base_cur[:, 1]
        row_w = np.full((rec.unix_cur.shape[0],), float(ww_year), dtype=np.float64)
        az_rad = np.deg2rad(az_res)
        np.add.at(slot_sin, slot_idx, row_w * np.sin(az_rad))
        np.add.at(slot_cos, slot_idx, row_w * np.cos(az_rad))
        np.add.at(slot_el_sum, slot_idx, row_w * el_res)
        np.add.at(slot_w, slot_idx, row_w)

    slot_az = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
    slot_el = np.zeros((core.SLOTS_PER_YEAR,), dtype=np.float64)
    valid = slot_w > 0.0
    slot_az[valid] = ((np.rad2deg(np.arctan2(slot_sin[valid], slot_cos[valid])) + 180.0) % 360.0) - 180.0
    slot_el[valid] = slot_el_sum[valid] / slot_w[valid]
    slot_az = _circular_smooth_deg(slot_az, int(smooth_window))
    slot_el = _linear_smooth(slot_el, int(smooth_window))
    slot_az = np.clip(slot_az, -abs(float(az_cap)), abs(float(az_cap)))
    slot_el = np.clip(slot_el, -abs(float(el_cap)), abs(float(el_cap)))
    return {
        "slot_az_bias_deg": slot_az.astype(np.float32),
        "slot_el_bias_deg": slot_el.astype(np.float32),
        "slot_weight": slot_w.astype(np.float32),
    }


def _apply_recent_slot_overlay_local(
    unix: np.ndarray,
    pred_azel: np.ndarray,
    pack: Dict[str, np.ndarray | float] | None,
    alpha: float,
) -> np.ndarray:
    out = np.asarray(pred_azel, dtype=np.float64).copy()
    if (pack is None) or float(alpha) <= 0.0:
        return out
    slot_idx = core.compute_slot_index(unix)
    saz = np.asarray(pack["slot_az_bias_deg"], dtype=np.float64)
    sel = np.asarray(pack["slot_el_bias_deg"], dtype=np.float64)
    out[:, 0] = core.wrap360(out[:, 0] + float(alpha) * saz[slot_idx])
    out[:, 1] = np.clip(out[:, 1] + float(alpha) * sel[slot_idx], -90.0, 90.0)
    return out


def _train_recent_slot_overlay(
    records: List[PairRecord],
    year_start_pack: Dict[str, np.ndarray | int],
    corr_pack: Dict[str, np.ndarray | float] | None,
    month_blend_gain: Dict[str, float],
    anchor_unix: float,
    ecfg: hm.ErrorCorrectionConfig,
    recent_pairs: int,
    smooth_window: int,
    az_cap: float,
    el_cap: float,
    repeat_trend_pack: Dict[str, np.ndarray | float | dict] | None,
) -> Dict[str, np.ndarray | float | int] | None:
    recs = sorted(records, key=lambda r: int(r.cur_year))
    recs = recs[-max(2, int(recent_pairs)) :]
    if len(recs) < 2:
        return None

    pre_pred_cache: Dict[int, np.ndarray] = {}
    for rec in recs:
        pred_base = _baseline_prediction_for_record(rec, repeat_trend_pack)
        pred_cur = _apply_year_start_correction_local(rec.unix_cur, pred_base, year_start_pack)
        if corr_pack is not None:
            pred_cur = _apply_learned_error_correction_local(
                unix=rec.unix_cur,
                pred_azel=pred_cur,
                anchor_unix=anchor_unix,
                corr_pack=corr_pack,
                cfg=ecfg,
                az_cap=float(corr_pack.get("az_cap", az_cap)),
                el_cap=float(corr_pack.get("el_cap", el_cap)),
            )
        if month_blend_gain:
            pred_cur = _apply_month_blend_gain_local(
                unix=rec.unix_cur,
                pred_repeat=pred_base,
                pred_corr=pred_cur,
                gain_map=month_blend_gain,
            )
        pre_pred_cache[int(rec.cur_year)] = pred_cur

    alpha_grid = [0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35]
    best_alpha = 0.0
    best_score = float("inf")
    for alpha in alpha_grid:
        score_sum = 0.0
        valid_count = 0
        for hold_idx, rec in enumerate(recs):
            hist = [x for i, x in enumerate(recs) if i != hold_idx]
            pack_hold = _build_recent_slot_overlay_from_records(
                records=hist,
                recent_pairs=int(recent_pairs),
                smooth_window=int(smooth_window),
                az_cap=float(az_cap),
                el_cap=float(el_cap),
            )
            if pack_hold is None:
                continue
            pred_adj = _apply_recent_slot_overlay_local(
                unix=rec.unix_cur,
                pred_azel=pre_pred_cache[int(rec.cur_year)],
                pack=pack_hold,
                alpha=float(alpha),
            )
            overall = _compute_azel_metrics(rec.true_azel, pred_adj)["overall"]
            max_abs, p99 = _compute_overall_max_p99(rec.true_azel, pred_adj)
            score = float(max_abs + 0.35 * p99 + 0.10 * overall["mae_mean"])
            score_sum += score
            valid_count += 1
        if valid_count <= 0:
            continue
        score_mean = score_sum / float(valid_count)
        if score_mean < best_score:
            best_score = score_mean
            best_alpha = float(alpha)

    pack_final = _build_recent_slot_overlay_from_records(
        records=recs,
        recent_pairs=int(recent_pairs),
        smooth_window=int(smooth_window),
        az_cap=float(az_cap),
        el_cap=float(el_cap),
    )
    if pack_final is None:
        return None
    out: Dict[str, np.ndarray | float | int] = {
        "recent_pairs": int(recent_pairs),
        "smooth_window": int(smooth_window),
        "az_cap": float(az_cap),
        "el_cap": float(el_cap),
        "alpha": float(best_alpha),
        "slot_az_bias_deg": np.asarray(pack_final["slot_az_bias_deg"], dtype=np.float32),
        "slot_el_bias_deg": np.asarray(pack_final["slot_el_bias_deg"], dtype=np.float32),
        "slot_weight": np.asarray(pack_final["slot_weight"], dtype=np.float32),
    }
    return out


def _train_month_blend_gain_map(
    tf,
    model,
    records: List[PairRecord],
    seq_len: int,
    batch_size: int,
    anchor_unix: float,
    ecfg: hm.ErrorCorrectionConfig,
    corr_pack: Dict[str, np.ndarray | float] | None,
    year_start_pack: Dict[str, np.ndarray | int],
    recent_gamma: float,
    az_cap: float,
    el_cap: float,
    repeat_trend_pack: Dict[str, np.ndarray | float | dict] | None,
) -> Dict[str, float]:
    years = sorted({int(rec.cur_year) for rec in records})
    y_min = min(years)
    y_max = max(years)
    rep_sum = {mm: 0.0 for mm in range(1, 13)}
    cor_sum = {mm: 0.0 for mm in range(1, 13)}
    weight_sum = {mm: 0.0 for mm in range(1, 13)}

    for rec in records:
        pred_corr = _baseline_prediction_for_record(rec, repeat_trend_pack)
        pred_corr = _apply_year_start_correction_local(rec.unix_cur, pred_corr, year_start_pack)
        if corr_pack is not None:
            pred_corr = _apply_learned_error_correction_local(
                unix=rec.unix_cur,
                pred_azel=pred_corr,
                anchor_unix=anchor_unix,
                corr_pack=corr_pack,
                cfg=ecfg,
                az_cap=az_cap,
                el_cap=el_cap,
            )

        if y_max > y_min:
            pos = (float(rec.cur_year) - float(y_min)) / float(y_max - y_min)
            wy = float(math.exp(float(recent_gamma) * pos))
        else:
            wy = 1.0

        mon = core.compute_month_from_unix_local(rec.unix_cur)
        rep_az = np.abs(hm.angle_diff_deg(rec.repeat_base_cur[:, 0], rec.true_azel[:, 0]))
        rep_el = np.abs(rec.repeat_base_cur[:, 1] - rec.true_azel[:, 1])
        cor_az = np.abs(hm.angle_diff_deg(pred_corr[:, 0], rec.true_azel[:, 0]))
        cor_el = np.abs(pred_corr[:, 1] - rec.true_azel[:, 1])
        rep_err = 0.5 * (rep_az + rep_el)
        cor_err = 0.5 * (cor_az + cor_el)

        for mm in range(1, 13):
            mask = mon == mm
            if not np.any(mask):
                continue
            rep_sum[mm] += wy * float(np.sum(rep_err[mask]))
            cor_sum[mm] += wy * float(np.sum(cor_err[mask]))
            weight_sum[mm] += wy * float(np.sum(mask))

    out: Dict[str, float] = {}
    for mm in range(1, 13):
        if weight_sum[mm] <= 0.0:
            out[f"{mm:02d}"] = 0.0
            continue
        rep_mae = rep_sum[mm] / weight_sum[mm]
        cor_mae = cor_sum[mm] / weight_sum[mm]
        gain = max(0.0, min(1.0, (rep_mae - cor_mae) / max(rep_mae, 1.0e-9)))
        out[f"{mm:02d}"] = float(gain)
    return out


def _sidereal_score(metrics: Dict[str, Dict[str, float]]) -> float:
    overall = metrics.get("overall", {})
    return float(
        float(overall.get("max_abs_error_max", 1.0e9))
        + 0.25 * float(overall.get("mae_mean", 0.0))
        + 0.10 * float(overall.get("rmse_mean", 0.0))
    )


def _train_sidereal_coeff_mode(
    args: argparse.Namespace,
    train_files: List[Path],
    train_years: List[int],
    output_dir: Path,
    template_path: Path,
    meta_path: Path,
) -> None:
    core.log("Loading training data...")
    unix_all, azel_all, years_all = core.load_training_data_azel(train_files)
    core.log(f"Total training rows: {len(unix_all)}")

    recency_w = core.build_sample_weights(years_all, gamma=float(args.recent_weight_gamma)).astype(np.float64)
    regime_w = core.build_regime_consistency_weights(
        years=years_all,
        unix=unix_all,
        azel=azel_all,
        reference_recent_years=3,
        az_scale_deg=2.0,
        el_scale_deg=1.6,
        min_weight=0.05,
    ).astype(np.float64)
    core.log_regime_weight_summary(years_all, regime_w)
    sample_w = (recency_w * regime_w).astype(np.float64)
    sample_w = sample_w / max(float(np.mean(sample_w)), 1.0e-9)

    weight_by_year: Dict[int, np.ndarray] = {}
    for yy in train_years:
        mask = years_all == int(yy)
        weight_by_year[int(yy)] = np.asarray(sample_w[mask], dtype=np.float64)

    year_data = _build_year_data(train_files)
    latest_year = max(train_years)
    hist_years = [yy for yy in train_years if yy < latest_year]
    if len(hist_years) < 3:
        raise RuntimeError("sidereal_coeff mode requires at least 4 consecutive years including holdout.")

    year_center = float(np.mean(np.asarray(train_years, dtype=np.float64)))
    year_origin = float(min(train_years))
    base_cfg = scm.cfg_from_dict(
        {
            "ridge": float(args.sidereal_ridge),
            "correction_ridge": float(args.sidereal_correction_ridge),
            "chunk_rows": int(args.sidereal_chunk_rows),
        }
    )
    candidate_cfgs = scm.default_candidate_cfgs(base_cfg)

    core.log("Searching sidereal coefficient configurations on forward holdout...")
    best = None
    val_unix, val_true_azel = year_data[latest_year]
    val_tpl_prev = scm._build_prev_template(*year_data[int(latest_year - 1)])
    for idx, cfg in enumerate(candidate_cfgs, start=1):
        core.log(
            f"[sidereal {idx}/{len(candidate_cfgs)}] "
            f"sidereal_h={cfg.sidereal_harmonics}, yearly_h={cfg.yearly_harmonics}, ridge={cfg.ridge:g}"
        )
        base_model_val = scm.fit_transition_delta_model(
            year_data=year_data,
            train_years=hist_years,
            cfg=cfg,
            weight_by_year=weight_by_year,
            year_center=year_center,
            year_origin=year_origin,
        )
        corr_model_val = scm.fit_transition_correction_model(
            year_data=year_data,
            ordered_years=hist_years,
            cfg=cfg,
            weight_by_year=weight_by_year,
            year_center=year_center,
            year_origin=year_origin,
        )
        pred_base_val, _, base_delta_val = scm.apply_transition_delta_model(
            model=base_model_val,
            tpl_prev=val_tpl_prev,
            unix=val_unix,
            corr_model=None,
            alpha_az=1.0,
            alpha_el=1.0,
        )
        pred_val = pred_base_val.copy()
        base_val = pred_base_val.copy()
        corr_delta_val = np.zeros_like(base_delta_val, dtype=np.float64)
        if corr_model_val is not None:
            pred_val, _, total_delta_val = scm.apply_transition_delta_model(
                model=base_model_val,
                tpl_prev=val_tpl_prev,
                unix=val_unix,
                corr_model=corr_model_val,
                alpha_az=1.0,
                alpha_el=1.0,
            )
            corr_delta_val[:, 0] = total_delta_val[:, 0] - base_delta_val[:, 0]
            corr_delta_val[:, 1] = total_delta_val[:, 1] - base_delta_val[:, 1]
        alpha_az = 1.0
        alpha_el = 1.0
        if corr_model_val is not None:
            alpha_az, alpha_el = scm.tune_correction_alpha(
                true_azel=val_true_azel,
                base_azel=base_val,
                delta_azel=corr_delta_val,
            )
            pred_val, _, _ = scm.apply_transition_delta_model(
                model=base_model_val,
                tpl_prev=val_tpl_prev,
                unix=val_unix,
                corr_model=corr_model_val,
                alpha_az=alpha_az,
                alpha_el=alpha_el,
            )
        metrics = _compute_azel_metrics(val_true_azel, pred_val)
        score = _sidereal_score(metrics)
        core.log(
            "  holdout metrics: "
            f"mae={metrics['overall']['mae_mean']:.6f}, "
            f"rmse={metrics['overall']['rmse_mean']:.6f}, "
            f"max={metrics['overall']['max_abs_error_max']:.6f}, "
            f"alpha=({alpha_az:.3f},{alpha_el:.3f})"
        )
        if best is None or score < best["score"]:
            best = {
                "score": float(score),
                "cfg": cfg,
                "metrics": metrics,
                "alpha_az": float(alpha_az),
                "alpha_el": float(alpha_el),
            }

    if best is None:
        raise RuntimeError("No sidereal coefficient candidate succeeded.")

    best_cfg = best["cfg"]
    core.log(
        "Selected sidereal configuration: "
        f"sidereal_h={best_cfg.sidereal_harmonics}, "
        f"yearly_h={best_cfg.yearly_harmonics}, "
        f"ridge={best_cfg.ridge:g}, "
        f"score={best['score']:.6f}"
    )

    final_model = scm.fit_transition_delta_model(
        year_data=year_data,
        train_years=train_years,
        cfg=best_cfg,
        weight_by_year=weight_by_year,
        year_center=year_center,
        year_origin=year_origin,
    )
    final_corr = scm.fit_transition_correction_model(
        year_data=year_data,
        ordered_years=train_years,
        cfg=best_cfg,
        weight_by_year=weight_by_year,
        year_center=year_center,
        year_origin=year_origin,
    )

    model_path = output_dir / "ufo4_sidereal_coeff_model.npz"
    lla_physical_model_path = output_dir / "ufo4_lla_physical_model.npz"
    save_kwargs = {
        "year_center": np.asarray([float(final_model["year_center"])], dtype=np.float32),
        "year_origin": np.asarray([float(final_model["year_origin"])], dtype=np.float32),
        "gamma_delta": np.asarray(final_model["gamma_delta"], dtype=np.float32),
        "alpha_az": np.asarray([float(best["alpha_az"])], dtype=np.float32),
        "alpha_el": np.asarray([float(best["alpha_el"])], dtype=np.float32),
    }
    if final_corr is not None:
        save_kwargs["beta_corr"] = np.asarray(final_corr["beta_corr"], dtype=np.float32)
        save_kwargs["correction_cap_az"] = np.asarray([float(final_corr["correction_cap_az"])], dtype=np.float32)
        save_kwargs["correction_cap_el"] = np.asarray([float(final_corr["correction_cap_el"])], dtype=np.float32)
        save_kwargs["correction_used_years"] = np.asarray(final_corr["used_years"], dtype=np.int32)
    np.savez_compressed(model_path, **save_kwargs)

    latest_unix, latest_azel = year_data[latest_year]
    latest_tpl = core.build_azel_template(
        unix=latest_unix,
        azel=latest_azel,
        weight=np.ones((len(latest_unix),), dtype=np.float32),
    )
    _save_template_pack(template_path, latest_tpl, reference_year=int(latest_year))

    lla_physical_summary = {"enabled": bool(args.lla_physical_enabled), "trained": False}
    if bool(args.lla_physical_enabled):
        try:
            core.log("Training LLA physical no-TLE model...")
            year_data_full = _build_year_data_full(train_files)
            lla_pack, lla_summary = lpm.fit_and_select_model(
                year_data=year_data_full,
                train_years=train_years,
                observer_lat=float(args.observer_lat),
                observer_lon=float(args.observer_lon),
                observer_alt_m=float(args.observer_alt_m),
            )
            lpm.save_model(lla_physical_model_path, lla_pack)
            lla_physical_summary = {
                "enabled": True,
                "trained": True,
                "path": str(lla_physical_model_path.name),
                **lpm.summary_to_jsonable(lla_summary),
            }
        except Exception as e:
            core.log(f"[WARN] LLA physical model training skipped: {e}")

    meta = {
        "training_mode": "sidereal_transition_delta_with_forward_residual_correction",
        "target_mode": "AZEL_via_sin_cos_pairs",
        "train_files": [str(x) for x in train_files],
        "train_years": [int(core.parse_year_from_path(x)) for x in train_files],
        "anchor_unix": float(np.max(unix_all)),
        "model_path": str(model_path.name),
        "template_path": str(template_path.name),
        "template_reference_year": int(latest_year),
        "sidereal_coeff_config": scm.cfg_to_dict(best_cfg),
        "alpha_calibration": {
            "alpha_az": float(best["alpha_az"]),
            "alpha_el": float(best["alpha_el"]),
        },
        "validation_year": int(latest_year),
        "validation_metrics_azel": best["metrics"],
        "month_bias_azel": {},
        "repeat_trend_correction": {"enabled": False, "trained": False},
        "error_correction": {"enabled": False, "trained": False},
        "year_start_correction": {},
        "month_blend_gain": {},
        "recent_slot_overlay": {"enabled": False, "trained": False},
        "lla_physical_model": lla_physical_summary,
        "observer_lat": float(args.observer_lat),
        "observer_lon": float(args.observer_lon),
        "observer_alt_m": float(args.observer_alt_m),
        "geo_radius_km": float(args.geo_radius_km),
        "sat_name": str(args.sat_name),
        "use_latest_tle_correction": bool(args.use_latest_tle_correction),
        "latest_tle_dir": str(args.latest_tle_dir),
        "tle_correction_start": str(args.tle_correction_start),
        "tle_priority_days": float(args.tle_priority_days),
        "tle_max_weight": float(args.tle_max_weight),
        "tle_decay_hours": float(args.tle_decay_hours),
        "tle_max_hours": float(args.tle_max_hours),
        "tle_adapt_epochs": 0,
        "tle_adapt_lr": float(args.tle_adapt_lr),
        "tle_adapt_reg": float(args.tle_adapt_reg),
        "tle_adapt_min_rows": int(args.tle_adapt_min_rows),
    }
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    core.log(f"Saved sidereal coeff model : {model_path}")
    core.log(f"Saved latest template      : {template_path}")
    if bool(lla_physical_summary.get("trained")):
        core.log(f"Saved LLA physical model   : {lla_physical_model_path}")
    core.log(f"Saved meta                 : {meta_path}")
    core.log("Train-only run complete.")


def main() -> None:
    args = parse_args()
    core.require_tensorflow()
    hm.require_tensorflow()
    tf = core.tf

    np.random.seed(int(args.seed))
    tf.random.set_seed(int(args.seed))

    train_files = _resolve_train_files(
        raw_paths=[str(x) for x in args.train_files],
        auto_extend=bool(args.auto_extend_train_files),
        holdout_latest_available_year=bool(args.holdout_latest_available_year),
    )

    train_years = sorted(int(core.parse_year_from_path(p)) for p in train_files)
    if len(train_years) >= 2:
        gaps = [b - a for a, b in zip(train_years[:-1], train_years[1:])]
        if any(g > 1 for g in gaps) and (not bool(args.allow_year_gaps)):
            raise ValueError(
                "Gap detected in --train-files years. "
                f"years={train_years}. "
                "If intentional, set --allow-year-gaps."
            )
    core.log(f"Training years: {train_years[0]}..{train_years[-1]} (n={len(train_years)})")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    model_path = output_dir / "ufo4_lstm_trig4.keras"
    template_path = output_dir / "ufo4_latest_template.npz"
    repeat_trend_path = output_dir / "ufo4_repeat_trend_correction.npz"
    error_corr_path = output_dir / "ufo4_error_correction.npz"
    year_start_corr_path = output_dir / "ufo4_year_start_correction.npz"
    recent_slot_overlay_path = output_dir / "ufo4_recent_slot_overlay.npz"
    lla_physical_model_path = output_dir / "ufo4_lla_physical_model.npz"
    meta_path = output_dir / "ufo4_azel_model_meta.json"

    if str(args.model_kind).strip() == "sidereal_coeff":
        _train_sidereal_coeff_mode(
            args=args,
            train_files=train_files,
            train_years=train_years,
            output_dir=output_dir,
            template_path=template_path,
            meta_path=meta_path,
        )
        return

    lcfg = hm.lcfg_from_dict(
        {
            "seq_len": int(args.seq_len),
            "sequence_stride": int(args.sequence_stride),
            "lstm_units_1": int(args.lstm_units_1),
            "lstm_units_2": int(args.lstm_units_2),
            "dense_units": int(args.dense_units),
            "dropout": float(args.dropout),
            "recurrent_dropout": float(args.recurrent_dropout),
            "time_yearly_harmonics": int(args.time_yearly_harmonics),
        }
    )
    ecfg = hm.ecfg_from_dict(
        {
            "daily_harmonics": int(args.error_daily_harmonics),
            "yearly_harmonics": int(args.error_yearly_harmonics),
            "drift_order": int(args.error_drift_order),
        }
    )

    core.log("Loading training data...")
    unix_all, azel_all, years_all = core.load_training_data_azel(train_files)
    core.log(f"Total training rows: {len(unix_all)}")
    anchor_unix = float(np.max(unix_all))

    recency_w = core.build_sample_weights(years_all, gamma=float(args.recent_weight_gamma)).astype(np.float64)
    regime_w = core.build_regime_consistency_weights(
        years=years_all,
        unix=unix_all,
        azel=azel_all,
        reference_recent_years=3,
        az_scale_deg=2.0,
        el_scale_deg=1.6,
        min_weight=0.05,
    ).astype(np.float64)
    core.log_regime_weight_summary(years_all, regime_w)
    sample_w = (recency_w * regime_w).astype(np.float64)
    sample_w = (sample_w / np.mean(sample_w)).astype(np.float32)

    train_mask_global, val_mask_global = core.split_train_val(unix_all, years_all, val_days=int(args.val_days))
    core.log(f"Train rows: {int(np.sum(train_mask_global))}, Val rows: {int(np.sum(val_mask_global))}")

    year_data = _build_year_data(train_files)
    weight_by_year: Dict[int, np.ndarray] = {}
    val_mask_by_year: Dict[int, np.ndarray] = {}
    for yy in train_years:
        mask = years_all == int(yy)
        weight_by_year[int(yy)] = np.asarray(sample_w[mask], dtype=np.float32)
        val_mask_by_year[int(yy)] = np.asarray(val_mask_global[mask], dtype=bool)

    pair_years = [(yy - 1, yy) for yy in train_years if (yy - 1) in year_data]
    if not pair_years:
        raise RuntimeError("At least one consecutive-year pair is required for LSTM training.")

    records: List[PairRecord] = []
    for prev_year, cur_year in pair_years:
        rec = _build_pair_record(
            year_data=year_data,
            weight_by_year=weight_by_year,
            prev_year=int(prev_year),
            cur_year=int(cur_year),
            lcfg=lcfg,
        )
        records.append(rec)
        core.log(
            f"Prepared pair {prev_year}->{cur_year}: "
            f"rows={rec.unix_cur.shape[0]}, features={rec.feat_ext.shape[1]}, seq_len={lcfg.seq_len}"
        )

    latest_year = max(train_years)
    train_datasets = []
    val_datasets = []
    train_seq_total = 0
    val_seq_total = 0

    for i, rec in enumerate(records):
        n_cur = int(rec.unix_cur.shape[0])
        if rec.cur_year == latest_year and np.any(val_mask_by_year[latest_year]):
            first_val_idx = int(np.argmax(val_mask_by_year[latest_year]))
        else:
            first_val_idx = n_cur

        feat_train, y_train, w_train = _slice_pair_arrays(rec, 0, first_val_idx, int(lcfg.seq_len))
        ds_train, n_train = _make_seq_dataset(
            tf=tf,
            feat_ext=feat_train,
            target_trig=y_train,
            sample_w=w_train,
            seq_len=int(lcfg.seq_len),
            stride=int(lcfg.sequence_stride),
            batch_size=int(args.batch_size),
            shuffle=True,
            seed=int(args.seed) + i,
        )
        if ds_train is not None:
            train_datasets.append(ds_train)
            train_seq_total += int(n_train)

        if first_val_idx < n_cur:
            feat_val, y_val, w_val = _slice_pair_arrays(rec, first_val_idx, n_cur, int(lcfg.seq_len))
            ds_val, n_val = _make_seq_dataset(
                tf=tf,
                feat_ext=feat_val,
                target_trig=y_val,
                sample_w=w_val,
                seq_len=int(lcfg.seq_len),
                stride=1,
                batch_size=int(args.batch_size),
                shuffle=False,
                seed=int(args.seed) + 1000 + i,
            )
            if ds_val is not None:
                val_datasets.append(ds_val)
                val_seq_total += int(n_val)

    if not train_datasets:
        raise RuntimeError("Training sequence dataset is empty.")
    if not val_datasets:
        raise RuntimeError("Validation sequence dataset is empty.")

    ds_train = _concat_datasets(train_datasets)
    ds_val = _concat_datasets(val_datasets)
    feat_dim = int(records[0].feat_ext.shape[1])
    core.log(f"Sequence feature dimension: {feat_dim}")
    core.log(f"Train sequences: {train_seq_total}, Val sequences: {val_seq_total}")

    model = _build_lstm_model(tf=tf, seq_len=int(lcfg.seq_len), feat_dim=feat_dim, lcfg=lcfg)
    loss_fn = _make_periodic_trig_loss(tf=tf, mse_weight=float(args.loss_mse_weight))
    model.compile(
        optimizer=tf.keras.optimizers.Adam(
            learning_rate=float(args.learning_rate),
            clipnorm=float(args.gradient_clipnorm),
        ),
        loss=loss_fn,
        metrics=[_make_trig_mse_metric(tf=tf)],
    )
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=int(args.patience),
            restore_best_weights=True,
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=max(3, int(args.patience) // 3),
            min_lr=1.0e-6,
        ),
    ]

    core.log("Stage 1 training (cyclic trig features + LSTM with validation)...")
    model.fit(
        ds_train,
        validation_data=ds_val,
        epochs=int(args.epochs),
        verbose=1,
        callbacks=callbacks,
    )

    latest_record = [rec for rec in records if rec.cur_year == latest_year][-1]
    latest_val_mask = val_mask_by_year[latest_year]
    val_start_idx = int(np.argmax(latest_val_mask)) if np.any(latest_val_mask) else int(latest_record.unix_cur.shape[0])
    val_feat, _, _ = _slice_pair_arrays(latest_record, val_start_idx, int(latest_record.unix_cur.shape[0]), int(lcfg.seq_len))
    val_pred_trig = _predict_trig4_windows(
        tf=tf,
        model=model,
        feat_ext=val_feat,
        n_targets=int(latest_record.unix_cur.shape[0]) - val_start_idx,
        seq_len=int(lcfg.seq_len),
        batch_size=int(args.batch_size),
        verbose=1,
    )
    val_pred_azel = hm.trig4_to_azel(val_pred_trig)
    val_true_azel = latest_record.true_azel[val_start_idx:]
    val_unix = latest_record.unix_cur[val_start_idx:]
    val_metrics = _compute_azel_metrics(val_true_azel, val_pred_azel)
    month_bias_map = _compute_month_bias(val_unix, val_true_azel, val_pred_azel)
    if month_bias_map:
        core.log(
            "Saved month bias map for inference: "
            + ", ".join(f"{k}(n={v['rows']})" for k, v in sorted(month_bias_map.items()))
        )

    if int(args.fine_tune_epochs) > 0:
        ds_all = _concat_datasets(
            [
                _make_seq_dataset(
                    tf=tf,
                    feat_ext=rec.feat_ext,
                    target_trig=rec.target_trig,
                    sample_w=rec.sample_w,
                    seq_len=int(lcfg.seq_len),
                    stride=int(lcfg.sequence_stride),
                    batch_size=int(args.batch_size),
                    shuffle=True,
                    seed=int(args.seed) + 10_000 + i,
                )[0]
                for i, rec in enumerate(records)
            ]
        )
        core.log("Stage 2 fine-tuning on all rows...")
        model.compile(
            optimizer=tf.keras.optimizers.Adam(
                learning_rate=float(args.fine_tune_learning_rate),
                clipnorm=float(args.gradient_clipnorm),
            ),
            loss=loss_fn,
            metrics=[_make_trig_mse_metric(tf=tf)],
        )
        model.fit(ds_all, epochs=int(args.fine_tune_epochs), verbose=1)

    model.save(model_path)

    latest_unix, latest_azel = year_data[latest_year]
    latest_tpl = core.build_azel_template(
        unix=latest_unix,
        azel=latest_azel,
        weight=np.ones((len(latest_unix),), dtype=np.float32),
    )
    _save_template_pack(template_path, latest_tpl, reference_year=int(latest_year))

    repeat_trend_pack = None
    repeat_trend_summary = {"enabled": bool(args.repeat_trend_enabled), "trained": False}
    if bool(args.repeat_trend_enabled):
        core.log("Training repeat-trend correction from consecutive-year transitions...")
        repeat_trend_pack = _train_repeat_trend_correction(
            records=records,
            recent_pairs=int(args.repeat_trend_recent_pairs),
            max_shift_minutes=int(args.repeat_trend_max_shift_minutes),
            search_sample_step=int(args.repeat_trend_search_sample_step),
            smooth_window=int(args.repeat_trend_smooth_window),
            shift_smooth_days=int(args.repeat_trend_shift_smooth_days),
            gain_smooth_days=int(args.repeat_trend_gain_smooth_days),
            recent_gamma=float(args.repeat_trend_recent_gamma),
            az_cap=float(args.repeat_trend_az_cap),
            el_cap=float(args.repeat_trend_el_cap),
        )
        if repeat_trend_pack is not None:
            np.savez_compressed(
                repeat_trend_path,
                year_center=np.asarray([float(repeat_trend_pack["year_center"])], dtype=np.float32),
                max_shift_minutes=np.asarray([int(repeat_trend_pack["max_shift_minutes"])], dtype=np.int32),
                az_cap=np.asarray([float(repeat_trend_pack["az_cap"])], dtype=np.float32),
                el_cap=np.asarray([float(repeat_trend_pack["el_cap"])], dtype=np.float32),
                day_shift_intercept=np.asarray(repeat_trend_pack["day_shift_intercept"], dtype=np.float32),
                day_shift_slope=np.asarray(repeat_trend_pack["day_shift_slope"], dtype=np.float32),
                day_gain=np.asarray(repeat_trend_pack["day_gain"], dtype=np.float32),
                slot_az_intercept=np.asarray(repeat_trend_pack["slot_az_intercept"], dtype=np.float32),
                slot_az_slope=np.asarray(repeat_trend_pack["slot_az_slope"], dtype=np.float32),
                slot_el_intercept=np.asarray(repeat_trend_pack["slot_el_intercept"], dtype=np.float32),
                slot_el_slope=np.asarray(repeat_trend_pack["slot_el_slope"], dtype=np.float32),
            )
            repeat_trend_summary = {
                "enabled": True,
                "trained": True,
                "path": str(repeat_trend_path.name),
                "recent_pairs": int(args.repeat_trend_recent_pairs),
                "max_shift_minutes": int(args.repeat_trend_max_shift_minutes),
                "search_sample_step": int(args.repeat_trend_search_sample_step),
                "smooth_window": int(args.repeat_trend_smooth_window),
                "shift_smooth_days": int(args.repeat_trend_shift_smooth_days),
                "gain_smooth_days": int(args.repeat_trend_gain_smooth_days),
                "recent_gamma": float(args.repeat_trend_recent_gamma),
                "az_cap": float(args.repeat_trend_az_cap),
                "el_cap": float(args.repeat_trend_el_cap),
                "week_gain_map": dict(repeat_trend_pack.get("week_gain_map", {}) or {}),
                "month_gain_map": dict(repeat_trend_pack.get("month_gain_map", {}) or {}),
            }
            core.log(
                "Saved repeat-trend gain summary: "
                + ", ".join(f"week-{k}={float(v):.3f}" for k, v in sorted(repeat_trend_summary["week_gain_map"].items())[:10])
            )

    corr_pack = None
    error_corr_summary = {"enabled": bool(args.error_correction_enabled), "trained": False}
    if bool(args.error_correction_enabled):
        core.log("Training learned inference-error correction model...")
        corr_pack = _train_error_correction(
            tf=tf,
            model=model,
            records=records,
            seq_len=int(lcfg.seq_len),
            batch_size=int(args.batch_size),
            anchor_unix=anchor_unix,
            cfg=ecfg,
            ridge=float(args.error_ridge),
            slot_smooth_window=int(args.error_slot_smooth_window),
            recent_gamma=float(args.error_recent_gamma),
            az_cap=float(args.error_az_cap),
            el_cap=float(args.error_el_cap),
            repeat_trend_pack=repeat_trend_pack if bool(repeat_trend_summary.get("trained")) else None,
        )
        np.savez_compressed(
            error_corr_path,
            slot_az_bias_deg=np.asarray(corr_pack["slot_az_bias_deg"], dtype=np.float32),
            slot_el_bias_deg=np.asarray(corr_pack["slot_el_bias_deg"], dtype=np.float32),
            slot_weight=np.asarray(corr_pack["slot_weight"], dtype=np.float32),
            beta_az=np.asarray(corr_pack["beta_az"], dtype=np.float32),
            beta_el=np.asarray(corr_pack["beta_el"], dtype=np.float32),
            pair_years=np.asarray(corr_pack["pair_years"], dtype=np.int32),
        )
        error_corr_summary = {
            "enabled": True,
            "trained": True,
            "path": str(error_corr_path.name),
            "feature_dim": int(hm.error_feature_dim(ecfg)),
            "config": hm.ecfg_to_dict(ecfg),
            "ridge": float(args.error_ridge),
            "slot_smooth_window": int(args.error_slot_smooth_window),
            "recent_gamma": float(args.error_recent_gamma),
            "az_cap": float(args.error_az_cap),
            "el_cap": float(args.error_el_cap),
        }

    core.log("Training year-start correction template...")
    year_start_pack = _train_year_start_correction(
        tf=tf,
        model=model,
        records=records,
        seq_len=int(lcfg.seq_len),
        batch_size=int(args.batch_size),
        recent_gamma=float(args.error_recent_gamma),
        window_days=int(args.year_start_correction_days),
        smooth_window=int(args.year_start_correction_smooth_window),
        az_cap=max(1.0, float(args.error_az_cap)),
        el_cap=max(1.0, float(args.error_el_cap)),
        repeat_trend_pack=repeat_trend_pack if bool(repeat_trend_summary.get("trained")) else None,
    )
    np.savez_compressed(
        year_start_corr_path,
        days=np.asarray([int(year_start_pack["days"])], dtype=np.int32),
        slot_az_bias_deg=np.asarray(year_start_pack["slot_az_bias_deg"], dtype=np.float32),
        slot_el_bias_deg=np.asarray(year_start_pack["slot_el_bias_deg"], dtype=np.float32),
        weight=np.asarray(year_start_pack["weight"], dtype=np.float32),
    )
    year_start_summary = {
        "path": str(year_start_corr_path.name),
        "days": int(year_start_pack["days"]),
        "smooth_window": int(args.year_start_correction_smooth_window),
    }
    month_blend_gain = _train_month_blend_gain_map(
        tf=tf,
        model=model,
        records=records,
        seq_len=int(lcfg.seq_len),
        batch_size=int(args.batch_size),
        anchor_unix=anchor_unix,
        ecfg=ecfg,
        corr_pack=corr_pack if bool(error_corr_summary.get("trained")) else None,
        year_start_pack=year_start_pack,
        recent_gamma=float(args.error_recent_gamma),
        az_cap=float(args.error_az_cap),
        el_cap=float(args.error_el_cap),
        repeat_trend_pack=repeat_trend_pack if bool(repeat_trend_summary.get("trained")) else None,
    )
    core.log(
        "Saved month blend gains: "
        + ", ".join(f"{k}={v:.3f}" for k, v in sorted(month_blend_gain.items()))
    )

    recent_slot_overlay_summary = {"enabled": bool(args.recent_slot_overlay_enabled), "trained": False}
    if bool(args.recent_slot_overlay_enabled):
        core.log("Training recent slot-overlay correction from latest repeat-template residual maps...")
        recent_slot_overlay_pack = _train_recent_slot_overlay(
            records=records,
            year_start_pack=year_start_pack,
            corr_pack=corr_pack if bool(error_corr_summary.get("trained")) else None,
            month_blend_gain=month_blend_gain,
            anchor_unix=anchor_unix,
            ecfg=ecfg,
            recent_pairs=int(args.recent_slot_overlay_recent_pairs),
            smooth_window=int(args.recent_slot_overlay_smooth_window),
            az_cap=float(args.recent_slot_overlay_az_cap),
            el_cap=float(args.recent_slot_overlay_el_cap),
            repeat_trend_pack=repeat_trend_pack if bool(repeat_trend_summary.get("trained")) else None,
        )
        if recent_slot_overlay_pack is not None:
            np.savez_compressed(
                recent_slot_overlay_path,
                recent_pairs=np.asarray([int(recent_slot_overlay_pack["recent_pairs"])], dtype=np.int32),
                smooth_window=np.asarray([int(recent_slot_overlay_pack["smooth_window"])], dtype=np.int32),
                az_cap=np.asarray([float(recent_slot_overlay_pack["az_cap"])], dtype=np.float32),
                el_cap=np.asarray([float(recent_slot_overlay_pack["el_cap"])], dtype=np.float32),
                alpha=np.asarray([float(recent_slot_overlay_pack["alpha"])], dtype=np.float32),
                slot_az_bias_deg=np.asarray(recent_slot_overlay_pack["slot_az_bias_deg"], dtype=np.float32),
                slot_el_bias_deg=np.asarray(recent_slot_overlay_pack["slot_el_bias_deg"], dtype=np.float32),
                slot_weight=np.asarray(recent_slot_overlay_pack["slot_weight"], dtype=np.float32),
            )
            recent_slot_overlay_summary = {
                "enabled": True,
                "trained": True,
                "path": str(recent_slot_overlay_path.name),
                "recent_pairs": int(recent_slot_overlay_pack["recent_pairs"]),
                "smooth_window": int(recent_slot_overlay_pack["smooth_window"]),
                "az_cap": float(recent_slot_overlay_pack["az_cap"]),
                "el_cap": float(recent_slot_overlay_pack["el_cap"]),
                "alpha": float(recent_slot_overlay_pack["alpha"]),
            }
            core.log(
                "Saved recent slot-overlay correction: "
                f"alpha={float(recent_slot_overlay_pack['alpha']):.3f}, "
                f"pairs={int(recent_slot_overlay_pack['recent_pairs'])}, "
                f"smooth={int(recent_slot_overlay_pack['smooth_window'])}"
            )

    lla_physical_summary = {"enabled": bool(args.lla_physical_enabled), "trained": False}
    if bool(args.lla_physical_enabled):
        try:
            core.log("Training LLA physical no-TLE model...")
            year_data_full = _build_year_data_full(train_files)
            lla_pack, lla_summary = lpm.fit_and_select_model(
                year_data=year_data_full,
                train_years=train_years,
                observer_lat=float(args.observer_lat),
                observer_lon=float(args.observer_lon),
                observer_alt_m=float(args.observer_alt_m),
            )
            lpm.save_model(lla_physical_model_path, lla_pack)
            lla_physical_summary = {
                "enabled": True,
                "trained": True,
                "path": str(lla_physical_model_path.name),
                **lpm.summary_to_jsonable(lla_summary),
            }
            hold = lla_summary.get("holdout_metrics_azel", {}).get("overall", {})
            core.log(
                "Saved LLA physical model: "
                f"max={float(hold.get('max_abs_error_max', 0.0)):.6f}, "
                f"p99={float(hold.get('p99_abs_error_max', 0.0)):.6f}, "
                f"mae={float(hold.get('mae_mean', 0.0)):.6f}"
            )
        except Exception as e:
            core.log(f"[WARN] LLA physical model training skipped: {e}")

    val_model_metrics = val_metrics
    meta = {
        "training_mode": "lstm_trig4_repeat_template_plus_repeat_trend_and_learned_error_correction",
        "target_mode": "AZEL_via_sin_cos_pairs",
        "train_files": [str(x) for x in train_files],
        "train_years": [int(core.parse_year_from_path(x)) for x in train_files],
        "anchor_unix": float(anchor_unix),
        "model_path": str(model_path.name),
        "template_path": str(template_path.name),
        "template_reference_year": int(latest_year),
        "lstm_config": hm.lcfg_to_dict(lcfg),
        "sequence_feature_dim": int(feat_dim),
        "month_bias_azel": month_bias_map,
        "validation_metrics_azel": val_model_metrics,
        "repeat_trend_correction": repeat_trend_summary,
        "error_correction": error_corr_summary,
        "year_start_correction": year_start_summary,
        "month_blend_gain": month_blend_gain,
        "recent_slot_overlay": recent_slot_overlay_summary,
        "lla_physical_model": lla_physical_summary,
        "observer_lat": float(args.observer_lat),
        "observer_lon": float(args.observer_lon),
        "observer_alt_m": float(args.observer_alt_m),
        "geo_radius_km": float(args.geo_radius_km),
        "sat_name": str(args.sat_name),
        "use_latest_tle_correction": bool(args.use_latest_tle_correction),
        "latest_tle_dir": str(args.latest_tle_dir),
        "tle_correction_start": str(args.tle_correction_start),
        "tle_priority_days": float(args.tle_priority_days),
        "tle_max_weight": float(args.tle_max_weight),
        "tle_decay_hours": float(args.tle_decay_hours),
        "tle_max_hours": float(args.tle_max_hours),
        "tle_adapt_epochs": int(args.tle_adapt_epochs),
        "tle_adapt_lr": float(args.tle_adapt_lr),
        "tle_adapt_reg": float(args.tle_adapt_reg),
        "tle_adapt_min_rows": int(args.tle_adapt_min_rows),
        "loss_mse_weight": float(args.loss_mse_weight),
    }
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    core.log(f"Saved model               : {model_path}")
    core.log(f"Saved latest template     : {template_path}")
    if bool(repeat_trend_summary.get("trained")):
        core.log(f"Saved repeat-trend corr   : {repeat_trend_path}")
    if bool(error_corr_summary.get("trained")):
        core.log(f"Saved error correction    : {error_corr_path}")
    core.log(f"Saved year-start corr     : {year_start_corr_path}")
    if bool(recent_slot_overlay_summary.get("trained")):
        core.log(f"Saved recent slot overlay : {recent_slot_overlay_path}")
    if bool(lla_physical_summary.get("trained")):
        core.log(f"Saved LLA physical model  : {lla_physical_model_path}")
    core.log(f"Saved meta                : {meta_path}")
    core.log("Train-only run complete.")


if __name__ == "__main__":
    main()
